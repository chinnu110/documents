# jenkins-shared-libraries

Configuring these libraries as **Global Pipeline Libraries**    

Log in to Jenkins instance with Overall Administer rights or contact Jenkins administrator to configure.    

1. Go to **Manage Jenkins** -> **Configure System**    
2. Under **Global Pipeline Libraries** click **Add**    
3. Enter desired name to be referenced by Jenkins pipelines    
4. Set **Source Code Management** to point to this repository    
5. Click **Save** then click **Apply**    
    
   
# Global Vars

These are usable directly in jenkins pipeline without the need for a script block
   
## loadEnvironment

Sets language specific environment variables   

#### language

* elixir
  * sets MIX_ENV based on branch (defaults to dev if no matches are made)
    * develop: dev
	* release/*: qa
	* master: perf
	* v*: prod

```groovy
loadEnvironment(language:'elixir')
```

## s2iImage
    
Creates an environment to interact with s2i Images
Passes instance of Source2Image to body

#### image
    
Name of docker s2i Image
    
#### tag
    
Tag of docker s2i Image
    
#### source_dir
    
Relative path in source code to elixir based

```groovy
s2iImage(image:"hl-s2i-elixir", tag:"latest",source_dir:"app_name") { param ->
	echo param.docker_image
}
```

## s2iAssemble

Runs assemble script inside s2iImage

#### image

Instance of Source2Image passed from s2iImage

#### secret_volumes

List of credentials (type:secret file) to mount as volumes in s2i Image during assemble
Each map requires two keys
* key: credentialsId of secret to mount
* path: path to mount secret to inside of s2i Image

```groovy
s2iImage(image:"hl-s2i-elixir", tag:"latest",source_dir:"app_name") { param ->
	s2iAssemble(image:param, secret_volumes: [[key:"jenkins-secret",path:"/opt/app-root/secret"],[key:"app-secret",path:"/opt/app-root/app/secret"]]
}
```
    
## setEnvVar

Sets environment variable in jenkins pipelines

```groovy
setEnvVar('var1','value1')
```

## linuxServer

Creates an environment to interact with remote servers via ssh (auth via pub-key) using jenkins credentials (type:secret file)
Passes instance of LinuxServer class to body

#### server

FQDN or IP address of remote server

#### secret

credentialsId of secret (type: secret file) that contains ssh private key

#### user

Name of user for authentication to remote server

```groovy
linuxServer(server:'deverlapp01.hobbylobby.corp',secret:'weborder-ssh-key') { param ->
	serverRemoteCommand(server:param,command:hostname)
}
```

## serverRemoteCommand

Execute commands on remote Linux server

#### server

Instance of LinuxServer class passed from linuxServer

#### command

Command to be executed on remote server

```groovy
linuxServer(server:'deverlapp01.hobbylobby.corp',secret:'weborder-ssh-key') { param ->
	serverRemoteCommand(server:param,command:hostname)
}
```
## serverSCP

SCP file from workspace to remote Linux server

#### server

Instance of LinuxServer class passed from linuxServer

#### file

Relative path to file being copied

#### destination

Absolute path to destination on remote Linux server

```groovy
linuxServer(server:'deverlapp01.hobbylobby.corp',secret:'weborder-ssh-key') { param ->
	serverSCP(server:param,file:'file.txt',destination:'/app_data/')
}
```

## deployElixir

Deploy elixir release to remote Linux server

Steps
* SCP release artifact to remote server
* Stop app service on remote server
* Extract artifact on remote server
* Start app service on remote server
* If url is specified run curl loop until output is returned or timeout is reached

#### server

Instance of LinuxServer class passed from linuxServer

#### directory

Directory that contains application

#### service

Name of application service

#### artifact
Optional

Override name of artifact to be copied to server

#### url
Optional

Url to test after starting application service

#### timeout
Optional

Override default timeout for url test

```groovy
linuxServer(server:'deverlapp02.hobbylobby.corp',secret:'weborder-ssh-key') { param ->
	deployElixir(server:param, directory:"/app_data/",url:"http://${param.server}:4000/",service:"elixir_app.service")
}
```
# Source

## corp.hobbylobby.Source2Image

Handles interaction with s2i docker images similar to OpenShift usage

#### Attributes

###### script

`this` from Jenkins pipeline

###### docker_args

List of additional docker args to be passed to s2i image during run

###### docker_image

Docker s2i image

###### app_archive

Name of archive copied to workspace after assemble run

###### source_dir

Relative path to application source in workspace

#### Methods

###### assemble

Runs s2i assemble script inside of container and copies build artifact to workspace

Arguments
* pull: set to false to prevent pull of latest version of image tag
* secret_volumes: list of credentials (type:secret file) to mount during assemble process.  Each entry should contain two keys.
  * key: credentialsId
  * path: absolute path within container to mount secret

## corp.hobbylobby.LinuxServer

Handles interaction with remote linux servers for application deployment

#### Attributes

###### script

`this` from Jenkins pipeline

###### server

FQDN or IP Address of remote Linux server

###### secret

credentialID of Jenkins credential (type:secret file) that contains ssh private key for authentication to server

###### user

Name of user for authentication to server

#### Methods

###### scp

Copy file from Jenkins workspace to remote server

Arguments
1. file in Jenkinis workspace
2. destination: destination on remote server

###### remoteCommand

Run command on remote server

Arguments
1. Command to run on remote server