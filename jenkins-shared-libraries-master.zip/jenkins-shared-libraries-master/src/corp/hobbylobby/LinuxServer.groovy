package corp.hobbylobby;

class LinuxServer implements Serializable {
	def script
	String server = ""
	String secret = "jenkins-ssh-key"
	String user = "appuser"
	
	def scp(String file, String destination) {
		script.withCredentials([script.file(credentialsId: "${secret}", variable: "IDENTITY_FILE")]) {
			script.echo "Copying ${file} to ${destination} on ${server}"
			script.sh "scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i ${script.IDENTITY_FILE} ${file} ${user}@${server}:${destination}"
		}
	}
	
	def remoteCommand(String command) {
		script.withCredentials([script.file(credentialsId: "${secret}", variable: "IDENTITY_FILE")]) {
			script.echo "Executing ${command} on ${server}"
			script.sh "ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i ${script.IDENTITY_FILE} ${user}@${server} \"${command}\""
		}
	}
}