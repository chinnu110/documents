package corp.hobbylobby;


class Elixir implements Serializable {
    def script
    List docker_args = []
	String docker_image = "hlrepomgmt01:8088/hl-s2i-elixir:v1.6.5-rhel7"
	String app_archive = "app.tar.gz"
	String remote_app_dir = "/app_data/elixir"
	String remote_secret = "jenkins-ssh-key"
	String remote_user = "appuser"
	String remote_app_service
	String app_name

    def assemble(secret_volumes) {
		try {
			script.sh "docker pull ${docker_image}"
		} catch(Exception exc) {
			script.echo exc.toString()
		}
		String args = ""
		List secrets = []
		for(volume in secret_volumes) {
			script.echo "Parsing secret volume mount ${volume.key}"
			script.withCredentials([script.file(credentialsId: "${volume.key}", variable: "TEMP")]){
				script.sh "cp ${script.TEMP} ${script.env.WORKSPACE}@tmp/${volume.key}"
				args = args + "-v ${script.env.WORKSPACE}@tmp/${volume.key}:${volume.path} "
			}
		}
		script.echo args
		script.withDockerContainer(args: "--group-add 0 -v ${script.env.WORKSPACE}:/tmp/src "+args, image:docker_image) {
			script.sh "printenv"
			script.sh "cd /opt/app-root/src && ./.s2i/bin/assemble || /usr/libexec/s2i/assemble"
			script.sh "cp /tmp/app.tar.gz ."
		}
		for(volume in secret_volumes) {
			script.sh "rm -f ${script.env.WORKSPACE}@tmp/${volume.key}"
		}
		script.archiveArtifacts allowEmptyArchive: true, artifacts: "${app_archive}", onlyIfSuccessful: true 
    }
	
	def deploy(Map args=[:], List servers, String user="appuser", String secret="appuser-private-key", String directory="/app_data"){
		
		for(server in servers) {
			script.echo "Deploying to ${server}"
			serverDeploy(server,remote_secret)
			
			scp(server,private_key_secret,app_archive,"${remote_app_root}/${app_name}/",remote_user);
			
			script.withCredentials([script.file(credentialsId: "${secret}", variable: "IDENTITY_FILE")]) {
				script.echo "Copying ${file} to ${dest} on ${server}"
				script.sh "scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i ${script.IDENTITY_FILE} ${app_archive} ${user}@${server}:${directory}"
			}
		
			remoteCommand(server,private_key_secret,remote_user,"sudo systemctl stop ${remote_app_service} && cd ${remote_app_root}/${app_name}/&&tar zxf ${app_archive} && sudo systemctl start ${remote_app_service}")
			
			
		}
	}
	
	def serverDeploy(String server, String private_key_secret) {
		scp(server,private_key_secret,app_archive,"${remote_app_root}/${app_name}/",remote_user);
		remoteCommand(server,private_key_secret,remote_user,"sudo systemctl stop ${remote_app_service} && cd ${remote_app_root}/${app_name}/&&tar zxf ${app_archive} && sudo systemctl start ${remote_app_service}")
	}
	
	def scp(String server, String private_key_secret, String file, String dest, String user) {
		script.withCredentials([script.file(credentialsId: "${private_key_secret}", variable: "IDENTITY_FILE")]) {
			script.echo "Copying ${file} to ${dest} on ${server}"
			script.sh "scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i ${script.IDENTITY_FILE} ${file} ${user}@${server}:${dest}"
		}
	}
	
	def remoteCommand(String server, String private_key_secret, String user, String command) {
		script.withCredentials([script.file(credentialsId: "${private_key_secret}", variable: "IDENTITY_FILE")]) {
			script.echo "Executing ${command} on ${server}"
			script.sh "ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i ${script.IDENTITY_FILE} ${user}@${server} \"${command}\""
		}
	}
}