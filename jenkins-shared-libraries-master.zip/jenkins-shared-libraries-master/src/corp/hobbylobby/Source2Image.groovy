package corp.hobbylobby;


class Source2Image implements Serializable {
    def script
    List docker_args = []
	String docker_image = "hlrepomgmt01:8088/hl-s2i-elixir:v1.6.5-rhel7"
	String app_archive = ""
	String source_dir = ""
	
    def assemble(Map arguments = [:], pull = true, secret_volumes = []) {
		if(arguments.pull){
			try {
				script.sh "docker pull ${docker_image}"
			} catch(Exception exc) {
				script.echo exc.toString()
			}
		}
		
		String docker_args = ""
		for(volume in arguments.secret_volumes) {
			script.echo "Parsing secret volume mount ${volume.key}"
			script.withCredentials([script.file(credentialsId: "${volume.key}", variable: "TEMP")]){
				script.sh "cp ${script.TEMP} ${script.env.WORKSPACE}@tmp/${volume.key}"
				docker_args = docker_args + "-v ${script.env.WORKSPACE}@tmp/${volume.key}:${volume.path} "
			}
		}
		
		script.withDockerContainer(args: "--group-add 0 -v ${script.env.WORKSPACE}/${source_dir}:/tmp/src "+docker_args, image:docker_image) {
			script.sh "printenv"
			script.sh "cd /opt/app-root/src && ./.s2i/bin/assemble || /usr/libexec/s2i/assemble"
			script.sh "cp /tmp/app.tar.gz ${app_archive}"
		}
		for(volume in arguments.secret_volumes) {
			script.sh "rm -f ${script.env.WORKSPACE}@tmp/${volume.key}"
		}
    }
}