def call(Map arguments) {
	Map config = [
		command: "echo"
	]
	config << arguments
	config.server.remoteCommand(config.command)
}