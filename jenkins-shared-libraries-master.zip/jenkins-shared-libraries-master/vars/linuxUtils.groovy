import corp.hobbylobby.LinuxServer

def call(Map arguments) {
	Map config = [
		user:"appuser",
		secret: "jenkins-ssh-key",
		file:"app.tar.gz"
	]
	config << arguments
	server = new LinuxServer(
		script: this,
		server: config.server,
		secret: config.secret,
		user: config.user
	)
}