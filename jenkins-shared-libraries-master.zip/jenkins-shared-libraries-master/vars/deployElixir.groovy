import corp.hobbylobby.LinuxServer

def call(Map arguments) {
	Map config = [
		timeout:29,
		artifact: env.artifact
	]
	config << arguments
	
	echo "Deploying to ${config.server.server}"
	echo "Coping files"
	serverSCP(server:config.server,file:config.artifact,destination:config.directory)
	echo "Stopping service"
	serverRemoteCommand(server:config.server,command:"sudo systemctl stop ${config.service}")
	echo "Extracting artifact"
	serverRemoteCommand(server:config.server,command:"cd ${config.directory} && tar zxf ${config.artifact}")
	echo "Starting service"
	serverRemoteCommand(server:config.server,command:"sudo systemctl start ${config.service}")
	if(config.containsKey('url')){
		echo "Testing ${config.url}"
		sh "i=0;while [ \"\$(curl ${config.url} 2>/dev/null)\" == \"\" ];do i=\$(( \$i + 1 )); echo \"Wait \${i} for app to start\";sleep 1;if [ \$i -gt \${config.timeout} ];then exit 1;fi;done"
	}
	echo "Deployed to ${config.server.server}"
}

