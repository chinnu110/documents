import corp.hobbylobby.Source2Image

def call(Map arguments) {
	Map config = [
		image: null,
		secret_volumes: [],
		pull: true
	]
	config << arguments
	config.image.assemble(pull:config.pull,secret_volumes:config.secret_volumes)
}