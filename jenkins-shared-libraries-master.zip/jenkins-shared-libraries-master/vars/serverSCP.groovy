def call(Map arguments) {
	Map config = [
		file: "app.tar.gz",
		destination: "/app_data/elixir"
	]
	config << arguments
	config.server.scp(config.file,config.destination)
}