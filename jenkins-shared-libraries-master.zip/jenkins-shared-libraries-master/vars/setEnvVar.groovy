def call(String updateVar, String updateValue) {
	echo "setting env.${updateVar} to ${updateValue}"
	env."${updateVar}" = updateValue
}