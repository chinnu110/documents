import corp.hobbylobby.Source2Image

def call(Map arguments, Closure body) {
	Map config = [
		image: null,
		tag: "latest",
		app_archive: "app.tar.gz",
		repo: "hlrepomgmt01.hobbylobby.corp:8088",
		secret_volumes: [],
		pull: true,
		source_dir:""
	]
	config << arguments
	echo "${config}"
	echo "${config.image}:${arguments.image}"
	echo "${config.repo}:${arguments.repo}"
	echo "${config.tag}:${arguments.tag}"
	if (body) {
		body(
			new Source2Image(
				script: this,
				app_archive: config.app_archive,
				docker_image: config.repo + "/" + config.image + ":" + config.tag,
				source_dir:config.source_dir
			)
		)
	}
}