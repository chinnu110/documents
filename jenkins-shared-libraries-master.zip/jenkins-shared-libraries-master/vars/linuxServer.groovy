import corp.hobbylobby.LinuxServer

def call(Map arguments, Closure body) {
	Map config = [
		user:"appuser",
		secret: "jenkins-ssh-key"
	]
	config << arguments
	if (body) {
		body(
			new LinuxServer(
				script: this,
				server: config.server,
				secret: config.secret,
				user: config.user
			)
		)
	}
}