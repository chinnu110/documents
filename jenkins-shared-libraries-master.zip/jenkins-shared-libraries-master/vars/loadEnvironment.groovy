def call(Map arguments) {
	echo "Starting to load environment"
	if(!arguments.containsKey("language")){
		return
	}
	switch(arguments.language.toLowerCase()) {
		case "elixir":
			echo "loading elixir environment from defaults"
			switch(env.BRANCH_NAME) {
				case "develop" || "sandbox":
					env.MIX_ENV = env.MIX_ENV ?: "dev"
					break
				case ~/release\/.*/:
					env.MIX_ENV = env.MIX_ENV ?: "qa"
					break
				case ~/^v\d+\.\d+\.\d+[a-z]?-rc\d?$/:
					env.MIX_ENV = env.MIX_ENV ?: "perf"
					break
				case "master":
					env.MIX_ENV = env.MIX_ENV ?: "prod"
					break
				default:
					echo "Invalid MIX_ENV"
			}
			break
	}
}