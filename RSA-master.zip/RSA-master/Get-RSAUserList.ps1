﻿#Script to update RSA User Table
#By David Bluemlein
#Last updated 7/25/2019

#Variable Unique to this script
$BaseURL = "https://access.securid.com/AdminInterface/restapi/v1/users/lookup"
$TableName = "RsaCloudUsers"
$TestUser = "david.bluemlein@hobbylobby.com"
$RootFolder = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
$ScriptName = [io.path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Definition)
$TempTableName = "Temp" + $TableName
$UsersProcessed = 0
$UsersSkipped = 0
$UsersError = 0
$UsersInserted = 0
$UsersUpdated = 0
$UsersDeleted = 0
$TempTableCreated = $False

#Run common script
. $RootFolder\RSA-Common.ps1

#Test Connection to RSA Access
If ($OkToContinue) {
    Write-Log "     Testing REST API with user $TestUser."
    $Body = @{ "email" = "$TestUser" } | ConvertTo-Json
    Try {
        $Raw = Invoke-WebRequest $BaseURL -Method Post -Headers $Header -Body $Body -ContentType "application/json" -ErrorAction SilentlyContinue
    } Catch {
        Write-Log "     Can't conenct to test user ($TestUser.)  Error: $($_.Exception.Response.StatusCode.Value__) $($_.Exception.Response.StatusCode).  Dying..."
        $OkToContinue = $False
    }
    If ($OkToContinue) {
        $Response = $Raw.Content | ConvertFrom-Json
        If ($Response.id) {
            Write-Log "     Connection to REST API at $BaseURL - OK!"
            Write-Log "         Test user $TestUser has ID $($Response.id)"
        }Else{
            Write-Log "     Didn't get ID on $TestUser.  Dying..."
            $OkToContinue = $False
        }
    }
}

#Create Temp Table
If($OkToContinue) {
    $SQL = "DROP TABLE $TempTableName"
    $Error.Clear()
    $Results = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        If ($Error[0].Exception.HResult -ne '-2146233088') {
            Write-Log "     Error: Unable to drop $TempTableName from database $DatabaseName on $DatabaseServer. Error: " + $Error[0].Exception.Message + " (" + $Error[0].Exception.HResult + ")  Dying..."
            $OkToContinue = $False
        }
    }Else{
        Write-Log "     Table $TempTableName already exists.  Dropped."
    }
    $SQL = "SELECT TOP 0 * INTO $TempTableName FROM $TableName"
    $Error.Clear()
    $Results = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        Write-Log "     Error: Unable to create $TempTableName in database $DatabaseName on $DatabaseServer. Error: " + $Error[0].Exception.Message + " (" + $Error[0].Exception.HResult + ")  Dying..."
        $OkToContinue = $False
    }Else{
        $TempTableCreated = $True
        Write-Log "     Created table $TempTableName."
    }
}

#Get list of emails
If ($OkToContinue) {
    Write-Log "     Getting list of emails from domain."
    Try{
        $LdapUserSearch = New-Object DirectoryServices.DirectorySearcher "(&(ObjectCategory=User)(ObjectClass=Person)(mail=*)(sAMAccountName=*))"
        $LdapUserSearch.PageSize = 500
        $LDAPUsers = $LdapUserSearch.FindAll()
        $UserCount = $LDAPUsers.Count
    }Catch{
        Write-Log "     Unable to get list of email from AD.  Dying"
        $OkToContinue = $False
    }
}
If ($OkToContinue) {
    Write-Log "     Found $UserCount User Accounts.  Processing"
}

#Loop through each user
#   1) Access REST to pull user info
#   2) Clean it up and make a list
#   3) Insert data into SQL temp table
If ($OkToContinue) {
    ForEach ($LDAPUser In $LDAPUsers) {
        $UsersProcessed++
        $AdUserName = $LDAPUser.Properties.samaccountname
        $Email = $LDAPUser.Properties.mail
        If ($AdUserName.Length -gt 0 -and $Email.Length -gt 0) {
            $Body = @{ "email" = "$Email" } | ConvertTo-Json
            Try {
                $Raw = Invoke-WebRequest $BaseURL -Method Post -Headers $Header -Body $Body -ContentType "application/json" -ErrorAction SilentlyContinue
            } Catch {
                $UsersSkipped++
                Continue
            }
            $Response = $Raw.Content | ConvertFrom-Json
            $ColumnNames = "ADUserName,"
            $Values = "'" + $AdUserName + "',"
            ForEach($Property In $Response.PSObject.Properties) {
                If ($Property.Value) {
                    $ColumnNames = $ColumnNames + $Property.Name + ","
                    If ($Property.Name -Eq "eventLogDate") {
                        $Values = $Values + "'" + ([datetime]::SpecifyKind($Property.Value,'UTC')) + "',"
                    }Else{
                        $Values = $Values + "'" + ($Property.Value -replace "'","''") + "',"
                    }
                }
            }
            $SQL = "INSERT INTO $TempTableName (" + $ColumnNames.Substring(0,$ColumnNames.Length - 1) + ") VALUES (" + $Values.Substring(0,$Values.Length - 1) + ")"
            $Error.Clear()
            Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
            If ($Error) {
                Write-Log "      Error: Failed to insert $Email. Error: $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
                $UsersError++
            }Else{
                If (($UsersProcessed % 500) -eq 0) {
                    "          Processed $UsersProcessed of $UserCount users"
                }
            }
        }
    
    }
}

#Merge the tables
If ($OkToContinue) {
    $SQL = "EXEC MergeRSACloudUsers"
    $Error.Clear()
    $Results = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        Write-Log "      Error: Failed to merge new data into $TableName. Error: $Error[0].Exception.Message ($Error[0].Exception.HResult)"
        Write-Log "      No data was altered.  (This is bad)."
        $OkToContinue = $False
    }Else {
        $UsersInserted = $Results.InsertedCount
        $UsersUpdated = $Results.UpdateCount
        $UsersDeleted = $Results.DeletedCount
        Write-Log "     Skipped $UsersSkipped users"
        Write-Log "     Added $UsersInserted users"
        Write-Log "     Updated $UsersUpdated users"
        Write-Log "     Deleted $UsersDeleted users"
        Write-Log "     Had Errors on $UsersError users"
    }
}

#Clean Up temp table
If ($TempTableCreated) {
    $SQL = "DROP TABLE $TempTableName"
    $Error.Clear()
    Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        Write-Log "     Error: Failed to drop table $TempTableName. Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
    }Else{
        Write-Log "     Dropped $TempTableName."
    }
}

#Finalize Log
$EndTime = Get-Date
$RunTime = New-TimeSpan -End $EndTime -Start $StartTime
Write-Log "   Done at $EndTime"
Write-Log "   Run Time: $($RunTime.Minutes) minutes, $($RunTime.Seconds) seconds."
"`n`n" >> $Global:LogFile

#Send Email on failure
If (!($OkToContinue)) {
    $Subject = "RSA: $ScriptName Failed"
    Send-MailMessage -SmtpServer $SMTPServer -From $NotificationFrom -To $NotificationEmail -Subject $Subject -Body $Global:LogText
    If ($Error) {
        Write-Log "     Failed to send failure email.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
    }Else{
        Write-Log "     Sent failure email to $NotificationEmail"
        $FailureEmailSent = $True
    }
}

#Write Log to SQL
$SQL = "INSERT INTO RunLogs (StartTime, EndTime, ScriptName, Successful, Skipped, Added, Updated, Deleted, Errors, LogText, FailureEmailSent) "
$SQL = $SQL + "VALUES('" + $StartTime + "', '" + $EndTime + "', '" + $ScriptName + "', " + [Int]$OkToContinue + ", " + $UsersSkipped.ToString() + ", "
$SQL = $SQL + $UsersInserted.ToString() + ", " + $UsersUpdated.ToString() + ", " +  $UsersDeleted.ToString()  + ", " +  $UsersError.ToString() + ", '"
$SQL = $SQL + ($Global:LogText -replace "'","''") + "'," + [Int]$FailureEmailSent + ")"
$Error.Clear()
Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
If ($Error) {
    Write-Log "      Error: Failed to write logging to SQL.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
}