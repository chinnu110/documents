﻿#Common code for all RSA scripts
#By David Bluemlein
#Last updated 4/9/2019

#Gobal Variables (Settable)
$Global:LogToConsole = $True
$KeyFile = "HLRSAKeyREST1.key" 
$DatabaseServer = "DEVSQLAPP12"
$DatabaseName = "RSALogs"
#$NotificationEmail = "rsa.alerts@hobbylobby.com"
$NotificationEmail = "david.bluemlein@hobbylobby.com"
$SMTPServer = "hlsmtp01.hobbylobby.corp"
$NotificationFrom = "rsa.admins@hobbylobby.com"
$SplunkURl = "https://splunkhf.hobbylobby.corp:8443/services/collector/event"
$SplunkHeader = [Ordered]@{ "Authorization" = "Splunk 7423da15-2b9a-4f9c-97b0-35aa0d826609"}
$DomainName = "Hobbylobby.corp"

#Other Global Variables
$StartTime = Get-Date
$KeyFile = $RootFolder + "\" + $KeyFile
$LibFolder = $RootFolder + "\lib"
$ClassPath = "$LibFolder\rsa-securidaccess-rest-client-sdk-1.1.0.jar;$LibFolder\gson-2.8.1.jar;$LibFolder\nimbus-jose-jwt-4.37.jar;$LibFolder\commons-cli-1.3.1.jar;$LibFolder\commons-lang-2.6.jar;$LibFolder\log4j-1.2.17.jar;$LibFolder\commons-csv-1.4.jar;$LibFolder\spring-web-4.3.10.RELEASE.jar;$LibFolder\commons-logging-1.2.jar;$LibFolder\jcip-annotations-1.0-1.jar;$LibFolder\json-smart-2.3.jar;$LibFolder\bcpkix-jdk15on-1.56.jar;$LibFolder\spring-aop-4.3.10.RELEASE.jar;$LibFolder\spring-beans-4.3.10.RELEASE.jar;$LibFolder\spring-context-4.3.10.RELEASE.jar;$LibFolder\spring-core-4.3.10.RELEASE.jar;$LibFolder\accessors-smart-1.2.jar;$LibFolder\bcprov-jdk15on-1.56.jar;$LibFolder\spring-expression-4.3.10.RELEASE.jar;$LibFolder\asm-4.0.jar"
$Global:LogText = ""
$OkToContinue = $True
$FailureEmailSent = $False

#Function to write log output to console, log file and save for SQL
Function Write-Log {
    Param ([Parameter(Mandatory=$True,ValueFromPipeline)][string]$LogEntry    )
    If ($Global:LogToConsole) {
        $LogEntry
    }
    If ($LogEntry) {
        $Global:LogText = $Global:LogText + $LogEntry + "`n"
    }
    $LogEntry >> $Global:LogFile
}

#Open Log File
$LogPath = $RootFolder + "\Logs\" + (Get-Date).Year + "\" + (Get-Culture).DateTimeFormat.GetMonthName((Get-Date).Month)
If(!(Test-Path $LogPath -ErrorAction SilentlyContinue)) {
    New-Item -Path $LogPath -Force -Confirm:$False -ItemType Directory -ErrorAction SilentlyContinue
    If (!(Test-Path $LogPath -ErrorAction SilentlyContinue)) {
        "Error: Can't create $LogPath.  Dying..."
        $OkToContinue = $False
    }

}
$Global:LogFile = $LogPath + "\" + $ScriptName + " " + (Get-Date -UFormat "%m-%d-%Y") + ".Log"
Write-Log "Run at $StartTime"
Write-Log "    Logging to $Global:LogFile."
Write-Log "     Using Base URL $BaseURL"

#Test if SQL Module is installed
If (!(Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue )) {
     Write-Log "     SQL PowerShell Module is not installed.  Dying..."
     $OkToContinue = $False
}

#Test SQL Connection
If ($OkToContinue) {
    $SQL = "SELECT Table_Name FROM $DatabaseName.INFORMATION_SCHEMA.TABLES"
    $Error.Clear()
    $Results = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        Write-Log "     Error: Unable to connect to $DatabaseName on $DatabaseServer.  Dying..."
        $OkToContinue = $False
    }Else{
        Write-Log "     SQL connection to $DatabaseName on $DatabaseServer is ok!"
    }
}

#Make sure table exists
If ($OkToContinue) {
    $SQL = "SELECT Table_Name FROM " + $DatabaseName + ".INFORMATION_SCHEMA.TABLES WHERE Table_Name = '" + $TableName + "'"
    $Error.Clear()
    $Results = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL  -ErrorAction SilentlyContinue
    If ($Error -or ($Results.Count -eq 0)) {
        Write-Log "     Error: Table $TableName does not exist in database $DatabaseName on $DatabaseServer.  Dying..."
        $OkToContinue = $False
    }Else{
        Write-Log "     Table $TableName is OK!"
    }
}

#Get JWT.  Don't touch this code.  It will break if you look at it funny!!!!!!
If ($OkToContinue) {
    Try {
        $Raw = &Java.exe -classpath $ClassPath com.rsa.securidaccess.admin.client.AdminApiClientCliTool -o generateToken -f $KeyFile
        $JWT = $Raw -Replace "Generated Access Token:","" -Replace " ",""
    }Catch{
        Write-Log  "   Error: Can't generate JWT.  Dying..."
        $OkToContinue = $False
    }
    If ($OkToContinue) {
        $Header = @{ "Authorization" = "Bearer$JWT" }
        Write-Log  "     JWT: $JWT"
    }
}