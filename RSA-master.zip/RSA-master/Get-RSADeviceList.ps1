﻿#Script to update RSA Device Table
#By David Bluemlein
#Last updated 2/6/2019

#Variable Unique to this script
$BaseURL = "https://access.securid.com/AdminInterface/restapi/v1/users"
$TableName = "RsaCloudDevices"
$TestUser = "092127e5-686f-4a82-b5fd-289849bd3c36"
$RootFolder = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
$ScriptName = [io.path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Definition)
$TempTableName = "Temp" + $TableName
$DevicesSkipped = 0
$DevicesError = 0
$DevicesInserted = 0
$DevicesUpdated = 0
$DevicesDeleted = 0
$Global:LogText = ""
$TempTableCreated = $False

#Run common script
. $RootFolder\RSA-Common.ps1

#Test Connection to RSA Access
If ($OkToContinue) {
    $URL = $BaseURL + "/" + $TestUser + "/devices" 
    Write-Log "Testing $URL"
    For ($i = 1; $i -le 3; $i++) {
        $ConnectionOk = $True
        Try {
            $Raw = Invoke-WebRequest $URL -Method Get -Headers $Header -ErrorAction SilentlyContinue
        } Catch {
            Write-Log "     Failed to connect on try $i  Error: $($_.Exception.Response.StatusCode.Value__) $($_.Exception.Response.StatusCode)."
            $ConnectionOK = $False
        }
        If ($ConnectionOK) {
            Write-Log "     Connection to REST API at $BaseURL - OK!"
            Break
        }
    }
    If (!($ConnectionOK)) {
        Write-Log "     Failed to connect to $BaseURL.  Dying..."
        $OkToContinue = $False
    }
}

#Create Temp Table
If($OkToContinue) {
    $SQL = "DROP TABLE $TempTableName"
    $Error.Clear()
    $Results = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        If ($Error[0].Exception.HResult -ne '-2146233088') {
            Write-Log "     Error: Unable to drop $TempTableName from database $DatabaseName on $DatabaseServer. Error: " + $Error[0].Exception.Message + " (" + $Error[0].Exception.HResult + ")  Dying..."
            $OkToContinue = $False
        }
    }Else{
        Write-Log "     Table $TempTableName already exists.  Dropped."
    }
    $SQL = "SELECT TOP 0 * INTO $TempTableName FROM $TableName"
    $Error.Clear()
    $Results = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        Write-Log "     Error: Unable to create $TempTableName in database $DatabaseName on $DatabaseServer. Error: " + $Error[0].Exception.Message + " (" + $Error[0].Exception.HResult + ")  Dying..."
        $OkToContinue = $False
    }Else{
        Write-Log "     Created table $TempTableName."
        $TempTableCreated = $True
    }
}

#Get list of Users to check for devices
If ($OkToContinue) {
    $SQL = "SELECT id, ADUserName FROM RsaCloudUsers"
    $Error.Clear()
    $Users = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        Write-Log "     Error: Unable to get list of users. Error: $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))  Dying..."
        $OkToContinue = $False
    }Else {
        $UserCount = $Users.Count
        Write-Log "     Searching $UserCount users for devices "
    }
}

#Loop through each user
#   1) Access REST to pull pull
#   2) Clean it up and make a list
#   3) Insert data into SQL temp table
If ($OkToContinue) {
    ForEach ($User In $Users) {
        $DevicesFound++
        $AdUserName = $User.ADUserName
        $ID = $User.id
        $URL = $BaseURL + "/" + $ID + "/devices"
        Try {
            $Raw = Invoke-WebRequest $URL -Method Get -Headers $Header -ErrorAction SilentlyContinue
        } Catch {
            $DevicesSkipped++
            Continue
        }
        $Response = $Raw.Content | ConvertFrom-Json
        If ($Response.ID) {
            $DeviceFoundForUser = $False
            ForEach ($Device in $Response) {
                If ($Device.osType -like "Android*" -or $Device.osType -like "iOS*") {
                    $DeviceFoundForUser = $True
                    $Values = "'" + $Device.id + "', '" + ($Device.name -replace "'","''") + "', '" + $Device.userId + "', '" + $Device.osType + "', '"
                    $Values = $Values + $Device.capabilities + "', '" + ([datetime]::SpecifyKind($Device.registeredDate,'UTC')) + "', '" + ([datetime]::SpecifyKind($Device.lastUsedDate,'UTC')) + "', '" + $AdUserName + "'"
                    $SQL = "INSERT INTO $TempTableName (id, name, userID, osType, capabilities, registeredDate, lastUsedDate, ADUserName) VALUES (" + $Values + ")"
                    $Error.Clear()
                    Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
                    If ($Error) {
                        Write-Log "      Error: Failed to insert device for $AdUserName. Error: $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
                        $DevicesError++
                    }
                }
            }
            If (!($DeviceFoundForUser)) {
                $DevicesSkipped++
            }
        }Else{
            $DevicesSkipped++
        }
    }
}

#Merge the tables
If ($OkToContinue) {
    $SQL = "EXEC MergRSACloudDevices"
    $Error.Clear()
    $Results = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        Write-Log "      Error: Failed to merge new data into $TableName . Error: $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
        Write-Log "      No data was altered.  (This is bad)."
    }Else {
        $DevicesInserted = $Results.InsertedCount
        $DevicesUpdated = $Results.UpdateCount
        $DevicesDeleted = $Results.DeletedCount
        Write-Log "     No device found for $DevicesSkipped users"
        Write-Log "     Added $DevicesInserted devices"
        Write-Log "     Updated $DevicesUpdated devices"
        Write-Log "     Deleted $DevicesDeleted devices"
        Write-Log "     Had Errors on $DevicesError devices"
    }
}

#Clean Up temp table
If ($TempTableCreated) {
    $SQL = "DROP TABLE $TempTableName"
    $Error.Clear()
    Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
    If ($Error) {
        Write-Log "      Error: Failed to drop table $TempTableName. Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
    }Else{
        Write-Log "     Dropped $TempTableName."
    }
}

#Compute Run Time
$EndTime = Get-Date
$RunTime = New-TimeSpan -End $EndTime -Start $StartTime
Write-Log "   Done at $EndTime"
Write-Log "   Run Time: $($RunTime.Minutes) minutes, $($RunTime.Seconds) seconds."

#Send Email on failure
If (!($OkToContinue)) {
    $SendEmail = $True
    $SQL = "SELECT TOP 1 StartTime FROM RunLogs WHERE ScriptName = '$ScriptName' AND FailureEmailSent = 1 ORDER BY StartTime DESC"
    $Error.Clear()
    $LastEmailSent = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue | Select -ExpandProperty StartTime
    If ($Error) {
        Write-Log "      Failed to get last failure email sent.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
    }Else{
        If ($LastEmailSent) {
             Write-Log "     Last notification email sent at $LastEmailSent."
            If ($LastEmailSent -gt $StartTime.AddHours(-1)) {
                $SendEmail = $False
            }
        }       
    }
    If ($SendEmail) {
        $Subject = "RSA: $ScriptName Failed"
        $Error.Clear()
        Send-MailMessage -SmtpServer $SMTPServer -From $NotificationFrom -To $NotificationEmail -Subject $Subject -Body $Global:LogText -ErrorAction SilentlyContinue
        If ($Error) {
            Write-Log "     Failed to send failure email.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
        }Else{
            Write-Log "     Sent failure email to $NotificationEmail"
            $FailureEmailSent = $True
        }
    }
}

#Write Log to SQL
$SQL = "INSERT INTO RunLogs (StartTime, EndTime, ScriptName, Successful, Skipped, Added, Updated, Deleted, Errors, LogText, FailureEmailSent) "
$SQL = $SQL + "VALUES('" + $StartTime + "', '" + $EndTime + "', '" + $ScriptName + "', " + [Int]$OkToContinue + ", " + $DevicesSkipped.ToString() + ", "
$SQL = $SQL + $DevicesInserted.ToString() + ", " + $DevicesUpdated.ToString() + ", " +  $DevicesDeleted.ToString()  + ", " +  $DevicesError.ToString() + ", '"
$SQL = $SQL + ($Global:LogText -replace "'","''") + "'," + [Int]$FailureEmailSent + ")"
$Error.Clear()
Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
If ($Error) {
    Write-Log "      Error: Failed to write logging to SQL.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
}

#Finalize Log
"`n`n" >> $LogFile