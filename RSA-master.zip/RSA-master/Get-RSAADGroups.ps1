﻿#Script to update RSA AD group list
#By David Bluemlein
#Last updated 4/29/2-19

#Variable Unique to this script
$TableName = "ADGroups"
$RootFolder = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
$ScriptName = [io.path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Definition)
$Groups = @("sg_VPN_Standard","sg_VPN_Extended", "ag_Origami_Risk")

#Run common script
. $RootFolder\RSA-Common.ps1

#Make sure AD Modules are installed
If (!(Get-Command Get-ADUser -ErrorAction SilentlyContinue )) {
     Write-Log "     AD PowerShell Module is not installed.  Dying..."
     $OkToContinue = $False
}

#Test connection to AD
If ($OkToContinue) {
    Try {
        Get-ADDomain $DomainName -ErrorAction SilentlyContinue 2>&1 > $Null
    }Catch{
        Write-Log "     Can't connect to $DomainName.  Dying...."
        $OkToContinue = $False
    }
}

If ($OkToContinue) {
    ForEach($Group in $Groups) {
        $SQL = "DELETE FROM $TableName WHERE GroupName = '$Group'"
        Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
        If ($Error) {
            Write-Log "     Error: Unable to get list of users in $Group. Error: $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))  Skipping..."
        }Else{   
            $Members = Get-ADGroupMember -Identity $Group -ErrorAction SilentlyContinue
            If ($Error) {
                Write-Log "     Error: Unable to get list of users in $Group. Error: $($Error[0].Exception.Message) ($($Error[0].Exception.HResult)) Skipping..."
            }Else{
                ForEach ($User In $Members) {
                    $UserName = $User.SamAccountName
                    $FullName = $User.Name
                    $ADUser = Get-ADUser $User -Properties Department -ErrorAction SilentlyContinue
                    If ($Error) {
                        $Department = ""
                        Write-Log "     Error: Unable to get department for $UserName. Error: $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))."
                        $Error.Clear()
                    }Else{
                        $Department = $ADUser.Department
                    }
                    $SQL = "INSERT INTO $TableName (GroupName, UserName, FullName, Department) VALUES ('$Group', '$UserName', '$FullName', '$Department')"
                    Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
                    If ($Error) {
                        Write-Log "     Error: Unable update group membership for $UserName. Error: $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))."
                        $Error.Clear()
                    }
                }
            }
        }
    }
}

#Compute Run Time
$EndTime = Get-Date
$RunTime = New-TimeSpan -End $EndTime -Start $StartTime
Write-Log "   Done at $EndTime"
Write-Log "   Run Time: $($RunTime.Minutes) minutes, $($RunTime.Seconds) seconds."

#Send Email on failure
If (!($OkToContinue)) {
    $SendEmail = $True
    $SQL = "SELECT TOP 1 StartTime FROM RunLogs WHERE ScriptName = '$ScriptName' AND FailureEmailSent = 1 ORDER BY StartTime DESC"
    $Error.Clear()
    $LastEmailSent = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue | Select -ExpandProperty StartTime
    If ($Error) {
        Write-Log "      Failed to get last failure email sent.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
    }Else{
        If ($LastEmailSent) {
             Write-Log "     Last notification email sent at $LastEmailSent."
            If ($LastEmailSent -gt $StartTime.AddHours(-1)) {
                $SendEmail = $False
            }
        }       
    }
    If ($SendEmail) {
        $Subject = "RSA: $ScriptName Failed"
        $Error.Clear()
        Send-MailMessage -SmtpServer $SMTPServer -From $NotificationFrom -To $NotificationEmail -Subject $Subject -Body $Global:LogText -ErrorAction SilentlyContinue
        If ($Error) {
            Write-Log "     Failed to send failure email.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
        }Else{
            Write-Log "     Sent failure email to $NotificationEmail"
            $FailureEmailSent = $True
        }
    }
}

#Write Log to SQL
$SQL = "INSERT INTO RunLogs (StartTime, EndTime, ScriptName, Successful, LogText, FailureEmailSent) "
$SQL = $SQL + "VALUES('" + $StartTime + "', '" + $EndTime + "', '" + $ScriptName + "', " + [Int]$OkToContinue + ", '" 
$SQL = $SQL + ($Global:LogText -replace "'","''") + "'," + [Int]$FailureEmailSent + ")"
$Error.Clear()
Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
If ($Error) {
    Write-Log "      Error: Failed to write logging to SQL.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
}

#Finalize Log
"`n`n" >> $LogFile