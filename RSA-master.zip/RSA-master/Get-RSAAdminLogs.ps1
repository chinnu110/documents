#Get-RSAAdminLogs
#Download RSA SecureID Admin logs from the cloud and uploads them to SQL and Splunk
#By David Bluemlein
#Last Updated 4/9/2019

#Variable Unique to this script
$CatchEmAll = $False
$BaseURL = "https://access.securid.com/AdminInterface/restapi/v1/adminlog/exportlogs"
$TableName = "RsaCloudAdminLogs"
$RootFolder = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
$ScriptName = [io.path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Definition)
$LogEntriesSkipped = 0
$LogEntriesError = 0
$LogEntriesInserted = 0
$SplunkAdded = 0
$SplunkFailed = 0

#Run common script
. $RootFolder\RSA-Common.ps1

#Figure out how far back we're going
If ($OkToContinue) {
    If ($CatchEmAll) {
        $LastLogEntry = (Get-Date).AddDays(-365)
        Write-Log "      Processing the last year of logs (Starting Date $LastLogEntry)"
    }Else{
        $SQL = "SELECT TOP 1 eventLogDate FROM $TableName ORDER BY eventLogDate DESC"
        $LastLogEntry = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue | SELECT -ExpandProperty eventLogDate
        If (!($LastLogEntry)) {
         $LastLogEntry = (Get-Date).AddDays(-7)
         Write-Log "     No logs found in DB.  Defaulting to 7 days worth."
        }Else {
        Write-Log "      Last Log Entry: $LastLogEntry"
        }
    }
}

#Encode URL
$BeginingDate = $LastLogEntry.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffffffZ")
$EncodedDate = [uri]::EscapeDataString($BeginingDate)
$BaseURL = $BaseURL + "?startTimeAfter=" + $EncodedDate
Write-Log "      Using Base URL of  $BaseURL"

#Get Page Count
If ($OkToContinue) {
    Try {
        $RawResponse = Invoke-WebRequest $BaseURL -Headers $Header -ErrorAction SilentlyContinue
        $Response = $RawResponse.Content | ConvertFrom-Json
        $Pages = $Response.totalPages
    }Catch{
        Write-Log "      Error: Failed to retreive number of pages.  Error: $($_.Exception.Response.StatusCode.Value__) $($_.Exception.Response.StatusCode).  Dying..."
        $OkToContinue = $False
    }
    Write-Log "      Processing $($Response.TotalElements) log entries in $Pages pages."
}

 #Loop Through Pages
 If ($OkToContinue) {
    For ($Page = 0; $Page -lt $Pages ; $Page++) {
        $URL = $BaseURL + "&pageNumber=$Page"
        Try{
            $RawResponse = Invoke-WebRequest $URL -Headers $Header -ErrorAction SilentlyContinue
        }Catch{
            Write-Log "      Error: Unable to download page $Page. Error: $($_.Exception.Response.StatusCode.Value__) $($_.Exception.Response.StatusCode).  Continuing"
            Continue
        }
        $Response = $RawResponse.Content | ConvertFrom-Json
        $Events = $Response.elements
        ForEach ($Event In $Events) {
            If ($Event.eventId){
                $SQL = "SELECT * FROM $TableName WHERE eventID = '" + $Event.eventId + "'"
                If (Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue) {
                    $LogEntriesSkipped++
                }Else{
                    #Build SQL and insert data
                    $ColumnNames = ""
                    $Values = ""
                    ForEach($Property In $Event.PSObject.Properties) {
                        If ($Property.Value) {
                            $ColumnNames = $ColumnNames + $Property.Name + ","
                            If ($Property.Name -Eq "eventLogDate") {
                                $Values = $Values + "'" + ([datetime]::SpecifyKind($Property.Value,'UTC')) + "',"
                            }Else{
                                $Values = $Values + "'" + ($Property.Value -replace "'","''") + "',"
                            }
                        }
                    }
                    $SQL = "INSERT INTO $TableName (" + $ColumnNames.Substring(0,$ColumnNames.Length - 1) + ") VALUES (" + $Values.Substring(0,$Values.Length - 1) + ")"
                    $Error.Clear()
                    Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL
                    If ($Error) {
                        Write-Log "      Error: Failed to insert $($Event.eventId) (" + $SQL + ")"
                        $LogEntriesFailed++
                    }Else{
                        $LogEntriesInserted++
                    }

                    #Format Log for Splunk and upload
                    $SentEvent =  [Ordered] @{
                        "time" = Get-Date -Date $Event.eventLogDate -UFormat %s
                        "host" = "access.securid.com"
                        "source" = "RSA SecurID Access Admin Log"
                        "sourcetype" = "json_data"
                        "event" = $Event
                    } | ConvertTo-Json
                    Try {
                        $Results = Invoke-RestMethod -Uri $SplunkURl -Headers $SplunkHeader -Method Post -Body $SentEvent 
                    }Catch{
                        Write-Log "      Error: Unable to upload event $($Event.eventId) to splunk. Error: $($_.Exception.Response.StatusCode.Value__) $($_.Exception.Response.StatusCode).  Continuing"
                        $SplunkFailed++
                        Continue
                    }
                    If ($Results.code -eq 0) {
                        $SplunkAdded++
                    }Else{
                        $SplunkFailed++
                    }

                }
            }Else{
                Write-Log "     Error: Found event with no event ID!"
                $LogEntriesError++
            }
        }
          
    }
 
}

Write-Log "      Skipped $LogEntriesSkipped events"
Write-Log "      Added $LogEntriesInserted events to SQL"
Write-Log "      Added $SplunkAdded events to Splunk"
Write-Log "      RSA Error on $LogEntriesError"
Write-Log "      SQL Error on $LogEntriesFailed events "
Write-Log "      Splunk Error on $SplunkFailed events "

#Compute Run Time
$EndTime = Get-Date
$RunTime = New-TimeSpan -End $EndTime -Start $StartTime
Write-Log "   Done at $EndTime"
Write-Log "   Run Time: $($RunTime.Minutes) minutes, $($RunTime.Seconds) seconds."

#Send Email on failure
If (!($OkToContinue)) {
    $SendEmail = $True
    $SQL = "SELECT TOP 1 StartTime FROM RunLogs WHERE ScriptName = '$ScriptName' AND FailureEmailSent = 1 ORDER BY StartTime DESC"
    $Error.Clear()
    $LastEmailSent = Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue | Select -ExpandProperty StartTime
    If ($Error) {
        Write-Log "      Error: Failed to get last failure email sent.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
    }Else{
        If ($LastEmailSent) {
             Write-Log "     Last notification email sent at $LastEmailSent."
            If ($LastEmailSent -gt $StartTime.AddHours(-1)) {
                $SendEmail = $False
            }
        }       
    }
    If ($SendEmail) {
        $Subject = "RSA: $ScriptName Failed"
        $Error.Clear()
        Send-MailMessage -SmtpServer $SMTPServer -From $NotificationFrom -To $NotificationEmail -Subject $Subject -Body $Global:LogText -ErrorAction SilentlyContinue
        If ($Error) {
            Write-Log "     Failed to send failure email.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
        }Else{
            Write-Log "     Sent failure email to $NotificationEmail"
            $FailureEmailSent = $True
        }
    }
}


#Write Log to SQL
$SQL = "INSERT INTO RunLogs (StartTime, EndTime, ScriptName, Successful, Skipped, Added, Updated, Deleted, Errors, LogText, FailureEmailSent) "
$SQL = $SQL + "VALUES('" + $StartTime + "', '" + $EndTime + "', '" + $ScriptName + "', " + [Int]$OkToContinue + ", " + $LogEntriesSkipped.ToString() + ", "
$SQL = $SQL + $LogEntriesInserted.ToString() + ", " + $SplunkAdded.ToString() + ", " +  $SplunkFailed.ToString()  + ", " +  $LogEntriesError.ToString() + ", '"
$SQL = $SQL + ($Global:LogText -replace "'","''") + "'," + [Int]$FailureEmailSent + ")"
$Error.Clear()
Invoke-Sqlcmd -ServerInstance $DatabaseServer -Database $DatabaseName -Query $SQL -ErrorAction SilentlyContinue
If ($Error) {
    Write-Log "      Error: Failed to write logging to SQL.  Error:  $($Error[0].Exception.Message) ($($Error[0].Exception.HResult))"
}
#Finalize Log
"`n`n" >> $LogFile