USE [RSALogs]
GO

/****** Object:  Table [dbo].[AdGroups]    Script Date: 7/26/2019 8:26:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AdGroups](
	[GroupName] [nvarchar](50) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[FullName] [nvarchar](50) NULL,
	[Department] [nvarchar](50) NULL
) ON [PRIMARY]
GO

