USE [RSALogs]
GO

/****** Object:  StoredProcedure [dbo].[MergeRSACloudUsers]    Script Date: 2/1/2019 8:47:01 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[MergeRSACloudUsers] AS

DECLARE @MergeResultsTable TABLE (MergeAction VARCHAR(20));
DECLARE @Today DATE = GETDATE();
DECLARE @DeleteOlderThan DATE = DATEADD(d,-3,@Today);

MERGE RSACloudUsers T
	USING TempRSACloudUsers S
		ON S.id = T.id
	WHEN MATCHED AND EXISTS
		 (SELECT S.emailAddress, S.firstName, S.lastName, S.creationDate, S.identitySource,
			S.userStatus, S.markDeleted, S.markDeletedAt, S.markDeletedBy, S.smsNumber,
			S.voiceNumber, S.isTokenLocked, S.isSmsLocked, S.isVoiceLocked, S.lastSyncTime,
			S.AdUserName
		EXCEPT
		 SELECT T.emailAddress, T.firstName, T.lastName, T.creationDate, T.identitySource,
			T.userStatus, T.markDeleted, T.markDeletedAt, T.markDeletedBy, T.smsNumber,
			T.voiceNumber, T.isTokenLocked, T.isSmsLocked, T.isVoiceLocked, T.lastSyncTime,
			T.ADUserName)
	THEN
		UPDATE SET
			T.emailAddress = S.emailAddress,
			T.firstName = S.firstName,
			T.lastName = S.lastName,
			T.creationDate = S.creationDate,
			T.identitySource = S.identitySource,
			T.userStatus = S.userStatus,
			T.markDeleted = S.markDeleted,
			T.markDeletedAt = S.markDeletedAt,
			T.markDeletedBy = S.markDeletedBy,
			T.smsNumber = S.smsNumber,
			T.voiceNumber = S.voiceNumber,
			T.isTokenLocked = S.isTokenLocked,
			T.isSmsLocked = S.isSmsLocked,
			T.isVoiceLocked = S.isVoiceLocked,
			T.lastSyncTime = S.lastSyncTime,
			T.ADUserName = S.ADUserName,
			T.LastSeen = @Today
	WHEN NOT MATCHED BY TARGET
			THEN
				INSERT (id, emailAddress, firstName, lastName, creationDate, identitySource,
					userStatus, markDeleted, markDeletedAt, markDeletedBy, smsNumber,
					voiceNumber, isTokenLocked, isSmsLocked, isVoiceLocked, lastSyncTime, ADUserName)
				VALUES (S.id, S.emailAddress, S.firstName, S.lastName, S.creationDate, S.identitySource,
					S.userStatus, S.markDeleted, S.markDeletedAt, S.markDeletedBy, S.smsNumber,
					S.voiceNumber, S.isTokenLocked, S.isSmsLocked, S.isVoiceLocked, S.lastSyncTime,
					S.ADUserName)
	--WHEN NOT MATCHED BY SOURCE THEN DELETE
	OUTPUT $action INTO @mergeResultsTable;

DELETE
FROM RSACloudUsers
WHERE LastSeen < @DeleteOlderThan

SELECT @@ROWCOUNT AS DeletedCount,
	(SELECT COUNT(*) FROM @mergeResultsTable WHERE MergeAction = 'UPDATE') AS UpdateCount,
	(SELECT COUNT(*) FROM @mergeResultsTable WHERE MergeAction = 'INSERT') AS InsertedCount
GO

