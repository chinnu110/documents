USE [RSALogs]
GO

/****** Object:  Table [dbo].[RsaCloudUsers]    Script Date: 7/26/2019 8:26:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RsaCloudUsers](
	[id] [nvarchar](50) NOT NULL,
	[emailAddress] [nvarchar](100) NULL,
	[firstName] [nvarchar](50) NULL,
	[lastName] [nvarchar](50) NULL,
	[creationDate] [datetime] NULL,
	[identitySource] [nvarchar](50) NULL,
	[userStatus] [nvarchar](50) NULL,
	[markDeleted] [bit] NULL,
	[markDeletedAt] [datetime] NULL,
	[markDeletedBy] [nvarchar](50) NULL,
	[smsNumber] [nvarchar](50) NULL,
	[voiceNumber] [nvarchar](50) NULL,
	[isTokenLocked] [bit] NULL,
	[isSmsLocked] [bit] NULL,
	[isVoiceLocked] [bit] NULL,
	[lastSyncTime] [datetime] NULL,
	[AdUserName] [nvarchar](50) NULL,
	[LastSeen] [datetime] NULL
) ON [PRIMARY]
GO

