USE [RSALogs]
GO

/****** Object:  Table [dbo].[RSACloudAdminLogs]    Script Date: 2/1/2019 8:43:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RSACloudAdminLogs](
	[eventId] [nvarchar](64) NOT NULL,
	[eventLogDate] [datetime2](7) NULL,
	[eventType] [nvarchar](max) NULL,
	[serverURL] [nvarchar](max) NULL,
	[serverIPAddress] [nvarchar](max) NULL,
	[application] [nvarchar](max) NULL,
	[customerId] [nvarchar](max) NULL,
	[customerName] [nvarchar](max) NULL,
	[sourceIPAddress] [nvarchar](max) NULL,
	[adminUserName] [nvarchar](max) NULL,
	[adminUserRole] [nvarchar](max) NULL,
	[activityKey] [nvarchar](max) NULL,
	[activityCode] [nvarchar](max) NULL,
	[result] [nvarchar](max) NULL,
	[reasonKey] [nvarchar](max) NULL,
	[message] [nvarchar](max) NULL,
	[requiresPublish] [nvarchar](max) NULL,
	[targetObject1Id] [nvarchar](max) NULL,
	[targetObject1Name] [nvarchar](max) NULL,
	[targetObject1Type] [nvarchar](max) NULL,
	[targetObject2Id] [nvarchar](max) NULL,
	[targetObject2Name] [nvarchar](max) NULL,
	[targetObject2Type] [nvarchar](max) NULL,
 CONSTRAINT [PK_RSACloudAdminLogs] PRIMARY KEY CLUSTERED 
(
	[eventId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

