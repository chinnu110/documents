USE [RSALogs]
GO

/****** Object:  Table [dbo].[RsaCloudUserLogs]    Script Date: 2/1/2019 8:44:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RsaCloudUserLogs](
	[eventId] [nchar](64) NOT NULL,
	[eventLogDate] [datetime] NULL,
	[eventType] [nchar](16) NULL,
	[eventLevel] [nchar](32) NULL,
	[eventCategory] [nchar](64) NULL,
	[serverIPAddress] [nchar](32) NULL,
	[tenantId] [nchar](64) NULL,
	[customerName] [nchar](64) NULL,
	[userId] [nchar](64) NULL,
	[sourceIPAddress] [nchar](16) NULL,
	[eventCode] [nchar](16) NULL,
	[eventDescription] [nvarchar](max) NULL,
	[application] [nvarchar](max) NULL,
	[method] [nvarchar](max) NULL,
	[deviceName] [nvarchar](max) NULL,
	[deviceId] [nvarchar](max) NULL,
	[policyId] [nvarchar](max) NULL,
	[policyName] [nvarchar](max) NULL,
	[authenticationDetails] [nvarchar](max) NULL,
	[assuranceLevel] [nvarchar](max) NULL,
 CONSTRAINT [PK_RsaCloudUserLogs] PRIMARY KEY CLUSTERED 
(
	[eventId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

