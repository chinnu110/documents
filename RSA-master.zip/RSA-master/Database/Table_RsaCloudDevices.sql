USE [RSALogs]
GO

/****** Object:  Table [dbo].[RSACloudDevices]    Script Date: 2/1/2019 8:44:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RSACloudDevices](
	[id] [bigint] NOT NULL,
	[name] [nvarchar](50) NULL,
	[userId] [nvarchar](50) NULL,
	[osType] [nvarchar](50) NULL,
	[capabilities] [nvarchar](50) NULL,
	[registeredDate] [datetime] NULL,
	[lastUsedDate] [datetime] NULL,
	[ADUserName] [nvarchar](50) NULL,
 CONSTRAINT [PK_RSACloudDevices] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

