USE [RSALogs]
GO

/****** Object:  View [dbo].[RsaUsersWithDevices]    Script Date: 2/1/2019 8:46:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[RsaUsersWithDevices] AS


SELECT U.ADUserName UserName, u.emailAddress EmailAddress, U.firstName FirstName, U.lastName LastName,
	U.id RsaId,	U.CreationDate CreationDate, U.userStatus CloudUserStatus, U.lastSyncTime LastSyncTime,
	D.Name PhoneName, D.osType PhoneOS, D.capabilities PhoneCapabilities, D.registeredDate PhoneRegistered, 
	D.lastUsedDate PhoneLastUsed, T.userenabled AmUserEnabled, T.badpasswordcount AmBadPasswordCount,
	DATEADD(Hour, DATEDIFF(hour, GETUTCDATE(), GETDATE()), T.lastfailedlogon) AmLastFailedLogin,
	T.mustchangepassword AmMustChangePin, T.userislockedout AmLockedOut,
	DATEADD(Hour, DATEDIFF(hour, GETUTCDATE(), GETDATE()), T.userlockoutexpire) AmLockoutExpires,
	DATEADD(Hour, DATEDIFF(hour, GETUTCDATE(), GETDATE()), T.userlockouttime) AmUserLockedOutAt,
	T.tokenid AmTokenId, T.tokenenabled AmTokenEnabled, 
	DATEADD(Hour, DATEDIFF(hour, GETUTCDATE(), GETDATE()), T.pinchanged) AmPinLastChanged, 
	DATEADD(Hour, DATEDIFF(hour, GETUTCDATE(), GETDATE()), T.tokenassigned)  AmTokenAssigned,
	DATEADD(Hour, DATEDIFF(hour, GETUTCDATE(), GETDATE()), T.tokenexpires) AmTokenExpires,
	DATEADD(Hour, DATEDIFF(hour, GETUTCDATE(), GETDATE()), t.tokencreated) AmTokenCreated,
	CASE
		WHEN D.osType LIKE 'ios%' THEN 'iPhone'
		WHEN D.osType LIKE 'ANDROID%' THEN 'Android'
		WHEN D.osType IS NOT NULL THEN 'Other'
		ELSE NULL
	END PhoneType
FROM RSACloudUsers U
	LEFT JOIN RsaCloudDevices D
		ON U.id = D.userId
	LEFT JOIN RSATokens T
		ON U.ADUserName = T.username
WHERE T.id IS NOT NULL
	OR D.id IS NOT NULL


GO

