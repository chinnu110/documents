USE [RSALogs]
GO

/****** Object:  View [dbo].[RSAUserEvents]    Script Date: 2/1/2019 8:46:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[RSAUserEvents] AS 
select * from [dbo].[RsaCloudUsers] AS U
LEFT JOIN [dbo].[RsaCloudUserLogs] AS L on U.emailAddress = l.userId






GO

