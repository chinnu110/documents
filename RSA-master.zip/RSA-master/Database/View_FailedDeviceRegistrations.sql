USE [RSALogs]
GO

/****** Object:  View [dbo].[FailedDeviceRegistrations]    Script Date: 2/1/2019 8:45:39 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[FailedDeviceRegistrations] AS

SELECT F.email email, F.lastFailedDate LastFailedDate, U.ADUserName AdUserName
FROM RSACloudUsers U
	RIGHT JOIN 
	(SELECT UserID email, MAX(eventLogDate) LastFailedDate
		FROM RsaCloudUserLogs
		WHERE EventCode = 3002
		GROUP BY UserID ) F
	ON U.emailAddress = F.email
GO

