USE [RSALogs]
GO

/****** Object:  Table [dbo].[RunLogs]    Script Date: 2/7/2019 4:45:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RunLogs](
	[StartTime] [datetime] NOT NULL,
	[EndTime] [datetime] NOT NULL,
	[ScriptName] [nvarchar](50) NOT NULL,
	[Successful] [bit] NOT NULL,
	[Skipped] [bigint] NULL,
	[Added] [bigint] NULL,
	[Updated] [bigint] NULL,
	[Deleted] [bigint] NULL,
	[Errors] [bigint] NULL,
	[LogText] [text] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

