USE [RSALogs]
GO

/****** Object:  StoredProcedure [dbo].[MergRSACloudDevices]    Script Date: 2/1/2019 8:47:17 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[MergRSACloudDevices] AS



DECLARE @MergeResultsTable TABLE (MergeAction VARCHAR(20));

MERGE RSACloudDevices T
	USING TempRSACloudDevices S
		ON S.id = T.id
	WHEN MATCHED AND EXISTS
		 (SELECT S.id, S.name, S.userID, S.osType, S.capabilities,
			S.registeredDate, S.lastUsedDate, S.AdUserName
		EXCEPT
		 SELECT T.id, T.name, T.userID, T.osType, T.capabilities,
			T.registeredDate, T.lastUsedDate, T.ADUserName)
	THEN
		UPDATE SET
			T.id = S.id,
			T.name = S.name,
			T.userID = S.userID,
			T.osType = S.osType,
			T.capabilities = S.capabilities,
			T.registeredDate = S.registeredDate,
			T.lastUsedDate = S.lastUsedDate,
			T.ADUserName = S.ADUserName
	WHEN NOT MATCHED BY TARGET
			THEN
				INSERT (id, name, userID, osType, capabilities, registeredDate, lastUsedDate, ADUserName)
				VALUES (S.id, S.name, S.userID, S.osType, S.capabilities, S.registeredDate,
					S.lastUsedDate, S.ADUserName)
	WHEN NOT MATCHED BY SOURCE THEN DELETE
	OUTPUT $action INTO @mergeResultsTable;

SELECT (SELECT COUNT(*)	FROM @mergeResultsTable WHERE MergeAction = 'DELETE') AS DeletedCount,
	(SELECT COUNT(*) FROM @mergeResultsTable WHERE MergeAction = 'UPDATE') AS UpdateCount,
	(SELECT COUNT(*) FROM @mergeResultsTable WHERE MergeAction = 'INSERT') AS InsertedCount
GO

