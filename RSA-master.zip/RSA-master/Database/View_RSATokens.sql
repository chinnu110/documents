USE [RSALogs]
GO

/****** Object:  View [dbo].[RSATokens]    Script Date: 2/1/2019 8:45:58 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[RSATokens] AS
SELECT *
FROM OPENQUERY(AUTHMANAGER, '
	SELECT u.id, u.identity_src_key LDAPPath, u.loginuid UserName, u.last_updated_on LastUpdated, u.enable_flag UserEnabled, u.fail_password_count BadPasswordCount,
		u.fail_password_date LastFailedLogon, u.change_password_flag MustChangePassword, u.lockout_flag UserIsLockedOut, u.expire_lockout_date UserLockoutExpire,
		u.administrator_flag IsAdministrator, u.lockout_time_stamp UserLockoutTime, t.serial_number TokenID, t.is_enabled TokenEnabled, t.pin_modified_date PinChanged,
		t.token_assigned_date TokenAssigned, t.token_shutdown_date TokenExpires, t.token_start_date TokenCreated
	FROM db.rsa_rep.am_token t
		RIGHT JOIN db.rsa_rep.ims_principal_data u
			ON t.principal_id = u.id
	')
GO

