# RSA
RSA Support Scripts


Get-Logs: Script to pull RSA logs from the cloud and 1) save them in a SQL table and 2) Upload them to Splunk

