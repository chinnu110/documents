﻿$ConfFile = "$env:USERPROFILE\airwatch.conf"

Function create-InputLabel{
    Param(
        [parameter(Mandatory=$true)]
        [String]
        $Text,
        [parameter(Mandatory=$true)]
        [Int]
        $entry
    )
    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size(10,(20+(30*$entry))) 
    $objLabel.Size = New-Object System.Drawing.Size(80,20) 
    $objLabel.Text = $Text

    return $objLabel
}

Function create-InputBox{
    Param(
        [parameter(Mandatory=$false)]
        [Bool]
        $hidden = $false,
        [parameter(Mandatory=$true)]
        [Int]
        $entry
    )
    if ($hidden) {
        $objTextBox = New-Object System.Windows.Forms.MaskedTextBox
        $objTextBox.PasswordChar = '*'
    }
    else {
        $objTextBox = New-Object System.Windows.Forms.TextBox 
    }
    $objTextBox.Location = New-Object System.Drawing.Size(90,(20+(30*$entry))) 
    $objTextBox.Size = New-Object System.Drawing.Size(260,20)
    
    return $objTextBox
}

Function Load-Config{
    Param(
        [parameter(Mandatory=$true)]
        [String]
        $file
    )

    $loadedData = Get-Content $file | ConvertFrom-JSON

    $secpasswd = ConvertTo-SecureString $loadedData.Password
    $credentials = New-Object System.Management.Automation.PSCredential ($loadedData.UserName, ($loadedData.Password | ConvertTo-SecureString))
    
    return @{
        Url = $loadedData.Url
        TenantCode = $loadedData.TenantCode
        Credentials = $credentials
    }
}

Function Save-Config{
    Param(
        [parameter(Mandatory=$true)]
        [String]
        $file,
        [parameter(Mandatory=$true)]
        [HashTable]
        $data
    )

    $data = @{
        Url = $data.Url
        Password = $data.Credentials.Password | ConvertFrom-SecureString
        UserName = $data.Credentials.UserName
        TenantCode = $data.TenantCode
    }

    Set-Content $file ($data | ConvertTo-JSON)
}

Function Validate-Devices{
    Param(
        [parameter(Mandatory=$false)]
        [Array]
        $deviceList
    )

    if ($deviceList.Length -eq 0) {
        return $false
    }

    foreach ($entry in $deviceList) {
        if ($entry.Trim() -notmatch "^[0-9a-zA-Z]{12}$") {
            return $false
        }
    }
    return $true
}

Function AW-Test{
    Param(
        [parameter(Mandatory=$true)]
        [String]
        $url
    )
    
    $response = Invoke-WebRequest -Uri $url -Headers @{Accept='application/json';version=1} -Method GET
    if ($response.StatusCode -ne 200) {
        return $false
    }
    else {
        return $true
    }
}

Function Delete-Devices {
    Param(
        [parameter(Mandatory=$true)]
        [HashTable]
        $data
    )

    Save-Config -file $ConfFile -data $data

    $headers = @{
        Accept = 'application/json'
        version = 1
        'aw-tenant-code' = $data.TenantCode
    }

    $results = @()

    foreach ($entry in $data.Devices) {
        $result = @{
            Device = $entry.Trim()
        }
        Write-Host "Deleting "$result.Device
        try {
            $response = Invoke-WebRequest -Uri ($data.Url + '/api/mdm/devices?searchBy=Serialnumber&id=' + $result.Device) -Headers $headers -Method DELETE -Credential $data.Credentials
        } catch {
            $response = $_.Exception
        }
        
        if ($response.StatusCode -eq 204) {
            $result.Status = 'Success'
        }
        else {
            $result.Status = 'Failed'
            $result.Message = $response.Message
            $result.Code = $response.Response.StatusCode.value__
        }
        $results += $result
    }

    $output = ""
    foreach ($result in $results) {
        if ($result.Status -like 'Success') {
            $output += ($result.Device + ": Success`n")
        }
        else {
            $output += ($result.Device + ': ' + $result.Message + "`n")
        }
    }

    $done = [System.Windows.Forms.MessageBox]::Show($output , "Results")

}

if (Test-Path $ConfFile) {
    $data = Load-Config -file $ConfFile
}
else {
    $data = $null
}

$formPass = $false

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

$objForm = New-Object System.Windows.Forms.Form 
$objForm.Text = "AirWatch Credentials"
$objForm.Size = New-Object System.Drawing.Size(380,380) 
$objForm.StartPosition = "CenterScreen"

$objForm.KeyPreview = $True
$objForm.Add_KeyDown({
    if ($_.KeyCode -eq "Escape"){
        $objForm.Close()
    }
})

$ErrorProvider = New-Object System.Windows.Forms.ErrorProvider

Function Verify-Form{
    Param(
        [parameter(Mandatory=$true)]
        [HashTable]
        $data
    )

    if($data.Url -notmatch "^https?:\/\/[\w\.\-]+$") {
        $ErrorProvider.SetError($data.Url, "Entry AirWatch console base url (i.e. http://awconsole.example.com)");
        return $false
    }
    elseif ((AW-Test -url $data.Url) -eq $false) {
        $ErrorProvider.SetError($objTextForm1, "Error connecting to AirWatch api, verify url (i.e. http://awconsole.example.com)");
        return $false
    }
    elseif ($false -eq (Validate-Devices -deviceList $data.Devices)) {
        $ErrorProvider.SetError($objTextForm5, "Error in device list (Serial Numbers are expected to be 12 characters long using only numbers and letters)");
        return $false
    }
    else {
        return $true
    }
}
$OKButton = New-Object System.Windows.Forms.Button
$OKButton.Location = New-Object System.Drawing.Size(200,310)
$OKButton.Size = New-Object System.Drawing.Size(75,23)
$OKButton.Text = "OK"
$OKButton.Add_Click({
    $tempDevices = $objTextForm5.Text -Split [Environment]::NewLine
    $secpasswd = ConvertTo-SecureString $objTextForm3.Text -AsPlainText -Force
    $credentials = New-Object System.Management.Automation.PSCredential ($objTextForm2.Text, $secpasswd)
    $data = @{
        Url = $objTextForm1.Text
        TenantCode = $objTextForm4.Text
        Credentials = $credentials
        Devices = @()
    }
    foreach ($device in $tempDevices) {
        if ($device -ne '') {
            $data.Devices += $device
        }
    }
    $formPass = Verify-Form -data $data
    if ($formPass -eq $true) {
        Delete-Devices $data

        $objForm.Close()
    }
})
$objForm.Controls.Add($OKButton)


$CancelButton = New-Object System.Windows.Forms.Button
$CancelButton.Location = New-Object System.Drawing.Size(280,310)
$CancelButton.Size = New-Object System.Drawing.Size(75,23)
$CancelButton.Text = "Cancel"
$CancelButton.Add_Click({
    $objForm.Close()
})
$objForm.Controls.Add($CancelButton)

$objLabel = New-Object System.Windows.Forms.Label
$objLabel.Location = New-Object System.Drawing.Size(10,20) 
$objLabel.Size = New-Object System.Drawing.Size(280,20) 
$objLabel.Text = "Enter credentials below:"
$objForm.Controls.Add($objLabel) 

$objTextLabel1 = create-InputLabel -entry 1 -Text 'AirWatch URL: '
$objForm.Controls.Add($objTextLabel1) 

$objTextForm1 = create-InputBox -entry 1 -hidden $False
if($data -ne $null) {$objTextForm1.Text = $data.Url}
$objForm.Controls.Add($objTextForm1)

$objTextLabel2 = create-InputLabel -entry 2 -Text 'UserName: '
$objForm.Controls.Add($objTextLabel2) 

$objTextForm2 = create-InputBox -entry 2 -hidden $False
if($data -ne $null) {$objTextForm2.Text = $data.Credentials.UserName}
$objForm.Controls.Add($objTextForm2)

$objTextLabel3 = create-InputLabel -entry 3 -Text 'Password: '
$objForm.Controls.Add($objTextLabel3) 

$objTextForm3 = create-InputBox -entry 3 -hidden $True
if($data -ne $null) {$objTextForm3.Text = $data.Credentials.GetNetworkCredential().Password}
$objForm.Controls.Add($objTextForm3)

$objTextLabel4 = create-InputLabel -entry 4 -Text 'Tenant Code: '
$objForm.Controls.Add($objTextLabel4) 

$objTextForm4 = create-InputBox -entry 4 -hidden $False
if($data -ne $null) {$objTextForm4.Text = $data.TenantCode}
$objForm.Controls.Add($objTextForm4)

$objTextLabel5 = New-Object System.Windows.Forms.Label
$objTextLabel5.Location = New-Object System.Drawing.Size(10,(20+(30*5))) 
$objTextLabel5.Size = New-Object System.Drawing.Size(340,20) 
$objTextLabel5.Text = 'Serial Numbers: (One per line)'
$objForm.Controls.Add($objTextLabel5)

$objTextForm5 = New-Object System.Windows.Forms.TextBox 
$objTextForm5.Location = New-Object System.Drawing.Size(10,190) 
$objTextForm5.Size = New-Object System.Drawing.Size(340,100)
$objTextForm5.AcceptsReturn = $true
$objTextForm5.AcceptsTab = $false
$objTextForm5.Multiline = $true
$objTextForm5.ScrollBars = 'Both'
$objForm.Controls.Add($objTextForm5)

$objForm.Topmost = $True

$objForm.Add_Shown({$objForm.Activate()})
$formResults = $objForm.ShowDialog()