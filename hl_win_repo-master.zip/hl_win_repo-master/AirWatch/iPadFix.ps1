﻿Function create-InputLabel{
    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size(10,(20+(30*$args[0]))) 
    $objLabel.Size = New-Object System.Drawing.Size(80,20) 
    $objLabel.Text = $args[1]

    return $objLabel
}

Function create-InputBox{
    if ($args[1]) {
        $objTextBox = New-Object System.Windows.Forms.MaskedTextBox
        $objTextBox.PasswordChar = '*'
    }
    else {
        $objTextBox = New-Object System.Windows.Forms.TextBox 
    }
    $objTextBox.Location = New-Object System.Drawing.Size(90,(20+(30*$args[0]))) 
    $objTextBox.Size = New-Object System.Drawing.Size(260,20)
    
    return $objTextBox
}

Function Get-FileName($initialDirectory)
{   
 [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") |
 Out-Null

 $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
 $OpenFileDialog.initialDirectory = $initialDirectory
 $OpenFileDialog.filter = "All files (*.*)| *.*"
 $OpenFileDialog.ShowDialog() | Out-Null
 $OpenFileDialog.filename
} #end function Get-FileName

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

$objForm = New-Object System.Windows.Forms.Form 
$objForm.Text = "AirWatch Credentials"
$objForm.Size = New-Object System.Drawing.Size(400,320) 
$objForm.StartPosition = "CenterScreen"

$objForm.KeyPreview = $True
$objForm.Add_KeyDown({
    if ($_.KeyCode -eq "Enter" -or $_.KeyCode -eq "Escape"){
        $objForm.Close()
    }
})

$OKButton = New-Object System.Windows.Forms.Button
$OKButton.Location = New-Object System.Drawing.Size(220,240)
$OKButton.Size = New-Object System.Drawing.Size(75,23)
$OKButton.Text = "OK"
$OKButton.Add_Click({$objForm.Close()})
$objForm.Controls.Add($OKButton)

$CancelButton = New-Object System.Windows.Forms.Button
$CancelButton.Location = New-Object System.Drawing.Size(300,240)
$CancelButton.Size = New-Object System.Drawing.Size(75,23)
$CancelButton.Text = "Cancel"
$CancelButton.Add_Click({$objForm.Close()})
$objForm.Controls.Add($CancelButton)

$objLabel = New-Object System.Windows.Forms.Label
$objLabel.Location = New-Object System.Drawing.Size(10,20) 
$objLabel.Size = New-Object System.Drawing.Size(280,20) 
$objLabel.Text = "Enter credentials below:"
$objForm.Controls.Add($objLabel) 

$objTextLabel1 = create-InputLabel 1 'AirWatch URL: '
$objForm.Controls.Add($objTextLabel1) 

$objTextForm1 = create-InputBox 1 $False
$objForm.Controls.Add($objTextForm1)

$objTextLabel2 = create-InputLabel 2 'UserName: '
$objForm.Controls.Add($objTextLabel2) 

$objTextForm2 = create-InputBox 2 $False
$objForm.Controls.Add($objTextForm2)

$objTextLabel3 = create-InputLabel 3 'Password: '
$objForm.Controls.Add($objTextLabel3) 

$objTextForm3 = create-InputBox 3 $True
$objForm.Controls.Add($objTextForm3)

$objTextLabel4 = create-InputLabel 4 'Tenant Code: '
$objForm.Controls.Add($objTextLabel4) 

$objTextForm4 = create-InputBox 4 $False
$objForm.Controls.Add($objTextForm4)

$objTextLabel5 = create-InputLabel 5 'CSV File: '
$objForm.Controls.Add($objTextLabel5) 

$objTextForm5 = create-InputBox 5 $False
$objForm.Controls.Add($objTextForm5)

$BrowseButton = New-Object System.Windows.Forms.Button
$BrowseButton.Location = New-Object System.Drawing.Size(275,200)
$BrowseButton.Size = New-Object System.Drawing.Size(75,23)
$BrowseButton.Text = "Browse"
$BrowseButton.Add_Click({
    $objTextForm5.Text = Get-FileName
    $objTextForm5.Refresh();
})
$objForm.Controls.Add($BrowseButton)

$objForm.Topmost = $True

$objForm.Add_Shown({$objForm.Activate()})
[void]$objForm.ShowDialog()

$url = $objTextForm1.Text

$headers = @{}

$headers.add('Accept','application/json')
$headers.add('version','1')
$headers.add('aw-tenant-code',$objTextForm4.Text)

$secpasswd = ConvertTo-SecureString $objTextForm3.Text -AsPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential ($objTextForm2.Text, $secpasswd)

$response = Invoke-WebRequest -Uri ($url + '/AirWatch/Login') -Method GET -SessionVariable WebSession

$form = $response.Forms[0]

$form.fields['UserName'] = $credentials.UserName
$form.fields['Password'] = $credentials.GetNetworkCredential().Password

$loginResponse = Invoke-WebRequest -Uri ($url + $form.Action) -WebSession $WebSession -Method POST -Body $form.Fields

$loginContent = ConvertFrom-Json -InputObject $loginResponse.Content

$WebSession.Headers.Add('X-Requested-With','XMLHttpRequest')

$devices = Import-Csv $objTextForm5.Text

foreach ($entry in $devices) {
    $postData = ConvertTo-Json -InputObject @{"AssetNumber"=$entry.number;"DeviceFriendlyName"=$entry.store+"-"+$entry.number;"IsSupervised"=$True}
    $response = Invoke-WebRequest -Uri ($url + '/api/mdm/devices?searchBy=Serialnumber&id=' + $entry.sn) -Headers $headers -Method PUT -Credential $credentials -Body $postData -ContentType application/json

    $response = Invoke-WebRequest -Uri ($url + '/api/mdm/devices?searchBy=Serialnumber&id=' + $entry.sn) -Headers $headers -Method GET -Credential $credentials

    $device = ConvertFrom-JSON -InputObject $response.Content


    $editDeviceResponse = Invoke-WebRequest -Uri ($url + '/AirWatch/Devices/DeviceDetails.EditDevice/' + $device.Id.Value) -WebSession $WebSession -Method GET

    $editForm = $editDeviceResponse.Forms[0]

    $editForm.Fields['SetFriendlyNameAsDeviceName'] = $true
    $editForm.Fields['DeviceOwnershipId'] = 1
    $editForm.Fields['DeviceCategory'] = ($editDeviceResponse.ParsedHtml.body.getElementsByTagName('select') | Where {$_.getAttributeNode('id').Value -eq 'DeviceCategory'}).value

    $editDeviceSubmitResponse = Invoke-WebRequest -Uri ($url + $editForm.Action) -WebSession $WebSession -Method POST -Body $editForm.Fields
}