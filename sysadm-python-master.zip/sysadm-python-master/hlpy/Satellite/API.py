import logging
import requests
import json
from .. import core

logger = logging.getLogger(__name__)
logger.addHandler(core._NullHandler())


class SatelliteAPIException(Exception):
	"""
	generic satellite api exception
	"""
	pass


class SatelliteAPI(object):
	def __init__(self,
				 server='https://localhost',
				 user=None,
				 password=None,
				 session=None,
				 timeout=None,
				 insecure=False):
		"""
		TODO: Add usage comment
		"""
		
		self.logger = logging.getLogger(__name__)
		if session:
			self.session = session
		else:
			self.session = requests.Session()
			if insecure:
				self.session.verify = False
		
		# Default headers for all requests
		self.session.headers.update({
			'Content-Type': 'application/json-rpc',
			'User-Agent': 'python/satpy',
			'Cache-Control': 'no-cache'
		})
		
		self.session.auth = (user, password)
		
		self.timeout = timeout
		
		self.url = server
		self.logger.info("Katello Server Endpoint: %s", self.url)
	
	def get(self, resource, **kwargs):
		
		url = "{0}{1}".format(self.url,resource)
		
		response = self.session.get(
			url,
			timeout=self.timeout,
			params=kwargs
		)
		
		# NOTE: Getting a 412 response code means the headers are not in the
		# list of allowed headers.
		response.raise_for_status()
		
		if not len(response.text):
			raise SatelliteAPIException("Received empty response")
		
		try:
			response_json = json.loads(response.text)
		except ValueError:
			raise SatelliteAPIException(
				"Unable to parse json: %s" % response.text
			)
		self.logger.debug("Response Body: \n%s", json.dumps(response_json,
													 indent=4,
													 separators=(',', ': ')))
		
		return response_json
	
	def post(self, resource, **kwargs):
		
		url = "{0}{1}".format(self.url,resource)
		
		response = self.session.post(
			url,
			timeout=self.timeout,
			data=json.dumps(kwargs)
		)
		
		# NOTE: Getting a 412 response code means the headers are not in the
		# list of allowed headers.
		response.raise_for_status()
		
		if not len(response.text):
			raise SatelliteAPIException("Received empty response")
		
		try:
			response_json = json.loads(response.text)
		except ValueError:
			raise SatelliteAPIException(
				"Unable to parse json: %s" % response.text
			)
		self.logger.debug("Response Body: \n%s", json.dumps(response_json,
													 indent=4,
													 separators=(',', ': ')))
		
		return response_json
	
	def __getattr__(self, attr):
		"""
		Dynamically create an object class (ie: activation_keys)
		"""
		if attr == 'docker':
			path = '/docker/api/v2/'
		elif attr == 'bootdisk':
			path = '/bootdisk/'
		elif attr == 'foreman' or attr == 'foreman_tasks':
			path = '/foreman_tasks/api/'
		elif attr == 'katello':
			path = '/katello/api/'
		else:
			path = '/api/'
			return SatelliteAPIObjectClass(attr, self, path)
		return SatelliteAltAPIObjectClass(attr, self, path)


class SatelliteAltAPIObjectClass(object):
	def __init__(self, name, parent, path):
		self.name = name
		self.parent = parent
		self.path = path
	
	def __getattr__(self,attr):
		return SatelliteAPIObjectClass(attr, self.parent, self.path)

class SatelliteAPIObjectClass(object):
	def __init__(self, name, parent, path):
		self.name = name
		self.parent = parent
		self.path = path
	
	def __getattr__(self, attr):
		"""
		Dynamically call a method (ie: get)
		"""
		
		def fn(*args, **kwargs):
			
			if len(args) > 2:
				raise SatelliteAPIException(u"Error: too many positional args")
			
			if len(args) > 0:
				subpath = self.name + '/' + '/'.join(map(str,args))
			else:
				subpath = self.name
			
			if attr == "get":
				results = []
				temp_kwargs = kwargs.copy()
				if 'page' not in kwargs:
					temp_kwargs['page'] = 1
				while True:
					page_results = self.parent.get(self.path + subpath, **temp_kwargs)
					if 'results' not in page_results or 'page' in kwargs:
						results = page_results
						break
					else:
						results.extend(page_results['results'])
					
					if len(page_results['results']) < page_results['per_page']:
						break
					temp_kwargs['page']+=1
						
			elif attr == "post" or attr == "create":
				results = self.parent.post(self.path + subpath, **kwargs)['results']
			else:
				raise SatelliteAPIException(u"Error: Unsupported request type {0}".format(attr))
			
			if 'results' in results:
				return results['results']
			else:
				return results
		
		return fn
