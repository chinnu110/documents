from .. import core

import logging
logging.basicConfig(level=logging.ERROR)
logger = logging.getLogger(__name__)
logger.addHandler(core._NullHandler())

import argparse
from .API import SatelliteAPI

def getHosts(satellite_api,**kwargs):
	return ' '.join(map(lambda x: x['name'], satellite_api.hosts.get()))
	
def getErrata(satellite_api,errata_restrict_installable=False,errata_restrict_applicable=True,**kwargs):
	return '\n'.join(map(lambda x: x['title'], satellite_api.katello.errata.get(**kwargs)))

def configArgParser(parser):
	parser.add_argument('--server',help='Base URI of Red Hat Satellite server')
	parser.add_argument('--user',help='Username')
	parser.add_argument('--password',help='Password')
	parser.add_argument('--insecure',action='store_true',help='Disable SSL Certificate Verification')
	
	subparsers = parser.add_subparsers(help='sub-command help')
	
	parser_host = subparsers.add_parser('host', help='Hosts')
	subparsers_host = parser_host.add_subparsers(help='Host Sub-Command help')
	parser_host_get = subparsers_host.add_parser('get')
	parser_host_get.set_defaults(func=getHosts)
	
	parser_errata = subparsers.add_parser('errata', help='Errata sub-command help')
	subparsers_errata = parser_errata.add_subparsers(help='Errata Sub-Command help')
	parser_errata_get = subparsers_errata.add_parser('get')
	parser_errata_get.set_defaults(func=getErrata)
	parser_errata_get.add_argument('--installable',action='store_true',dest='errata_restrict_installable')

def main():
	logging.debug('Creating Argument parser')
	parser = argparse.ArgumentParser(description='Hobby Lobby Satellite Script')
	
	configArgParser(parser)
	
	args = parser.parse_args()
	satellite_api = SatelliteAPI(server=args.server,user=args.user,password=args.password,insecure=args.insecure)
	
	print args.func(satellite_api, **vars(args))

if __name__ == '__main__':
	main()