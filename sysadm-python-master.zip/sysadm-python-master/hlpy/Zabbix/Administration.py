from .. import core
import json
try:
	import cPickle as pickle
except Exception, e:
	import pickle

from glob import glob

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.addHandler(core._NullHandler())

import random

def upsertUserGroups(api, groups=[],**kwargs):
	logger.warn('WIP')
	for group in groups:
		server_group = api.usergroup.get(filter={"name":group}, output=['groupid'])
		group_config = groups[group].copy()
		group_config['name'] = group
		if 'permissions' in group_config:
			del group_config['permissions']
			group_config['rights'] = translateUserGroupPermissions(api,groups[group]['permissions'])
		if len(server_group) == 0:
			server_group = [{'usrgrpid':api.usergroup.create(**group_config)['usrgrpids'][0]}]
			logger.info('Created user group {}'.format(group_config['name']))
		else:
			api.usergroup.update(usrgrpid=server_group[0]['usrgrpid'],**group_config)
			logger.info('Updated user group {}'.format(group_config['name']))

def cleanUserGroups(api, groups=[]):
	for group in api.usergroup.get(output=['name']):
		if group['name'] not in groups:
			api.usergroup.delete(usrgrpids=group['usrgrpid'])
			logger.info('Deleted user group {}'.format(group['name']))

def translateUserGroupPermissions(api,permissions):
	output_permissions = []
	for entry in permissions:
		if '*' in entry['name']:
			hostgroups = api.hostgroup.get(search={'name':entry['name']},output=['groupid'],searchWildcardsEnabled=True)
		else:
			hostgroups = api.hostgroup.get(filter={'name':entry['name']},output=['groupid'])
		if len(hostgroups) > 0:
			for hostgroup in hostgroups:
				output_permissions.append({'id':hostgroup['groupid'],'permission':entry['permissions']})
		else:
			logger.warn('Unable to find hostgroup {}'.format(entry['name']))
	return output_permissions

def upsertUsers(api, users=[], **kwargs):
	logger.warn('WIP')
	for user in users:
		user_config = users[user].copy()
		user_config['alias'] = user
		if 'usrgrps' in user_config:
			del user_config['usrgrps']
			user_config['usrgrps'] = translateUserUserGroups(api,users[user]['usrgrps'])
		if 'user_medias' in user_config:
			del user_config['user_medias']
			user_config['user_medias'] = translateUserMedia(api,users[user]['user_medias'])
		server_user = api.user.get(filter={"alias":user}, output=['userid'])
		if len(server_user) == 0:
			if 'passwd' not in user_config:
				user_config['passwd'] = ''.join(random.sample("abcdefghijklmnopqrstuvwxyz01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()?",16)) 
			server_user = [{'userid':api.user.create(**user_config)['userids'][0]}]
			logger.info('Created user {}'.format(user))
		else:
			api.user.update(userid=server_user[0]['userid'], **user_config)
			logger.info('Updated user {}'.format(user))

def cleanUsers(api,users):			
	for user in api.user.get(output=['alias']):
		if user['alias'] not in users:
			api.user.delete(userid=user['userid'])
			logger.info('Deleted user {}'.format(user['alias']))

def translateUserUserGroups(api,usrgrps):
	output_usrgrps = []
	for entry in usrgrps:
		usergroups = api.usergroup.get(filter={'name':entry},output=['usrgrpid'])
		if len(usergroups) == 1:
			output_usrgrps.append({'usrgrpid':usergroups[0]['usrgrpid']})
		else:
			logger.warn('Unable to find user group {}'.format(entry))
	logger.debug(output_usrgrps)
	return output_usrgrps

def translateUserMedia(api,user_medias):
	output_user_medias = []
	for entry in user_medias:
		new_entry = entry.copy()
		del new_entry['name']
		medias = api.mediatype.get(filter={'description':entry['name']},output=['mediatypeid'])
		if len(medias) == 1:
			new_entry.update({'mediatypeid':medias[0]['mediatypeid']})
			output_user_medias.append(new_entry)
	return output_user_medias

def upsertMediaTypes(api,mediatypes):
	logger.warn('WIP')
	for mediatype in mediatypes:
		mediatype_config = mediatypes[mediatype].copy()
		mediatype_config['description'] = mediatype
		server_mediatype = api.mediatype.get(filter={'description':mediatype},output=['mediatypeid'])
		if len(server_mediatype) == 0:
			server_mediatype = [{'mediatypeid':api.mediatype.create(**mediatype_config)['mediatypeid'][0]}]
			logger.info('Created media type {}'.format(mediatype))
		else:
			api.mediatype.update(mediatypeid=server_mediatype[0]['mediatypeid'], **mediatype_config)
			logger.info('Updated media type {}'.format(mediatype))

def cleanMediaTypes(api,mediatypes):
	for mediatype in api.mediatype.get(output=['description']):
		if mediatype['description'] not in mediatypes:
			api.mediatype.delete(mediatype['mediatypeid'])
			logger.info('Deleted media type {}'.format(mediatype['description']))
