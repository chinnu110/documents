from .. import core
import json

from glob import glob

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.addHandler(core._NullHandler())
from sys import argv

import argparse
from pyzabbix import ZabbixAPI

from . import Configuration, Administration

def genApiConnection(args):
	logger.info(args)
	
	zabbix_api = ZabbixAPI(args.server)
	
	if args.basic:
		zabbix_api.session.auth = (args.user,args.password)
	
	if args.insecure:
		zabbix_api.session.verify = False
	
	zabbix_api.login(args.user,args.password)
	
	return zabbix_api

def configureServer(api, files=[],clean=False,**kwargs):
	logger.warn('WIP')
	config_files = []
	config = {}
	for file in files:
		config_files+=glob(file)
	
	logger.info(config_files)
	
	for config_file in config_files:
		with open(config_file) as handle:
			new_config = json.loads(handle.read())
			config = core.update_dict(config,new_config)
	
	logger.info(config)
	
	if 'groups' in config:
		Configuration.insertGroups(api,groups=config['groups'])
		if clean:
			Configuration.cleanGroups(api,groups=config['groups'])
	
	if 'usergroups' in config:
		Administration.upsertUserGroups(api,groups=config['usergroups'])
		if clean:
			Administration.cleanUserGroups(api,groups=config['usergroups'])
	
	if 'users' in config:
		Administration.upsertUsers(api,users=config['users'])
		if clean:
			Administration.cleanUsers(api,users=config['users'])
	
	if 'mediatypes' in config:
		Administration.upsertMediaTypes(api,mediatypes=config['mediatypes'])
		if clean:
			Administration.cleanMediaTypes(api,mediatypes=config['mediatypes'])
	
	if 'actions_auto_registration' in config:
		Configuration.upsertActions(api,config['actions_auto_registration'],2)
		if clean:
			Configuration.cleanActions(api,config['actions_auto_registration'],2)
	
	if 'actions_trigger' in config:
		Configuration.upsertActions(api,config['actions_trigger'],0)
		if clean:
			Configuration.cleanActions(api,config['actions_trigger'],0)
		
	if 'actions_discovery' in config:
		Configuration.upsertActions(api,config['actions_discovery'],1)
		if clean:
			Configuration.cleanActions(api,config['actions_discovery'],1)

def configArgParser(parser):
	parser.set_defaults(connect=genApiConnection)
	parser.add_argument('--server',help='Base URI of Zabbix Web Console')
	parser.add_argument('--user',help='Username')
	parser.add_argument('--password',help='Password')
	parser.add_argument('--basic',action='store_true',help='Use basic authentication')
	parser.add_argument('--insecure',action='store_true',help='Disable SSL Certificate Verification')
	
	subparsers = parser.add_subparsers(help='sub-command help')
	
	parser_template = subparsers.add_parser('template', help='Templates')
	subparsers_template = parser_template.add_subparsers(help='Template Sub-Command help')
	
	parser_template_export = subparsers_template.add_parser('export')
	parser_template_export.set_defaults(func=Configuration.genTemplateConfig)
	parser_template_export.add_argument('--group',help='Template Hostgroup name (supports * as wildcard)',nargs='*')
	parser_template_export.add_argument('--groupid',help='Template Hostgroup ID',dest='groupids',nargs='*',type=int)
	
	parser_template_import = subparsers_template.add_parser('import')
	parser_template_import.set_defaults(func=Configuration.importTemplateConfig)
	parser_template_import.add_argument('--file',help='Template configuration file to import (supports * as wildcard)',nargs='*',dest='files')
	
	parser_server = subparsers.add_parser('server', help='Server configuration')
	parser_server.add_argument('--file',help='Configuration file location')
	subparsers_server = parser_server.add_subparsers(help='Server Sub-Command help')
	
	parser_server_configure = subparsers_server.add_parser('configure')
	parser_server_configure.set_defaults(func=configureServer)
	parser_server_configure.add_argument('--file',help='Template configuration file to import (supports * as wildcard)',dest='files',action='append')
	parser_server_configure.add_argument('--clean',help='Delete unmatched items',action='store_true')

def main():
	logger.debug('Creating Argument parser')
	parser = argparse.ArgumentParser(description='Hobby Lobby Zabbix Script')
	
	configArgParser(parser)
	
	args = parser.parse_args()
	
	zabbix_api = args.connect(args)
	
	logger.debug(vars(args))
	args.func(zabbix_api, **vars(args))
	

if __name__ == '__main__':
	main()
