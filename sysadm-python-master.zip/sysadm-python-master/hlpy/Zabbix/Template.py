import logging

class _NullHandler(logging.Handler):
	def emit(self, record):
		pass

logger = logging.getLogger(__name__)
logger.addHandler(_NullHandler())

try:
	import zapi.ZabbixAPI
except Exception, e:
	logger.exception("Failed to import ZabbixAPI Library.  Ensure that pyzabbix is installed.  (i.e. pip install pyzabbix)")

class ZabbixTemplateException(Exception):
	pass

class Template(object):
	def __init__(self,
				name=None,
				id=None,
				zabbix_api=None):
		
		"""
		Parameters:
			name: Template name
			id: Template id (overrides name if set)
			zabbix_api: Instance of ZabbixAPI Class
		"""
		
		if zabbix_api is None:
			self.zabbix_api = ZabbixAPI()
			self.zabbix_api.login('Admin','zabbix')
		else:
			self.zabbix_api = zabbix_api
		
		if id is not None:
			self.id = id
		else:
			self.id = self.getTemplateID(name=name)
	
	def getTemplateID(self, name, zabbix_api=None):
		if zabbix_api is none:
			zabbix_api = self.zabbix_api
		
		templates = zabbix_api.template.get(filter={'host':name},output=['templateid'])
		if len(templates) == 1:
			return templates[0]['templateid']
		
		templates = zabbix_api.template.get(filter={'name':name},output=['templateid'])
		if len(templates) == 1:
			return templates[0]['templateid']
		
		templates = zabbix_api.template.get(search={'host':name},output=['templateid'])
		if len(templates) == 1:
			return templates[0]['templateid']
		
		templates = zabbix_api.template.get(search={'name':name},output=['templateid'])
		if len(templates) == 1:
			return templates[0]['templateid']
		
		raise ZabbixTemplateException("Unable to find template with name {}".format(name))
	
	def promoteTemplate(self, template, target_api, target_id=None):
		if target_id is None:
			try:
				target_id = self.getTemplateID(name=template['host'], zabbix_api=target_api)
			except ZabbixTemplateException:
				logging.info('Unable to determine target template id, creating a new template')
		
		if target_id is None:
			return target_api.template.create(**template)
		else:
			template['templateid'] = target_id
			return target_api.template.update(**template)