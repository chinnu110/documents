from .. import core
import json
try:
	import cPickle as pickle
except Exception, e:
	import pickle

from glob import glob

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.addHandler(core._NullHandler())

import_rules = {
    'applications': {
        'createMissing': True,
		'deleteMissing': True
    },
    'discoveryRules': {
        'createMissing': True,
        'updateExisting': True,
		'deleteMissing': True
    },
    'graphs': {
        'createMissing': True,
        'updateExisting': True,
		'deleteMissing': True
    },
    'groups': {
        'createMissing': True
    },
    'hosts': {
        'createMissing': True,
        'updateExisting': True
    },
    'images': {
        'createMissing': True,
        'updateExisting': True
    },
    'items': {
        'createMissing': True,
        'updateExisting': True,
		'deleteMissing': True
    },
    'maps': {
        'createMissing': True,
        'updateExisting': True
    },
    'screens': {
        'createMissing': True,
        'updateExisting': True
    },
    'templateLinkage': {
        'createMissing': True,
    },
    'templates': {
        'createMissing': True,
        'updateExisting': True
    },
    'templateScreens': {
        'createMissing': True,
        'updateExisting': True,
		'deleteMissing': True
    },
    'triggers': {
        'createMissing': True,
        'updateExisting': True,
		'deleteMissing': True
    },
    'valueMaps': {
        'createMissing': True,
        'updateExisting': True
    },
    'httptests': {
        'createMissing': True,
        'updateExisting': True,
        'deleteMissing': True
    }
}

def exportTemplate(api,**kwargs):
	logger.info(kwargs)
	results = api.configuration.export(format='json',options={'templates':[kwargs['templateid']]})
	
	results = json.loads(results)
	
	del results['zabbix_export']['date']
	
	return results

def importTemplate(api,name='',templates={},completed=[]):
	if name not in templates:
		logger.error('Missing export for template {}. continuing'.format(name))
		return False
	if name in completed:
		logger.info('Skipping {}.  Already imported'.format(name))
		return True
	for parent_template in templates[name]['zabbix_export']['templates'][0]['templates']:
		importTemplate(api,name=parent_template['name'],templates=templates,completed=completed)
	logger.info('Importing {}'.format(name))
	api.confimport('json', json.dumps(templates[name]),import_rules)
	logger.info('Updated script')
	completed.append(name)

def importTemplateConfig(api, files=[], **kwargs):
	template_files = []
	for file in files:
		template_files+=glob(file)
	
	logger.info(template_files)
	
	templates = {}
	
	for template_file in template_files:
		with open(template_file) as handle:
			template = json.loads(handle.read())
		templates[template['zabbix_export']['templates'][0]['name']] = template
	
	logger.info(len(templates))
	
	imported_templates = []
	
	for template in templates:
		importTemplate(api,name=template,templates=templates,completed=imported_templates)

def genTemplateConfig(api, groupids=[],group=[],**kwargs):
	if group is not None:
		groups = api.hostgroup.get(output=['groupid'],search={'name':group},searchWildcardsEnabled=True)
	else:
		groups = []
	if groupids is None:
		groupids = []
	logger.info(group)
	logger.info(groupids)
	logger.info(groups)
	templates = api.template.get(output=['templateid'],groupids=groupids+map(lambda x: x['groupid'],groups))
	for template in templates:
		template_config = exportTemplate(api,templateid=template['templateid'])
		saveFile = open('{}.json'.format(template_config['zabbix_export']['templates'][0]['name']),'wb')
		saveFile.write(json.dumps(template_config, indent=4, sort_keys=True))
	
	return templates

def insertGroups(api, groups):
	logger.warn('WIP')
	server_groups = map(lambda x: x['name'],api.hostgroup.get(output=['name']))
	for group in groups:
		if group not in server_groups:
			api.hostgroup.create({'name':group})
			logger.info('Created hostgroup {}'.format(group))
		else:
			logger.info('Hostgroup {} already exists'.format(group))

def cleanGroups(api, groups):
	logger.warn('WIP')
	for group in api.hostgroup.get(output=['name','groupid']):
		if group['name'] not in groups:
			api.hostgroup.delete(group['groupid'])
			logger.info('Deleted host group {}'.format(group['name']))

def upsertActions(api,actions,type):
	logger.warn('WIP')
	for action in actions:
		server_action = api.action.get(filter={"name":action,"eventsource":type})
		new_action_config = {
			"esc_period": "1h"
		}
		if type == 2:
			new_action_config["filter"] = {
				"evaltype":0
			}
		action_config = core.update_dict(new_action_config,actions[action])
		action_config['name'] = action
		if 'operations' in action_config:
			del action_config['operations']
			action_config['operations']=translateActionOperations(api,actions[action]['operations'])
		if 'recovery_operations' in action_config:
			del action_config['recovery_operations']
			action_config['recovery_operations']=translateActionOperations(api,actions[action]['recovery_operations'])
		if 'acknowledge_operations' in action_config:
			del action_config['acknowledge_operations']
			action_config['acknowledge_operations']=translateActionOperations(api,actions[action]['acknowledge_operations'])
		if len(server_action) == 0:
			action_config = core.update_dict(new_action_config,action_config)
			server_action = [{"actionid":api.action.create(eventsource=type,**action_config)['actionids'][0]}]
			logger.info('Created action {}'.format(action))
		else:
			api.action.update(actionid=server_action[0]['actionid'],**action_config)
			logger.info('Updated action {}'.format(action))

def cleanActions(api,actions,type):			
	for action in api.action.get(filter={'eventsource':type},output=['name']):
		if action['name'] not in actions:
			api.action.delete(action['actionid'])
			logger.info('Deleted action {}'.format(action['name']))

def translateActionOperations(api,operations):
	output_action_operations = []
	for operation in operations:
		if operation['operationtype'] == 0:
			operation_config = {
				"opmessage_grp":[]
			}
			operation_config = core.update_dict(operation_config,operation)
			if 'usergroups' in operation_config:
				del operation_config['usergroups']
				for group in operation['usergroups']:
					operation_config['opmessage_grp'].extend(map(lambda x: {'usrgrpid':x['usrgrpid']},api.usergroup.get(filter={'name':group},output=['usrgrpid'])))
		
		if operation['operationtype'] == 4:
			operation_config = {
				"opgroup": []
			}
			operation_config = core.update_dict(operation_config,operation)
			if 'groups' in operation_config:
				del operation_config['groups']
				for group in operation['groups']:
					operation_config['opgroup'].extend(map(lambda x: {'groupid':x['groupid']}, api.hostgroup.get(filter={'name':group},output=['groupid'])))
		
		if operation['operationtype'] == 6:
			operation_config = {
				"optemplate": []
			}
			operation_config = core.update_dict(operation_config,operation)
			if 'templates' in operation_config:
				del operation_config['templates']
				for template in operation['templates']:
					operation_config['optemplate'].extend(map(lambda x: {'templateid':x['templateid']}, api.template.get(filter={'host':template},output=['templateid'])))
		
		if operation['operationtype'] == 11 or operation['operationtype'] == 12:
			operation_config = operation.copy()
		
		output_action_operations.append(operation_config)
	
	return output_action_operations
