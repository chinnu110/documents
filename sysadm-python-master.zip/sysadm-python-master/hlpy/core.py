import logging
import collections
from os.path import expanduser

class _NullHandler(logging.Handler):
	def emit(self, record):
		pass

def update_dict(d, u):
	new_dict = d.copy()
	for k, v in u.items():
		if isinstance(v, collections.Mapping):
			default = v.copy()
			default.clear()
			r = update_dict(new_dict.get(k, default), v)
			new_dict[k] = r
		else:
			new_dict[k] = v
	return new_dict

class config(object):
	def __init__(self, name='hlpy', path='~/.config'):
		self.config_file = expanduser("{}/{}.json".format(path,name))