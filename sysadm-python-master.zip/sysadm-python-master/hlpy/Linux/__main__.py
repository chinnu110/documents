from .. import core

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.addHandler(core._NullHandler())

import argparse
try:
	import ConfigParser as configparser
except:
	import configparser

#import requests
import os
import stat
import getpass

import subprocess
from glob import glob
import re

ip_arg_regex = re.compile('^(?:(gw|gateway|int|interface|ip|address)=)?([^=]+)$')
ip_regex = '((?:\d{1,3}\.){3}\d{1,3})(?:\/((?:3[0-2])|(?:[1-2])?[1-9]))?'

disk_arg_regex = re.compile('^(?:(type|bind|func|function|disk|device|dev)=)?([^=]+)$')

def checkIPArg(value):
	test = ip_arg_regex.match(value)
	if test:
		key = test.groups()[0]
		new_value = test.groups()[1]
		if key is None or key == 'ip' or key == 'address':
			if validateIPAddress(new_value):
				return 'address={}'.format(new_value)
			else:
				raise argparse.ArgumentTypeError('{} is an invalid ip address value. (Ex. 10.100.37.98 [gw=10.100.37.1])'.format(new_value))
		elif key == 'gw' or key == 'gateway':
			if validateIPAddress(new_value):
				return 'gateway={}'.format(new_value)
			else:
				raise argparse.ArgumentTypeError('{} is an invalid ip address for gateway. (Ex. gw=10.100.37.1)'.format(new_value))
		elif key == 'int' or key == 'interface':
			return 'interface={}'.format(new_value)
	else: raise argparse.ArgumentTypeError('{} is an invalid option for ip argument (address,gateway,interface)'.format(value))

def validateIPAddress(value):
	if re.match('^'+ip_regex+'$',value):
		return value
	else:
		return False

class IPAddressAction(argparse.Action):
	def __call__(self, parser, namespace, values, option_string=None):
		logger.info(values)
		output_value = {}
		for entry in values:
			entry_split = entry.split('=')
			if entry_split[0] == 'address':
				address_parse = re.match(ip_regex,entry_split[1])
				if address_parse:
					output_value['address'] = address_parse.group(1)
					output_value['cidr'] = address_parse.group(2)
			else: output_value[entry_split[0]] = entry_split[1]
		output_array = getattr(namespace,self.dest)
		logger.info(output_array)
		if not output_array:
			output_array = []
		
		output_array.append(output_value)
		logger.info(output_array)
		setattr(namespace, self.dest, output_array)

def checkDiskArg(value):
	test = disk_arg_regex.match(value)
	if test:
		key = test.group(1)
		new_value = test.group(2)
		if key is None or key in ['disk','device','dev']:
			return 'device={}'.format(new_value)
		elif key == 'type':
			return 'type={}'.format(new_value)
		elif key == 'bind':
			return 'bind={}'.format(new_value)
		elif key == 'func' or key == 'function':
			return 'function={}'.format(new_value)
	else: raise argparse.ArgumentTypeError('{} is an invalid option for disk argument (type,bind,function)'.format(value))

class DiskAction(argparse.Action):
	def __call__(self, parser, namespace, values, option_string=None):
		logger.info(values)
		output_value = {}
		for entry in values:
			entry_split = entry.split('=')
			output_value[entry_split[0]] = entry_split[1]
		
		if 'type' not in output_value:
			output_value['type'] = 'app'
		if 'function' not in output_value:
			output_value['function'] = 'data'
		output_array = getattr(namespace,self.dest)
		logger.info(output_array)
		if not output_array:
			output_array = []
		
		output_array.append(output_value)
		logger.info(output_array)
		setattr(namespace, self.dest, output_array)

class ProcessException(Exception):
	"""Base class for HLProcess Exceptions"""
	pass

class NonZeroExit(ProcessException):
	"""Default class for non-zero exit code exception for HLProcess"""
	pass

class HLProcess(object):
	ip_match = re.compile(ip_regex)
	
	def __init__(self,*args):
		self.history = []
	
	def Run(self,args,stdin=None):
		results = subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,stdin=subprocess.PIPE)
		out, err = results.communicate(input=stdin)
		output = (results.returncode,' '.join(args),out,err)
		self.history.append(output)
		logger.debug(output)
		if output[0] != 0:
			raise NonZeroExit(output)
		return (out,err,)

def configureLinux(process,args):
	if args.hostname is not None:
		results = setHostname(process,args.hostname)
	if args.ip is not None:
		for entry in args.ip:
			setIPAddress(process,entry)
	if args.satellite:
		registerSatellite(process,args.satellite_server,args.satellite_org,args.satellite_environment)
	if args.disk is not None:
		for entry in args.disk:
			configureDisks(process,entry)
	
	if args.ad:
		joinActiveDirectory(process,args.ad_ou,args.ad_subou,args.ad_env,args.ad_user,args.ad_sudoers)
	
def setHostname(process,hostname):
	current_hostname = process.Run(['hostname'])[0].rstrip()
	if current_hostname != hostname:
		logger.info('Changing hostname from {} to {}'.format(current_hostname,hostname))
		process.Run(['hostnamectl','set-hostname',hostname])
	else:
		logger.info('Hostname already set to {}'.format(hostname))
	
	with open('/etc/hosts','r') as f:
		hosts_file = f.read()
	
	if current_hostname not in hosts_file:
		logger.warn('No entry for previous hostname in /etc/hosts')
		return
	
	hosts_file.replace(current_hostname,hostname)
	
	with open('/etc/hosts','w') as f:
		f.write(hosts_file)
	
	logger.info('Updated /etc/hosts with new ip address')

def setIPAddress(process,ip):
	if 'interface' not in ip:
		for line in process.Run(['nmcli','-f','NAME','con','show'])[0].split('\n'):
			if line.strip() == 'NAME':
				continue
			ip['interface'] = line.strip()
			break
	
	logger.info(ip)
	try:
		current_address_command = process.Run(['nmcli','-f','ipv4.addresses,ipv4.gateway','con','show',ip['interface']])
	except NonZeroExit, e:
		logger.error('Unable to find interface {}'.format(ip['interface']))
		logger.exception(e)
		return
	
	logger.info(current_address_command[0])
	current_ip = {}
	for line in current_address_command[0].split('\n'):
		temp = line.split(':')
		if temp[0] == 'ipv4.addresses':
			address_parse = re.match(ip_regex,temp[1].strip())
			logger.info(address_parse.groups())
			if address_parse:
				current_ip['address'] = address_parse.group(1)
				current_ip['cidr'] = address_parse.group(2)
		if temp[0] == 'ipv4.gateway':
			current_ip['gateway'] = temp[1].strip()
	
	if 'gateway' not in current_ip or 'address' not in current_ip:
		logger.error('Unable to determine ip configuration for interface {}'.format(ip['interface']))
		return
	
	if current_ip['address'] == ip['address'] and (current_ip['cidr'] == ip['cidr'] or ip['cidr'] == None):
		logger.info('IP Address already set to {}'.format(ip['address']))
		return
	
	try:
		process.Run(['nmcli','con','mod',ip['interface'],'ipv4.addr',ip['address']+'/'+ip['cidr'] if ip['cidr'] != None else ip['address']+'/'+current_ip['cidr'],'ipv4.gateway',ip['gateway'] if 'gateway' in ip else current_ip['gateway']])
	except NonZeroExit, e:
		logger.error('Failed updating ip address on interface {}'.format(ip['interface']))
		return
	
	logger.info('Updated ip address on interface {} from {}/{} to {}.  Restart of network interface required for changes to take effect.'.format(ip['interface'],current_ip['address'],current_ip['cidr'],ip['address']+'/'+ip['cidr'] if ip['cidr'] != None else ip['address']))
	
	with open('/etc/hosts','r') as f:
		hosts_file = f.read()
	
	if current_ip['address'] not in hosts_file:
		logger.warn('No entry for previous address in /etc/hosts')
		return
	
	hosts_file.replace(current_ip['address'],ip['address'])
	
	with open('/etc/hosts','w') as f:
		f.write(hosts_file)
	
	logger.info('Updated /etc/hosts with new ip address')

def registerSatellite(process,server,org,environment):
	try:
		katello_ca_pkg_res = process.Run(['yum','list','-q','installed','katello-ca-consumer-*'])
		katello_ca_pkg_name = re.search('(katello\-ca\-consumer\-([\w\.]+)(?:\.noarch))\s+[0-9\.\-]+\s+installed',katello_ca_pkg_res[0])
	except NonZeroExit, e:
		katello_ca_pkg_name = False
	if katello_ca_pkg_name:
		if not server == katello_ca_pkg_name.group(2):
			logger.info('Removing package {} from incorrect satellite instance'.format(katello_ca_pkg_name.group(1)))
			katello_ca_pkg_rem_res = process.Run(['yum','-y','remove',katello_ca_pkg_name.group(1)])
			katello_ca_pkg_ins_res = process.Run(['yum','-y','localinstall','http://{}/pub/katello-ca-consumer-latest.noarch.rpm'.format(server)])
		else:
			logger.info('Katello CA package already installed')
	else:
		katello_ca_pkg_ins_res = process.Run(['yum','-y','localinstall','http://{}/pub/katello-ca-consumer-latest.noarch.rpm'.format(server)])
	
	sm_cfg = configparser.ConfigParser(allow_no_value=True)
	sm_cfg.read('/etc/rhsm/rhsm.conf')
	
	if server != sm_cfg.get('server','hostname'):
		logger.error('Subscription-manager is configured with the incorrect server ({})'.format(sm_cfg.get('server','hostname')))
		return
	
	try:
		sm_status_res = (0,['subscription-manager','status'],process.Run(['subscription-manager','status'])[0],'',)
		sm_att_res = process.Run(['subscription-manager','attach','--auto'])
		logger.info('Server already registered to {} with subscription manager'.format(server))
	except NonZeroExit, e:
		sm_status_res = e.message
		if re.search('Overall Status\: Unknown',sm_status_res[2]):
			try:
				logger.info('Registering to {} with subscription manager'.format(server))
				sm_reg_res = (0,['subscription-manager','register','--org',org,'--activationkey','RHEL_{}'.format(environment)],process.Run(['subscription-manager','register','--org',org,'--activationkey','RHEL_{}'.format(environment)]),'')
			except NonZeroExit, e:
				sm_reg_res = e.message
				if re.search('Unable to find available subscriptions for all your installed products.',sm_reg_res[2]):
					logger.info('Running auto-attach to pull applicable subscriptions')
					sm_att_res = process.Run(['subscription-manager','attach','--auto'])
		else:
			logger.error(e.message)
		
	process.Run(['subscription-manager','repos','--enable','rhel-7-server-rh-common-rpms','--enable','rhel-7-server-rpms'])
	
	if not os.path.exists('/root/.ssh'):
		process.Run(['mkdir','-p','/root/.ssh'])
	
	if os.path.exists('/root/.ssh/authorized_keys'):
		with open('/root/.ssh/authorized_keys','r') as f:
			hosts_file = f.read()
	else:
		hosts_file = ''
	
	r = process.Run(['curl','https://{}:9090/ssh/pubkey'.format(server)])
	ssh_key = r[0]
	logger.info(ssh_key)
	
	if ssh_key not in hosts_file:
		hosts_file +='\n{}'.format(ssh_key)
		with open('/root/.ssh/authorized_keys','w') as f:
			f.write(hosts_file)
		logger.info('Updated authorized keys with ssh key from satellite')
	
	try:
		katello_agent_pkg_res = process.Run(['yum','list','-q','installed','katello-agent'])
	except NonZeroExit, e:
		process.Run(['yum','install','-y','katello-agent'])
		logger.info('Installed katello agent')
	
def configureDisks(process,disk):
	disk_check = process.Run(['file','-sL',disk['device']])
	if disk_check[0] == '{}: cannot open (No such file or directory)\n'.format(disk['device']):
		logger.error('{} does not exist'.format(disk['device']))
		return
	elif disk_check[0] != '{}: data\n'.format(disk['device']):
		if not (('swap file' in disk_check[0] and disk['type'] == 'swap') or ('Linux Logical Volume Manager' in disk_check[0])):
			logger.error('{} isn\'t partitioned as expected'.format(disk['device']))
			return
	else:
		if disk['type'] == 'swap':
			process.Run(['mkswap',disk['device']])
			logger.info('Formatted {} as a swap disk'.format(disk['device']))
		else:
			process.Run(['pvcreate',disk['device']])
			logger.info('Formatted {} as lvm physical volume'.format(disk['device']))
	
	if disk['type'] == 'swap':
		with open('/proc/swaps','r') as f:
			swaps_file = f.read()
		if re.search('{}\s.*'.format(disk['device']),swaps_file):
			logger.info('{} already mounted as swap'.format(disk['device']))
		else:
			process.Run(['swapon',disk['device']])
			logger.info('Enabled {} as swap device.'.format(disk['device']))
		with open('/etc/fstab','r') as f:
			fstab_file = f.read()
		fstab_check = re.findall('^(?:UUID=)?\"?([^\s\#]+?|/dev/[^\s])\"?\s+swap',fstab_file,re.MULTILINE)
		entry_found = False
		for entry in fstab_check:
			if '/dev/' in entry:
				if entry == disk['device']:
					logger.info('{} already in fstab'.format(disk['device']))
					entry_found = True
			else:
				if os.readlink('/dev/disk/by-uuid/{}'.format(entry)).split('/')[2] == disk['device'].split('/')[2]:
					logger.info('{} already in fstab'.format(disk['device']))
					entry_found = True
		if not entry_found:
			uuid = process.Run(['blkid',disk['device'],'-o','value'])[0].split('\n')[0]
			logger.info(uuid)
			fstab_file +='\nUUID="{}"\tswap\tswap\tdefaults\t0\t0'.format(uuid)
			logger.info(fstab_file)
			with open('/etc/fstab','w') as f:
				f.write(fstab_file)
			logger.info('Added entry for {} in fstab'.format(disk['device']))
	else:
		pv = process.Run(['pvdisplay',disk['device']])
		vg = re.search('VG Name +([^\s]+)',pv[0])
		if vg is None:
			process.Run(['vgcreate','{}_vol_grp'.format(disk['type']),disk['device']])
			logger.info('Created volume group {}_vol_grp using {}'.format(disk['type'],disk['device']))
			pv = process.Run(['pvdisplay',disk['device']])
			vg = re.search('VG Name +([^\s]+)',pv[0])
		else:
			logger.info('Disk {} is part of volume group {}'.format(disk['device'],vg.group(1)))
		lv = re.search('LV Name +([^\s]+)',process.Run(['lvdisplay',vg.group(1)])[0])
		if lv is None:
			process.Run(['lvcreate',vg.group(1),'-n','lv_{}'.format(disk['function']),'-l','100%FREE'])
			logger.info('Created logical volume lv_{} on volume group {}_vol_grp'.format(disk['function'],vg.group(1)))
			lv = re.search('LV Name +([^\s]+)',process.Run(['lvdisplay',vg.group(1)])[0])
		else:
			logger.info('Logical volume {} already exists'.format(lv.group(1)))
		
		partition_check = process.Run(['file','-sL','/dev/mapper/{}-{}'.format(vg.group(1),lv.group(1))])
		
		if '/dev/mapper/{}-{}: data\n'.format(vg.group(1),lv.group(1)) == partition_check[0]:
			process.Run(['mkfs.xfs','/dev/mapper/{}-{}'.format(vg.group(1),lv.group(1))])
			logger.info('Formatted {} as xfs'.format('/dev/mapper/{}-{}'.format(vg.group(1),lv.group(1))))
		elif 'XFS' in partition_check[0]:
			logger.info('{} already formated as xfs'.format('/dev/mapper/{}-{}'.format(vg.group(1),lv.group(1))))
			
		with open('/etc/fstab','r') as f:
			fstab_file = f.read()
		fstab_check = re.findall('^/dev/mapper/{}\-{}'.format(vg.group(1),lv.group(1)),fstab_file,re.MULTILINE)
		try:
			os.lstat('/mnt/{}{}'.format(disk['type'],disk['function']))
		except OSError, e:
			os.makedirs('/mnt/{}{}'.format(disk['type'],disk['function']))
			logger.info('created {}'.format('/mnt/{}{}'.format(disk['type'],disk['function'])))
		if len(fstab_check) > 0:
			logger.info('/dev/mapper/{}-{} already has entry in fstab'.format(vg.group(1),lv.group(1)))
		else:
			fstab_file += '\n/dev/mapper/{}-{}\t/mnt/{}{}\txfs\tdefaults\t0\t0\n'.format(vg.group(1),lv.group(1),disk['type'],disk['function'])
			with open('/etc/fstab','w') as f:
				f.write(fstab_file)
			logger.info('Added entry for {} in fstab'.format('/dev/mapper/{}-{}'.format(vg.group(1),lv.group(1))))
			process.Run(['mount','/mnt/{}{}'.format(disk['type'],disk['function'])])

def joinActiveDirectory(process,ou,subou,env,user,sudoers):
	try:
		package_check = process.Run(['yum','list','installed','sssd','realmd','oddjob','samba-common-tools','nfs-utils','cifs-utils'])
		logger.info('SSSD required packages already installed')
	except NonZeroExit, e:
		process.Run(['yum','-y','install','sssd','realmd','oddjob','oddjob-mkhomedir','samba-common-tools','nfs-utils','cifs-utils'])
	
	try:
		process.Run(['realm','discover','HobbyLobby.corp'])
	except NonZeroExit, e:
		try:
			process.Run(['systemctl','restart','realmd'])
			logger.info('Restarting realm to try to avoid restarting dbus')
		except NonZeroExit, e:
			process.Run(['systemctl','restart','dbus','realmd'])
			logger.warn('Restarted dbus and realmd to allow discovering domain.  This will require a reboot of the os after configuration is completed.')
	
	realm_check = process.Run(['realm','list'])
	if realm_check[0] == '':
		if ou == 'Apps':
			if subou is None or env is None:
				logger.error('sub-ou and env must be specified when joining using Apps ou')
				return
			pwd = getpass.getpass()
			process.Run(['realm','join','hobbylobby.corp','-U',user,'--computer-ou','OU={},OU={},OU={},OU=Tier 1 RHEL,DC=HobbyLobby,DC=corp'.format(env,subou,ou)],stdin=pwd)
		else:
			pwd = getpass.getpass()
			process.Run(['realm','join','hobbylobby.corp','-U',user,'--computer-ou','OU={},OU=Tier 1 RHEL,DC=HobbyLobby,DC=corp'.format(ou)],stdin=pwd)
		logger.info('Joined server to domain')
	else:
		logger.info('Server already joined to active directory')
	
	sssd_cfg = configparser.ConfigParser(allow_no_value=True)
	sssd_cfg.read('/etc/sssd/sssd.conf')
	
	try:
		sssd_cfg.get('sssd','default_domain_suffix')
	except configparser.NoOptionError, e:
		sssd_cfg.set('sssd','default_domain_suffix','hobbylobby.corp')
		with open('/etc/sssd/sssd.conf','wb') as f:
			sssd_cfg.write(f)
		logger.info('Added default domain to sssd config')
	
	try:
		sssd_cfg.get('domain/HobbyLobby.corp','ad_hostname')
	except configparser.NoOptionError, e:
		sssd_cfg.set('domain/HobbyLobby.corp','ad_hostname',process.Run(['hostname','-f'])[0])
		with open('/etc/sssd/sssd.conf','wb') as f:
			sssd_cfg.write(f)
		logger.info('Set ad hostname in sssd config')
	
	try:
		dyndns_enabled = sssd_cfg.getboolean('domain/HobbyLobby.corp','dyndns_update')
	except configparser.NoOptionError, e:
		dyndns_enabled = False
	
	if not dyndns_enabled:
		sssd_cfg.set('domain/HobbyLobby.corp','dyndns_update','true')
		sssd_cfg.set('domain/HobbyLobby.corp','dyndns_refresh_interval','43200')
		sssd_cfg.set('domain/HobbyLobby.corp','dyndns_update_ptr','true')
		sssd_cfg.set('domain/HobbyLobby.corp','dyndns_ttl','3600')
		with open('/etc/sssd/sssd.conf','wb') as f:
			sssd_cfg.write(f)
		logger.info('Enabled Dynamic DNS updates in sssd config')
	
	with open('/etc/fstab','r') as f:
		fstab_file = f.read()
	
	if not re.search('^hlisi01nfs:/NFS_Users\s+/home\s+',fstab_file,re.MULTILINE):
		fstab_file +='\nhlisi01nfs:/NFS_Users\t/home\tnfs\tnfsvers=3\t0\t0'
		with open('/etc/fstab','w') as f:
			f.write(fstab_file)
		logger.info('Added entry for /home in fstab')
	
	sudoers_entries = ['admins']
	if sudoers is not None:
		sudoers_entries.extend(sudoers)
	
	for entry in sudoers_entries:
		try:
			os.stat('/etc/sudoers.d/sg_rhel_{}'.format(entry))
		except OSError, e:
			if e.strerror == 'No such file or directory':
				with open('/etc/sudoers.d/sg_rhel_{}'.format(entry),'wb') as f:
					f.write('%sg_rhel_{}@HobbyLobby.corp	All=(ALL)	ALL'.format(entry))
				logger.info('Created sudoers entry for sg_rhel_{}'.format(entry))

def configArgParser(parser):
	parser.set_defaults(connect=HLProcess)
	
	subparsers = parser.add_subparsers(help='sub-command help')
	
	parser_configure = subparsers.add_parser('configure',help='Configure hobby lobby linux server')
	parser_configure.set_defaults(func=configureLinux)
	
	parser_configure.add_argument('--hostname',help='Hostname to set')
	
	parser_configure.add_argument('--ip',help='IP Address to set',nargs='+',type=checkIPArg,action=IPAddressAction)
	
	parser_configure.add_argument('--satellite',help='Register with satellite',action='store_true')
	parser_configure.add_argument('--satellite-server',help='Override satellite server/capsule for registrations',default='hlsatellite02.hobbylobby.corp')
	parser_configure.add_argument('--satellite-org',help='Satellite Organization',default='HL')
	parser_configure.add_argument('--satellite-environment',help='Satellite Lifecycle environment',default='PROD')
	
	parser_configure.add_argument('--disk',help='Configure disk storage',nargs='+',type=checkDiskArg,action=DiskAction)
	
	parser_configure.add_argument('--ad',help='Join active directory domain',action='store_true')
	parser_configure.add_argument('--ad-ou',help='Active directory ou to join server',default='Operations',choices=['Operations','AD Management','Development','Security','Security-Splunk','Apps'])
	parser_configure.add_argument('--ad-subou',help='Active directory sub-ou required by Apps OU',choices=['Customer','SAP','Store','Web'])
	parser_configure.add_argument('--ad-env',help='Lifecycle environment to use when joining to Apps ou')
	parser_configure.add_argument('--ad-user',help='Username to use when joining active directory')
	parser_configure.add_argument('--ad-sudoers',help='Active directory security groups to add to sudoers',nargs='+')
	

def main():
	logger.debug('Creating argument parser')
	parser = argparse.ArgumentParser(description='Hobby Lobby Red Hat Enterprise Linux script')
	
	configArgParser(parser)
	
	args = parser.parse_args()
	
	process = args.connect(args)
	
	logger.debug(vars(args))
	args.func(process, args)
	
if __name__ == '__main__':
	main()