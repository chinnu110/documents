from . import core

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.addHandler(core._NullHandler())

import argparse
from Zabbix import __main__ as Zabbix
from Satellite import __main__ as Satellite

def configArgParser(parser):
	subparsers = parser.add_subparsers(help='sub-command help')
	
	parser_zabbix = subparsers.add_parser('zbx', help='Zabbix')
	Zabbix.configArgParser(parser_zabbix)
	
	parser_satellite = subparsers.add_parser('sat', help='Satellite')
	Satellite.configArgParser(parser_satellite)

def main():
	parser = argparse.ArgumentParser(description='Hobby Lobby Script')
	
	configArgParser(parser)
	
	print(parser.prog)
	args = parser.parse_args()
	
	connection = args.connect(args)
	
	print(vars(args))
	args.func(connection, **vars(args))

if __name__ == '__main__':
	main()