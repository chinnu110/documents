# -*- coding: utf-8 -*-

# Learn more: https://github.com/kennethreitz/setup.py

from setuptools import setup, find_packages


with open('README.rst') as f:
    readme = f.read()

with open('LICENSE') as f:
    license = f.read()

setup(
    name='hlpy',
    version='0.1.0',
    description='HL Python Package',
	entry_points = {
		'console_scripts': [
			'hlpy = hlpy.__main__:main',
			'hlsat = hlpy.Satellite.__main__:main',
			'hlzbx = hlpy.Zabbix.__main__:main',
			'hllnx = hlpy.Linux.__main__:main'
		]
	},
    long_description=readme,
    author='HL Linux System Administrators',
    author_email='hllinuxadmins@hobbylobby.corp',
    url='http://hlgithub.hobbylobby.corp/SystemAdmins/hl-python',
    license=license,
    packages=find_packages(exclude=('tests', 'docs')),
)
