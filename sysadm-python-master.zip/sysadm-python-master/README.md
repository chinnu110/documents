# sysadm-python

```
{
	"usergroups": [
		{
			"name":"Zabbix administrators"
		},
		{
			"name":"Guests"
		},
		{
			"name":"Disabled"
		},
		{
			"name":"Enabled debug mode"
		},
		{
			"name":"No access to the frontend"
		}
	],
	"users": [
		{
			"alias":"Admin",
			"lang":"en_US",
			"usrgrps": [
				"Zabbix administrators"
			],
			"user_medias": [
			]
		},
		{
			"alias":"guest",
			"lang":"en_US",
			"usrgrps": [
				"Guests"
			]
		}
	],
	"mediatypes": [
		{
			"description":"Email",
			"type":0,
		},
		{
			"description":"Jabber",
			"type":3
		},
		{
			"description":"SMS",
			"type":2
		}
	],
	"groups": [
		"Templates",
		"Linux servers",
		"Zabbix servers",
		"Discovered hosts",
		"Virtual machines",
		"Hypervisors",
		"Templates/Modules",
		"Templates/Network Devices",
		"Templates/Operating Systems",
		"Templates/Servers Hardware",
		"Templates/Applications",
		"Templates/Databases",
		"Templates/Virtualization"
	],
	"actions_auto_registration": [
	],
	"actions_trigger": [
		{
			"name":"Report problems to Zabbix administrators"
		}
	],
	"actions_discovery": [
		{
			"name": "Auto discovery. Linux servers."
		}
	]
}
```