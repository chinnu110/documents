from flask import Flask
application = Flask(__name__)

@application.route("/")
def hello():
    return "Helloooooooo  Everyone at Hobby Lobby"

if __name__ == "__main__":
    application.run()
