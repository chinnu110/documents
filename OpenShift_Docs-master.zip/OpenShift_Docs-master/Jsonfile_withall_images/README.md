By default when ever we install openshift there are predefined images which can be found in the catalog. 
If some images have been deleted we can create them back by using a Json script (test.json)
Command to be used for creating the images is:
# oc create –f test.json –n project name
To see the list of images available 
# oc get is -n projectname
If we want to delete a specified image in the catalog :
# oc delete is python –n project name
if you want to create a individual images in the catalog we have to use only that image particular (indivdualpython.json)
# oc create –f individualpython.json –n projectname
Note: if we have specified project name as (–n openshift) the image will available in all the projects.  

