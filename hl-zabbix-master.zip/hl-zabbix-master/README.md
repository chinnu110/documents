# hl-zabbix

This project contains definition files for configuring Zabbix in for Hobby Lobby Linux environment.
The content in this project is primarily used by hlzbx which is provided by [sysadm-python](https://hlgithub.hobbylobby.corp/SystemAdmins/sysadm-python).

## JSON files

* config.json
  * common configuration accross all environments
* dev-config.json
  * dev lifecycle environment specific configuration
* qa-config.json
  * qa lifecycle environment specific configuration
* prod-config.json
  * prod lifecycle environment specific configuration

## TE files

* hl-zabbix.te
  * source used to configure zabbix agent selinux module

## template directory

Contains json exports of Zabbix Hobby Lobby Corporate templates