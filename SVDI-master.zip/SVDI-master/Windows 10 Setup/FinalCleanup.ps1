
##Delete Temp User (In case it failed earlier)
#"Removing Temp User"
#Get-WmiObject Win32_UserProfile | ? {$_.LocalPath -like "C:\Users\Temp"} | Remove-WMIObject -ErrorAction SilentlyContinue
#Remove-LocalUser Temp -Confirm:$False -ErrorAction SilentlyContinue
#
##Force .net Runtime Optimization Service
#"Optimizing .Net"
#Start-Process $Env:WINDIR\microsoft.net\framework64\v4.0.30319\ngen.exe -ArgumentList "update /force" -Wait
#
#Run CCleaner
Start-Process -FilePath "\\hlresources.hobbylobby.corp\software\SVDI\Utils\CCleaner\CCleaner64.exe" -Wait


#Clear all event logs
"Purging all even logs"
Get-WinEvent -ListLog * -Force | % { Wevtutil.exe cl $_.logname }

#Delete any Shadowcopies out there
"Deleting shadow copies"
Set-Service VSS -StartupType Manual
Start-Service VSS
Start-Process VSSAdmin.exe -ArgumentList "Delete Shadows /All /Quiet" -Wait
Stop-Service VSS
Set-Service VSS -StartupType Disabled

#Defrag C:
"Defraging C:"
Set-Service defragsvc -StartupType Manual
Start-Service defragsvc
Optimize-Volume -DriveLetter C -Defrag
Stop-Service defragsvc
Set-Service defragsvc -StartupType Disabled

#Zero out free space
Start-Process -FilePath "\\hlresources.hobbylobby.corp\software\SVDI\Utils\sdelete64.exe" -ArgumentList "/z" -Wait

#Release IP and Flush DNS
"Flushing IP"
ipconfig /Release
ipconfig /flushdns

#ShutDown
"Bye...."
shutdown -s -t 3 -f