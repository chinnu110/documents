$Source = "\\hlresources.hobbylobby.corp\software\SVDI"

#Set Time
"Setting Time"
Set-Service W32Time -StartupType Automatic
Start-Service W32Time
Set-TimeZone -Name "Central Standard Time"
w32tm /config /ManualPeerList:"10.201.0.41,10.201.0.42" /update /syncfromflags:"Manual" /Reliable:Yes
w32tm /resync

#Set Time to what it will be on the domain
w32tm /config /update /syncfromflags:"DOMHIER"

#Setup Local Admin Account
"Fixing up local admin account"
$Password = Read-Host -Prompt "Password for HLAdmin?" -AsSecureString
Rename-LocalUser -Name Administrator -NewName HLAdmin -ErrorAction SilentlyContinue
Set-LocalUser -Name HLAdmin -Password $Password -Confirm:$False -ErrorAction SilentlyContinue
Enable-LocalUser -Name HLAdmin -ErrorAction SilentlyContinue

#Install domain certificates
Import-Certificate -Filepath "\\hlresources.hobbylobby.corp\software\SVDI\Certificates\HL-ROOT-02.crt" -CertStoreLocation "Cert:\LocalMachine\Root" -Confirm:$False
Import-Certificate -Filepath "\\hlresources.hobbylobby.corp\software\SVDI\Certificates\HL-ISSUING-CA-03.crt" -CertStoreLocation "Cert:\LocalMachine\CA" -Confirm:$False
Import-Certificate -Filepath "\\hlresources.hobbylobby.corp\software\SVDI\Certificates\HL-ISSUING-CA-04.crt" -CertStoreLocation "Cert:\LocalMachine\CA" -Confirm:$False

#Enable Features
"Adding Windows features"
Add-WindowsCapability -Online -Name NetFx3~~~~ -Source D:\Sources\sxs
Enable-WindowsOptionalFeature -Online -FeatureName TFTP -NoRestart
Enable-WindowsOptionalFeature -Online -FeatureName TelnetClient -NoRestart

#Removing Features
"removing Windows features"
Remove-WindowsCapability -Online -Name Hello.Face.17658~~~~0.0.1.0Op
Remove-WindowsCapability -Online -Name App.Support.QuickAssist~~~~0.0.1.0
Disable-WindowsOptionalFeature -Online -FeatureName FaxServicesClientPackage -NoRestart -Remove
Disable-WindowsOptionalFeature -Online -FeatureName WorkFolders-Client -NoRestart -Remove

#Install Office
Start-Process -FilePath "\\hlresources.hobbylobby.corp\Software\SVDI\Apps\Office2013\Deploy-Application.exe" -Wait

#Install Chrome
"Installing Chrome"
Start-Process Msiexec.exe -ArgumentList '/i "\\hlresources.hobbylobby.corp\software\SVDI\Apps\GoogleChromeStandaloneEnterprise64.msi" /qb!' -Wait
Unregister-ScheduledTask -TaskName "GoogleUpdateTaskMachineCore" -Confirm:$False
Unregister-ScheduledTask -TaskName "GoogleUpdateTaskMachineUA" -Confirm:$False

#Install Java
"Installing Java"
Start-Process -FilePath "\\hlresources.hobbylobby.corp\software\SVDI\Apps\jre-8u201-windows-i586.exe" -ArgumentList "INSTALL_SILENT=Enable AUTO_UPDATE=Disable" -Wait
Start-Process -FilePath "\\hlresources.hobbylobby.corp\software\SVDI\Apps\jre-8u201-windows-x64.exe" -ArgumentList "INSTALL_SILENT=Enable AUTO_UPDATE=Disable" -Wait
Remove-Item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Java\Check For Updates.lnk" -Force -Confirm:$False
Remove-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run" -Name "SunJavaUpdateSched" -Force -Confirm:$False

#Install 7-Zip
"Installing 7-zip"
Start-Process -FilePath "\\hlresources.hobbylobby.corp\software\SVDI\Apps\7z1900-x64.exe" -ArgumentList "/S" -Wait

#Install Notepad++
"Installing Notepad++"
Start-Process -FilePath "\\hlresources.hobbylobby.corp\software\SVDI\Apps\npp.7.6.4.Installer.exe" -ArgumentList "/S" -Wait
Rename-Item -Path "C:\Program Files (x86)\Notepad++\updater" -NewName "updater_disabled" -Force -Confirm:$False

#Install Putty
"Installing Putty"
Start-Process Msiexec.exe -ArgumentList '/i "\\hlresources.hobbylobby.corp\software\SVDI\Apps\putty-64bit-0.70-installer.msi" /qb!'-Wait

#Install WinSCP
"Installing SCP"
Start-Process -FilePath "\\hlresources.hobbylobby.corp\software\SVDI\Apps\WinSCP-5.13.8-Setup.exe" -ArgumentList "/Silent /Norestart" -Wait
Remove-Item "C:\Users\Public\Desktop\WinSCP.lnk" -Force -Confirm:$False

#Install View Agent
Start-Process "\\HLResources\Software\SVDI\Agent\VMware-Horizon-Agent-x86_64-7.7.0-11054235.exe" -Wait -ArgumentList '/s /v"RDPCHOICE=1 VDM_VC_MANAGED_AGENT=1 VDM_IP_PROTOCOL_USAGE=IPv4 ADDLOCAL=Core,SVIAgent,V4V /qb!"'

#Run Optimization Tool
"Running VMware Optimization Tool"
Start-Process -FilePath "\\hlresources.hobbylobby.corp\software\SVDI\VMwareOSOptimizationTool\VMwareOSOptimizationTool.exe" -Wait -ArgumentList '-o -t "\\hlresources.hobbylobby.corp\software\SVDI\VMwareOSOptimizationTool\Windows 10 - Vendor 0.17.xml"'

#Create IE Shortcut for All Users
"Creating IE Shortcut"
$Shell = New-Object -ComObject Wscript.Shell
$Shortcut = $Shell.CreateShortcut("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Internet Explorer.lnk")
$Shortcut.TargetPath = "C:\Program Files\internet explorer\iexplore.exe"
$Shortcut.WorkingDirectory = "%HOMEDRIVE%%HOMEPATH%"
$Shortcut.Description = "Finds and displays information and Web sites on the Internet."
$Shortcut.Save()

#Copy over local policy
"Copy local policy over"
Copy-Item "\\hlresources.hobbylobby.corp\software\SVDI\LocalPolicy\*" "C:\Windows\System32\GroupPolicy\" -Confirm:$False -Force

#Import Clean Start menu
"Cleaning up start menu"
Import-StartLayout -LayoutPath "\\hlresources.hobbylobby.corp\software\SVDI\Windows 10 Setup\StartMenu.xml" -MountPath "C:\"


