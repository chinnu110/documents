Nginx 1.8 server and a reverse proxy server container image
========================================================

**The Nginx 1.8 container image is deprecated.**
