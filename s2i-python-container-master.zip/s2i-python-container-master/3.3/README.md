Python container image
===================

**The Python 3.3 image is deprecated.**
