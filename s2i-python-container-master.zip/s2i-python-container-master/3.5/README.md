Python 3.5 container image
===================

**The Python 3.5 image is deprecated.**
