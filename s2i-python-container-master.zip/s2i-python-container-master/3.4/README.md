Python 3.4 container image
===================

**The Python 3.4 image is deprecated.**
