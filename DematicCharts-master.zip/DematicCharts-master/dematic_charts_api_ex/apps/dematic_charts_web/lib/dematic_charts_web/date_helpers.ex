defmodule DateHelpers do
  def monday_in_the_week_of({{year, month, day}, _} = date) do
    from_monday = :calendar.day_of_the_week({year, month, day}) - 1

    {year, month, day}
    |> :calendar.date_to_gregorian_days()
    |> Kernel.-(from_monday)
    |> :calendar.gregorian_days_to_date()
  end

  def sunday_in_the_week_of({{year, month, day}, _} = date) do
    from_sunday = :calendar.day_of_the_week({year, month, day}) - 7

    {year, month, day}
    |> :calendar.date_to_gregorian_days()
    |> Kernel.-(from_sunday)
    |> :calendar.gregorian_days_to_date()
  end
end
