defmodule DematicChartsCore.Stateserver do
  use GenServer
  require Logger

  @name SS


  #####################
  ##   Client APIs   ##
  #####################


  def start_link(opts \\ []) do
    GenServer.start_link(__MODULE__, :ok, opts ++ [name: SS])
  end

  def get_data do
    GenServer.call(@name, :read)
  end

  def update(key, newvalue) do
    GenServer.cast(@name, {:update, key, newvalue})
  end



  #####################
  ## Server Callbacks ##
  #####################


  #read current state
  def handle_call(:read, _from, state) do
    {:reply, state, state}  
  end


  #update state with new data
  def handle_cast({:update, key, newvalue}, state) do

    state = update_state(state, key, newvalue)

    {:noreply, state}
  end


  def handle_info(:loop, state) do


    case DematicChartsWebWeb.Endpoint.broadcast("channel:data", "data_updated", state) do
      :ok -> :ok
      {:error, reason} -> reason |> Logger.error()
    end
      

    Process.send_after(self, :loop, 20000)  
    {:noreply, state}

  end 


  def init(:ok) do
    Process.send_after(self, :loop, 4000)   #loop
    {:ok, %{}}
  end



  #####################
  ## Helper Functions ##
  #####################


  defp update_state(state, key, newvalue) do
    newstate = case Map.has_key?(state, key) do
        true ->
            Map.replace!(state, key, newvalue)
        false ->
            Map.put_new(state, key, newvalue)
    end
    newstate
  end

end