defmodule DematicChartsCore.PutSysStatsHistory do
  defstruct WarehouseNumber: "",
            WarehouseName: "",
            Date: "",
            PutCases: "",
            ResidualCases: "",
            FullCases: "",
            TotalCasesReceived: "",
            ClosedRepacks: "",
            CasesShipped: "",
            CasesSent: ""
end
