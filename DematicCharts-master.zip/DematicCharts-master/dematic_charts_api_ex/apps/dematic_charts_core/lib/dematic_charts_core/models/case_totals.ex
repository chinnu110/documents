defmodule DematicChartsCore.CaseTotals do
  defstruct BuildingSixShippedLastYear: "",
            BuildingSixInducedLastYear: "",
            BuildingSixShippedToday: "",
            BuildingSixInducedToday: "",
            BuildingTwoShippedLastYear: "",
            BuildingTwoInducedLastYear: "",
            BuildingTwoShippedToday: "",
            BuildingTwoInducedToday: "",
            BuildingSixInducedLastWeek: "",
            BuildingSixShippedLastWeek: "",
            BuildingTwoInducedLastWeek: "",
            BuildingTwoShippedLastLastWeek: "",
            BuildingSixInducedYesterday: "",
            BuildingTwoInducedYesterday: "",
            BuildingTwoShippedYesterday: "",
            BuildingSixShippedYesterday: ""
end
