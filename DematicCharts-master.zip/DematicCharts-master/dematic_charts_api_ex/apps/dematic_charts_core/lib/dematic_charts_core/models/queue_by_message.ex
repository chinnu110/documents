defmodule DematicChartsCore.QueueByMessage do
  defstruct msg_type: "",
            num_of_msgs: "",
            oldest: "",
            newest: "",
            latency: ""
end
