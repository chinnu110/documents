defmodule DematicChartsCore.WmsMessageQueue do
  defstruct MsgId: "",
            MsgPriority: "",
            RetryCount: "",
            ResendCount: "",
            CreatedTime: "",
            UpdatedTime: "",
            PurgeTimeUtc: ""
end
