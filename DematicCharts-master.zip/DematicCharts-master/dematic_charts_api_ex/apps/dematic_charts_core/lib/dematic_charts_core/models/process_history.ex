defmodule DematicChartsCore.ProcessHistory do
  defstruct timeofday: "",
            create_count: "",
            process_count: ""
end
