defmodule DematicChartsCore.ConsumptionRate do
  defstruct create_count: "",
            consumed_count: "",
            consumption_rate: ""
end
