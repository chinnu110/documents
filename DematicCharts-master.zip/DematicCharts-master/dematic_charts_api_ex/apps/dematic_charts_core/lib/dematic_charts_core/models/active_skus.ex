defmodule DematicChartsCore.ActiveSkus do
  defstruct LocationID: "",
            SKU: "",
            PO: "",
            Distribution: "",
            ManifestID: "",
            SKUType: ""
end
