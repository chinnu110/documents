defmodule DematicChartsCore.GetConsumptionRateWorker do
    use GenServer
  
    @name GCRW


    #####################
    ##   Client APIs   ##
    ##################### 

    def start_link(opts \\ []) do
        GenServer.start_link(__MODULE__, :ok, name: {:global, :GCRW})
    end
    


    def handle_info(:loop, state) do

        #call Repo to get updated data
        {:ok, get_consumption_rate_data} = DematicChartsCore.DematicRepo.get_consumption_rate(-1)
        
        #call state server to send updated data
        DematicChartsCore.Stateserver.update(:get_consumption_rate, get_consumption_rate_data)
 
        #restart the loop after a 10 second wait
        Process.send_after(self, :loop, 30000)  
        
        {:noreply, state}

    end


    ######################
    ## Server Callbacks ##
    ######################

    def init(:ok) do
        Process.send_after(self, :loop, 2500)   #loop
        {:ok, %{}}
    end

end
