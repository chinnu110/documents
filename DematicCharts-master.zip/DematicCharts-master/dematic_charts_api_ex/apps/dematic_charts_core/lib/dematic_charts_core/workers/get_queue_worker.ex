defmodule DematicChartsCore.GetQueueWorker do
    use GenServer
  
    @name GQW

    #####################
    ##   Client APIs   ##
    ##################### 

    def start_link(opts \\ []) do
        GenServer.start_link(__MODULE__, :ok, name: {:global, :GQW})
    end
    


    #get_queue_data
    def handle_info(:loop, state) do

        #call Repo to get updated data
        {:ok, get_queue_data} = DematicChartsCore.DematicRepo.get_queue()
        # IO.puts("get queue worker looped")
        #call state server to send updated data
        DematicChartsCore.Stateserver.update(:get_queue, get_queue_data)
 
        #restart the loop after a 10 second wait
        Process.send_after(self, :loop, 30000)  
        
        {:noreply, state}

    end


    ######################
    ## Server Callbacks ##
    ######################

    def init(:ok) do
        Process.send_after(self, :loop, 2000)   #loop
        {:ok, %{}}
    end



end
