defmodule DematicChartsCore.GetActiveSkusWorker do
    use GenServer
  
    @name GASW


    #####################
    ##   Client APIs   ##
    ##################### 

    
    def start_link(opts \\ []) do
        GenServer.start_link(__MODULE__, :ok, name: {:global, :GASW})
    end
    

    ######################
    ## Server Callbacks ##
    ######################


    def handle_info(:loop, state) do

        #call Repo to get updated data
        {:ok, get_active_skus_data} = DematicChartsCore.DematicRepo.get_active_skus()

        #call state server to send updated data
        DematicChartsCore.Stateserver.update(:get_active_skus, get_active_skus_data)
 
        #restart the loop after a 10 second wait
        Process.send_after(self, :loop, 30000)  
        
        {:noreply, state}

    end




    def init(:ok) do
        Process.send_after(self, :loop, 3500)   #loop
        {:ok, %{}}
    end

end
