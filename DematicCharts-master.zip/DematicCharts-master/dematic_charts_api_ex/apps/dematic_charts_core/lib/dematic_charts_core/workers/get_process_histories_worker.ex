defmodule DematicChartsCore.GetProcessHistoriesWorker do
    use GenServer
  
    @name GPHW


    #####################
    ##   Client APIs   ##
    ##################### 

    def start_link(opts \\ []) do
        GenServer.start_link(__MODULE__, :ok, name: {:global, :GPHW})
    end
    

    def handle_info(:loop, _) do


        {{year, month, day}, _} = :calendar.local_time()

        #call Repo to get updated data
        {:ok, get_process_histories_data} = DematicChartsCore.DematicRepo.get_process_histories(year, month, day)
        # IO.puts("process histories worker looped")
        # call state server to send updated data
        DematicChartsCore.Stateserver.update(:get_process_histories, get_process_histories_data)
 
        #restart the loop after a 10 second wait
        Process.send_after(self, :loop, 30000)  
        
        {:noreply, []}

    end


    ######################
    ## Server Callbacks ##
    ######################

    def init(:ok) do
        Process.send_after(self, :loop, 2200)   #loop
        {:ok, %{}}
    end

end
