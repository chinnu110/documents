defmodule DematicChartsCore.GetBoxHistoryWorker do
    use GenServer
  
    @name GBHW
  
  
    #####################
    ##   Client APIs   ##
    #####################
  
  
    def start_link(opts \\ []) do
      GenServer.start_link(__MODULE__, :ok, name: {:global, :GBHW})
    end
  

  
    #####################
    ## Server Callbacks ##
    #####################
  

    def handle_info(:loop, _) do

    #get current date and separate into respective variables
    {{year, month, day}, _} = :calendar.local_time()

    #set integer for last year
    lastyear = year - 1

    #hardcoded warehouses 2 and 6 will need to be changed if we add warehouses
    warehouses = "2,6"

    # make sure month and day strings are both always 2 characters
    day = String.pad_leading("#{day}", 2, "0")
    month = String.pad_leading("#{month}", 2, "0")

    # Jan 1 of last year
    from_last_year = "#{lastyear}-01-01"

    # Today's date(m/d) of last year
    to_last_year = "#{lastyear}-#{month}-#{day}"

    #datestring is current date in YYYY-MM-DD form used for the initial SQL query
    datestring = "#{year}-#{month}-#{day}"

    todaysigil = Date.from_erl(:calendar.local_time |> elem(0)) |> elem(1)

    #subtract one day from the local time sigil to get the yesterdaysigil
    yesterdaysigil = Date.add(todaysigil, -1)
  

    ##Date Range Definitions

    #Define the Today date range
    todaydaterange = Date.range(todaysigil, todaysigil)

    #Define the Yesterday date range
    yesterdaydaterange = Date.range(yesterdaysigil, yesterdaysigil)

    #Define the last year date range from Jan 1 to today's month & day last year if not a leap year
    #If this year is a leap year, replace Feb 29th of last year with Feb 28th of last year
    lastyeardaterange = 
    case Calendar.ISO.leap_year?(year) && month == "02" && day == "29" do
        true ->
            #replaces Feb 29 of last year with Feb 28 if this year is a leap year
            Date.range(Date.from_iso8601(from_last_year) |> elem(1), Date.from_iso8601("#{lastyear}-#{month}-28") |> elem(1))
        false -> 
            Date.range(Date.from_iso8601(from_last_year) |> elem(1), Date.from_iso8601(to_last_year) |> elem(1))
    end
    

    #set last week date range from last week's Monday to it's following Sunday
    lastweekdaterange = Date.range(Date.from_erl(DateHelpers.monday_in_the_week_of(Timex.shift(:calendar.local_time(), weeks: -1))) |> elem(1),
                                   Date.from_erl(DateHelpers.sunday_in_the_week_of(Timex.shift(:calendar.local_time(), weeks: -1))) |> elem(1))
    

    # results handling for box history
    with {:ok, results} <-
           DematicChartsCore.HarvestRepo.get_box_history(
             from_last_year,
             datestring,
             warehouses
           ) do

        # bldg 6 shipped & induced today
        {buildingsixshippedtoday, buildingsixinducedtoday} = filter_range(results, todaydaterange, 6)

        # bldg 2 shipped & induced today 
        {buildingtwoshippedtoday, buildingtwoinducedtoday} = filter_range(results, todaydaterange, 2)

        # bldg 6 shipped & induced yesterday
        {buildingsixshippedyesterday, buildingsixinducedyesterday} = filter_range(results, yesterdaydaterange, 6)

        # bldg 2 shipped & induced yesterday 
        {buildingtwoshippedyesterday, buildingtwoinducedyesterday} = filter_range(results, yesterdaydaterange, 2)

        # bldg 6 shipped & induced last year
        {buildingsixshippedlastyear, buildingsixinducedlastyear} = filter_range(results, lastyeardaterange, 6)

        # bldg 2 shipped & induced last year
        {buildingtwoshippedlastyear, buildingtwoinducedlastyear} = filter_range(results, lastyeardaterange, 2)

        # bldg 6 shipped & induced last week
        {buildingsixshippedlastweek, buildingsixinducedlastweek} = filter_range(results, lastweekdaterange, 6)

        # bldg 2 shipped & induced last week
        {buildingtwoshippedlastlastweek, buildingtwoinducedlastweek} = filter_range(results, lastweekdaterange, 2)


      #output the gathered data
      ret = %{
        buildingSixShippedToday: buildingsixshippedtoday,
        buildingSixInducedToday: buildingsixinducedtoday,
        buildingTwoShippedToday: buildingtwoshippedtoday,
        buildingTwoInducedToday: buildingtwoinducedtoday,
        buildingSixShippedLastYear: buildingsixshippedlastyear,
        buildingSixInducedLastYear: buildingsixinducedlastyear,
        buildingTwoShippedLastYear: buildingtwoshippedlastyear,
        buildingTwoInducedLastYear: buildingtwoinducedlastyear,
        buildingSixShippedLastWeek: buildingsixshippedlastweek,
        buildingSixInducedLastWeek: buildingsixinducedlastweek,
        buildingTwoShippedLastLastWeek: buildingtwoshippedlastlastweek,
        buildingTwoInducedLastWeek: buildingtwoinducedlastweek,
        buildingSixShippedYesterday: buildingsixshippedyesterday,
        buildingSixInducedYesterday: buildingsixinducedyesterday,
        buildingTwoShippedYesterday: buildingtwoshippedyesterday,
        buildingTwoInducedYesterday: buildingtwoinducedyesterday
      }



        #call state server to send updated data
        DematicChartsCore.Stateserver.update(:get_box_history, ret)
    end
  
        Process.send_after(self, :loop, 30000) #repeat loop

        {:noreply, []}
    end
  
  
    def init(:ok) do
        Process.send_after(self, :loop, 3000)  
        {:ok, %{}}
    end
  
  
  
    #####################
    ## Helper Functions ##
    #####################

    #function that filters and sums/reduces the gathered data
    defp filter_range(results, daterange, warehouse) do
        results
        |> Enum.filter(fn x ->
            x."bcwh#" == warehouse &&
            Enum.member?(daterange, Date.from_iso8601(x.date) |> elem(1))
        end)
        |> Enum.reduce({0, 0}, fn x, {shipped, induced} ->
            {x.cases_shipped + shipped, x.total_cases_received + induced}
        end)
    end

  
  end