defmodule DematicChartsCore.Repo do
  use Ecto.Repo, otp_app: :dematic_charts_core

  def exec_sql(sql, parms) do
    Ecto.Adapters.SQL.query(DematicChartsCore.Repo, sql, parms)
  end
end
