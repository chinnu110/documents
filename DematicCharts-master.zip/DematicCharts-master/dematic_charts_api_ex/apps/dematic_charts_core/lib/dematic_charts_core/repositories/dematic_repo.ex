defmodule DematicChartsCore.DematicRepo do
  def get_queue() do
    with query <- "select msg_type, count(*) as num_of_msgs,
               min(created_time) as oldest, max(created_time) as newest,
               datediff(ms, min(created_time), max(created_time)) as latency
               from hst.wmsmessagequeue (nolock)
               where transmitted = 'N' group by msg_type",
         {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []) do
      results
      |> DematicChartsCore.Util.gen_processor_multi(%DematicChartsCore.QueueByMessage{})
    end
  end

  def get_total_queue() do
    with query <- "select total_messages, oldest, newest, datediff(ms, oldest, newest) as latency
               from
               (
               select count(*) as total_messages, min(created_time) as oldest, max(created_time) as newest
               from DirectorIT_Sorting.hst.wmsmessagequeue (nolock)
               where transmitted = 'N'
               ) a",
         {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []) do
      results
      |> DematicChartsCore.Util.gen_processor_multi(%DematicChartsCore.TotalQueue{})
    end
  end

  def get_process_histories(year, month, day) do
    with query <-
           "select coalesce(a.timeofday, b.timeofday) as timeofday, create_count, process_count
               from
               (
               select format(created_time, 'MM-dd-yy HH:mm') as timeofday,
               count(*) as create_count
               from DirectorIT_Sorting.hst.wmsmessagequeueLog (nolock)
               where transmitted = 'Y'
               and created_time between
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 04, 00, 01, 0 ) and
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 23, 59, 59, 0 )
               group by format(created_time, 'MM-dd-yy HH:mm')
               ) a
                
               left join
               (
               select format(updated_time, 'MM-dd-yy HH:mm') as timeofday,
               count(*) as process_count
               from DirectorIT_Sorting.hst.wmsmessagequeueLog (nolock)
               where transmitted = 'Y'
               and created_time between
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 04, 00, 01, 0 ) and
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 23, 59, 59, 0 )
               group by format(updated_time, 'MM-dd-yy HH:mm')
               ) b on a.timeofday = b.timeofday
               order by timeofday",
         {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []) do
      results
      |> DematicChartsCore.Util.gen_processor_multi(%DematicChartsCore.ProcessHistory{})
    end
  end

  def get_consumption_rate(last_minutes) do
    with query <-
           "select a.create_count, b.consumed_count, b.consumed_count/(iif(a.create_count = 0,1,a.create_count) * 1.00) as consumption_rate
               from
               (
               select count(*) as create_count
               from DirectorIT_Sorting.hst.wmsMessageQueueLog (nolock)
               where created_time between dateadd(mi,#{last_minutes},getdate()) and getdate()
               ) a
                
               cross join
                
               (
               select count(*) as consumed_count
               from DirectorIT_Sorting.hst.wmsMessageQueueLog (nolock)
               where updated_time between dateadd(mi,#{last_minutes},getdate()) and getdate()
               ) b",
         {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []) do
      results
      |> DematicChartsCore.Util.gen_processor_multi(%DematicChartsCore.ConsumptionRate{})
    end
  end

  def get_active_skus() do
    with query <-
           "SELECT DISTINCT LocationID, BM.SKU, BM.PO, BM.Distribution, S.ManifestID, SKUType
               FROM DirectorIT_SORTING.WCS.SupplyLocation SL
               INNER JOIN DirectorIT_SORTING.WCS.Supply S ON SL.SupplyKey = S.SupplyKey
               INNER JOIN DirectorIT_SORTING.WCS.BatchMap BM ON S.BatchKey = BM.BatchKey
               WHERE StartSKU = 'Y'",
         {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []) do
      results
      |> DematicChartsCore.Util.gen_processor_multi(%DematicChartsCore.ActiveSkus{})
    end
  end
end


##CODE FROM CONTROLLER


# def get_all_values(year, month, day, warehouses) do
  
#   all_values = %{
#     get_consumption_rate: get_consumption_rate(),
#     get_queue: get_queue(conn, _params),
#     get_total_queue: get_total_queue(),
#     get_active_skus: get_active_skus(),
#     get_process_histories: get_process_histories(year, month, day),
#     get_box_history: get_box_history(warehouses)
#   }

# {:ok, all_values}

# end





# def get_box_history(conn, %{"warehouses" => warehouses} = params) do
#   # get set current date and previous year
#   {{year, month, day}, _} = :calendar.local_time()
#   lastyear = year - 1
#   yesterday_int = day - 1

#   # make sure month and day are both always 2 digits
#   day = String.pad_leading("#{day}", 2, "0")
#   month = String.pad_leading("#{month}", 2, "0")
#   yesterday = String.pad_leading("#{yesterday_int}", 2, "0")

#   # Jan 1 of last year
#   from_last_year = "#{lastyear}-01-01"

#   # Today's date last year
#   to_last_year = "#{lastyear}-#{month}-#{day}"

#   # datestring is current date
#   datestring = "#{year}-#{month}-#{day}"

#   # yesterdaydatestring is yesterday's date
#   yesterdaydatestring = "#{year}-#{month}-#{yesterday}"

#   # current month & day but previous year
#   lastyeardatestring = "#{lastyear}-#{month}-#{day}"


#   #Define the Today date range
#   todaydaterange = Date.range(Date.from_iso8601(datestring) |> elem(1), Date.from_iso8601(datestring) |> elem(1))

#   #Define the Yesterday date range
#   yesterdaydaterange = Date.range(Date.from_iso8601(yesterdaydatestring) |> elem(1), Date.from_iso8601(yesterdaydatestring) |> elem(1))

#   #Define the last year date range from Jan 1 to today's month & day last year
#   lastyeardaterange = Date.range(Date.from_iso8601(from_last_year) |> elem(1), Date.from_iso8601(to_last_year) |> elem(1))


#   #set last week date range from last week's Monday to it's following Sunday
#   lastweekdaterange = Date.range(Date.from_erl(DateHelpers.monday_in_the_week_of(Timex.shift(:calendar.local_time(), weeks: -1))) |> elem(1),
#                                  Date.from_erl(DateHelpers.sunday_in_the_week_of(Timex.shift(:calendar.local_time(), weeks: -1))) |> elem(1))
  




# results handling for box history
#   with {:ok, results} <-
#          DematicChartsCore.HarvestRepo.get_box_history(
#            from_last_year,
#            datestring,
#            warehouses
#          ) do

#     # bldg 6 shipped & induced today
#     {buildingsixshippedtoday, buildingsixinducedtoday} = filter_range(results, todaydaterange, 6)

#     # bldg 2 shipped & induced today 
#     {buildingtwoshippedtoday, buildingtwoinducedtoday} = filter_range(results, todaydaterange, 2)

#     # bldg 6 shipped & induced yesterday
#     {buildingsixshippedyesterday, buildingsixinducedyesterday} = filter_range(results, yesterdaydaterange, 6)

#     # bldg 2 shipped & induced yesterday 
#     {buildingtwoshippedyesterday, buildingtwoinducedyesterday} = filter_range(results, yesterdaydaterange, 2)

#     # bldg 6 shipped & induced last year
#     {buildingsixshippedlastyear, buildingsixinducedlastyear} = filter_range(results, lastyeardaterange, 6)

#     # bldg 2 shipped & induced last year
#     {buildingtwoshippedlastyear, buildingtwoinducedlastyear} = filter_range(results, lastyeardaterange, 2)

#     # bldg 6 shipped & induced last week
#     {buildingsixshippedlastweek, buildingsixinducedlastweek} = filter_range(results, lastweekdaterange, 6)

#     # bldg 2 shipped & induced last week
#     {buildingtwoshippedlastlastweek, buildingtwoinducedlastweek} = filter_range(results, lastweekdaterange, 2)


#     #output the gathered data
#     ret = %{
#       buildingSixShippedToday: buildingsixshippedtoday,
#       buildingSixInducedToday: buildingsixinducedtoday,
#       buildingTwoShippedToday: buildingtwoshippedtoday,
#       buildingTwoInducedToday: buildingtwoinducedtoday,
#       buildingSixShippedLastYear: buildingsixshippedlastyear,
#       buildingSixInducedLastYear: buildingsixinducedlastyear,
#       buildingTwoShippedLastYear: buildingtwoshippedlastyear,
#       buildingTwoInducedLastYear: buildingtwoinducedlastyear,
#       buildingSixShippedLastWeek: buildingsixshippedlastweek,
#       buildingSixInducedLastWeek: buildingsixinducedlastweek,
#       buildingTwoShippedLastLastWeek: buildingtwoshippedlastlastweek,
#       buildingTwoInducedLastWeek: buildingtwoinducedlastweek,
#       buildingSixShippedYesterday: buildingsixshippedyesterday,
#       buildingSixInducedYesterday: buildingsixinducedyesterday,
#       buildingTwoShippedYesterday: buildingtwoshippedyesterday,
#       buildingTwoInducedYesterday: buildingtwoinducedyesterday
#     }

#     conn |> json(ret)
#   else
#     {:error, reason} -> conn |> send_error_resp(reason)
#   end
# end





