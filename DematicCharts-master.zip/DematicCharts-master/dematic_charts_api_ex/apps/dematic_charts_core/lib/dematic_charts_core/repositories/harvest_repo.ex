defmodule DematicChartsCore.HarvestRepo do
  def get_box_history(from, to, warehouses) do
    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "SQLREPORTS.USPRPT_PUT_SYS_STATS_HISTORY",
      [
        {{:sql_char, 10}, [from |> String.to_char_list()]},
        {{:sql_char, 10}, [to |> String.to_char_list()]},
        {{:sql_char, 50}, [warehouses |> String.to_char_list()]}
      ],
      DematicChartsCore.BoxHistory,
      :inventory
    )
  end
end
