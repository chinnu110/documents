defmodule DematicChartsCore.Application do
  # See https://hexdocs.pm/elixir/Application.html
  # for more information on OTP Applications
  @moduledoc false

  use Application

  def start(_type, _args) do
    db2_connection_pool_config = [
      {:name, {:local, :inventory}},
      {:worker_module, HobbylobbyHarvestEx.ConnectionPoolWorker},
      {:size, 2},
      {:max_overflow, 1}
    ]

    
    # List all child processes to be supervised
    children = [
      :poolboy.child_spec(:inventory, db2_connection_pool_config, :inventory),
      {Cluster.Supervisor, [Application.get_env(:libcluster, :topologies), [name: DematicChartsCore.ClusterSupervisor]]},
      {DematicChartsCore.Repo, []},
      {DematicChartsCore.Stateserver,[]},
      {DematicChartsCore.GetProcessHistoriesWorker,[]},
      {DematicChartsCore.GetActiveSkusWorker,[]},
      {DematicChartsCore.GetTotalQueueWorker,[]},
      {DematicChartsCore.GetBoxHistoryWorker,[]},
      {DematicChartsCore.GetConsumptionRateWorker,[]},
      {DematicChartsCore.GetQueueWorker,[]}
    ]

    # See https://hexdocs.pm/elixir/Supervisor.html
    # for other strategies and supported options
    opts = [strategy: :one_for_one, name: DematicChartsCore.Supervisor]
    Supervisor.start_link(children, opts)
  end
end
