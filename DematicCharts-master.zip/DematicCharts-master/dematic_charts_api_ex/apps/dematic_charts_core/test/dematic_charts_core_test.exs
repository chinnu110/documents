defmodule DematicChartsCoreTest do
  use ExUnit.Case
  doctest DematicChartsCore

  test "greets the world" do
    assert DematicChartsCore.hello() == :world
  end
end
