defmodule DematicChartsCore.MixProject do
  use Mix.Project

  def project do
    [
      app: :dematic_charts_core,
      version: "0.1.0",
      build_path: "../../_build",
      config_path: "../../config/config.exs",
      deps_path: "../../deps",
      lockfile: "../../mix.lock",
      elixir: "~> 1.7",
      start_permanent: Mix.env() == :prod,
      deps: deps()
    ]
  end

  # Run "mix help compile.app" to learn about applications.
  def application do
    [
      extra_applications: [:logger, :mssqlex, :mssql_ecto],
      mod: {DematicChartsCore.Application, []}
    ]
  end

  # Run "mix help deps" to learn about dependencies.
  defp deps do
    [
      {:mssql_ecto, "~> 1.2"},
      # {:hobbylobby_harvest_ex, git: "http://hlgithub.hobbylobby.corp/HobbyLobby/HarvestEx.git", tag: "v1.2.2.beta03"},
      {:hobbylobby_harvest_ex, git: "git@hlgithub.hobbylobby.corp:HobbyLobby/HarvestEx.git", tag: "v1.2.2.beta03"},
      {:mssqlex, "~> 1.1"},
      {:libcluster, "~> 3.0"}
    ]
  end
end
