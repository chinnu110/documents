import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  MatSelectModule,
  MatInputModule,
  MatCardModule,
  MatButtonModule,
  MatListModule,
  MatTableModule,
  MatPaginatorModule,
  MatSliderModule,
  MatDialogModule,
  MatSnackBarModule,
  MatToolbarModule,
  MatAutocompleteModule,
  MatSortModule,
  MatIconModule,
  MatMenuModule,
  MatTooltipModule,
  MatGridListModule,
  MatProgressSpinnerModule,
  MatProgressBarModule,
  MatChipsModule,
  MatExpansionModule,
  MatTabsModule,
  MatCheckboxModule,
  MatRadioModule,
  MatDividerModule,
  MatBadgeModule,
  MatButtonToggleGroup,
  MatButtonToggleModule
} from '@angular/material';
import { ApproutingModule } from './approuting/approuting.module';
import { HttpClientModule } from '@angular/common/http';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ApproutingModule,
    MatButtonModule,
    MatCheckboxModule,
    MatToolbarModule,
    NgxChartsModule,
    MatTableModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
