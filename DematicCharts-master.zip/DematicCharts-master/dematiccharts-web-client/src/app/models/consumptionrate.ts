export class get_consumption_rate {
    consumed_count: number;
    consumption_rate: string;
    create_count: number;
}