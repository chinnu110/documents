export class get_process_histories {
    create_count: number;
    process_count: number;
    timeofday: string;
}