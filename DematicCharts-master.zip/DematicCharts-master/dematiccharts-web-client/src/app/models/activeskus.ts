export class get_active_skus {
    Distribution: string;
    LocationID: string;
    ManifestID: string;
    PO: string;
    SKU: string;
    SKUType: string;
}