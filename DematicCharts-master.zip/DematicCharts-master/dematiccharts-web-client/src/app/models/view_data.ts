import { SeriesData } from "./series_data";

export class ViewData{
    name: string;
    series: SeriesData[];
}