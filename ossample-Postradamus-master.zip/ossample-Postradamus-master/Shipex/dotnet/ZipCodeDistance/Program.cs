﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using Dapper;
using Newtonsoft.Json;

namespace ZipCodeDistance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            List<ZipCodeDistance> zipCodeDistance = new List<ZipCodeDistance>();
            List<ZipCode> zipCodes = GetAllZipCodes();
            ZipCode hl_zipcode = zipCodes.FirstOrDefault(z => z.zip_code == "73179");

            foreach(ZipCode zp in zipCodes)
            {
                ZipCodeDistance zpd = new ZipCodeDistance(hl_zipcode, zp);
                zipCodeDistance.Add(zpd);
            }

            Console.WriteLine("Main :: writing json");
            using (StreamWriter file = File.CreateText(@"zip_code_distances.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, zipCodeDistance);
            }
            Console.WriteLine("Main :: complete writing json");

            Console.WriteLine("Goodbye World!");
        }

        private static List<ZipCode> GetAllZipCodes()
        {
            Console.WriteLine("GetAllZipCodes :: start");

            string sql = "SELECT Zip_Code as zip_code, State as state, Latitude as latitude, Longitude as longitude " +
                "FROM [Enterprise].[dbo].[ZIP_DATA] as zd ";

            List<ZipCode> ztl;
            using (var connection = new SqlConnection("Server=HLSQLAPP12;Database=HLShipper;Integrated Security=True;User Id=mhcrosb1; Password=abzB#~1T7p;"))
            {
                ztl = connection.Query<ZipCode>(sql).ToList();
            }

            Console.WriteLine("GetAllZipCodes :: end :: ({0} Records)", ztl.Count);
            return ztl;
        }
    }
}
