﻿using System;
namespace ZipCodeDistance
{
    public class ZipCodeDistance
    {
        public ZipCodeDistance(ZipCode zipCode1, ZipCode zipCode2)
        {
            double dist = HaversineFormula.Distance(zipCode1, zipCode2);

            this.zip_code_1 = zipCode1;
            this.zip_1 = zipCode1.zip_code;
            this.zip_code_2 = zipCode2;
            this.zip_2 = zipCode2.zip_code;
            this.distance = dist;
        }
        public ZipCode zip_code_1 { get; set; }
        public string zip_1 { get; set; }
        public ZipCode zip_code_2 { get; set; }
        public string zip_2 { get; set; }
        public double distance { get; set; }
    }
}
