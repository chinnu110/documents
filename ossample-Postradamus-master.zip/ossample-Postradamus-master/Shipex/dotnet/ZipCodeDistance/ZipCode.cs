﻿using System;

namespace ZipCodeDistance
{
    public class ZipCode
    {
        public ZipCode()
        {
        }

        public string zip_code { get; set; }
        public string state { get; set; }
        public double latitude { get; set; }
        public double longitude { get; set; }
    }
}
