﻿using System;

namespace ZipCodeDistance
{
    public static class HaversineFormula
    {
        public static double Distance(ZipCode zip_code_1, ZipCode zip_code_2)
        {
            //double R = (type == DistanceType.Miles) ? 3960 : 6371;
            double R = 3960;

            double dLat = toRadian(zip_code_2.latitude - zip_code_1.latitude);
            double dLon = toRadian(zip_code_2.longitude - zip_code_1.longitude);

            double a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                Math.Cos(toRadian(zip_code_1.latitude)) * Math.Cos(toRadian(zip_code_2.latitude)) *
                Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
            double c = 2 * Math.Asin(Math.Min(1, Math.Sqrt(a)));
            double d = R * c;

            return d;
        }

        private static double toRadian(double val)
        {
            return (Math.PI / 180) * val;
        }
    }
}
