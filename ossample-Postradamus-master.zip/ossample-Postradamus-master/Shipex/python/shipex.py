import logging
import sys
import os.path
import os
import shutil
import getopt
import math
import pandas as pd
import numpy as np
import pyodbc
import json
import tensorflow as tf
from multiprocessing import Pool
from datetime import datetime, timedelta
from sklearn.model_selection import train_test_split
from itertools import permutations
from logging.handlers import TimedRotatingFileHandler
from tensorflow.python.framework.graph_util import convert_variables_to_constants
from keras import backend
from keras.models import Sequential, load_model
from keras.layers import Dense
from keras.callbacks import EarlyStopping


def unhandled_exception_handler(_type, value, _tb):
    logger.exception("Uncaught exception: {0}".format(str(value)))


log_dir = './logs/'
log_file = 'shipex-' + datetime.today().strftime("%Y-%m-%d") + '.log'
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

format = '%(asctime)s - %(levelname)s - %(message)s'
formatter = logging.Formatter(format)

logging.basicConfig(
    format=format,
    datefmt='%m/%d/%Y %I:%M:%S %p',
    level=logging.DEBUG
)

logger = logging.getLogger(__name__)
handler = TimedRotatingFileHandler(log_dir + log_file, when="d", interval=1, backupCount=5)
handler.setLevel(logging.DEBUG)
handler.setFormatter(formatter)
logger.addHandler(handler)
sys.excepthook = unhandled_exception_handler


def parse_date(date_string):
    try:
        new_date = datetime.strptime(date_string, '%m/%d/%Y')
    except ValueError:
        try:
            new_date = datetime.strptime(date_string, '%m-%d-%Y')
        except ValueError:
            new_date = None

    return new_date


def get_shipping_data(start_date, end_date):
    """Gets Shipping data from HLShipper"""

    logger.debug('get_shipping_data :: retrieving data')

    server = 'tcp:hlsqlapp12.hobbylobby.corp'
    database = 'HLShipper'
    connection_string = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER=_server_;DATABASE=_database_;' \
                        'Trusted_Connection=yes;'
    connection_string = connection_string.replace('_server_', server)
    connection_string = connection_string.replace('_database_', database)

    cnxn = pyodbc.connect(connection_string)
    sql = "SELECT s.Msn, s.Ship_Dttm, s.Total_Charges, s.Shipper_Reference, sp.TrackingNumber_1, " \
          "sp.TrackingNumber_2, sp.Height, sp.Width, sp.Length, sp.Weight, c.Carrier_Name, " \
          "se.Service_Id, se.Service_Symbol, na.city, na.state_province, " \
          "CASE " \
          "WHEN CHARINDEX('-',na.postal_code) > 0 THEN LEFT(na.postal_code,CHARINDEX('-',na.postal_code)-1) " \
          "WHEN LEN(na.postal_code) > 5 THEN LEFT(na.postal_code,5) " \
          "WHEN CHARINDEX('-',na.postal_code) = 0 THEN na.postal_code " \
          "END as postal_code " \
          "FROM [ara].[Shipment] as s " \
          "LEFT JOIN [ara].[Shipment_Package] as sp on s.Msn = sp.Msn " \
          "LEFT JOIN [ara].[Name_Address] as na on s.Name_Address_Id = na.id " \
          "LEFT JOIN [dbo].[Service] as se on s.Service_Id = se.Service_Id " \
          "LEFT JOIN [dbo].[Carrier] as c on se.Carrier_Id = c.Carrier_Id " \
          "WHERE s.Is_Voided_Flag = 0 " \
          "AND s.Shipped_By_User_Id = 'panda' " \
          "AND se.Service_Symbol in ('CONNECTSHIP_ENDICIA.USPS.PRIORITY','FEX.SMART_POST','FEX.FEDEX_GROUND')" \
          "AND s.Ship_Dttm > 'start_date' " \
          "AND s.Ship_Dttm <= 'end_date'" \
          "ORDER BY s.Msn DESC;"

    sql = sql.replace('start_date', start_date)
    sql = sql.replace('end_date', end_date)

    df = pd.read_sql(sql, cnxn)

    logger.debug('get_shipping_data :: Records(' + str(len(df)) + ')')

    return df


def read_zipcode_distances():
    logger.debug('read_zipcode_distances :: getting zipcode data')

    with open('zip_code_distances.json', 'r') as f:
        zip_code_dict = json.load(f)

    df = pd.DataFrame.from_dict(zip_code_dict, orient='columns')

    logger.debug('read_zipcode_distances :: Records(' + str(len(df)) + ')')

    return df


def read_gas_prices():
    logger.debug('read_gas_prices :: getting gas price data')

    date_parser = pd.core.tools.datetimes.to_datetime

    df = pd.read_csv('gas_prices.csv'
                     , header='infer'
                     , delimiter=','
                     , dtype={'date': 'str', 'price': 'float'}
                     , parse_dates=['date']
                     , date_parser=date_parser
                     )

    logger.debug('read_gas_prices :: Records(' + str(len(df)) + ')')

    return df


def process_shipments(shipments_df, zip_code_df, show_log=True):
    if show_log:
        logger.debug('process_shipments :: start')

    count = 0
    x_train = pd.DataFrame(columns=['height', 'width', 'length', 'weight', 'distance'])
    y_train = pd.DataFrame(columns=['usps_priority', 'fedex_smart', 'fedex_ground'])

    # usps = shipments_df[shipments_df.Service_Symbol == 'CONNECTSHIP_ENDICIA.USPS.PRIORITY']
    # smart = shipments_df[shipments_df.Service_Symbol == 'FEX.SMART_POST']
    # ground = shipments_df[shipments_df.Service_Symbol == 'FEX.FEDEX_GROUND']

    # min_count = min([len(usps), len(smart), len(ground)])
    # usps = usps.sample(n=min_count)
    # smart = smart.sample(n=min_count)
    # ground = ground.sample(n=min_count)
    # shipments_df = pd.concat([usps, smart, ground], axis=0, sort=False)

    for index, row in shipments_df.iterrows():
        zipc = zip_code_df[zip_code_df.zip_2 == row['postal_code']]
        dim = set(permutations([row['Height'], row['Width'], row['Length']]))
        # gas_price = gas_prices_df[gas_prices_df.date <= row['Ship_Dttm']] \
        #    .sort_values(by=['date'], ascending=False).head(1)

        if len(zipc) > 0:
            for d in dim:
                df_x = pd.DataFrame({
                    'height': d[0]
                    , 'width': d[1]
                    , 'length': d[2]
                    , 'weight': row['Weight']
                    , 'distance': zipc.iloc[0]['distance']
                }, index=[count])

                df_y = {}
                if row['Service_Symbol'] == 'CONNECTSHIP_ENDICIA.USPS.PRIORITY':
                    df_y = pd.DataFrame({
                        'usps_priority': 1
                        , 'fedex_smart': 0
                        , 'fedex_ground': 0
                    }, index=[count])
                if row['Service_Symbol'] == 'FEX.SMART_POST':
                    df_y = pd.DataFrame({
                        'usps_priority': 0
                        , 'fedex_smart': 1
                        , 'fedex_ground': 0
                    }, index=[count])
                if row['Service_Symbol'] == 'FEX.FEDEX_GROUND':
                    df_y = pd.DataFrame({
                        'usps_priority': 0
                        , 'fedex_smart': 0
                        , 'fedex_ground': 1
                    }, index=[count])

                x_train = x_train.append(df_x)
                y_train = y_train.append(df_y)

                count += 1
                if count % 10000 == 0 and show_log:
                    logger.debug('Count = %i' % count)

    if show_log:
        logger.debug('x_train shape: ' + str(x_train.shape))
        logger.debug('y_train shape: ' + str(y_train.shape))
        logger.debug('process_shipments :: complete')

    return x_train, y_train


def freeze_session(session, keep_var_names=None, output_names=None, clear_devices=True):
    graph = session.graph
    with graph.as_default():
        freeze_var_names = list(set(v.op.name for v in tf.global_variables()).difference(keep_var_names or []))
        output_names = output_names or []
        output_names += [v.op.name for v in tf.global_variables()]
        input_graph_def = graph.as_graph_def()
        if clear_devices:
            for node in input_graph_def.node:
                node.device = ""
        frozen_graph = convert_variables_to_constants(session, input_graph_def, output_names, freeze_var_names)
        return frozen_graph


def version_model(model_file_h5, model_file_pb):
    if not os.path.isfile(model_file_h5):
        logger.error('Model file [' + model_file_h5 + '] not found.')

    if not os.path.isfile(model_file_pb):
        logger.error('Model file [' + model_file_pb + '] not found.')

    version = 1
    ver_dir = './versions/'
    if not os.path.exists(ver_dir):
        os.makedirs(ver_dir)
        if not os.path.exists(ver_dir + 'h5/'):
            os.makedirs(ver_dir + 'h5/')
        if not os.path.exists(ver_dir + 'pb/'):
            os.makedirs(ver_dir + 'pb/')
    else:
        for (dirpath, dirnames, filenames) in os.walk(ver_dir + 'h5/'):
            for name in filenames:
                if name.find('-') > -1:
                    # rating_pred-9.h5
                    ver = int(name[name.find('-') + 1:len(name) - 3])
                    if ver >= version:
                        version = ver + 1

    model_file_h5_new = 'rating_pred-' + str(version) + '.h5'
    model_file_pb_new = 'rating_pred-' + str(version) + '.pb'

    if os.path.isfile(model_file_h5):
        shutil.copy2('./' + model_file_h5, ver_dir + 'h5/' + model_file_h5_new)
    if os.path.isfile(model_file_pb):
        shutil.copy2('./' + model_file_pb, ver_dir + 'pb/' + model_file_pb_new)

    return


if __name__ == '__main__':
    argv = sys.argv[1:]
    # raise ValueError('Network out of balance')

    usage = '\n\nusage: shipex.py \n' \
            '    -e : environment to use; ex. dev/test/prod, default: prod \n' \
            '    -s : start date; ex. ''6/25/2018'' \n' \
            '    -n : end date; ex. ''6/25/2018'' \n' \
            '    -v : save shipping data; ex. 1 = True, 0 = False; default: 0 \n' \
            '    -t : train and save ml model; ex. 1 = True, 0 = False; default: 1 \n' \
            '    -x : training file for the X data \n' \
            '    -y : training file for the Y data \n'

    environment = 'prod'
    save = False
    train = True
    start = (datetime.today() - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    end = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
    x_file = ""
    y_file = ""

    try:
        opts, args = getopt.getopt(argv, 'e:s:n:v:t:x:y:h', ['env='
            , 'start='
            , 'end='
            , 'save='
            , 'train='
            , 'x='
            , 'y='
            , 'help'])
    except getopt.GetoptError:
        logger.error(usage)
        sys.exit(2)

    for opt, arg in opts:
        if opt == '-h':
            logger.info(usage)
            sys.exit(-1)
        elif opt in ('-e', '--env'):
            environment = arg.lower()
        elif opt in ('-s', '--start'):
            start = parse_date(arg)
            if start is None:
                logger.error('Start date not a date.')
                logger.error(usage)
                sys.exit(-1)
        elif opt in ('-n', '--end'):
            end = parse_date(arg)
            if end is None:
                logger.error('End date not a date.')
                logger.error(usage)
                sys.exit(-1)
        elif opt in ('-v', '--save'):
            if arg == '1':
                save = True
        elif opt in ('-t', '--train'):
            if arg == '0':
                train = False
        elif opt in ('-x', '--x'):
            if os.path.isfile(arg):
                x_file = arg
            else:
                logger.error('X file (%s) is not found.' % arg)
                sys.exit(-1)
        elif opt in ('-y', '--y'):
            if os.path.isfile(arg):
                y_file = arg
            else:
                logger.error('Y file (%s) is not found.' % arg)
                sys.exit(-1)

    if not x_file == "" and y_file == "":
        logger.error("Y file needed when X file was given.")
        sys.exit(-1)
    if x_file == "" and not y_file == "":
        logger.error("X file needed when Y file was given.")
        sys.exit(-1)

    logger.info("main :: start")
    logger.info('main ::          Environment = ' + environment)
    logger.info('main ::                Start = ' + start.strftime("%m-%d-%Y %H:%M:%S"))
    logger.info('main ::                  End = ' + end.strftime("%m-%d-%Y %H:%M:%S"))
    logger.info('main ::   Save Shipping Data = ' + str(save))
    logger.info('main :: Train and Save model = ' + str(train))
    if not x_file == "":
        logger.info('main ::                    X = ' + x_file)
    if not y_file == "":
        logger.info('main ::                    Y = ' + y_file)

    zip_codes = read_zipcode_distances()
    # gas_prices = read_gas_prices()

    if x_file == "" and y_file == "":
        shipment_df = get_shipping_data(start_date=start.strftime("%m-%d-%Y %H:%M:%S")
                                        , end_date=end.strftime("%m-%d-%Y %H:%M:%S"))

        if len(shipment_df) == 0:
            logger.warning("main :: 0 records to process")
            sys.exit()

        logger.info('main :: process_shipments :: start')

        df_split = np.array_split(shipment_df, 500)
        args = []
        for x in df_split:
            args.append([x, zip_codes, False])

        # x, y = process_shipments(shipments_df=shipment_df, zip_code_df=zip_codes)
        with Pool(processes=8) as pool:
            df = pool.starmap(process_shipments, args)

        x = pd.DataFrame(columns=['height', 'width', 'length', 'weight', 'distance'])
        y = pd.DataFrame(columns=['usps_priority', 'fedex_smart', 'fedex_ground'])
        for f in df:
            x = x.append(f[0], sort=False)
            y = y.append(f[1], sort=False)

        logger.info("main :: X shape: %s" % str(x.shape))
        logger.info("main :: Y shape: %s" % str(y.shape))
        logger.info('main :: process_shipments :: end')

        if save:
            x.to_csv('ship_x.csv', sep='|')
            y.to_csv('ship_y.csv', sep='|')

    else:
        x = pd.read_csv(x_file
                        , header='infer'
                        , delimiter='|'
                        , dtype={'index': 'int'
                , 'height': 'int'
                , 'width': 'int'
                , 'length': 'int'
                , 'weight': 'float'
                , 'distance': 'float'
                                 })
        y = pd.read_csv(y_file
                        , header='infer'
                        , delimiter='|'
                        , dtype={'index': 'int'
                , 'usps_priority': 'int'
                , 'fedex_smart': 'int'
                , 'fedex_ground': 'int'
                                 })

        x = x[['height', 'width', 'length', 'weight', 'distance']].values
        y = y[['usps_priority', 'fedex_smart', 'fedex_ground']].values

    model_file_h5 = 'rating_pred.h5'
    model_file_pb = 'rating_pred.pb'

    if os.path.isfile(model_file_h5):
        logger.info('main :: Loading Model')
        model = load_model(model_file_h5)
    else:
        logger.info('main :: Building Model')
        model = Sequential()
        model.add(Dense(128, activation='tanh', input_shape=x.shape[1:]))
        model.add(Dense(16, activation='relu'))
        model.add(Dense(3, activation='softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='adagrad', metrics=['accuracy'])

    score = model.evaluate(x, y, verbose=0)
    acc = score[1]
    if math.isnan(acc):
        acc = 0
    logger.info('main :: -------------------------')
    logger.info('main :: Accuracy: ' + str(acc))
    logger.info('main :: -------------------------')

    if train:
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=.3)

        early_stopper = EarlyStopping(patience=5)

        model.fit(x_train, y_train
                  , batch_size=15
                  , epochs=10000
                  , verbose=1
                  , validation_data=(x_test, y_test)
                  , callbacks=[early_stopper]
                  )

        score = model.evaluate(x_test, y_test, verbose=0)
        acc = score[1]
        if math.isnan(acc):
            acc = 0

        logger.info('main :: -------------------------')
        logger.info('main :: New Accuracy: ' + str(acc))
        logger.info('main :: -------------------------')

        version_model(model_file_h5=model_file_h5, model_file_pb=model_file_pb)

        logger.debug('main :: saving h5 model: ' + model_file_h5)
        model.save(model_file_h5)

        logger.debug('main :: saving pb model: ' + model_file_pb)
        frozen_graph = freeze_session(backend.get_session(), output_names=[out.op.name for out in model.outputs])
        tf.train.write_graph(frozen_graph, "./", model_file_pb, as_text=False)

    logger.info("main :: end")
