import logging
import math
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense
from keras.callbacks import EarlyStopping


early_stopper = EarlyStopping(patience=3)


def compile_model(network, nb_classes, input_shape):
    nb_layers = network['nb_layers']
    nb_neurons = network['nb_neurons']
    activation = network['activation']
    optimizer = network['optimizer']

    model = Sequential()

    for i in range(nb_layers):

        if i == 0:
            model.add(Dense(nb_neurons[i], activation=activation[i], input_shape=input_shape))
        else:
            model.add(Dense(nb_neurons[i], activation=activation[i]))

    model.add(Dense(nb_classes, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['accuracy'])

    return model


def train_and_score(network, nb_classes, x, y):

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=.3, random_state=1100)

    model = compile_model(network, nb_classes, x_train.shape[1:])

    logging.info('')
    logging.info(network)
    
    model.fit(x_train, y_train,
              batch_size=10,
              epochs=10000,  # using early stopping, so no real limit
              verbose=1,
              validation_data=(x_test, y_test),
              callbacks=[early_stopper])

    score = model.evaluate(x_test, y_test, verbose=0)
    acc = score[1]
    if math.isnan(acc):
        acc = 100
    logging.info("Score %.2f%%" % acc)

    return acc  # 1 is accuracy. 0 is loss.
