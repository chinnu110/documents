﻿using System;

namespace ClassLibrary
{
    public class Class1
    {
        public void Method1()
        {    
        }
    }
}
