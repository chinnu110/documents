#!/bin/env bash

SATELLITE_HOST="hlsatellite02.hobbylobby.corp"
LOG_FILE="/var/log/$0.log"

SWITCHES="""$@"""

if [[ $SWITCHES = *" -h"* || $SWITCHES = *" --help"* || $SWITCHES == "-h" || $SWITCHES == "--help" ]]
then
	echo -e """$0
	--host <hostname>
	--ip <ip_address>
	--org <satellite_org>
	--key <satellite_activationkey>
	--swap-disk <swap_drive>
	--app-disk <app_disk>
	--app-dir <app_dir> (default to "/mnt/app01" if --app-disk specified
	--ou <ad_ou>
	--sub-ou <ad_sub_ou>
	--ad-env <ad_env>
	--reboot
	--update"""
	exit 1
fi

while [ "$SWITCHES" != "" ]
do
	case $1 in
	--host|--name|--hostname)
		NEW_HOSTNAME=$2
		shift
		;;
	--ip|--ip-address)
		IP_ADDRESS=$2
		shift
		;;
	--org|--satorg|--satellite-org)
		ORG=$2
		shift
		;;
	--key|--activationkey)
		ACTIVATION_KEY=$2
		shift
		;;
	--swap-drive|--swap|--swap-disk)
		SWAP_DISK=$2
		shift
		;;
	--app-drive|--app|--app-disk)
		APP_DISK=$2
		shift
		;;
	--add-dir|--app-folder)
		APP_DIR=$2
		shift
		;;
	--ou|--ad-ou)
		OU=$2
		shift
		;;
	--sub-ou|--ad-sub-ou)
		SUB_OU=$2
		shift
		;;
	--environment|--env)
		ENV=$2
		shift
		;;
	--reboot)
		REBOOT=TRUE
		;;
	--update)
		UPDATE=TRUE
		;;
	esac
	shift
	SWITCHES="""$@"""
done

if [ "z$NEW_HOSTNAME" != "z" ]
then
	echo "Setting Hostname to ${NEW_HOSTNAME}"
	hostnamectl set-hostname ${NEW_HOSTNAME} > $LOG_FILE 2>&1
	if [ $? -ne 0 ]
	then
		echo "Failed to change Hostname to ${NEW_HOSTNAME}" >&2
		exit 1
	else
		sed -i "s/template/${NEW_HOSTNAME}/g" /etc/hosts
	fi
fi

if [ "z${IP_ADDRESS}" != "z" ]
then
	INTERFACES=`ls -1 /sys/class/net/`
	INTERFACES="""${INTERFACES/$'\n'lo/}"""
	if [ `echo """${INTERFACES}""" | wc -l` -eq 1 ]
	then
		sed -i "s/10.100.37.98/${IP_ADDRESS}/g" /etc/sysconfig/network-scripts/ifcfg-${INTERFACES}
		sed -i "s/10.100.37.98/${IP_ADDRESS}/g" /etc/hosts
	else
		echo "Unable to determine network interface"
	fi
fi

if [ "$ORG" != "" ]
then
	echo "Configuring Subscription-manager to attach to ${SATELLITE_HOST}"

	yum list katello-ca-consumer-hlsatellite02.hobbylobby.corp -q >$LOG_FILE 2>&1

	if [ $? -eq 1 ]
	then
		echo "Installing Katello CA"
		# Get and Install Katello CA from Satellite server
		curl -O http://${SATELLITE_HOST}/pub/katello-ca-consumer-latest.noarch.rpm > $LOG_FILE 2>&1
		if [ $? -ne 0 ]
		then
			echo "Unable to retireve Katello CA RPM" >&2
			exit 1
		fi

		rpm -ivh katello-ca-consumer-latest.noarch.rpm > $LOG_FILE 2>&1
		rm -f katello-ca-consumer-latest.noarch.rpm > $LOG_FILE 2>&1
	fi

	# Register with satellite server
	echo "Registering server with satellite"
	subscription-manager register --org="${ORG}" --activationkey="${ACTIVATION_KEY}"  --force > $LOG_FILE 2>&1
	if [ $? -ne 0 ]
	then
		echo "Failed to register with Satellite server" >&2
		exit 1
	fi

	echo "Enabling standard repos"
	subscription-manager repos \
		--enable rhel-7-server-optional-rpms \
		--enable rhel-7-server-rh-common-rpms \
		--enable rhel-7-server-rpms \
		--enable rhel-7-server-extras-rpms \
		--enable rhel-7-server-supplementary-rpms \
		--enable rhel-7-server-satellite-tools-6.3-rpms >$LOG_FILE 2>&1

	if [ $? -ne 0 ]
	then
		echo "Failed to enable satellite repos" >&2
	fi

	echo "Add satellite ssh public key"
	# Get Satellite SSH Public key
	if [ ! -d "~/.ssh" ]
	then
		mkdir -p ~/.ssh
	fi

	curl -s https://${SATELLITE_HOST}:9090/ssh/pubkey --insecure >> ~/.ssh/authorized_keys
	if [ $? -ne 0 ]
	then
		echo "Failed to get SSH Key from satellite server" >&2
	else
		chmod 700 ~/.ssh
		chmod 600 ~/.ssh/authorized_keys
	fi

	# Install Katello agent, upgrade packages, and install puppet agent
	echo "Installing Katello agent"
	yum install katello-agent -y > $LOG_FILE 2>&1
	if [ $? -ne 0 ]
	then
		echo "Failed to install Katello agent" >&2
	fi
fi


# Create swap partition and format if swap disk specified in cli switches
if [ -n "${SWAP_DISK}" ]
then
	if [ ! -b ${SWAP_DISK}[0-9]* ]
	then
		echo "Formating ${SWAP_DISK} as swap"
		mkswap ${SWAP_DISK}
		swapon ${SWAP_DISK} >$LOG_FILE 2>&1
		UUID=`blkid ${SWAP_DISK} | awk '{print $2}'`
		if [[ "$(</etc/fstab)" != *${UUID}* ]]
		then
			echo -e "${UUID}\tswap\tswap\tdefaults\t0\t0" >> /etc/fstab
		fi
	else
		echo "${SWAP_DISK} already has a partition skipping"
	fi

		mount -a
		if [ $? -ne 0 ]
		then
			echo "Failed to mount swap"
			exit 1
		fi
fi

# Create app partition and format to xfs if app disk specified in cli switches
if [ -n "${APP_DISK}" ]
then
	if [ ! -b ${APP_DISK}1 ]
	then
		echo "Formatting ${APP_DISK} as xfs"
		# Setup LVM and format lv
		pvcreate ${APP_DISK} > $LOG_FILE 2>&1
		vgcreate app_vol_grp ${APP_DISK} > $LOG_FILE 2>&1
		lvcreate -n lv_data1 app_vol_grp -l 100%FREE > $LOG_FILE 2>&1
		mkfs.xfs /dev/app_vol_grp/lv_data1 > $LOG_FILE 2>&1

		# Create App directory and add mount entry to fstab
			APP_DIR=${APP_DIR:-"/mnt/app01"}
		if [ ! -d ${APP_DIR} ]
		then
			mkdir -p ${APP_DIR}
		fi
		if [[ "$(</etc/fstab)" != *"/dev/mapper/app_vol_grp-lv_data1"* ]]
		then
			echo -e "/dev/mapper/app_vol_grp-lv_data1\t${APP_DIR}\txfs\tdefaults\t0\t0" >> /etc/fstab
		fi
	else
		echo "${APP_DISK} already has a partition skipping"
	fi
		mount -a
		if [ $? -ne 0 ]
		then
			echo "Failed to mount application volume"
			exit 1
		fi
fi

if [ "$UPDATE" == "TRUE" ]
then
	# Update all packages
	echo "Updating packages"
	yum update -y > $LOG_FILE 2>&1
	if [ $? -ne 0 ]
	then
		echo "Error updating packages" >&2
	fi
fi

# Install open-vm-tools if VMWare virtual machine
if [ "$(</sys/class/dmi/id/product_name)" == "VMware Virtual Platform" ]
then
	echo "Installing open-vm-tools"
	yum install open-vm-tools -y > $LOG_FILE 2>&1
fi

if [ "$OU" != "" ]
then
	# Install and configure SSSD
	echo "Setting up SSSD"
	yum install sssd realmd oddjob oddjob-mkhomedir samba-common-tools nfs-utils cifs-utils -y > $LOG_FILE 2>&1
	if [ $? -ne 0 ]
	then
		echo "Failed to install required packages" >&2
		exit 1
	fi

	systemctl is-active realmd > $LOG_FILE 2>&1

	if [ $? -ne 0 ]
	then
		systemctl restart dbus realmd >$LOG_FILE 2>&1
	fi

	realm discover HobbyLobby.corp > $LOG_FILE 2>&1
	if [ $? -ne 0 ]
	then
		echo "Failed to discover domain" >&2
		exit 1
	fi

	until [ "${OU}" == "AD Management" -o "${OU}" == "Development" -o "${OU}" == "Operations" -o "${OU}" == "Security" -o "${OU}" == "Apps" ]
	do
		read -p """Active Directory OU [AD Management, Apps, Development, Operations, Security]: """ OU
	done

	if [ "${OU}" == "Apps" ]
	then
		until [ "${SUB_OU}" == "Customer" -o "${SUB_OU}" == "Store" -o "${SUB_OU}" == "Web" ]
		do
			read -p """Apps sub OU [Customer, Store, Web]: """ SUB_OU
		done

		until [ "${ENV}" == "Dev" -o "${ENV}" == "Perf" -o "${ENV}" == "Prod" -o "${ENV}" == "QA" ]
		do
			read -p """Enviroment [Dev, QA, Perf, Prod]: """ ENV
		done
	fi

	# Join domain
	read -p "Username: " AD_USER
	if [ -z "${SUB_OU}" ]
	then
		realm join hobbylobby.corp -U ${AD_USER} --computer-ou "OU=${OU},OU=Tier 1 RHEL,DC=HobbyLobby,DC=corp"
	else
		realm join hobbylobby.corp -U ${AD_USER} --computer-ou "OU=${ENV},OU=${SUB_OU},OU=${OU},OU=Tier 1 RHEL,DC=HobbyLobby,DC=corp"
	fi

	if [ $? -ne 0 ]
	then
		echo "Failed to join domain" >&2
		exit 1
	fi


	if [[ "$(</etc/sssd/sssd.conf)" != *default_domain* ]]
	then
		sed -i "s/\[sssd\]/[sssd]\ndefault_domain_suffix = HobbyLobby.corp/" /etc/sssd/sssd.conf
	fi

	if [[ "$(</etc/sssd/sssd.conf)" != *ad_hostname* ]]
	then
		sed -i "s/\[domain\/HobbyLobby.corp\]/[domain\/HobbyLobby.corp]\nad_hostname = `hostname -f`/" /etc/sssd/sssd.conf
	fi

	if [[ "$(</etc/sssd/sssd.conf)" != *dyndns* ]]
	then
		sed -i "s/\[domain\/HobbyLobby.corp\]/[domain\/HobbyLobby.corp]\ndyndns_update = true\ndyndns_refresh_interval = 43200\ndyndns_update_ptr = true\ndyndns_ttl = 3600/" /etc/sssd/sssd.conf
	fi

	if [[ "$(</etc/fstab)" != *\/home* ]]
	then
		echo -e """hlisi01nfs:/NFS_Users\t/home\tnfs\tnfsvers=3\t0\t0""" >> /etc/fstab
		mount -a
		if [ $? -ne 0 ]
		then
			echo "Failed to mount nfs home directory" >&2
			exit 1
		fi
	fi

	if [ -z "$(grep -r '^[^\#].*sg_rhel_admins' /etc/sudoers*)" ]
	then
		echo -e "%sg_rhel_admins@HobbyLobby.corp\tALL=(ALL)\tALL" > /etc/sudoers.d/sg_rhel_admins
	fi
fi

echo "System configuration complete"
