# satApi.py

*satApi.py* is a python library for interacting with the Red Hat Satellite API.

## Usage

### Connecting to satellite api

```python
>>> from satApi import SatelliteAPI
>>> api = SatelliteAPI(server="https://satellite.example.com",user="admin",password="password")
```

### Making api calls using methods

Satellite
```python
>>> api.subnets.get()
[{u'dns_primary': u'192.168.1.1', u'from': u'', u'network': u'192.168.1.0', u'name': u'default', u'tftp': None, u'ipam': u'None', u'created_at': u'1970-01-01 00:00:00 -0000', u'mask': u'255.255.255.0', u'updated_at': u'1970-01-01 00:00:00 -0000', u'vlanid': u'1', u'id': 1, u'priority': None, u'to': u'', u'dns': None, u'dhcp': None, u'cidr': 24, u'dns_secondary': u'192.168.1.2', u'network_address': u'192.168.1.0/24', u'gateway': u'192.168.1.1', u'boot_mode': u'Static'}]
```

Katello
```python
>>> api.katello.status.get()
{u'version': u'3.0.0.000', u'timeUTC': u'1970-01-01 00:00:00 UTC'}
```

Docker
```python
>>> api.docker.containers.get()
[]
```

Foreman
```python
>>> api.foreman_tasks.tasks.get()
[{u'username': u'admin', u'ended_at': u'1970-01-01T00:00:00.000-00:00', u'output': {}, u'cli_example': None, u'label': u'Actions::Katello::Host::Hypervisors', u'state': u'stopped', u'result': u'success', u'input': {}, u'progress': 1.0, u'started_at': u'1970-01-01T00:00:01.000-00:00', u'humanized': {u'action': u'Hypervisors', u'input': [], u'errors': [], u'output': u''}, u'id': u'00000000-0000-0000-0000-000000000000', u'pending': False}]
```

### Making manual api calls

```python
>>> api.get("/api/subnets")
{u'sort': {u'by': None, u'order': None}, u'search': None, u'results': [{u'dns_primary': u'192.168.1.1', u'from': u'', u'network': u'192.168.1.0', u'name': u'default', u'tftp': None, u'ipam': u'None', u'created_at': u'1970-01-01 00:00:00 -0000', u'mask': u'255.255.255.0', u'updated_at': u'1970-01-01 00:00:00 -0000', u'vlanid': u'1', u'id': 1, u'priority': None, u'to': u'', u'dns': None, u'dhcp': None, u'cidr': 24, u'dns_secondary': u'192.168.1.2', u'network_address': u'192.168.1.0/24', u'gateway': u'192.168.1.1', u'boot_mode': u'Static'}], u'per_page': 20, u'total': 1, u'subtotal': 1, u'page': 1}
```

### Get queries and Post Data

Key word args are as params for GETs and data for POSTs

```python
>>> api.domains.get(organization_id=1)
[{u'name': u'example.com', u'created_at': u'1970-01-01 00:00:00 -0000', u'updated_at': u'1970-01-01 00:00:00 -0000', u'dns_id': None, u'fullname': None, u'id': 1}]
```

### IDs and sub queries

One non-keyworded arg is used to specify id and sub queries

```python
>>> api.domains.get('1')
{u'subnets': [{u'network_address': u'192.168.1.0/24', u'id': 1, u'name': u'default'}], u'name': u'example.com', u'parameters': [], u'organizations': [{u'description': u'', u'title': u'Default Organization', u'id': 9, u'name': u'DEFAULT_ORGANIZATION'}, {u'description': u'', u'title': u'Default', u'id': 1, u'name': u'DEFAULT'}], u'created_at': u'1970-01-01 00:00:00 -0000', u'updated_at': u'1970-01-01 00:00:00 -0000', u'locations': [], u'interfaces': [], u'dns_id': None, u'fullname': None, u'id': 1}
```

# rhel_configure.sh

*rhel_configure.sh* is used to configure a newly deployed rhel server.  Sets hostname, sets ip address, connects to Satellite, formats and mounts swap and application storage, install open-vm-tools if run on a virtual machine, installs and configures sssd, and adds sg_rhel_admins to sudoers.

## Usage
```shell
rhel_configure.sh <hostname> <ip_address> <satellite_org> <satellite_activationkey> <swap_drive> <app_drive> <app_dir> <ad_ou> <ad_sub_ou> <ad_env>
```
* hostname: hostname of server \[hlserver01\]
* ip_address: ip address of server \[10.100.37.21\]
* satellite_org: Satellite Organization to join server assign server \[HL\]
* satellite_activationkey: Activation key from satellite to use when registering \[RHEL\]
* swap_drie: Drive to use as swap \[/dev/sdb\]
* app_drive: Drive to use as application storage \[/dev/sdc\]
* ad_ou: OU to join server to in active directory \[Operations\]
* ad_sub_ou: Sub OU to join server to is ad_ou is 'Apps' \[Customer\]
* ad_env: Environment OU if ad_sub_ou is set \[Dev\]
