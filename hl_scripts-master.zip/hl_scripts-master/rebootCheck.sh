#!/bin/bash

host=$1

sshCommand() {
	ssh  -o ConnectTimeout=10 -o StrictHostKeyChecking=no -i ~foreman-proxy/.ssh/id_rsa_foreman_proxy $1 "$2"
}

shutdownWait() {
	check=0
	echo -n "Waiting for shutdown."
	sleep 60
	while [ $check -lt 40 ]
	do
		echo -n "."
		ping -c 1 -W 1 $1 > /dev/null 2>&1
		pingCode=$?
		if [ $pingCode -ne 0 ]
		then
			echo ""
			break
		fi
	done
	checo=$[check + 1]
	sleep 3
}

startupWait() {
	check=0

	echo -n "Waiting for startup"
	while [ $check -lt 10 ]
	do
	        echo -n "."
	        ping -c 1 -W 1 $host > /dev/null 2>&1
	        pingCode=$?
	        if [ $pingCode -eq 0 ]
	        then
			echo ""
	                echo "Host successfully booted"
	                sleep 10
	                sshCommand $host 'systemctl --state=failed'
			break
	        fi
	        check=$[check + 1]
        	sleep 3
	done
}

rebootHost() {
	sshCommand $host 'shutdown -r +1'
}

echo -e "\n\n\n#######################################  ${host}  ###############################################\n"

ping -c 1 -W 1 $host >/dev/null 2>&1

if [ $? -eq 0 ]
then
        echo "Host available"
else
        echo "Host not available exiting ..."
        exit 1
fi


RESTART_CHECK_OUTPUT=$(sshCommand $host 'needs-restarting -r')
if [ $? -eq 1 ]
then
	echo "#################  Host requires reboot  ##############################"
	echo -e """$RESTART_CHECK_OUTPUT"""
	echo "#######################################################################"
	rebootHost $host
	shutdownWait
	startupWait
else
	SERVICE_CHECK_OUTPUT=$(sshCommand $host 'needs-restarting -s')
	if [ $? -eq 1 ]
	then
		echo "##############################  Services require restart ########################################"
		echo """$SERVICE_CHECK_OUTPUT"""
		echo "################################################################################################"
	else
		echo "##############################  No action required  #############################################"
	fi
fi

exit 0

check=0
echo -e "Waiting for shutdown."
while [ $check -lt 10 ]
do
        echo -e "."
        ping -c 1 -W 1 $host > /dev/null 2>&1
        pingCode=$?
        if [ $pingCode -ne 0 ]
        then
                check=$[check + 10]
        fi
        sleep 3
done


check=0

echo -e "Checking host."
while [ $check -lt 10 ]
do
        echo -e "."
        ping -c 1 -W 1 $host > /dev/null 2>&1
        pingCode=$?
        if [ $pingCode -eq 0 ]
        then
                echo "Host successfully booted"
		sleep 10
		timeout 20 ssh  -o ConnectTimeout=10 -o StrictHostKeyChecking=no -i ~foreman-proxy/.ssh/id_rsa_foreman_proxy $host 'systemctl --state=failed'
                exit 0
        fi
        check=$[check + 1]
        sleep 3
done

echo "Host failed to respond to ping in a reasonable amount of time exiting ..."
exit 1
