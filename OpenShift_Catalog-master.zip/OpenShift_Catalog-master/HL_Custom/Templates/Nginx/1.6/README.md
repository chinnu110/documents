Nginx 1.6 server and a reverse proxy server container image
========================================================

**The Nginx 1.6 container image is deprecated.**
