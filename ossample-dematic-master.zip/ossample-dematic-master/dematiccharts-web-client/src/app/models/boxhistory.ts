export class get_box_history {
    building: number;
    induced_last_week: number;
    induced_last_year: number;
    induced_today: number;
    induced_yesterday: number;
    shipped_last_week: number;
    shipped_last_year: number;
    shipped_today: number;
    shipped_yesterday: number;
}