export class SeriesData{
    name: Date;
    value: number;
}