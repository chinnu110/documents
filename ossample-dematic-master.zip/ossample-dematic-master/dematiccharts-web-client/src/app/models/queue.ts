export class get_queue {
    latency: number;
    msg_type: string;
    newest: string;
    num_of_msgs: number;
    oldest: string;
}