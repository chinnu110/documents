export class BuildingNum {
    all_buildings: number[];
}