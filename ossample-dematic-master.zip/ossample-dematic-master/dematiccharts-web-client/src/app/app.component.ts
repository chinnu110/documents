import { Component } from '@angular/core';
import { CommonService } from './services/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'dematiccharts-web-client';

  constructor(public common: CommonService, public router: Router) {
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
  }

  buildings;

  ngOnInit() {
    this.common.getBuildings().subscribe(resp => {
      this.buildings = resp.all_buildings;
    })
  }

  toBuilding(num) {
    this.router.navigate(['/building', num]);
  }


}
