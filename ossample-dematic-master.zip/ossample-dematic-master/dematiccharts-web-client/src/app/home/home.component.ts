import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { Data } from '../models/data';
import { ViewData } from '../models/view_data';
import { SeriesData } from '../models/series_data';
import { Observable } from 'rxjs';
import { SocketService } from '../services/socket.service';
import { View } from '../models/view';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  model: Data = new Data;
  viewSource: ViewData[] = [];
  autoRefresh: boolean = false;

  closure = (x) => {
    this.initializeInfo(x);
    this.convertRawtoView(this.model.get_process_histories as View[]);
    this.isDataAvailable = true;
  }

  // options
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = false;
  legendTitle = 'Legend';
  legendPosition = 'right';
  showXAxisLabel = true;
  tooltipDisabled = false;
  xAxisLabel = 'Time of Day';
  showYAxisLabel = true;
  yAxisLabel = 'Message Count';
  showGridLines = true;
  innerPadding = '10%';
  barPadding = 8;
  groupPadding = 16;
  roundDomains = false;
  maxRadius = 10;
  minRadius = 3;
  showSeriesOnHover = true;
  roundEdges: boolean = true;
  animations: boolean = true;
  xScaleMin: any;
  xScaleMax: any;
  yScaleMin: number;
  yScaleMax: number;
  showDataLabel = false;
  colorScheme = {
    domain: ['#5AA454', '#A10A28']
  };

  inductedRows = [{ name: 'Today', col: 'induced_today' }, { name: 'Yesterday', col: 'induced_yesterday' }, { name: 'Last Week', col: 'induced_last_week' }, { name: 'Last Year', col: 'induced_last_year' }];
  shippedRows = [{ name: 'Today', col: 'shipped_today' }, { name: 'Yesterday', col: 'shipped_yesterday' }, { name: 'Last Week', col: 'shipped_last_week' }, { name: 'Last Year', col: 'shipped_last_year' }];

  constructor(public common: CommonService, public service: SocketService, public route: ActivatedRoute) { }

  // public boxHistory: Observable<any>
  isDataAvailable: boolean = false;
  buildingNum;
  boxHistory = [];

  ngOnInit() {

    this.buildingNum = this.route.snapshot.paramMap.get('num');
    if (!this.buildingNum) {
      this.common.getBuildings().subscribe(resp => {
        resp.all_buildings.sort();
        this.buildingNum = resp.all_buildings[0];
        this.connectToChannel();
      })
    }
    else {
      this.connectToChannel();
    }
  }

  connectToChannel() {
    this.service.getChannel(this.closure, this.buildingNum);
    this.service.onUpdate(x => {
      this.initializeInfo(x);
      this.sendGraphInfo(x);
    });
  }

  public convertRawtoView(records: View[]) {
    this.viewSource = [];
    let data = new ViewData();
    data.series = [];
    data.name = "Messages Created";

    let data2 = new ViewData();
    data2.series = [];
    data2.name = "Messages Processed";

    records.forEach(record => {
      let series = new SeriesData();
      series.name = new Date(record.timeofday); // Need to convert to date time
      series.value = record.create_count;
      data.series.push(series);

      let series2 = new SeriesData();
      series2.name = new Date(record.timeofday); // Need to convert to date time
      series2.value = record.process_count;
      data2.series.push(series2);
    });
    this.viewSource.push(data);
    this.viewSource.push(data2);
    this.viewSource = [...this.viewSource]
  }

  initializeInfo(data) {
    data.get_box_history.sort((x, y) => x.building < y.building ? -1 : x.building > y.building ? 1 : 0);
    this.boxHistory = data.get_box_history;
    this.model = data;
  }

  sendGraphInfo(x) {
    this.convertRawtoView(this.model.get_process_histories as View[]);
  }

  checkBuilding(building) {
    return building == parseInt(this.buildingNum, 10) ? 'highlight' : '';
  }

}
