import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { BuildingNum } from '../models/buildingnum';


@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(public http: HttpClient) { }

  getBuildings() {
    return this.http.get<BuildingNum>(environment.apiUrl + '/getallbuildings');
  }

}
