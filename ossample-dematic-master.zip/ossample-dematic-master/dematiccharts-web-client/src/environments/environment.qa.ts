export const environment = {
  production: false,
  apiUrl: 'https://qaapp.hobbylobby.corp/dematiccharts-api/api/',
  socketUrl: 'wss://qaapp.hobbylobby.corp/dematiccharts-api/socket'
};
