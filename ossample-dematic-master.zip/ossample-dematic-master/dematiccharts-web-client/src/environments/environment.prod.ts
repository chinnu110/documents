export const environment = {
  production: true,
  apiUrl: 'https://hlapp.hobbylobby.corp/dematiccharts-api/api/',
  socketUrl: 'wss://hlapp.hobbylobby.corp/dematiccharts-api/socket'
};
