defmodule DematicChartsApi.BuildingFourRepo do
  use Ecto.Repo, otp_app: :dematic_charts_api

  def exec_sql(sql, parms) do
    Ecto.Adapters.SQL.query(DematicChartsApi.BuildingFourRepo, sql, parms)
  end
end