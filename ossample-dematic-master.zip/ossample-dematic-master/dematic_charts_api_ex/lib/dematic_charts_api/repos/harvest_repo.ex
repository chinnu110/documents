defmodule DematicChartsApi.HarvestRepo do
  use HobbylobbyHarvestEx.Repo, otp_app: :dematic_charts_api

end
