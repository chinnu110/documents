defmodule DematicChartsApi.BuildingSixRepo do
  use Ecto.Repo, otp_app: :dematic_charts_api

  def exec_sql(sql, parms) do
    Ecto.Adapters.SQL.query(DematicChartsApi.BuildingSixRepo, sql, parms)
  end
end