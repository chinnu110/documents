defmodule DematicChartsApi.GetBoxHistoryWorker do
  use GenServer
  require Logger

  #####################
  ##   Client APIs   ##
  #####################


  def start_link(opts \\ []) do
    case :global.whereis_name(:GBHW) do
      :undefined ->
        Logger.info("get box history worker Starting Unlinked")
        {ok, pid} = GenServer.start_link(__MODULE__, :ok, [name: {:global, :GBHW}])
        {ok, pid}

      pid ->
        Logger.info("get box history worker Starting Linked")
        Process.flag(:trap_exit, true)
        Process.link(pid)
        {:ok, pid}
    end
  end



  #####################
  ## Server Callbacks ##
  #####################

  def init(:ok) do
    Process.send_after(self, :loop, 3000)
    {:ok, %{}}
  end

  def handle_info(:loop, _) do
    get_box_history("2,4,6")
    |> store_in_b4_stateserver()
    |> store_in_b6_stateserver()

  
    Process.send_after(self, :loop, 30000) #repeat loop
    {:noreply, []}
  end

  def handle_info({:EXIT, _from, :normal}, state) do
    {:noreply, state}
  end

  def handle_info(term, state) do
    Logger.error "gbhw TERMINATION CAUGHT, looping again in 20 seconds"
    {:noreply, state}
  end


  #####################
  ## Helper Functions ##
  #####################

  defp store_in_b4_stateserver(ret) do
    :global.whereis_name(:building4stateserver) |> GenServer.cast({:update, :get_box_history, ret})
    ret
  end

  defp store_in_b6_stateserver(ret) do
    :global.whereis_name(:building6stateserver) |> GenServer.cast({:update, :get_box_history, ret})
    ret
  end

  #function that filters and sums/reduces the gathered data
  defp filter_range(results, daterange, warehouse) do
      results
      |> Enum.filter(fn x ->
          x."bcwh#" == warehouse &&
          Enum.member?(daterange, Date.from_iso8601(x.date) |> elem(1))
      end)
      |> Enum.reduce({0, 0}, fn x, {shipped, induced} ->
          {x.cases_shipped + shipped, x.total_cases_received + induced}
      end)
  end

  defp get_box_history(warehouses) do
    case DematicChartsApi.BoxHistory.get_box_history(warehouses) do
      {:ok, ret} -> ret
      {:error, reason} -> Logger.error(reason)
    end
  end

end
