defmodule DematicChartsApi.GetProcessHistoriesWorker do
  use GenServer
  require Logger


  #####################
  ##   Client APIs   ##
  #####################

  def start_link(opts \\ []) do
    case :global.whereis_name(:GPHW) do
      :undefined ->
        Logger.info("get process histories worker Starting Unlinked")
        {ok, pid} = GenServer.start_link(__MODULE__, :ok, [name: {:global, :GPHW}])
        {ok, pid}

      pid ->
        Logger.info("get process histories worker Starting Linked")
        Process.flag(:trap_exit, true)
        Process.link(pid)
        {:ok, pid}
    end
  end

  def handle_info(:loop, _) do
    with  {{year, month, day}, _} <- :calendar.local_time(),
          {:ok, get_process_histories_data} <- DematicChartsApi.ProcessHistory.get_process_histories(year, month, day),
          {:ok, get_process_histories_data_4} <- DematicChartsApi.ProcessHistory.get_process_histories(year, month, day, "4")
    do
      :global.whereis_name(:building6stateserver) |> GenServer.cast({:update, :get_process_histories, get_process_histories_data})
      :global.whereis_name(:building4stateserver) |> GenServer.cast({:update, :get_process_histories, get_process_histories_data_4})
    else
      {:error, reason} -> Logger.error(reason)
    end
  
    Process.send_after(self, :loop, 30000)
    {:noreply, []}
  end

  ######################
  ## Server Callbacks ##
  ######################

  def init(:ok) do
    Process.send_after(self, :loop, 2200)
    {:ok, %{}}
  end

  def handle_info({:EXIT, _from, :normal}, state) do
      {:noreply, state}
  end
  
  def handle_info(term, state) do
    Logger.error "gbhw TERMINATION CAUGHT, looping again in 20 seconds"
    {:noreply, state}
  end
end
