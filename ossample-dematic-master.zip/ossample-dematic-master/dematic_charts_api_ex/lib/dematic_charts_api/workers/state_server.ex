defmodule DematicChartsApi.Stateserver do
  use GenServer
  require Logger

  #####################
  ##   Client APIs   ##
  #####################

  def start_link(opts \\ []) do
    Process.sleep(5_000)
    case :global.whereis_name(opts.name) do
      :undefined ->
        "#{opts.name |> Atom.to_string} starting unlinked" |> Logger.info()
        {ok, pid} = GenServer.start_link(__MODULE__, opts, [name: {:global, opts.name}])
        {ok, pid}

      pid ->
        "#{opts.name |> Atom.to_string} starting linked" |> Logger.info()
        Process.flag(:trap_exit, true)
        Process.link(pid)
        {:ok, pid}
    end
  end

  def init(state) do
    Process.flag(:trap_exit, true)
    Process.send_after(self, :loop, 10_000)
    {:ok, state}
  end

  def handle_call(:read, _from, state) do
    {:reply, state, state}
  end

  def handle_cast({:update, key, newvalue}, state) do
    state = update_state(state, key, newvalue)
    {:noreply, state}
  end

  def handle_info(:loop, state) do
    Process.send_after(self, :loop, 20_000)
    case DematicChartsApiWeb.Endpoint.broadcast("channel:#{state.building}", "data_updated", state) do
      :ok -> :ok
      {:error, reason} -> reason |> Logger.error()
    end
    {:noreply, state}
  end

  def handle_info({:EXIT, _from, :normal}, state) do
    {:noreply, state}
  end

  def handle_info(_term, state) do
    "#{state.name} TERMINATION CAUGHT, looping again in 20 seconds" |> Logger.error()
    {:noreply, state}
  end



  #####################
  ## Helper Functions ##
  #####################

  def get_data do
    :global.whereis_name(:StateServer)
    |> GenServer.call(:read)
  end

  def update(key, newvalue) do
    :global.whereis_name(:StateServer)
    |> GenServer.cast({:update, key, newvalue})
  end

  defp update_state(state, key, newvalue) do
    case Map.has_key?(state, key) do
      true ->
        Map.replace!(state, key, newvalue)
  
      false ->
        Map.put_new(state, key, newvalue)
      end
  end

end
