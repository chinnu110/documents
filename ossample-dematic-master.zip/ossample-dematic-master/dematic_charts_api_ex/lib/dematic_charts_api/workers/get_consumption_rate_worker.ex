defmodule DematicChartsApi.GetConsumptionRateWorker do
  use GenServer
  require Logger


  #####################
  ##   Client APIs   ##
  #####################

  def start_link(opts \\ []) do
    case :global.whereis_name(:GCRW) do
      :undefined ->
        Logger.info("get consumption rate worker Starting Unlinked")
        {ok, pid} = GenServer.start_link(__MODULE__, :ok, [name: {:global, :GCRW}])
        {ok, pid}

      pid ->
        Logger.info("get consumption rate worker Starting Linked")
        Process.flag(:trap_exit, true)
        Process.link(pid)
        {:ok, pid}
    end
  end

  def handle_info(:loop, state) do
    with  {:ok, get_consumption_rate_data} <- DematicChartsApi.ConsumptionRate.get_consumption_rate(-1),
          {:ok, get_consumption_rate_data_4} <- DematicChartsApi.ConsumptionRate.get_consumption_rate(-1,"4")
    do
      :global.whereis_name(:building6stateserver) |> GenServer.cast({:update, :get_consumption_rate, get_consumption_rate_data})
      :global.whereis_name(:building4stateserver) |> GenServer.cast({:update, :get_consumption_rate, get_consumption_rate_data_4})
    else
      {:error, reason} -> Logger.error(reason)
    end      

    Process.send_after(self, :loop, 30_000)
    {:noreply, state}
  end
  

  def handle_info({:EXIT, _from, :normal}, state) do
    {:noreply, state}
  end


  def handle_info(term, state) do
    Logger.error "gcrw TERMINATION CAUGHT, looping again in 20 seconds"

    {:noreply, state}
  end

  ######################
  ## Server Callbacks ##
  ######################

  def init(:ok) do
    Process.send_after(self, :loop, 2_500)
    {:ok, %{}}
  end
end
