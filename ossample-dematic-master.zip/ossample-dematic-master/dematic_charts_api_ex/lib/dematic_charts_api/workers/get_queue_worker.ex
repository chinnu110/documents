defmodule DematicChartsApi.GetQueueWorker do
  use GenServer
  require Logger

  
  #####################
  ##   Client APIs   ##
  #####################

  def start_link(opts \\ []) do

    case :global.whereis_name(:GQW) do
      :undefined ->
        Logger.info("StateServer Starting Unlinked")
        {ok, pid} = GenServer.start_link(__MODULE__, :ok, [name: {:global, :GQW}])
        {ok, pid}

      pid ->
        Logger.info("StateServer Starting Linked")
        Process.flag(:trap_exit, true)
        Process.link(pid)
        {:ok, pid}
    end
  end

  
  def handle_info(:loop, state) do
    with  {:ok, get_queue_data} <- DematicChartsApi.QueueByMessage.get_queue(),
          {:ok, get_queue_data_4} <- DematicChartsApi.QueueByMessage.get_queue("4")
    do
      :global.whereis_name(:building6stateserver) |> GenServer.cast({:update, :get_queue, get_queue_data})
      :global.whereis_name(:building4stateserver) |> GenServer.cast({:update, :get_queue, get_queue_data_4})
    else
      {:error, reason} -> Logger.error(reason)
    end

    Process.send_after(self, :loop, 30_000)
    {:noreply, state}
  end

  def handle_info({:EXIT, _from, :normal}, state) do

    {:noreply, state}
  end

  def handle_info(term, state) do
    Logger.error "TERMINATION CAUGHT, looping again in 20 seconds"

    {:noreply, state}
  end

  ######################
  ## Server Callbacks ##
  ######################

  def init(:ok) do
    Process.send_after(self, :loop, 2_000)
    {:ok, %{}}
  end

end
