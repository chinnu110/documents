defmodule DematicChartsApi.GetActiveSkusWorker do
    use GenServer
    require Logger

    #####################
    ##   Client APIs   ##
    #####################


    def start_link(opts \\ []) do
      case :global.whereis_name(:GASW) do
        :undefined ->
          Logger.info("get active skus worker Starting Unlinked")
          {ok, pid} = GenServer.start_link(__MODULE__, :ok, [name: {:global, :GASW}])
          {ok, pid}
  
        pid ->
          Logger.info("get active skus worker Starting Linked")
          Process.flag(:trap_exit, true)
          Process.link(pid)
          {:ok, pid}
      end
    end

    def init(:ok) do
      Process.send_after(self, :loop, 3500)   #loop
      {:ok, %{}}
    end


    def handle_info(:loop, state) do

      with {:ok, get_active_skus_data} <- DematicChartsApi.ActiveSkus.get_active_skus(),
            {:ok, get_active_skus_data_4} <- DematicChartsApi.ActiveSkus.get_active_skus("4")
      do
        :global.whereis_name(:building6stateserver) |> GenServer.cast({:update, :get_active_skus, get_active_skus_data})
        :global.whereis_name(:building4stateserver) |> GenServer.cast({:update, :get_active_skus, get_active_skus_data_4})
      else
        {:error, reason} -> Logger.error(reason)
      end      

      Process.send_after(self, :loop, 30000)
      {:noreply, state}
    end

    def handle_info({:EXIT, _from, :normal}, state) do
      {:noreply, state}
    end
  
    def handle_info(term, state) do
      Logger.error "gbhw TERMINATION CAUGHT, looping again in 20 seconds"
      {:noreply, state}
    end
end
