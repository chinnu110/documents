defmodule DematicChartsApi.GetTotalQueueWorker do
  use GenServer
  require Logger

  
  #####################
  ##   Client APIs   ##
  #####################

  def start_link(opts \\ []) do
    case GenServer.start_link(__MODULE__, :ok, name: {:global, :GTQW}) do
      {:ok, pid} ->
        Logger.info("get total queue worker starting unlinked")
        {:ok, pid}

      {:error, {:already_started, pid}} ->
        Logger.info("get total queue worker starting linked")
        Process.link(pid)
        {:ok, pid}
    end
  end

  def init(:ok) do
    Process.send_after(self, :loop, 100)
    {:ok, %{}}
  end

  def handle_info(:loop, _) do
    with  {:ok, data6} = DematicChartsApi.TotalQueue.get_total_queue(),
          {:ok, data4} = DematicChartsApi.TotalQueue.get_total_queue("4")
    do
      :global.whereis_name(:building6stateserver) |> GenServer.cast({:update, :get_total_queue, data6})
      :global.whereis_name(:building4stateserver) |> GenServer.cast({:update, :get_total_queue, data4})
    else
      {:error, reason} -> Logger.error(reason)
    end

    Process.send_after(self, :loop, 30_000)
    {:noreply, []}
  end

  def handle_info({:EXIT, _from, :normal}, state) do
      {:noreply, state}
  end
  
  def handle_info(term, state) do
    Logger.error "gbhw TERMINATION CAUGHT, looping again in 20 seconds"
    {:noreply, state}
  end  
end
