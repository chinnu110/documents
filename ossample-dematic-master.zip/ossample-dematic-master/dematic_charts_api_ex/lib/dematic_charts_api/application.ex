defmodule DematicChartsApi.Application do
  # See https://hexdocs.pm/elixir/Application.html
  # for more information on OTP Applications
  @moduledoc false

  use Application

  def start(_type, _args) do
    # List all child processes to be supervised
    children = [
      {DematicChartsApi.HarvestRepo, []},
      {Cluster.Supervisor, [Application.get_env(:libcluster, :topologies), [name: DematicChartsApi.ClusterSupervisor]]},
      {DematicChartsApi.BuildingSixRepo, []},
      {DematicChartsApi.BuildingFourRepo, []},
      Supervisor.child_spec({DematicChartsApi.Stateserver, %{name: :building6stateserver, building: 6}}, id: :building6stateserver),
      Supervisor.child_spec({DematicChartsApi.Stateserver, %{name: :building4stateserver, building: 4}}, id: :building4stateserver),
      {DematicChartsApi.GetProcessHistoriesWorker,[]},
      {DematicChartsApi.GetActiveSkusWorker,[]},
      {DematicChartsApi.GetTotalQueueWorker,[]},
      {DematicChartsApi.GetBoxHistoryWorker,[]},
      {DematicChartsApi.GetConsumptionRateWorker,[]},
      {DematicChartsApi.GetQueueWorker,[]},
      DematicChartsApiWeb.Endpoint
    ]

    # See https://hexdocs.pm/elixir/Supervisor.html
    # for other strategies and supported options
    opts = [strategy: :one_for_one, name: DematicChartsApi.Supervisor]
    Supervisor.start_link(children, opts)
  end

  # Tell Phoenix to update the endpoint configuration
  # whenever the application is updated.
  def config_change(changed, _new, removed) do
    DematicChartsApiWeb.Endpoint.config_change(changed, removed)
    :ok
  end
end
