defmodule DematicChartsApi.AllBuildings do
  defstruct all_buildings: []

  def get_all_buildings() do
    {:ok, %{all_buildings: [4,6]}}
  end

end
