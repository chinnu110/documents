defmodule DematicChartsApi.QueueByMessage do
  defstruct msg_type: "",
            num_of_msgs: "",
            oldest: "",
            newest: "",
            latency: ""


  def get_queue() do
    with query <- "select msg_type, count(*) as num_of_msgs,
               min(created_time) as oldest, max(created_time) as newest,
               datediff(ms, min(created_time), max(created_time)) as latency
               from hst.wmsmessagequeue (nolock)
               where transmitted = 'N' group by msg_type",
          {:ok, results} <- DematicChartsApi.BuildingSixRepo.exec_sql(query, []) do
      results
      |> DematicChartsApi.Util.gen_processor_multi(%DematicChartsApi.QueueByMessage{})
    end
  end

  def get_queue("4") do
    with query <- "select msg_type, count(*) as num_of_msgs,
               min(created_time) as oldest, max(created_time) as newest,
               datediff(ms, min(created_time), max(created_time)) as latency
               from hst.wmsmessagequeue (nolock)
               where transmitted = 'N' group by msg_type",
          {:ok, results} <- DematicChartsApi.BuildingFourRepo.exec_sql(query, []) do
      results
      |> DematicChartsApi.Util.gen_processor_multi(%DematicChartsApi.QueueByMessage{})
    end
  end

end
