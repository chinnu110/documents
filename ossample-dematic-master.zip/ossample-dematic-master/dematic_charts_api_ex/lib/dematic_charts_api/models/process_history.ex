defmodule DematicChartsApi.ProcessHistory do
  defstruct timeofday: "",
            create_count: "",
            process_count: ""


 def get_process_histories(year, month, day) do
    with  query <- "select coalesce(a.timeofday, b.timeofday) as timeofday, create_count, process_count
               from
               (
               select LEFT(CONVERT(VARCHAR, created_time, 8),5) as timeofday,
               count(*) as create_count
               from DirectorIT_Sorting.hst.wmsmessagequeueLog (nolock)
               where transmitted = 'Y'
               and created_time between
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 04, 00, 01, 0 ) and
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 23, 59, 59, 0 )
               group by LEFT(CONVERT(VARCHAR, created_time, 8),5)
               ) a
               
               left join
               (
               select LEFT(CONVERT(VARCHAR, updated_time, 8),5) as timeofday,
               count(*) as process_count
               from DirectorIT_Sorting.hst.wmsmessagequeueLog (nolock)
               where transmitted = 'Y'
               and created_time between
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 04, 00, 01, 0 ) and
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 23, 59, 59, 0 )
               group by LEFT(CONVERT(VARCHAR, updated_time, 8),5)
               ) b on a.timeofday = b.timeofday
               order by timeofday",
          {:ok, results} <- DematicChartsApi.BuildingSixRepo.exec_sql(query, []),
          results <- DematicChartsApi.Util.gen_processor_multi(results, %DematicChartsApi.ProcessHistory{})
           do

            add_dates(results, year, month, day)
    end
  end

  def get_process_histories(year, month, day, "4") do
    with  query <- "select coalesce(a.timeofday, b.timeofday) as timeofday, create_count, process_count
               from
               (
               select LEFT(CONVERT(VARCHAR, created_time, 8),5) as timeofday,
               count(*) as create_count
               from DirectorIT_Sorting.hst.wmsmessagequeueLog (nolock)
               where transmitted = 'Y'
               and created_time between
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 04, 00, 01, 0 ) and
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 23, 59, 59, 0 )
               group by LEFT(CONVERT(VARCHAR, created_time, 8),5)
               ) a
               
               left join
               (
               select LEFT(CONVERT(VARCHAR, updated_time, 8),5) as timeofday,
               count(*) as process_count
               from DirectorIT_Sorting.hst.wmsmessagequeueLog (nolock)
               where transmitted = 'Y'
               and created_time between
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 04, 00, 01, 0 ) and
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 23, 59, 59, 0 )
               group by LEFT(CONVERT(VARCHAR, updated_time, 8),5)
               ) b on a.timeofday = b.timeofday
               order by timeofday",
          {:ok, results} <- DematicChartsApi.BuildingFourRepo.exec_sql(query, []),
          results <- DematicChartsApi.Util.gen_processor_multi(results, %DematicChartsApi.ProcessHistory{})
           do

            add_dates(results, year, month, day)
    end
  end




  defp add_dates({:ok, results}, year, month, day) do
    #assumed that year, month, and day are strings

    results = 
    Enum.map(results, fn result -> 
      current_tod = Map.get(result, :timeofday)
      new_tod = "#{month}-#{day}-#{year} " <> current_tod

      Map.put(result, :timeofday, new_tod)
    end)

    {:ok, results}
  end
  
end
