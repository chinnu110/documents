defmodule DematicChartsApi.TotalQueue do
  defstruct total_messages: "",
            oldest: "",
            newest: "",
            latency: ""


  def get_total_queue() do
    with query <- "select total_messages, oldest, newest, datediff(ms, oldest, newest) as latency
               from
               (
               select count(*) as total_messages, min(created_time) as oldest, max(created_time) as newest
               from DirectorIT_Sorting.hst.wmsmessagequeue (nolock)
               where transmitted = 'N'
               ) a",
         {:ok, results} <- DematicChartsApi.BuildingSixRepo.exec_sql(query, []) do
      results
      |> DematicChartsApi.Util.gen_processor_multi(%DematicChartsApi.TotalQueue{})
    end
  end


  def get_total_queue("4") do
    with query <- "select total_messages, oldest, newest, datediff(ms, oldest, newest) as latency
               from
               (
               select count(*) as total_messages, min(created_time) as oldest, max(created_time) as newest
               from DirectorIT_Sorting.hst.wmsmessagequeue (nolock)
               where transmitted = 'N'
               ) a",
         {:ok, results} <- DematicChartsApi.BuildingFourRepo.exec_sql(query, []) do
      results
      |> DematicChartsApi.Util.gen_processor_multi(%DematicChartsApi.TotalQueue{})
    end
  end

end
