defmodule DematicChartsApi.ConsumptionRate do
  defstruct create_count: "",
            consumed_count: "",
            consumption_rate: ""


  def get_consumption_rate(last_minutes) do
    with query <-
           "select a.create_count, b.consumed_count, b.consumed_count/(iif(a.create_count = 0,1,a.create_count) * 1.00) as consumption_rate
               from
               (
               select count(*) as create_count
               from DirectorIT_Sorting.hst.wmsMessageQueueLog (nolock)
               where created_time between dateadd(mi,#{last_minutes},getdate()) and getdate()
               ) a
                
               cross join
                
               (
               select count(*) as consumed_count
               from DirectorIT_Sorting.hst.wmsMessageQueueLog (nolock)
               where updated_time between dateadd(mi,#{last_minutes},getdate()) and getdate()
               ) b",
         {:ok, results} <- DematicChartsApi.BuildingSixRepo.exec_sql(query, []) do
      results
      |> DematicChartsApi.Util.gen_processor_multi(%DematicChartsApi.ConsumptionRate{})
    end
  end

  def get_consumption_rate(last_minutes, "4") do
    with query <-
           "select a.create_count, b.consumed_count, b.consumed_count/(iif(a.create_count = 0,1,a.create_count) * 1.00) as consumption_rate
               from
               (
               select count(*) as create_count
               from DirectorIT_Sorting.hst.wmsMessageQueueLog (nolock)
               where created_time between dateadd(mi,#{last_minutes},getdate()) and getdate()
               ) a
                
               cross join
                
               (
               select count(*) as consumed_count
               from DirectorIT_Sorting.hst.wmsMessageQueueLog (nolock)
               where updated_time between dateadd(mi,#{last_minutes},getdate()) and getdate()
               ) b",
         {:ok, results} <- DematicChartsApi.BuildingFourRepo.exec_sql(query, []) do
      results
      |> DematicChartsApi.Util.gen_processor_multi(%DematicChartsApi.ConsumptionRate{})
    end
  end
end
