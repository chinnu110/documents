defmodule DematicChartsApi.BoxHistory do
  defstruct "bcwh#": "",
            whname: "",
            date: "",
            put_cases: "",
            residual_cases: "",
            full_cases: "",
            total_cases_received: "",
            closed_repacks: "",
            cases_shipped: "",
            cases_sent: ""


  def get_box_history_data(from, to, warehouses) do
    DematicChartsApi.HarvestRepo.map_to_procedure(
      "SQLREPORTS.USPRPT_PUT_SYS_STATS_HISTORY",
      [
        {{:sql_char, 10}, [from |> String.to_char_list()]},
        {{:sql_char, 10}, [to |> String.to_char_list()]},
        {{:sql_char, 50}, [warehouses |> String.to_char_list()]}
      ],
      DematicChartsApi.BoxHistory
    )
  end


  def get_box_history(warehouses) do 
    # set current date and previous year
    {{year, month, day}, _} = :calendar.local_time()
    lastyear = year - 1

    # make sure month and day are both always 2 digits
    day = String.pad_leading("#{day}", 2, "0")
    month = String.pad_leading("#{month}", 2, "0")

    from_last_year = "#{lastyear}-01-01"
    to_last_year = "#{lastyear}-#{month}-#{day}"
    datestring = "#{year}-#{month}-#{day}"
    lastyeardatestring = "#{lastyear}-#{month}-#{day}"


    todaydaterange = Date.range(Date.from_iso8601(datestring) |> elem(1), Date.from_iso8601(datestring) |> elem(1))
    yesterdaydaterange = Date.range(Date.add(Date.utc_today,-1),Date.add(Date.utc_today,-1))

    #Define the last year date range from Jan 1 to today's month & day last year
    lastyeardaterange = Date.range(Date.from_iso8601(from_last_year) |> elem(1), Date.from_iso8601(to_last_year) |> elem(1))

    #set last week date range from last week's Monday to it's following Sunday
    lastweekdaterange = Date.range(Date.from_erl(DateHelpers.monday_in_the_week_of(Timex.shift(:calendar.local_time(), weeks: -1))) |> elem(1),
                                    Date.from_erl(DateHelpers.sunday_in_the_week_of(Timex.shift(:calendar.local_time(), weeks: -1))) |> elem(1))
    

    with {:ok, results} <-
            DematicChartsApi.BoxHistory.get_box_history_data(
              from_last_year,
              datestring,
              warehouses
            ) do

        # shipped & induced today
        {buildingsixshippedtoday, buildingsixinducedtoday} = filter_range(results, todaydaterange, 6)
        {buildingtwoshippedtoday, buildingtwoinducedtoday} = filter_range(results, todaydaterange, 2)
        {buildingfourshippedtoday, buildingfourinducedtoday} = filter_range(results, todaydaterange, 4)

        # shipped & induced yesterday
        {buildingsixshippedyesterday, buildingsixinducedyesterday} = filter_range(results, yesterdaydaterange, 6)
        {buildingtwoshippedyesterday, buildingtwoinducedyesterday} = filter_range(results, yesterdaydaterange, 2)
        {buildingfourshippedyesterday, buildingfourinducedyesterday} = filter_range(results, yesterdaydaterange, 4)

        # shipped & induced last week
        {buildingsixshippedlastweek, buildingsixinducedlastweek} = filter_range(results, lastweekdaterange, 6)
        {buildingtwoshippedlastweek, buildingtwoinducedlastweek} = filter_range(results, lastweekdaterange, 2)
        {buildingfourshippedlastweek, buildingfourinducedlastweek} = filter_range(results, lastweekdaterange, 4)

        # shipped & induced last year
        {buildingsixshippedlastyear, buildingsixinducedlastyear} = filter_range(results, lastyeardaterange, 6)
        {buildingtwoshippedlastyear, buildingtwoinducedlastyear} = filter_range(results, lastyeardaterange, 2)
        {buildingfourshippedlastyear, buildingfourinducedlastyear} = filter_range(results, lastyeardaterange, 4)


        ret = [
            %{
              building: 2, 
              shipped_today: buildingtwoshippedtoday,
              induced_today: buildingtwoinducedtoday,
              shipped_yesterday: buildingtwoshippedyesterday,
              induced_yesterday: buildingtwoinducedyesterday,
              shipped_last_week: buildingtwoshippedlastweek,
              induced_last_week: buildingtwoinducedlastweek,
              shipped_last_year: buildingtwoshippedlastyear,
              induced_last_year: buildingtwoinducedlastyear,
            },
            %{
              building: 6, 
              shipped_today: buildingsixshippedtoday,
              induced_today: buildingsixinducedtoday,
              shipped_yesterday: buildingsixshippedyesterday,
              induced_yesterday: buildingsixinducedyesterday,
              shipped_last_week: buildingsixshippedlastweek,
              induced_last_week: buildingsixinducedlastweek,
              shipped_last_year: buildingsixshippedlastyear,
              induced_last_year: buildingsixinducedlastyear,
            },
            %{
              building: 4, 
              shipped_today: buildingfourshippedtoday,
              induced_today: buildingfourinducedtoday,
              shipped_yesterday: buildingfourshippedyesterday,
              induced_yesterday: buildingfourinducedyesterday,
              shipped_last_week: buildingfourshippedlastweek,
              induced_last_week: buildingfourinducedlastweek,
              shipped_last_year: buildingfourshippedlastyear,
              induced_last_year: buildingfourinducedlastyear,
            }
          ]
          
        {:ok, ret}

    else
      {:error, reason} -> {:error, reason}
    end
  end


  #function that filters and sums/reduces the gathered data
  defp filter_range(results, daterange, warehouse) do
      results
      |> Enum.filter(fn x ->
        x."bcwh#" == warehouse &&
          Enum.member?(daterange, Date.from_iso8601(x.date) |> elem(1))
      end)
      |> Enum.reduce({0, 0}, fn x, {shipped, induced} ->
        {x.cases_shipped + shipped, x.total_cases_received + induced}
      end)
  end

end