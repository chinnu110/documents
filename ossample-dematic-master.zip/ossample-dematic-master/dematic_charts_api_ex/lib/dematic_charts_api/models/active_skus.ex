defmodule DematicChartsApi.ActiveSkus do
  defstruct LocationID: "",
            SKU: "",
            PO: "",
            Distribution: "",
            ManifestID: "",
            SKUType: ""

 def get_active_skus() do
    with query <-
           "SELECT DISTINCT LocationID, BM.SKU, BM.PO, BM.Distribution, S.ManifestID, SKUType
               FROM DirectorIT_SORTING.WCS.SupplyLocation SL
               INNER JOIN DirectorIT_SORTING.WCS.Supply S ON SL.SupplyKey = S.SupplyKey
               INNER JOIN DirectorIT_SORTING.WCS.BatchMap BM ON S.BatchKey = BM.BatchKey
               WHERE StartSKU = 'Y'",
         {:ok, results} <- DematicChartsApi.BuildingSixRepo.exec_sql(query, []) do
      results
      |> DematicChartsApi.Util.gen_processor_multi(%DematicChartsApi.ActiveSkus{})
    end
  end

  def get_active_skus("4") do
    with query <-
           "SELECT DISTINCT LocationID, BM.SKU, BM.PO, BM.Distribution, S.ManifestID, SKUType
               FROM DirectorIT_SORTING.WCS.SupplyLocation SL
               INNER JOIN DirectorIT_SORTING.WCS.Supply S ON SL.SupplyKey = S.SupplyKey
               INNER JOIN DirectorIT_SORTING.WCS.BatchMap BM ON S.BatchKey = BM.BatchKey
               WHERE StartSKU = 'Y'",
         {:ok, results} <- DematicChartsApi.BuildingFourRepo.exec_sql(query, []) do
      results
      |> DematicChartsApi.Util.gen_processor_multi(%DematicChartsApi.ActiveSkus{})
    end
  end

end
