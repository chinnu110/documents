defmodule DematicChartsApiWeb.Router do
  use DematicChartsApiWeb, :router

  pipeline :api do
    plug :accepts, ["json"]
  end

  scope "/api", DematicChartsApiWeb do
    pipe_through(:api)

    get("/getallbuildings", BuildingSixController, :get_all_buildings)

    get("/buildingsix/getconsumptionrate", BuildingSixController, :get_consumption_rate)
    get("/buildingsix/getqueue", BuildingSixController, :get_queue)
    get("/buildingsix/gettotalqueue", BuildingSixController, :get_total_queue)
    get("/buildingsix/gethistory", BuildingSixController, :get_process_histories)
    get("/buildingsix/getboxhistory", BuildingSixController, :get_box_history)
    get("/buildingsix/getactiveskus", BuildingSixController, :get_active_skus)

    get("/buildingfour/getconsumptionrate", BuildingFourController, :get_consumption_rate)
    get("/buildingfour/getqueue", BuildingFourController, :get_queue)
    get("/buildingfour/gettotalqueue", BuildingFourController, :get_total_queue)
    get("/buildingfour/gethistory", BuildingFourController, :get_process_histories)
    get("/buildingfour/getboxhistory", BuildingFourController, :get_box_history)
    get("/buildingfour/getactiveskus", BuildingFourController, :get_active_skus)

  end

  
end
