defmodule DematicChartsApiWeb.BuildingSixController do
  use DematicChartsApiWeb, :controller

  def get_all_buildings(conn, _params) do
    case DematicChartsApi.AllBuildings.get_all_buildings() do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_consumption_rate(conn, _params) do
    case DematicChartsApi.ConsumptionRate.get_consumption_rate(-1) do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_queue(conn, _params) do
    case DematicChartsApi.QueueByMessage.get_queue() do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_total_queue(conn, _params) do
    case DematicChartsApi.TotalQueue.get_total_queue() do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_process_histories(conn, %{"year" => year, "month" => month, "day" => day} = params) do
    case DematicChartsApi.ProcessHistory.get_process_histories(year, month, day) do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_active_skus(conn, _params) do
    case DematicChartsApi.ActiveSkus.get_active_skus() do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_box_history(conn, %{"warehouses" => warehouses} = params) do
    case DematicChartsApi.BoxHistory.get_box_history(warehouses) do
      {:ok, ret} -> conn |> json(ret)
      {:error, reason} -> conn |> send_error_resp(reason)
    end
  end


  def send_error_resp(conn, error) do
    conn
    |> put_resp_content_type("application/json")
    |> send_resp(500, Poison.encode!(error))
    |> halt
  end

  
end

defimpl Poison.Encoder, for: [Tuple] do
  # Assumption is anything in this tuple format is an Ecto.DateTime
  def encode({{_y, _m, _d}, {_h, _min, _s, _ms}} = dt, _opts) do
    {:ok, dt} = Ecto.DateTime.load(dt)
    <<?", Ecto.DateTime.to_iso8601(dt)::binary, ?">>
  end
end