defmodule DematicChartsApiWeb.BuildingFourController do
  use DematicChartsApiWeb, :controller

  def get_consumption_rate(conn, _params) do
    case DematicChartsApi.ConsumptionRate.get_consumption_rate(-1, "4") do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_queue(conn, _params) do
    case DematicChartsApi.QueueByMessage.get_queue("4") do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_total_queue(conn, _params) do
    case DematicChartsApi.TotalQueue.get_total_queue("4") do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  #http://localhost:4000/api/buildingfour/gethistory?year=2019&month=06&day=03
  def get_process_histories(conn, %{"year" => year, "month" => month, "day" => day} = params) do
    case DematicChartsApi.ProcessHistory.get_process_histories(year, month, day, "4") do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_active_skus(conn, _params) do
    case DematicChartsApi.ActiveSkus.get_active_skus("4") do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  #
  def get_box_history(conn, %{"warehouses" => warehouses} = params) do
    case DematicChartsApi.BoxHistory.get_box_history(warehouses) do
      {:ok, ret} -> conn |> json(ret)
      {:error, reason} -> conn |> send_error_resp(reason)
    end
  end


  def send_error_resp(conn, error) do
    conn
    |> put_resp_content_type("application/json")
    |> send_resp(500, Poison.encode!(error))
    |> halt
  end

  
end
