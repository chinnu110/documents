defmodule DematicChartsApiWeb.Endpoint do
  use Phoenix.Endpoint, otp_app: :dematic_charts_api

  socket "/socket", DematicChartsApiWeb.UserSocket,
    websocket: true,
    longpoll: false

  plug(CORSPlug)

  plug Plug.Static,
    at: "/",
    from: :dematic_charts_api,
    gzip: false,
    only: ~w(css fonts images js favicon.ico robots.txt)

  # if code_reloading? do
  #   plug Phoenix.CodeReloader
  # end

  plug Plug.RequestId
  plug Plug.Logger

  plug Plug.Parsers,
    parsers: [:urlencoded, :multipart, :json],
    pass: ["*/*"],
    json_decoder: Phoenix.json_library()

  plug Plug.MethodOverride
  plug Plug.Head

  plug Plug.Session,
    store: :cookie,
    key: "_dematic_charts_api_key",
    signing_salt: "jWMWapL5"

  plug DematicChartsApiWeb.Router
end
