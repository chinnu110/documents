defmodule DematicChartsApiWeb.DataChannel do
    use Phoenix.Channel
    require Logger

    #"channel:6"
    def join("channel:" <> channelname, _payload, socket) do

      with  servername <- "building" <> channelname <> "stateserver" |> String.to_atom,
            send <- :global.whereis_name(servername) |> GenServer.call(:read)
      do
        {:ok, send, socket}   
      else
        reason -> Logger.error("tried to join an invalid channel", reason)
        {:error, reason}
      end
    end
  end
