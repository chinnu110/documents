use Mix.Config

config :dematic_charts_api, DematicChartsApi.BuildingSixRepo,
adapter: MssqlEcto,
database: "DirectorIT_Sorting",
username: "DematicChartsUser",
password: "jIFkCG&!X@eUcI1V",
hostname: "Hldmb6sql01.hobbylobby.corp",
instance_name: "MSSQLSERVER",
port: "1433",
pool_size: 2,
odbc_driver: "{ODBC Driver 17 for SQL Server}"

config :dematic_charts_api, DematicChartsApi.BuildingFourRepo,
adapter: MssqlEcto,
database: "DirectorIT_Sorting",
username: "DematicChartsUser",
password: "jIFkCG&!X@eUcI1V",
hostname: "Hldmb4sql01",
instance_name: "MSSQLSERVER",
port: "1433",
pool_size: 2,
odbc_driver: "{ODBC Driver 17 for SQL Server}"


##new harvest repos
config :dematic_charts_api, DematicChartsApi.HarvestRepo,
connection_string: 'DRIVER=IBM i Access ODBC Driver 64-bit;SYSTEM=10.100.1.39;UID=SVCOPPROGD;PWD=DustinIs#1',
db_type: :db2,
pool_size: 3
