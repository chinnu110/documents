use Mix.Config

config :cors_plug,
  origin: [
    "http://localhost",
    "http://localhost:4200",
    "https://hlapp",
    "https://hlapp.hobbylobby.corp"
  ],
  max_age: 86400,
  methods: ["GET", "POST"]


config :logger, level: :info

config :libcluster,
  topologies: [
    epmd: [
      strategy: Cluster.Strategy.Epmd,
      config: [hosts: [:"dematiccharts_node@hlerlapp01.hobbylobby.corp", :"dematiccharts_node@hlerlapp02.hobbylobby.corp"]]
    ]
  ]

config :phoenix, :stacktrace_depth, 20

import_config "prod.secret.exs"
