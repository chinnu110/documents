use Mix.Config

config :dematic_charts_api, DematicChartsApiWeb.Endpoint,
  http: [port: System.get_env("PORT")],
  debug_errors: true,
  code_reloader: false,
  check_origin: false,
  watchers: []

config :cors_plug,
  origin: [
    "http://localhost",
    "http://localhost:4200",
    "https://devapp",
    "https://devapp.hobbylobby.corp"
  ],
  max_age: 86400,
  methods: ["GET", "POST"]

config :logger, :console, format: "[$level] $message\n"

config :logger, level: :info

config :phoenix, :stacktrace_depth, 20

config :libcluster,
  topologies: [
    epmd: [
      strategy: Cluster.Strategy.Epmd,
      config: [hosts: [:"dematiccharts_node@deverlapp01.hobbylobby.corp", :"dematiccharts_node@deverlapp02.hobbylobby.corp"]]
    ]
  ]

import_config "dev.secret.exs"
