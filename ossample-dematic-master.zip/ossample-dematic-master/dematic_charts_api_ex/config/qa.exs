use Mix.Config

config :cors_plug,
  origin: [
    "http://localhost",
    "http://localhost:4200",
    "https://qaapp",
    "https://qaapp.hobbylobby.corp"
  ],
  max_age: 86400,
  methods: ["GET", "POST"]

config :logger, :error_log,
  host: 'https://splunkhf.hobbylobby.corp:8443/services/collector',
  token: "B2682596-651D-4473-A8A5-979B82A07EE3",
  log_name: "dematiccharts",
  format: "[$level] $message\n"

config :logger,
  backends: [{HobbylobbyLoggingEx.Backends.Splunk, :error_log}, :console],
  level: :info

config :phoenix, :stacktrace_depth, 20

config :libcluster,
  topologies: [
    epmd: [
      strategy: Cluster.Strategy.Epmd,
      config: [hosts: [:"dematiccharts_node@qaerlapp01.hobbylobby.corp", :"dematiccharts_node@qaerlapp02.hobbylobby.corp"]]
    ]
  ]

import_config "qa.secret.exs"
