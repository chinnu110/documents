use Mix.Config

config :dematic_charts_api, DematicChartsApiWeb.Endpoint,
  http: [port: System.get_env("PORT")],
  debug_errors: true,
  code_reloader: false,
  check_origin: false,
  watchers: []

config :cors_plug,
  origin: [
    "http://localhost",
    "http://localhost:4200",
    "https://devapp",
    "https://devapp.hobbylobby.corp"
  ],
  max_age: 86400,
  methods: ["GET", "POST"]

config :logger, :console, format: "[$level] $message\n"
config :logger, level: :info


config :logger, :error_log,
  host: 'https://splunkhf.hobbylobby.corp:8443/services/collector',
  token: "B2682596-651D-4473-A8A5-979B82A07EE3",
  log_name: "dematiccharts",
  format: "[$level] $message\n"

config :logger,
  backends: [{HobbylobbyLoggingEx.Backends.Splunk, :error_log}, :console],
  level: :info


config :phoenix, :stacktrace_depth, 20

config :libcluster,
  topologies: [
    epmd: [
      strategy: Cluster.Strategy.Epmd,
      config: [hosts: [:"dematiccharts_nodea@127.0.0.1", :"dematiccharts_nodeb@127.0.0.1"]]
    ]
  ]

import_config "dev.secret.exs"
