
use Mix.Config

config :dematic_charts_api,
  namespace: DematicChartsWeb

config :dematic_charts_api, DematicChartsApiWeb.Endpoint,
http: [
    port: {:system, "PORT"},
    protocol_options: [max_keepalive: 5_000_000]
  ],
  load_from_system_env: true,
  url: [host: "localhost", port: {:system, "PORT"}],
  check_origin: false,
  pubsub: [name: DematicChartsApi.PubSub, adapter: Phoenix.PubSub.PG2],
  server: true,
  root: ".",
  render_errors: [view: DematicChartsApiWeb.Endpoint,
  format: "json",
  accepts: ~w(json)]


config :logger, :console,
  format: "$time $metadata[$level] $message\n",
  metadata: [:user_id]

config :logger, :error_log,
  host: 'https://splunkhf.hobbylobby.corp:8443/services/collector',
  token: "B2682596-651D-4473-A8A5-979B82A07EE3",
  log_name: "dematiccharts",
  format: "[$level] $message\n"



import_config "#{Mix.env()}.exs"
