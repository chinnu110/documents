# DematicCharts
## What is it?
A web app that shows statistics for the messages received and sent to/from Dematic for warehousing.

## Dependency Versions
~~~~
{:hobbylobby_harvest_ex, git: "http://hlgithub.hobbylobby.corp/HobbyLobby/HarvestEx", tag: "v2.0.0"},
{:hobbylobby_logging_ex, git: "http://hlgithub.hobbylobby.corp/HobbyLobby/HobbyLobby.Logging.Ex.git", tag: "1.0.3"},
~~~~

## JSON API Endpoints 
- /api/buildingsix/getconsumptionrate
  - returns the count of messages created and consumed, and also a decimal comparison of those. 
- /api/buildingsix/getqueue
  - returns stats on the current queue of messages
- /api/buildingsix/gettotalqueue
  - returns the number of messages, oldest, and newest, and the latency, of the queue
- /api/buildingsix/gethistory?year=2019&month=06&day=03
  - returns a list of minutes for the date provided with each minutes process count and create count 
- /api/buildingsix/getboxhistory?warehouses=4,2,1
   - returns the number of boxes shipped and induced for today, yesterday, last week, and last year for the warehouses provided
- /api/buildingsix/getactiveskus
  - returns details on currently active skus
