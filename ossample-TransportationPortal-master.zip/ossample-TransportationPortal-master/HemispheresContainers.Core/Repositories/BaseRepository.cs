﻿using HemispheresContainers.Core.Models;

namespace HemispheresContainers.Core.Repositories
{
   public abstract class BaseRepository
    {
       public TransportationContext GetContext()
       {
           return new TransportationContext();
       }
    }
}
