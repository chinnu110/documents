﻿using System;
using System.Collections.Generic;
using System.Linq;
using TransportationPortal.Models;
using ContainerSystem.Models;
using ContainerSystem.Service;
using TransportationPortal;
using HobbyLobby.HLUtil.Logging;

namespace HemispheresContainers.Core.Repositories
{
    public class StatusRepository : BaseRepository
    {
        ContainerService containerService = null;
       
        public Container GetContainer()
        {
            return null;
        }
        public IEnumerable<ContainerActionResult> Make_Change(string ContainerNumber, string ActionCode)
        {
            containerService = new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);
            IEnumerable<string> containers = new string[] { ContainerNumber };
            var results = containerService.ContainerAction(ActionCode, containers, null, null);

                if (results.Count() > 0) // Only errors are returned.
                {
                    string err = string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error)));
                    HLLogging.Error("Container change error: " + err);
                    throw new Exception("Container change error: " + err);
                }
            return results;
        }

        public List<ContainerInfo> Get_Filtered(string filter)
        {
            containerService = new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);
            var containerInfoList = new List<ContainerInfo>();
            var container = new ContainerInfo();
            container = containerService.GetContainer(filter);
            if (container != null)
            {
                containerInfoList.Add(container);
            }
            return containerInfoList;
           
        }

    }
}
