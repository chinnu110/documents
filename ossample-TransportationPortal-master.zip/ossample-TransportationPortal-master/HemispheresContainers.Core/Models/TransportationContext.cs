﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using TransportationPortal;
using TransportationPortal.Models;

namespace HemispheresContainers.Core.Models
{
    public class TransportationContext : DbContext
    {
        public DbSet<Container> Container { get; set; }

        public TransportationContext()
            : base(LibConfigProperties.Settings.DispatchContext)
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            this.Configuration.LazyLoadingEnabled = false;
            base.OnModelCreating(modelBuilder);
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();
        }
    }
}
