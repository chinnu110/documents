﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;

namespace ExcelUtil
{
	/// <summary>
	/// OpenXml.Spreadsheet.Row overlay class to provide easier access to rows and cells.
	/// </summary>
	public class XRow
	{
		public XSpreadsheet XSpreadsheet { get; private set; }

		private uint _RowNumber = 0;

		public Row OpenXmlRow { get; private set; }
		
		public List<XCell> XCells { get; private set; }

		/// <summary>
		/// Retrieve the XCell for the specified column number, or null if not present.
		/// </summary>
		/// <param name="columnNumber"></param>
		/// <returns></returns>
		public XCell this[uint columnNumber]
		{
			get
			{
				if (columnNumber == 0)
				{
					throw new ArgumentException("ColumnNumber must be 1 or greater.", "columnNumber");
				}
				return XCells.FirstOrDefault(x => x.ColumnNumber == columnNumber);
			}
		}
		
		/// <summary>
		/// Get or set the Row Number. All XCell children will be updated as well.
		/// </summary>
		public uint RowNumber 
		{ 
			get
			{
				return _RowNumber;
			}

			set
			{
				_RowNumber = value;
				OpenXmlRow.RowIndex = new DocumentFormat.OpenXml.UInt32Value(_RowNumber);
				foreach (XCell xcell in XCells)
				{
					CellType cell = xcell.OpenXmlCell;
					cell.CellReference = cell.CellRefChange(row: _RowNumber);
				}
			}
		}

		/// <summary>
		/// Creates a basic XRow object and a basic OpenXml.Spreadsheet.Row object.
		/// </summary>
		/// <param name="xspreadsheet"></param>
		/// <param name="rowNumber"></param>
		public XRow(XSpreadsheet xspreadsheet, uint rowNumber)
		{
			XSpreadsheet = xspreadsheet;

			OpenXmlRow = new Row
			{
				RowIndex = new DocumentFormat.OpenXml.UInt32Value(rowNumber)
			};

			_RowNumber = OpenXmlRow.RowIndex;

			XCells = new List<XCell>();
		}

		/// <summary>
		/// Creates an XRow overlay object for the specified OpenXml.Spreadsheet.Row.
		/// The XRow XCells list will also be populated with overlay objects for the corresponding OpenXml.Spreadsheet.CellType objects.
		/// </summary>
		/// <param name="xspreadsheet"></param>
		/// <param name="openXmlRow"></param>
		internal XRow(XSpreadsheet xspreadsheet, Row openXmlRow)
		{
			XSpreadsheet = xspreadsheet;

			OpenXmlRow = openXmlRow;

			_RowNumber = OpenXmlRow.RowIndex;

			XCells = new List<XCell>();
			
			foreach (CellType cell in OpenXmlRow.Elements<CellType>())
			{
				if (cell != null)
				{
					XCells.Add(new XCell(this, cell));
				}
			}
		}

		/// <summary>
		/// Creates a new XCell for this XRow.
		/// </summary>
		/// <param name="columnNumber"></param>
		/// <returns></returns>
		public XCell AddXCell(uint columnNumber)
		{
			XCell xcell = new XCell(this, columnNumber);
			
			XCell insertionPointXCell = XCells.FirstOrDefault(x => x.ColumnNumber >= columnNumber);
			if (insertionPointXCell != null)
			{
				if (insertionPointXCell.ColumnNumber == columnNumber)
				{
					throw new ArgumentException("Column Number already exists in row.", "columnNumber");
				}
				else
				{
					XCells.Insert(XCells.IndexOf(insertionPointXCell), xcell);
				}
			}
			else
			{
				XCells.Add(xcell);
			}

			return xcell;
		}

		/// <summary>
		/// Removes the XCell from this XRow. The underlying CellType, if present, is also removed from its parent Row.
		/// </summary>
		/// <param name="xcell"></param>
		public void RemoveXCell(XCell xcell)
		{
			if (XCells.Contains(xcell))
			{
				if (xcell.OpenXmlCell != null)
				{
					xcell.OpenXmlCell.Remove();
				}
				XCells.Remove(xcell);
			}
		}
	}
}
