﻿using System;

namespace ExcelUtil
{
	public class BuiltinFormatCodes
	{
		public enum Code
		{
			/// <summary>
			/// "0"
			/// </summary>
			Id1 = 1,

			/// <summary>
			/// "0.00"
			/// </summary>
			Id2 = 2,

			/// <summary>
			/// "#,##0"
			/// </summary>
			Id3 = 3,

			/// <summary>
			/// "#,##0.00"
			/// </summary>
			Id4 = 4,

			/// <summary>
			/// "0%"
			/// </summary>
			Id9 = 9,

			/// <summary>
			/// "0.00%"
			/// </summary>
			Id10 = 10,

			/// <summary>
			/// "0.00E+00"
			/// </summary>
			Id11 = 11,

			/// <summary>
			/// "# ?/?"
			/// </summary>
			Id12 = 12,

			/// <summary>
			/// "# ??/??"
			/// </summary>
			Id13 = 13,

			/// <summary>
			/// "mm-dd-yy"
			/// </summary>
			Id14 = 14,

			/// <summary>
			/// "d-mmm-yy"
			/// </summary>
			Id15 = 15,

			/// <summary>
			/// "d-mmm"
			/// </summary>
			Id16 = 16,

			/// <summary>
			/// "mmm-yy"
			/// </summary>
			Id17 = 17,

			/// <summary>
			/// "h:mm AM/PM"
			/// </summary>
			Id18 = 18,

			/// <summary>
			/// "h:mm:ss AM/PM"
			/// </summary>
			Id19 = 19,

			/// <summary>
			/// "H:mm"
			/// </summary>
			Id20 = 20,

			/// <summary>
			/// "H:mm:ss"
			/// </summary>
			Id21 = 21,

			/// <summary>
			/// "m/d/yy H:mm"
			/// </summary>
			Id22 = 22,

			/// <summary>
			/// "#,##0 ;(#,##0)"
			/// </summary>
			Id37 = 37,

			/// <summary>
			/// "#,##0 ;[Red](#,##0)"
			/// </summary>
			Id38 = 38,

			/// <summary>
			/// "#,##0.00;(#,##0.00)"
			/// </summary>
			Id39 = 39,

			/// <summary>
			/// "#,##0.00;[Red](#,##0.00)"
			/// </summary>
			Id40 = 40,

			/// <summary>
			/// "mm:ss"
			/// </summary>
			Id45 = 45,

			/// <summary>
			/// "[h]:mm:ss"
			/// </summary>
			Id46 = 46,

			/// <summary>
			/// "mmss.0"
			/// </summary>
			Id47 = 47,

			/// <summary>
			/// "##0.0E+0"
			/// </summary>
			Id48 = 48,

			/// <summary>
			/// "@"
			/// </summary>
			Id49 = 49
		}

		public static string GetBuiltinFormatCode(uint numFmtId)
		{
			switch (numFmtId)
			{
				case 1: return "0";
				case 2: return "0.00";
				case 3: return "#,##0";
				case 4: return "#,##0.00";
				case 9: return "0%";
				case 10: return "0.00%";
				case 11: return "0.00E+00";
				case 12: return "# ?/?";
				case 13: return "# ??/??";
				case 14: return "mm-dd-yy";
				case 15: return "d-mmm-yy";
				case 16: return "d-mmm";
				case 17: return "mmm-yy";
				case 18: return "h:mm AM/PM";
				case 19: return "h:mm:ss AM/PM";
				case 20: return "H:mm";
				case 21: return "H:mm:ss";
				case 22: return "m/d/yy H:mm";
				case 37: return "#,##0 ;(#,##0)";
				case 38: return "#,##0 ;[Red](#,##0)";
				case 39: return "#,##0.00;(#,##0.00)";
				case 40: return "#,##0.00;[Red](#,##0.00)";
				case 45: return "mm:ss";
				case 46: return "[h]:mm:ss";
				case 47: return "mmss.0";
				case 48: return "##0.0E+0";
				case 49: return "@";
				default: return null;
			}
		}
	}
}
