﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Spreadsheet;

namespace ExcelUtil
{
	public static class ExtensionMethods
	{
		/// <summary>
		/// Returns a CellReference with an incremented or decremented row and/or column value. Use '0' to keep the current value.
		/// </summary>
		/// <param name="cellType"></param>
		/// <param name="rowChange"></param>
		/// <param name="columnChange"></param>
		/// <returns></returns>
		public static string CellRefMath(this CellType cellType, int rowChange, int columnChange)
		{
			uint rowValue = (uint)(cellType.GetRowNumber() + rowChange);
			if (rowValue < 1)
			{
				rowValue = 1;
			}

			uint columnValue = (uint)(cellType.GetColumnNumber() + columnChange);
			if (columnValue < 1)
			{
				columnValue = 1;
			}

			return string.Format("{0}{1}", int2col(columnValue), rowValue.ToString());
		}

		/// <summary>
		/// Returns a CellReference with the row and/or column value changed to the specified value.
		/// </summary>
		/// <param name="cellType"></param>
		/// <param name="row"></param>
		/// <param name="column"></param>
		/// <returns></returns>
		public static string CellRefChange(this CellType cellType, uint? row = null, uint? column = null)
		{
			if (row.HasValue && column.HasValue)
			{
				return string.Format("{0}{1}", int2col(column.Value), row.Value.ToString());
			}
			else if (row.HasValue)
			{
				return string.Format("{0}{1}", int2col(cellType.GetColumnNumber()), row.Value.ToString());
			}
			else if (column.HasValue)
			{
				return string.Format("{0}{1}", int2col(column.Value), cellType.GetRowNumber().ToString());
			}
			else
			{
				return cellType.CellReference;
			}
		}

		/// <summary>
		/// Returns a CellReference for the specified row and column.
		/// </summary>
		/// <param name="row"></param>
		/// <param name="column"></param>
		/// <returns></returns>
		public static string CellRefSet(uint row, uint column)
		{
			return string.Format("{0}{1}", int2col(column), row.ToString());
		}

		/// <summary>
		/// Returns the column number of a cell.
		/// </summary>
		/// <param name="cellType"></param>
		/// <returns>1 to x, if a CellReference is set; otherwise 0.</returns>
		public static uint GetColumnNumber(this CellType cellType)
		{
			if (cellType.CellReference == null)
			{
				return 0;
			}
			
			String columnPart = new string(cellType.CellReference.Value.Where(x => Char.IsLetter(x)).ToArray());

			if (string.IsNullOrEmpty(columnPart))
			{
				return 0;
			}

			return col2int(columnPart);
		}

		/// <summary>
		/// Returned the row number of a cell.
		/// </summary>
		/// <param name="cellType"></param>
		/// <returns>1 to x, if a CellReference is set; otherwise 0.</returns>
		public static uint GetRowNumber(this CellType cellType)
		{
			if (cellType.CellReference == null)
			{
				return 0;
			}

			String rowPart = new string(cellType.CellReference.Value.Where(x => Char.IsDigit(x)).ToArray());

			if (string.IsNullOrEmpty(rowPart))
			{
				return 0;
			}

			uint rowValue = 0;
			if (uint.TryParse(rowPart, out rowValue) == false)
			{
				return 0;
			}

			return rowValue;
		}

		private static uint col2int(String s)
		{
			const string letters = " ABCDEFGHIJKLMNOPQRSTUVWXYZ"; // index 0 is not used.

			uint i = 0;

			for (int a = s.Length - 1, m = 1; a >= 0; a--, m *= 26)
			{
				int p = letters.IndexOf(s[a]);
				if (p > 0)
				{
					i += (uint)(p * m);
				}
			}

			return i;
		}

		internal static String int2col(uint i)
		{
			const string letters = " ABCDEFGHIJKLMNOPQRSTUVWXYZ"; // index 0 is not used.

			// Formula adapted from http://mathbits.com/MathBits/CompSci/Introduction/frombase10.htm
			StringBuilder s = new StringBuilder();

			int dividend = (int)i;
			do
			{
				int remainder;
				dividend = Math.DivRem(dividend, 26, out remainder);
				s.Insert(0, letters[remainder]);
			} while (dividend != 0);

			return s.ToString();
		}
	}
}
