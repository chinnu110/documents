﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using System.Globalization;

namespace ExcelUtil
{
	/// <summary>
	/// OpenXml.Spreadsheet.CellType overlay class to provide easier methods to access and update cell values.
	/// </summary>
	public class XCell
	{
		/// <summary>
		/// Contains the cell value, regardless of type.
		/// </summary>
		private string _String;

		/// <summary>
		/// Contains a numeric cell value, parsed from _String. 
		/// </summary>
		private double? _Number;

		/// <summary>
		/// If _Number is present, this will be the formatted display value.
		/// </summary>
		public string NumberFormatted { get; private set; }
		
		/// <summary>
		/// If _Number is present and can be parsed to a datetime, this will be the formatted display value. 
		/// </summary>
		public string DateTimeFormatted { get; private set; }

		/// <summary>
		/// Contains any Formula set using XCell. Will not contain a formula loaded from the spreadsheet.
		/// </summary>
		private string _Formula;

		/// <summary>
		/// XRow that contains this XCell.
		/// </summary>
		public XRow XRow { get; private set; }

		/// <summary>
		/// Column number (1 to n) of this XCell in the containing XRow.
		/// </summary>
		public uint ColumnNumber { get; private set; }

		/// <summary>
		/// Reference to the underlying Excel OpenXmlCell object.
		/// </summary>
		public CellType OpenXmlCell { get; private set; }

		/// <summary>
		/// Gets the Cell address as a standard column/row value (A1, B32, C12, ...).
		/// </summary>
		public string CellAddress
		{
			get
			{
				return string.Format("{0}{1}", ExtensionMethods.int2col(ColumnNumber), XRow.RowNumber.ToString());
			}
		}
		
		/// <summary>
		/// Creates an emply XCell object. A value must be set before the underlying Cell is created and inserted in the Row.
		/// </summary>
		/// <param name="xrow"></param>
		/// <param name="columnNumber"></param>
		public XCell(XRow xrow, uint columnNumber)
		{
			XRow = xrow;

			ColumnNumber = columnNumber;
		}

		/// <summary>
		/// Internal constructor to create an XCell during spreadsheet open processing.
		/// </summary>
		/// <param name="xrow"></param>
		/// <param name="cellType"></param>
		internal XCell(XRow xrow, CellType cellType)
		{
			XRow = xrow;

			OpenXmlCell = cellType;

			ColumnNumber = cellType.GetColumnNumber();

			LoadValue();
		}

		/// <summary>
		/// SetValue is used to set any cell value, except a formula.
		/// If the object passed in can be determined to be any non-string primative, then the appropriate internal setter is called.
		/// Otherwise the object .ToString() value is parsed to a Double. If successful, the internal setter is called. 
		/// Otherwise, the internal string value is set. This avoids the spreadsheet cell warnings of "NUMBER STORED AS TEXT".
		/// </summary>
		/// <param name="value"></param>
		public void SetValue(object value)
		{
			this.String = null;
			this.Number = null;
			this.DateTimeValue = null;

			if (value != null)
			{
				if (value is Int32 || value is Int32?)
				{
					this.Number = (double?)(Int32)value;
				}
				else if (value is Decimal || value is Decimal?)
				{
					this.Number = (double?)(Decimal)value;
				}
				else if (value is DateTime || value is DateTime?)
				{
					this.DateTimeValue = (DateTime?)value;
				}
				else if (value is Int16 || value is Int16?)
				{
					this.Number = (double?)(Int16)value;
				}
				else if (value is Double || value is Double?)
				{
					this.Number = (double)value;
				}
				else if (value is Boolean || value is Boolean?)
				{
					this.String = (bool)value == true ? "1" : "0";
				}
				else
				{
					string strValue = value.ToString();
					if (!string.IsNullOrWhiteSpace(strValue))
					{
						double doubleValue;
						if (Double.TryParse(value.ToString(), out doubleValue))
						{
							this.Number = doubleValue;
						}
						else
						{
							this.String = strValue;
						}
					}
				}
			}
		}

		/// <summary>
		/// Get or set a String value.
		/// </summary>
		public string Formula
		{
			get
			{
				return _Formula;
			}

			set
			{
				_Formula = value;
				if (!string.IsNullOrEmpty(_Formula))
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.CellFormula = new CellFormula(_Formula);
					}
					else
					{
						OpenXmlCell = new Cell
						{
							CellReference = ExtensionMethods.CellRefSet(XRow.RowNumber, ColumnNumber),
							CellFormula = new CellFormula(_Formula)
						};
						// Locate the first column cell past where this cell should be for insertion.
						CellType nextCell = XRow.OpenXmlRow.Elements<CellType>().FirstOrDefault(x => x.GetColumnNumber() > ColumnNumber);
						if (nextCell != null)
						{
							nextCell.InsertBeforeSelf(OpenXmlCell);
						}
						else
						{
							XRow.OpenXmlRow.AppendChild(OpenXmlCell);
						}
					}
				}
				else
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.RemoveAllChildren();
					}
				}
			}
		}


		/// <summary>
		/// Get s String value, if present. Use SetValue to set any value.
		/// </summary>
		public string String
		{
			get
			{
				return _String;
			}

			private set
			{
				_String = value;
				if (!string.IsNullOrEmpty(_String))
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.CellValue = new CellValue(_String);
						OpenXmlCell.DataType = new EnumValue<CellValues>(CellValues.String);
					}
					else
					{
						OpenXmlCell = new Cell
						{
							CellReference = ExtensionMethods.CellRefSet(XRow.RowNumber, ColumnNumber),
							DataType = new EnumValue<CellValues>(CellValues.String),
							CellValue = new CellValue(_String)
						};
						// Locate the first column cell past where this cell should be for insertion.
						CellType nextCell = XRow.OpenXmlRow.Elements<CellType>().FirstOrDefault(x => x.GetColumnNumber() > ColumnNumber);
						if (nextCell != null)
						{
							nextCell.InsertBeforeSelf(OpenXmlCell);
						}
						else
						{
							XRow.OpenXmlRow.AppendChild(OpenXmlCell);
						}
					}
				}
				else
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.RemoveAllChildren();
					}
				}
			}
		}

		/// <summary>
		/// Get a numeric value, if present. Use SetValue to set any value.
		/// </summary>
		public double? Number 
		{
			get
			{
				return _Number;
			}

			private set
			{
				_Number = value;
				if (_Number.HasValue)
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.CellValue = new CellValue(_Number.ToString());
						OpenXmlCell.DataType = new EnumValue<CellValues>(CellValues.Number);
					}
					else
					{
						OpenXmlCell = new Cell
						{
							CellReference = ExtensionMethods.CellRefSet(XRow.RowNumber, ColumnNumber),
							DataType = new EnumValue<CellValues>(CellValues.Number),
							CellValue = new CellValue(_Number.ToString())
						};
						// Locate the first column cell past where this cell should be for insertion.
						CellType nextCell = XRow.OpenXmlRow.Elements<CellType>().FirstOrDefault(x => x.GetColumnNumber() > ColumnNumber);
						if (nextCell != null)
						{
							nextCell.InsertBeforeSelf(OpenXmlCell);
						}
						else
						{
							XRow.OpenXmlRow.AppendChild(OpenXmlCell);
						}
					}
				}
				else
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.RemoveAllChildren();
					}
				}
			}
		}

		/// <summary>
		/// Get a DateTime value, if present. Use SetValue to set any value.
		/// </summary>
		public DateTime? DateTimeValue
		{
			get
			{
				return (_Number.HasValue ? DateTime.FromOADate((double)_Number) : (DateTime?)null);
			}

			private set
			{
				if (value.HasValue)
				{
					_Number = value.Value.ToOADate();
					if (OpenXmlCell != null)
					{
						OpenXmlCell.CellValue = new CellValue(_Number.ToString());
						OpenXmlCell.DataType = null; // new EnumValue<CellValues>(CellValues.Date);  -- documentation says 'only available in Office 2010'
					}
					else
					{
						OpenXmlCell = new Cell
						{
							CellReference = ExtensionMethods.CellRefSet(XRow.RowNumber, ColumnNumber),
							DataType = null,
							CellValue = new CellValue(_Number.ToString())
						};
						// Locate the first column cell past where this cell should be for insertion.
						CellType nextCell = XRow.OpenXmlRow.Elements<CellType>().FirstOrDefault(x => x.GetColumnNumber() > ColumnNumber);
						if (nextCell != null)
						{
							nextCell.InsertBeforeSelf(OpenXmlCell);
						}
						else
						{
							XRow.OpenXmlRow.AppendChild(OpenXmlCell);
						}
					}
				}
				else
				{
					_Number = null;
					if (OpenXmlCell != null)
					{
						OpenXmlCell.RemoveAllChildren();
					}
				}
			}
		}

		/// <summary>
		/// Get a Boolean value, if present. Use SetValue to set any value.
		/// </summary>
		public Boolean? BooleanValue
		{
			get
			{
				if (string.IsNullOrEmpty(_String) == false && _String == "1")
				{
					return true;
				}
				else 
				{
					return false;
				}
			}

			private set
			{
				if (value.HasValue)
				{
					_String = value.Value == true ? "1" : "0";
					if (OpenXmlCell != null)
					{
						OpenXmlCell.CellValue = new CellValue(_String);
						OpenXmlCell.DataType = new EnumValue<CellValues>(CellValues.Boolean);
					}
					else
					{
						OpenXmlCell = new Cell
						{
							CellReference = ExtensionMethods.CellRefSet(XRow.RowNumber, ColumnNumber),
							DataType = new EnumValue<CellValues>(CellValues.Boolean),
							CellValue = new CellValue(_String)
						};
						// Locate the first column cell past where this cell should be for insertion.
						CellType nextCell = XRow.OpenXmlRow.Elements<CellType>().FirstOrDefault(x => x.GetColumnNumber() > ColumnNumber);
						if (nextCell != null)
						{
							nextCell.InsertBeforeSelf(OpenXmlCell);
						}
						else
						{
							XRow.OpenXmlRow.AppendChild(OpenXmlCell);
						}
					}
				}
				else
				{
					_Number = null;
					if (OpenXmlCell != null)
					{
						OpenXmlCell.RemoveAllChildren();
					}
				}
			}
		}

		/// <summary>
		/// Process the CellType DataType attribute and CellType CellValue element and try to get a value.
		/// _String is always loaded.
		/// _Number is loaded if _String can be converted to a Double.
		/// NumberFormatted is loaded from the cell's NumberFormat, if present, or the .ToString() method.
		/// DateTimeFormatted is created from _Number, if present. If the cell intent is a date or time value, this is the displayed format.
		/// </summary>
		private void LoadValue()
		{
			if ((object)OpenXmlCell.DataType == null)
			{
				if (OpenXmlCell.CellValue != null)
				{
					_String = OpenXmlCell.CellValue.Text;
					// Try to get a number from the string. Double should handle about any format.
					double parsedValue;
					if (Double.TryParse(_String, out parsedValue))
					{
						string formatCode = GetFormatCode(OpenXmlCell, XRow.XSpreadsheet.CellFormats, XRow.XSpreadsheet.NumberingFormats);
						// Put the number as a decimal
						_Number = parsedValue;
						// Get the format and show the number formatted.
						NumberFormatted = formatCode != null ? parsedValue.ToString(formatCode) : parsedValue.ToString();
						try
						{
							if (_Number.HasValue)
							{
								DateTimeFormatted = formatCode != null ? DateTime.FromOADate((double)_Number).ToString(formatCode) : DateTime.FromOADate((double)_Number).ToLongDateString();
							}
						}
						catch (Exception)
						{ }
					}
				}
			}
			else if (OpenXmlCell.DataType == CellValues.String)
			{
				if (OpenXmlCell.CellValue != null)
				{
					_String = OpenXmlCell.CellValue.Text;
				}
			}
			else if (OpenXmlCell.DataType == CellValues.InlineString)
			{
				if (OpenXmlCell.InlineString != null)
				{
					_String = OpenXmlCell.InlineString.InnerText;
				}
			}
			else if (OpenXmlCell.DataType == CellValues.SharedString)
			{
				if (OpenXmlCell.CellValue != null)
				{
					_String = OpenXmlCell.CellValue.Text;
					int sstindex;
					if (Int32.TryParse(_String, out sstindex))
					{
						OpenXmlElement xvalue = XRow.XSpreadsheet.SharedStringTable.ElementAtOrDefault(sstindex);
						if (xvalue != null)
						{
							_String = xvalue.InnerText;
						}
					}
				}
			}
			else if (OpenXmlCell.DataType == CellValues.Boolean)
			{
				if (OpenXmlCell.CellValue != null)
				{
					_String = OpenXmlCell.CellValue.Text;
				}
			}
			else if (OpenXmlCell.DataType == CellValues.Date)
			{
				if (OpenXmlCell.CellValue != null)
				{
					_String = OpenXmlCell.CellValue.Text;
					double parsedValue;
					if (Double.TryParse(_String, out parsedValue))
					{
						_Number = parsedValue;
						string formatCode = GetFormatCode(OpenXmlCell, XRow.XSpreadsheet.CellFormats, XRow.XSpreadsheet.NumberingFormats);
						if (formatCode != null)
						{
							DateTimeFormatted = formatCode != null ? DateTime.FromOADate(_Number.Value).ToString(formatCode) : DateTime.FromOADate(_Number.Value).ToLongDateString();
						}
					}
				}
			}
			else if (OpenXmlCell.DataType == CellValues.Number)
			{
				if (OpenXmlCell.CellValue != null)
				{
					_String = OpenXmlCell.CellValue.Text;
					double parsedValue;
					if (Double.TryParse(_String, out parsedValue))
					{
						_Number = parsedValue; 
						string formatCode = GetFormatCode(OpenXmlCell, XRow.XSpreadsheet.CellFormats, XRow.XSpreadsheet.NumberingFormats);
						NumberFormatted = formatCode != null ? parsedValue.ToString(formatCode) : parsedValue.ToString();
					}
				}
			}
		}

		/// <summary>
		/// Locate the number formatting string. It may be explicitly specified or one of the Excel built-in values.
		/// </summary>
		/// <param name="cellType">CellType object</param>
		/// <param name="cellFormats">CellFormat list</param>
		/// <param name="numberingFormats">NumberFormat list</param>
		/// <returns></returns>
		private static string GetFormatCode(CellType cellType, IEnumerable<CellFormat> cellFormats, IEnumerable<NumberingFormat> numberingFormats)
		{
			string formatCode = null;

			if (cellType.StyleIndex != null)
			{
				CellFormat cellFormat = cellFormats.ElementAtOrDefault((int)cellType.StyleIndex.Value);
				if (cellFormat != null)
				{
					// Look for one of the Excel built-in values.
					formatCode = BuiltinFormatCodes.GetBuiltinFormatCode(cellFormat.NumberFormatId.Value);
					if (formatCode == null)
					{
						NumberingFormat numberingFormat = numberingFormats.FirstOrDefault(x => x.NumberFormatId.Value == cellFormat.NumberFormatId.Value);
						if (numberingFormat != null)
						{
							// If the NumberingFormat was found, use its FormatCode
							formatCode = numberingFormat.FormatCode;
						}
					}
				}
			}

			return formatCode;
		}
	}
}
