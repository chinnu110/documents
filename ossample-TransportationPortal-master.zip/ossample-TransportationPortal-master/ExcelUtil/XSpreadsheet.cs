﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Packaging;
using System.IO;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Validation;

namespace ExcelUtil
{
	public class XSpreadsheet
	{
		// Getable and Setable properties.

		/// <summary>
		/// Stream object containing Excel .xlsx file. Must have Read/Write capability, if IsEditable is true.
		/// </summary>
		public Stream Stream { get; set; }

		/// <summary>
		/// Sheet name (tab name) to open. Or use SheetNumber.
		/// </summary>
		public string SheetName { get; set; }

		/// <summary>
		/// Sheet number (tab number) to open. Or use SheetName.
		/// </summary>
		public int? SheetNumber { get; set; }

		/// <summary>
		/// Indicates if the spreadsheet can be changed.
		/// </summary>
		public bool IsEditable { get; set; }

		/// <summary>
		/// Optional run-time object that can be accessed by the callback method. This can be used to pass parameters and hold values.
		/// </summary>
		public object RunObject { get; set; }

		// Get-only properties.

		public IList<XRow> XRows { get; private set; }

		public SharedStringTable SharedStringTable { get; private set; }

		public Stylesheet StyleSheet { get; private set; }

		public List<CellFormat> CellFormats { get; private set; }

		public List<NumberingFormat> NumberingFormats { get; private set; }

		public Worksheet WorkSheet { get; private set; }

		public SheetViews SheetViews { get; private set; }

		public SheetView LastSheetView { get; private set; }

		public Pane LastSheetViewPane { get; private set; }

		public List<Column> Columns { get; private set; }

		public SheetData SheetData { get; private set; }


		/// <summary>
		/// Create an UpdateSpreadsheet object for updating spreadsheet data.
		/// </summary>
		public XSpreadsheet()
		{
		}

		/// <summary>
		/// Process the Excel .xlsx file using the supplied Row function. The rowFunction is called once per row.
		/// </summary>
		/// <param name="rowFunction">Function taking XRow object and returning a bool.</param>
		public void Process(Func<XRow, bool> rowFunction)
		{
			using (SpreadsheetDocument package = SpreadsheetDocument.Open(Stream, IsEditable))
			{
				/*
				 * Get the WorkbookPart and validate the sheet name or number.
				 */

				WorkbookPart wbp = package.WorkbookPart;
				if (wbp == null)
				{
					throw new Exception("Cannot locate OpenXML WorkbookPart in Package.");
				}

				// Get the sheet id from the Workbook sheet lookup list and locate the WorksheetPart.

				Workbook wb = wbp.Workbook;

				Sheet sheet;

				if (SheetNumber.HasValue)
				{
					sheet = wb.Sheets.Elements<Sheet>().ElementAtOrDefault(SheetNumber.Value - 1);
					if (sheet == null)
					{
						throw new Exception(string.Format("Cannot locate Sheet number {0} in Workbook.", SheetNumber));
					}
				}
				else if (!string.IsNullOrEmpty(SheetName))
				{
					sheet = wb.Sheets.Elements<Sheet>().FirstOrDefault(x => x.Name == SheetName);
					if (sheet == null)
					{
						throw new Exception(string.Format("Cannot locate Sheet name '{0}' in Workbook.", SheetName));
					}
				}
				else
				{
					throw new Exception(string.Format("Specify a Sheet Name or a Sheet Number starting at 1.", SheetName));
				}

				/*
				 * Get the WorksheetPart.
				 */

				OpenXmlPart part = wbp.GetPartById(sheet.Id);
				if (part == null)
				{
					throw new Exception(string.Format("Cannot locate OpenXmlPart for Sheet.Id '{0}' in WorkbookPart.", sheet.Id));
				}

				WorksheetPart wsp = part as WorksheetPart;
				if (wsp == null)
				{
					throw new Exception(string.Format("Cannot cast '{0}' as WorksheetPart.", part.GetType().Name));
				}

				/*
				 * Get resources from the WorkbookPart.
				 */

				SharedStringTable = wbp.SharedStringTablePart.SharedStringTable;

				WorkbookStylesPart wbstyles = wbp.WorkbookStylesPart;


				StyleSheet = wbstyles.Stylesheet;

				if (StyleSheet.CellFormats != null)
				{
					CellFormats = StyleSheet.CellFormats.Elements<CellFormat>().ToList();
				}
				else
				{
					CellFormats = new List<CellFormat>();
				}

				if (StyleSheet.NumberingFormats != null)
				{
					NumberingFormats = StyleSheet.NumberingFormats.Elements<NumberingFormat>().ToList();
				}
				else
				{
					NumberingFormats = new List<NumberingFormat>();
				}

				/*
				 * Get resources from the WorksheetPart
				 */

				WorkSheet = wsp.Worksheet;

				SheetViews = WorkSheet.GetFirstChild<SheetViews>();

				if (SheetViews != null)
				{
					LastSheetView = SheetViews.Elements<SheetView>().LastOrDefault();
					if (LastSheetView != null)
					{
						LastSheetViewPane = LastSheetView.GetFirstChild<Pane>();
					}
				}

				Columns columnsElement = WorkSheet.GetFirstChild<Columns>();
				if (columnsElement != null)
				{
					Columns = columnsElement.Elements<Column>().ToList();
				}

				SheetData = WorkSheet.GetFirstChild<SheetData>();
				if (SheetData == null)
				{
					throw new Exception(string.Format("Cannot locate <SheetData> in Worksheet '{0}' in WorksheetPart.", SheetName));
				}

				XRows = new List<XRow>();

				ProcessRows(rowFunction);

				IsDocumentValid(package);
			}
		}

		private void ProcessRows(Func<XRow, bool> rowFunction)
		{
			/*
			 * Process Rows. Invoke callback function at the start and finish of each row.
			 */

			foreach (DocumentFormat.OpenXml.Spreadsheet.Row row in SheetData.Elements<DocumentFormat.OpenXml.Spreadsheet.Row>())
			{
				XRow xrow = new XRow(this, row);
				this.XRows.Add(xrow);
				if (rowFunction(xrow) == false)
				{
					return;
				}
			}
		}

		/// <summary>
		/// Process the Excel .xlsx file using the supplied update function. The updateFunction is called once.
		/// </summary>
		/// <param name="rowFunction">Function taking XRow object and returning a bool.</param>
		public bool Update(Func<XSpreadsheet, bool> updateFunction)
		{
			using (SpreadsheetDocument package = SpreadsheetDocument.Open(Stream, true))
			{
				/*
				 * Get the WorkbookPart and validate the sheet name or number.
				 */

				WorkbookPart wbp = package.WorkbookPart;
				if (wbp == null)
				{
					throw new Exception("Cannot locate OpenXML WorkbookPart in Package.");
				}

				// Get the sheet id from the Workbook sheet lookup list and locate the WorksheetPart.

				Workbook wb = wbp.Workbook;

				Sheet sheet;

				if (SheetNumber.HasValue)
				{
					sheet = wb.Sheets.Elements<Sheet>().ElementAtOrDefault(SheetNumber.Value - 1);
					if (sheet == null)
					{
						throw new Exception(string.Format("Cannot locate Sheet number {0} in Workbook.", SheetNumber));
					}
				}
				else if (!string.IsNullOrEmpty(SheetName))
				{
					sheet = wb.Sheets.Elements<Sheet>().FirstOrDefault(x => x.Name == SheetName);
					if (sheet == null)
					{
						throw new Exception(string.Format("Cannot locate Sheet name '{0}' in Workbook.", SheetName));
					}
				}
				else
				{
					throw new Exception(string.Format("Specify a Sheet Name or a Sheet Number starting at 1.", SheetName));
				}

				/*
				 * Get the WorksheetPart.
				 */

				OpenXmlPart part = wbp.GetPartById(sheet.Id);
				if (part == null)
				{
					throw new Exception(string.Format("Cannot locate OpenXmlPart for Sheet.Id '{0}' in WorkbookPart.", sheet.Id));
				}

				WorksheetPart wsp = part as WorksheetPart;
				if (wsp == null)
				{
					throw new Exception(string.Format("Cannot cast '{0}' as WorksheetPart.", part.GetType().Name));
				}

				/*
				 * Get resources from the WorkbookPart.
				 */ 

				SharedStringTable = wbp.SharedStringTablePart.SharedStringTable;

				WorkbookStylesPart wbstyles = wbp.WorkbookStylesPart;


				StyleSheet = wbstyles.Stylesheet;

				if (StyleSheet.CellFormats != null)
				{
					CellFormats = StyleSheet.CellFormats.Elements<CellFormat>().ToList();
				}
				else
				{
					CellFormats = new List<CellFormat>();
				}

				if (StyleSheet.NumberingFormats != null)
				{
					NumberingFormats = StyleSheet.NumberingFormats.Elements<NumberingFormat>().ToList();
				}
				else
				{
					NumberingFormats = new List<NumberingFormat>();
				}

				/*
				 * Get resources from the WorksheetPart
				 */

				WorkSheet = wsp.Worksheet;

				SheetViews = WorkSheet.GetFirstChild<SheetViews>();
				
				if (SheetViews != null)
				{
					LastSheetView = SheetViews.Elements<SheetView>().LastOrDefault();
					if (LastSheetView != null)
					{
						LastSheetViewPane = LastSheetView.GetFirstChild<Pane>();
					}
				}

				Columns columnsElement = WorkSheet.GetFirstChild<Columns>();
				if (columnsElement != null)
				{
					Columns = columnsElement.Elements<Column>().ToList();
				}

				SheetData = WorkSheet.GetFirstChild<SheetData>();
				if (SheetData == null)
				{
					throw new Exception(string.Format("Cannot locate <SheetData> in Worksheet '{0}' in WorksheetPart.", SheetName));
				}


				XRows = PrepareData();

				bool status = updateFunction(this);

				if (status == true)
				{
					IsDocumentValid(package);
				}

				return status;
			}
		}

		private IList<XRow> PrepareData()
		{
			List<XRow> rows = new List<XRow>();

			foreach (DocumentFormat.OpenXml.Spreadsheet.Row row in SheetData.Elements<DocumentFormat.OpenXml.Spreadsheet.Row>())
			{
				XRow xrow = new XRow(this, row); //MakeXRow(row);
				rows.Add(xrow);
			}

			return rows;
		}

		private void IsDocumentValid(SpreadsheetDocument package)
		{
			OpenXmlValidator validator = new OpenXmlValidator(FileFormatVersions.Office2007);

			var errors = validator.Validate(package);

			if (errors.Count() == 0)
			{
				return;
			}

			throw new Exception(String.Join("   ", errors.Select(x => x.Description)));
		}

		/// <summary>
		/// Creates a new XRow from an existing XRow. The underlying OpenXml.Spreadsheet.Row is .Clone()'d, which includes all the CellType objects. 
		/// This preserves the data, formatting, fonts, layout, and all other attributes of each cell of the row.
		/// </summary>
		/// <param name="xrow"></param>
		/// <param name="rowNumber"></param>
		/// <returns></returns>
		public XRow AddXRow(XRow xrow, uint rowNumber)
		{
			Row cloneRow = (Row)xrow.OpenXmlRow.Clone();

			XRow newXRow = new XRow(this, cloneRow);

			newXRow.RowNumber = rowNumber;

			// Determine where to insert the Row in SheetData. Rows must in the same order as their RowIndex values.
			Row insertPointRow = SheetData.Elements<Row>().FirstOrDefault(x => x.RowIndex >= rowNumber);
			if (insertPointRow != null)
			{
				if (insertPointRow.RowIndex == rowNumber)
				{
					throw new ArgumentException(string.Format("Row with Rowindex={0} already exists in SheetData.", rowNumber));
				}
				else
				{
					insertPointRow.InsertBeforeSelf(cloneRow);
				}
			}
			else
			{
				SheetData.Append(cloneRow);
			}

			XRows.Add(newXRow);

			return newXRow;
		}

		/// <summary>
		/// Removes the XRow from the active list and removes the underlying OpenXml Spreadsheet Row from the SheetData children.
		/// The XRow and underlying Row and XCells and underlying CellTypes are not disposed. The removed row can be used as a template.
		/// </summary>
		/// <param name="xrow">Removed XRow</param>
		public void RemoveXRow(XRow xrow)
		{
			if (xrow.OpenXmlRow != null)
			{
				xrow.OpenXmlRow.Remove();
				XRows.Remove(xrow);
			}
		}

		/// <summary>
		/// Retrieves the XRow with the specified rowNumber, or null if not found.
		/// </summary>
		/// <param name="rowNumber"></param>
		/// <returns></returns>
		public XRow this[uint rowNumber]
		{
			get
			{
				if (rowNumber == 0)
				{
					throw new ArgumentException("RowNumber must be 1 or greater.", "rowNumber");
				}
				return XRows.FirstOrDefault(x => x.RowNumber == rowNumber);
			}
		}
	}
}
