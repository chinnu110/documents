﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Packaging;
using System.IO;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Validation;

namespace ExcelUtil
{
	public class BuiltinFormatCodes
	{
		public enum Code
		{
			/// <summary>
			/// "0"
			/// </summary>
			Id1 = 1,

			/// <summary>
			/// "0.00"
			/// </summary>
			Id2 = 2,

			/// <summary>
			/// "#,##0"
			/// </summary>
			Id3 = 3,

			/// <summary>
			/// "#,##0.00"
			/// </summary>
			Id4 = 4,

			/// <summary>
			/// "0%"
			/// </summary>
			Id9 = 9,

			/// <summary>
			/// "0.00%"
			/// </summary>
			Id10 = 10,

			/// <summary>
			/// "0.00E+00"
			/// </summary>
			Id11 = 11,

			/// <summary>
			/// "# ?/?"
			/// </summary>
			Id12 = 12,

			/// <summary>
			/// "# ??/??"
			/// </summary>
			Id13 = 13,

			/// <summary>
			/// "mm-dd-yy"
			/// </summary>
			Id14 = 14,

			/// <summary>
			/// "d-mmm-yy"
			/// </summary>
			Id15 = 15,

			/// <summary>
			/// "d-mmm"
			/// </summary>
			Id16 = 16,

			/// <summary>
			/// "mmm-yy"
			/// </summary>
			Id17 = 17,

			/// <summary>
			/// "h:mm AM/PM"
			/// </summary>
			Id18 = 18,

			/// <summary>
			/// "h:mm:ss AM/PM"
			/// </summary>
			Id19 = 19,

			/// <summary>
			/// "H:mm"
			/// </summary>
			Id20 = 20,

			/// <summary>
			/// "H:mm:ss"
			/// </summary>
			Id21 = 21,

			/// <summary>
			/// "m/d/yy H:mm"
			/// </summary>
			Id22 = 22,

			/// <summary>
			/// "#,##0 ;(#,##0)"
			/// </summary>
			Id37 = 37,

			/// <summary>
			/// "#,##0 ;[Red](#,##0)"
			/// </summary>
			Id38 = 38,

			/// <summary>
			/// "#,##0.00;(#,##0.00)"
			/// </summary>
			Id39 = 39,

			/// <summary>
			/// "#,##0.00;[Red](#,##0.00)"
			/// </summary>
			Id40 = 40,

			/// <summary>
			/// "mm:ss"
			/// </summary>
			Id45 = 45,

			/// <summary>
			/// "[h]:mm:ss"
			/// </summary>
			Id46 = 46,

			/// <summary>
			/// "mmss.0"
			/// </summary>
			Id47 = 47,

			/// <summary>
			/// "##0.0E+0"
			/// </summary>
			Id48 = 48,

			/// <summary>
			/// "@"
			/// </summary>
			Id49 = 49
		}

		public static string GetBuiltinFormatCode(uint numFmtId)
		{
			switch (numFmtId)
			{
				case 1:  return "0";
				case 2:  return "0.00";
				case 3:  return "#,##0";
				case 4:  return "#,##0.00";
				case 9:  return "0%";
				case 10: return "0.00%";
				case 11: return "0.00E+00";
				case 12: return "# ?/?";
				case 13: return "# ??/??";
				case 14: return "mm-dd-yy";
				case 15: return "d-mmm-yy";
				case 16: return "d-mmm";
				case 17: return "mmm-yy";
				case 18: return "h:mm AM/PM";
				case 19: return "h:mm:ss AM/PM";
				case 20: return "H:mm";
				case 21: return "H:mm:ss";
				case 22: return "m/d/yy H:mm";
				case 37: return "#,##0 ;(#,##0)";
				case 38: return "#,##0 ;[Red](#,##0)";
				case 39: return "#,##0.00;(#,##0.00)";
				case 40: return "#,##0.00;[Red](#,##0.00)";
				case 45: return "mm:ss";
				case 46: return "[h]:mm:ss";
				case 47: return "mmss.0";
				case 48: return "##0.0E+0";
				case 49: return "@";
				default: return null;
			}
		}
	}

	public class ProcessSpreadsheet
	{
		// Getable and Setable properties.

		public Stream Stream { get; set; }

		public string SheetName { get; set; }

		public int? SheetNumber { get; set; }

		public bool IsEditable { get; set; }

		// Get-only properties.

		public SharedStringTable sharedStringTable { get; private set; }

		public Stylesheet styleSheet { get; private set; }

		public List<CellFormat> cellFormats { get; private set; }

		public List<NumberingFormat> numberingFormats { get; private set; }

		public Worksheet workSheet { get; private set; }

		public SheetViews sheetViews { get; private set; }

		public SheetView lastSheetView { get; private set; }

		public Pane lastSheetViewPane { get; private set; }

		public List<Column> columns { get; private set; }

		public SheetData sheetData { get; private set; }

		/// <summary>
		/// Create a ProcessSpreadsheet object for processing spreadsheet data.
		/// </summary>
		public ProcessSpreadsheet()
		{
		}

		/// <summary>
		/// Process the Excel .xlsx file using the supplied Row function.
		/// </summary>
		/// <param name="rowFunction">Function taking XRow object and returning a bool.</param>
		public void Process(Func<XRow, bool> rowFunction)
		{
			using (SpreadsheetDocument package = SpreadsheetDocument.Open(Stream, IsEditable))
			{
				/*
				 * Get the WorkbookPart and validate the sheet name or number.
				 */

				WorkbookPart wbp = package.WorkbookPart;
				if (wbp == null)
				{
					throw new Exception("Cannot locate OpenXML WorkbookPart in Package.");
				}

				// Get the sheet id from the Workbook sheet lookup list and locate the WorksheetPart.

				Workbook wb = wbp.Workbook;

				Sheet sheet;

				if (SheetNumber.HasValue)
				{
					sheet = wb.Sheets.Elements<Sheet>().ElementAtOrDefault(SheetNumber.Value - 1);
					if (sheet == null)
					{
						throw new Exception(string.Format("Cannot locate Sheet number {0} in Workbook.", SheetNumber));
					}
				}
				else if (!string.IsNullOrEmpty(SheetName))
				{
					sheet = wb.Sheets.Elements<Sheet>().FirstOrDefault(x => x.Name == SheetName);
					if (sheet == null)
					{
						throw new Exception(string.Format("Cannot locate Sheet name '{0}' in Workbook.", SheetName));
					}
				}
				else
				{
					throw new Exception(string.Format("Specify a Sheet Name or a Sheet Number starting at 1.", SheetName));
				}

				/*
				 * Get the WorksheetPart.
				 */

				OpenXmlPart part = wbp.GetPartById(sheet.Id);
				if (part == null)
				{
					throw new Exception(string.Format("Cannot locate OpenXmlPart for Sheet.Id '{0}' in WorkbookPart.", sheet.Id));
				}

				WorksheetPart wsp = part as WorksheetPart;
				if (wsp == null)
				{
					throw new Exception(string.Format("Cannot cast '{0}' as WorksheetPart.", part.GetType().Name));
				}

				/*
				 * Get resources from the WorkbookPart.
				 */ 

				sharedStringTable = wbp.SharedStringTablePart.SharedStringTable;

				WorkbookStylesPart wbstyles = wbp.WorkbookStylesPart;


				styleSheet = wbstyles.Stylesheet;

				if (styleSheet.CellFormats != null)
				{
					cellFormats = styleSheet.CellFormats.Elements<CellFormat>().ToList();
				}
				else
				{
					cellFormats = new List<CellFormat>();
				}

				if (styleSheet.NumberingFormats != null)
				{
					numberingFormats = styleSheet.NumberingFormats.Elements<NumberingFormat>().ToList();
				}
				else
				{
					numberingFormats = new List<NumberingFormat>();
				}

				/*
				 * Get resources from the WorksheetPart
				 */

				workSheet = wsp.Worksheet;

				sheetViews = workSheet.GetFirstChild<SheetViews>();
				
				if (sheetViews != null)
				{
					lastSheetView = sheetViews.Elements<SheetView>().LastOrDefault();
					if (lastSheetView != null)
					{
						lastSheetViewPane = lastSheetView.GetFirstChild<Pane>();
					}
				}

				Columns columnsElement = workSheet.GetFirstChild<Columns>();
				if (columnsElement != null)
				{
					columns = columnsElement.Elements<Column>().ToList();
				}

				sheetData = workSheet.GetFirstChild<SheetData>();
				if (sheetData == null)
				{
					throw new Exception(string.Format("Cannot locate <SheetData> in Worksheet '{0}' in WorksheetPart.", SheetName));
				}

				ProcessRows(rowFunction);
			
				IsDocumentValid(package);
			}
		}

		private void IsDocumentValid(SpreadsheetDocument package)
		{
			OpenXmlValidator validator = new OpenXmlValidator(FileFormatVersions.Office2007);

			var errors = validator.Validate(package);

			if (errors.Count() == 0)
			{
				return;
			}

			throw new Exception(String.Join("   ", errors.Select(x => x.Description)));
		}


		private void ProcessRows(Func<XRow, bool> rowFunction)
		{
			/*
			 * Process Rows. Invoke callback function at the start and finish of each row.
			 */

			foreach (DocumentFormat.OpenXml.Spreadsheet.Row row in sheetData.Elements<DocumentFormat.OpenXml.Spreadsheet.Row>())
			{
				XRow r = new XRow
				{
					RowNumber = row.RowIndex,
					OpenXmlRow = row
				};

				r.Cells = new List<XCell>();
				foreach (CellType cell in row.Elements<CellType>())
				{
					if (cell != null)
					{
						r.Cells.Add(MakeXCell(r, cell));
					}
				}

				if (rowFunction(r) == false)
				{
					return;
				}
			}
		}

		private XCell MakeXCell(XRow xrow, CellType cellType)
		{
			XCell xcell = xrow.AddCell(cellType.GetColumnNumber());
			xcell.OpenXmlCell = cellType;

			if ((object)cellType.DataType == null)
			{
				if (cellType.CellValue != null)
				{
					xcell._String = cellType.CellValue.Text;
					// Try to get a number from the string. Double should handle about any format.
					double parsedValue;
					if (Double.TryParse(xcell._String, out parsedValue))
					{
						string formatCode = GetFormatCode(cellType, cellFormats, numberingFormats);
						// Put the number as a decimal
						xcell._Number = (decimal)parsedValue;
						// Get the format and show the number formatted.
						xcell.NumberFormatted = formatCode != null ? parsedValue.ToString(formatCode) : parsedValue.ToString();
						// Grab just the digits and sign and decimal and try to get the same number as is formatted.
						string justNumberChars = new string(xcell.NumberFormatted.Where(x => Char.IsDigit(x) || x == '.' || x == '-').ToArray());
						decimal numberFromFormat;
						if (Decimal.TryParse(justNumberChars, out numberFromFormat))
						{
							xcell.NumberFromFormat = numberFromFormat;
						}
						// Try to get a date from the number. It's up to the application to determine if this is a date cell.
						try
						{
							xcell.DateTime = DateTime.FromOADate(parsedValue);
							if (xcell.DateTime.HasValue)
							{
								xcell.DateTimeFormatted = formatCode != null ? xcell.DateTime.Value.ToString(formatCode) : xcell.DateTime.Value.ToLongDateString();
							}
						}
						catch (Exception)
						{ }
					}
				}
			}
			else if (cellType.DataType == CellValues.String)
			{
				if (cellType.CellValue != null)
				{
					xcell._String = cellType.CellValue.Text;
				}
			}
			else if (cellType.DataType == new EnumValue<CellValues>(CellValues.InlineString).Value)
			{
				if (cellType.InlineString != null)
				{
					xcell._String = cellType.InlineString.InnerText;
				}
			}
			else if (cellType.DataType == CellValues.SharedString)
			{
				if (cellType.CellValue != null)
				{
					xcell._String = cellType.CellValue.Text;
					int sstindex;
					if (Int32.TryParse(xcell._String, out sstindex))
					{
						OpenXmlElement xvalue = sharedStringTable.ElementAtOrDefault(sstindex);
						if (xvalue != null)
						{
							xcell._String = xvalue.InnerText;
						}
					}
				}
			}
			else if (cellType.DataType == CellValues.Boolean)
			{
				if (cellType.CellValue != null)
				{
					xcell._String = cellType.CellValue.Text;
					if (xcell._String == "1")
					{
						xcell.Bool = true;
					}
					else if (xcell._String == "0")
					{
						xcell.Bool = false;
					}
				}
			}
			else if (cellType.DataType == CellValues.Date)
			{
				if (cellType.CellValue != null)
				{
					xcell._String = cellType.CellValue.Text;
					DateTime parsedValue;
					if (DateTime.TryParse(xcell._String, out parsedValue))
					{
						xcell.DateTime = parsedValue;
						string formatCode = GetFormatCode(cellType, cellFormats, numberingFormats);
						if (formatCode != null)
						{
							xcell.NumberFormatted = parsedValue.ToString(formatCode);
						}
					}
				}
			}
			else if (cellType.DataType == CellValues.Number)
			{
				if (cellType.CellValue != null)
				{
					xcell._String = cellType.CellValue.Text;
					decimal parsedValue;
					if (Decimal.TryParse(xcell._String, out parsedValue))
					{
						xcell._Number = parsedValue;
						string formatCode = GetFormatCode(cellType, cellFormats, numberingFormats);
						if (formatCode != null)
						{
							xcell.NumberFormatted = parsedValue.ToString(formatCode);
						}
					}
				}
			}

			return xcell;
		}

		private static string GetFormatCode(CellType cellType, IEnumerable<CellFormat> cellFormats, IEnumerable<NumberingFormat> numberingFormats)
		{
			string formatCode = null;

			if (cellType.StyleIndex != null)
			{
				CellFormat cellFormat = cellFormats.ElementAtOrDefault((int)cellType.StyleIndex.Value);
				if (cellFormat != null)
				{
					// Look for one of the Excel built-in values.
					formatCode = BuiltinFormatCodes.GetBuiltinFormatCode(cellFormat.NumberFormatId.Value);
					if (formatCode == null)
					{
						NumberingFormat numberingFormat = numberingFormats.FirstOrDefault(x => x.NumberFormatId.Value == cellFormat.NumberFormatId.Value);
						if (numberingFormat != null)
						{
							// If the NumberingFormat was found, use its FormatCode
							formatCode = numberingFormat.FormatCode;
						}
					}
				}
			}

			return formatCode;
		}
	}
}
