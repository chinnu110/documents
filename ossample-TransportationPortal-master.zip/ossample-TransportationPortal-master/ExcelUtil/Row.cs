﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Spreadsheet;

namespace ExcelUtil
{
	/// <summary>
	/// External class for calling Row handler function.
	/// </summary>
	public class XRow
	{
		public uint RowNumber { get; internal set; }

		public Row OpenXmlRow { get; internal set; }

		public List<XCell> Cells { get; internal set; }

		public XCell AddCell(uint columnNumber)
		{
			if (Cells.Any(x => x.ColumnNumber == columnNumber))
			{
				throw new ArgumentException("Column Number already exists in row.", "columnNumber");
			}

			XCell newCell = new XCell(this, columnNumber);
			Cells.Add(newCell);
			Cells = Cells.OrderBy(x => x.ColumnNumber).ToList();
			return newCell;
		}
	}
}
