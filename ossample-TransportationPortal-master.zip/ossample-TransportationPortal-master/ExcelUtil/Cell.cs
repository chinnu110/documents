﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;

namespace ExcelUtil
{
	/// <summary>
	/// External class for calling Cell handler function.
	/// </summary>
	public class XCell
	{
		public XRow XRow { get; internal set; }

		public uint ColumnNumber { get; internal set; }

		public CellType OpenXmlCell { get; internal set; }


		internal string _String;

		internal decimal? _Number;
		public string NumberFormatted { get; internal set; }
		public decimal? NumberFromFormat { get; internal set; }

		public DateTime? DateTime { get; internal set; }
		public string DateTimeFormatted { get; internal set; }

		public bool? Bool { get; internal set; }

		public string String
		{
			get
			{
				return _String;
			}

			set
			{
				_String = value;
				if (!string.IsNullOrEmpty(value))
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.CellValue = new CellValue(value);
						OpenXmlCell.DataType = new EnumValue<CellValues>(CellValues.String);
					}
					else
					{
						OpenXmlCell = new Cell
						{
							CellReference = ExtensionMethods.CellRefSet(XRow.RowNumber, ColumnNumber),
							DataType = new EnumValue<CellValues>(CellValues.String),
							CellValue = new CellValue(value)
						};
						// Locate the first column cell past where this cell should be for insertion.
						CellType nextCell = XRow.OpenXmlRow.Elements<CellType>().FirstOrDefault(x => x.GetColumnNumber() > ColumnNumber);
						if (nextCell != null)
						{
							nextCell.InsertBeforeSelf(OpenXmlCell);
						}
						else
						{
							XRow.OpenXmlRow.AppendChild(OpenXmlCell);
						}
					}
				}
				else
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.Remove();
						OpenXmlCell = null;
					}
				}
			}
		}


		public decimal? Number 
		{
			get
			{
				return _Number;
			}

			set
			{
				_Number = value;
				if (value.HasValue)
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.CellValue = new CellValue(value.ToString());
						OpenXmlCell.DataType = new EnumValue<CellValues>(CellValues.Number);
					}
					else
					{
						OpenXmlCell = new Cell
						{
							CellReference = ExtensionMethods.CellRefSet(XRow.RowNumber, ColumnNumber),
							DataType = new EnumValue<CellValues>(CellValues.Number),
							CellValue = new CellValue(value.ToString())
						};
						// Locate the first column cell past where this cell should be for insertion.
						CellType nextCell = XRow.OpenXmlRow.Elements<CellType>().FirstOrDefault(x => x.GetColumnNumber() > ColumnNumber);
						if (nextCell != null)
						{
							nextCell.InsertBeforeSelf(OpenXmlCell);
						}
						else
						{
							XRow.OpenXmlRow.AppendChild(OpenXmlCell);
						}
					}
				}
				else
				{
					if (OpenXmlCell != null)
					{
						OpenXmlCell.Remove();
						OpenXmlCell = null;
					}
				}
			}
		}

		internal XCell(XRow xrow, uint columnNumber)
		{
			XRow = xrow;
			ColumnNumber = columnNumber;
		}
	}
}
