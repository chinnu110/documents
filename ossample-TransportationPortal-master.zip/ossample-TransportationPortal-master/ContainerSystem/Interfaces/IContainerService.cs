﻿using System;
using System.Collections.Generic;
using ContainerSystem.Models;
using ContainerSystem.Service;

namespace ContainerSystem.Interfaces
{
	internal interface IContainerService
	{
		ContainerInfo GetContainer(string containerNumber);

		IEnumerable<ContainerInfo> GetContainerList(IEnumerable<string> statusCodes);

		IEnumerable<ContainerInfo> GetContainerListByNumber(IEnumerable<string> containerNumbers);

		Int32 UpdateContainer(string containerNumber, Dictionary<UpdateColumn, object> updateColumns);

		Int32 UpdateContainers(IEnumerable<string> containerNumbers, Dictionary<UpdateColumn, object> updateColumns);

		IEnumerable<ContainerActionResult> ContainerAction(string actionCode, IEnumerable<string> containerNumbers, string driverName, DateTime? actionDate);
	}
}
