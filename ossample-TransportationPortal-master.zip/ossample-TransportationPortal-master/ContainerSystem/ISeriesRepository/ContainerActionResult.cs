﻿using System;
using HobbyLobby.HLUtil.DataAccess;

namespace ContainerSystem.ISeriesRepository
{
	internal class ContainerActionResult : Models.ContainerActionResult
	{
		[DBColumn(Name = "Container_Number")]
		public override string ContainerNumber { get; set; }

		[DBColumn(Name = "Error")]
		public override string Error { get; set; }
	}
}