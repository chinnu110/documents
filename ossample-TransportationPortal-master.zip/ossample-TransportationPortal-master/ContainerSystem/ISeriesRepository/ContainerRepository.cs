﻿using ContainerSystem.Interfaces;
using ContainerSystem.Models;
using HobbyLobby.HLUtil.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using ContainerSystem.Service;

namespace ContainerSystem.ISeriesRepository
{
	internal class ContainerRepository : OleDBAccess, IContainerService
	{
		readonly string SP_GET_CONTAINER_BY_NUMBER = "INVLIBR.USP_TRANS_CONTAINER_BY_NUMBER";

		readonly string SP_GET_CONTAINERS_BY_NUMBER = "INVLIBR.USP_TRANS_CONTAINERS_BY_NUMBER";

		readonly string SP_GET_CONTAINERS_BY_STATUS = "INVLIBR.USP_TRANS_CONTAINERS_BY_STATUS";

		readonly string SP_UPDATE_CONTAINER_BY_NUMBER = "INVLIBR.USP_TRANS_CONTAINER_BY_NUMBER_UPD";

		readonly string SP_UPDATE_CONTAINERS_BY_LIST = "INVLIBR.USP_TRANS_CONTAINER_BY_NUMBER_MLT";

		readonly string SP_CONTAINER_ACTION = "INVLIBR.USP_TRANS_CONTAINER_UPD";

		public ContainerRepository(string connectionString) : base(connectionString)
		{ }

		public Models.ContainerInfo GetContainer(string containerNumber)
		{
			if (string.IsNullOrWhiteSpace(containerNumber))
			{
				throw new ArgumentException("Container Number argument is not valid");
			}

			InitCommand(SP_GET_CONTAINER_BY_NUMBER);

			AddParm("@container_number", OleDbType.VarChar, containerNumber);

			ContainerInfo containerInfo = null;

			using (IDataReader reader = ExecuteReader())
			{
				if (reader.Read() == true)
				{
					containerInfo = reader.Harvest<ContainerInfo>();
				}
			}

			return containerInfo;
		}

		public IEnumerable<Models.ContainerInfo> GetContainerList(IEnumerable<string> statusCodes)
		{
			if (statusCodes == null || statusCodes.Count() == 0)
			{
				yield break;
			}

			if (statusCodes.All(x => string.IsNullOrWhiteSpace(x)))
			{
				yield break;
			}

			InitCommand(SP_GET_CONTAINERS_BY_STATUS);

			string parmlist = string.Join(",", statusCodes.Select(x => string.Format("'{0}'", x)));

			AddParm("@STATUS_CODES", OleDbType.VarChar, parmlist);

			using (IDataReader reader = ExecuteReader())
			{
				while (reader.Read())
				{
					ContainerInfo containerInfo = reader.Harvest<ContainerInfo>();
					yield return containerInfo;
				}
			}
		}

		public int UpdateContainer(string containerNumber, Dictionary<UpdateColumn, object> updateColumns)
		{
			if (string.IsNullOrWhiteSpace(containerNumber))
			{
				throw new ArgumentException("Container Number argument is not valid.");
			}

			InitCommand(SP_UPDATE_CONTAINER_BY_NUMBER);

			// Keys
			AddParm("@CONTAINER_NUMBER", OleDbType.VarChar, containerNumber);

			// Updates
			string pulldriverName = (string)(updateColumns.ContainsKey(UpdateColumn.PullDriverName) ? updateColumns[UpdateColumn.PullDriverName] : null);
			AddParm("@DRIVER", OleDbType.VarChar, pulldriverName != null ? pulldriverName.ToUpper() : null);

			AddParm("@NOTE", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.Notes) ? updateColumns[UpdateColumn.Notes] : null);
			AddParm("@RAILPUNOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.PickupLocation) ? updateColumns[UpdateColumn.PickupLocation] : null);
			AddParm("@SHAGENOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.ShagNotes) ? updateColumns[UpdateColumn.ShagNotes] : null);
			AddParm("@LOTNOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.LotNotes) ? updateColumns[UpdateColumn.LotNotes] : null);
			AddParm("@RETURNNOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.ReturnNotes) ? updateColumns[UpdateColumn.ReturnNotes] : null);
			AddParm("@LOTLOCATION", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.LotLocation) ? updateColumns[UpdateColumn.LotLocation] : null);

			string commitDriverName = (string)(updateColumns.ContainsKey(UpdateColumn.CommitDriverName) ? updateColumns[UpdateColumn.CommitDriverName] : null);
			AddParm("@SHAGEDRIVER", OleDbType.VarChar, commitDriverName != null ? commitDriverName.ToUpper() : null);

			string returnDriverName = (string)(updateColumns.ContainsKey(UpdateColumn.ReturnDriverName) ? updateColumns[UpdateColumn.ReturnDriverName] : null);
			AddParm("@RETURNDRIVER", OleDbType.VarChar, returnDriverName != null ? returnDriverName.ToUpper() : null);

			// Return code
			AddOutputParm("@RETURN", OleDbType.Decimal);

			int rowsAffected = ExecuteNonQuery();

			decimal returnCode = (decimal)GetOutputParmValue("@RETURN");

			return Decimal.ToInt32(returnCode);
		}

		public int UpdateContainers(IEnumerable<string> containerNumbers, Dictionary<UpdateColumn, object> updateColumns) 
		{
			if (containerNumbers == null || containerNumbers.Count() == 0)
			{
				throw new ArgumentException("Container Number list empty or missing.");
			}
			
			string containerParm = string.Join(",", containerNumbers.Select(x => string.Format("'{0}'", x)));
		
			InitCommand(SP_UPDATE_CONTAINERS_BY_LIST);

			// Keys
			AddParm("@CONTAINER_NUMBERS", OleDbType.VarChar, containerParm);

			// Updates
			string pulldriverName = (string)(updateColumns.ContainsKey(UpdateColumn.PullDriverName) ? updateColumns[UpdateColumn.PullDriverName] : null);
			AddParm("@DRIVER", OleDbType.VarChar, pulldriverName != null ? pulldriverName.ToUpper() : null);

			AddParm("@NOTE", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.Notes) ? updateColumns[UpdateColumn.Notes] : null);
			AddParm("@RAILPUNOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.PickupLocation) ? updateColumns[UpdateColumn.PickupLocation] : null);
			AddParm("@SHAGENOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.ShagNotes) ? updateColumns[UpdateColumn.ShagNotes] : null);
			AddParm("@LOTNOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.LotNotes) ? updateColumns[UpdateColumn.LotNotes] : null);
			AddParm("@RETURNNOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.ReturnNotes) ? updateColumns[UpdateColumn.ReturnNotes] : null);
			AddParm("@LOTLOCATION", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.LotLocation) ? updateColumns[UpdateColumn.LotLocation] : null);
	
			string commitDriverName = (string)(updateColumns.ContainsKey(UpdateColumn.CommitDriverName) ? updateColumns[UpdateColumn.CommitDriverName] : null);
			AddParm("@SHAGEDRIVER", OleDbType.VarChar, commitDriverName != null ? commitDriverName.ToUpper() : null);

			string returnDriverName = (string)(updateColumns.ContainsKey(UpdateColumn.ReturnDriverName) ? updateColumns[UpdateColumn.ReturnDriverName] : null);
			AddParm("@RETURNDRIVER", OleDbType.VarChar, returnDriverName != null ? returnDriverName.ToUpper() : null);

			// Return code
			AddOutputParm("@RETURN", OleDbType.Decimal);

			int rowsAffected = ExecuteNonQuery();

			decimal returnCode = (decimal)GetOutputParmValue("@RETURN");

			return Decimal.ToInt32(returnCode);
		}


		public IEnumerable<Models.ContainerInfo> GetContainerListByNumber(IEnumerable<string> containerNumbers)
		{
			if (containerNumbers == null || containerNumbers.Count() == 0)
			{
				yield break;
			}

			if (containerNumbers.All(x => string.IsNullOrWhiteSpace(x)))
			{
				yield break;
			}

			InitCommand(SP_GET_CONTAINERS_BY_NUMBER);

			string parmlist = string.Join(",", containerNumbers.Select(x => string.Format("'{0}'", x)));

			AddParm("@CONTAINER_NUMBERS", OleDbType.VarChar, parmlist);

			using (IDataReader reader = ExecuteReader())
			{
				while (reader.Read())
				{
					ContainerInfo containerInfo = reader.Harvest<ContainerInfo>();
					yield return containerInfo;
				}
			}
		}


		public IEnumerable<Models.ContainerActionResult> ContainerAction(string actionCode, IEnumerable<string> containerNumbers, string driverName, DateTime? actionDate)
		{
			if (string.IsNullOrEmpty(actionCode))
			{
				throw new ArgumentException("Action Code is missing.");
			}

			if (containerNumbers == null || containerNumbers.Count() == 0)
			{
				throw new ArgumentException("Container Number list empty or missing.");
			}

			string containerParm = string.Join(",", containerNumbers.Select(x => string.Format("'{0}'", x)));

			InitCommand(SP_CONTAINER_ACTION);

			// Keys
			AddParm("@ACTION_CODE", OleDbType.VarChar, actionCode.PadRight(2).Substring(0, 2));
			AddParm("@CONTAINER_NUMBERS", OleDbType.VarChar, containerParm);
			AddParm("@DRIVER", OleDbType.VarChar, (driverName != null ? driverName.ToUpper() : string.Empty).PadRight(30).Substring(0, 30));
			AddParm("@PULLDATE", OleDbType.VarChar, (actionDate != null ? actionDate.Value : DateTime.MinValue).ToString("s").Substring(0, 10));

			using (IDataReader reader = ExecuteReader())
			{
				while (reader.Read())
				{
					ContainerActionResult containerInfo = reader.Harvest<ContainerActionResult>();
					yield return containerInfo;
				}
			}
		}
	}
}
