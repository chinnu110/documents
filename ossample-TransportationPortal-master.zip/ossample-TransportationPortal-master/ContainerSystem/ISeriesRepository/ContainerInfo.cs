﻿using System;
using System.Collections.Generic;
using HobbyLobby.HLUtil.DataAccess;

namespace ContainerSystem.ISeriesRepository
{
	internal class ContainerInfo : Models.ContainerInfo
	{
		[DBColumn(Name = "ContainerNumber")]
		public override string ContainerNumber { get; set; }

		[DBColumn(Name = "StatusCode")]
		public override string StatusCode { get; set; }

		public override DateTime? StatusDate { get; set; }

		[DBColumn(Name = "StatusDate")]
		public DateTime? StatusDate_convert
		{
			get { return StatusDate == null ? DateTime.MinValue : StatusDate; }
			set { StatusDate = value == DateTime.MinValue ? null : value; }
		}

		[DBColumn(Name = "PickupNumber")]
		public override string PickupNumber { get; set; }

		[DBColumn(Name = "PickupLocation")]
		public override string PickupLocation { get; set; }

		public override bool Hot { get; set; }

		[DBColumn(Name = "Hot")]
		public string Hot_Convert
		{
			get { return Hot == true ? "Y" : "N"; }
			set { Hot = value == "Y" ? true : false; }
		}

		public override DateTime? LastFreeDate { get; set; }

		[DBColumn(Name = "LastFreeDate")]
		public DateTime? LastFreeDate_convert
		{
			get { return LastFreeDate == null ? DateTime.MinValue : LastFreeDate; }
			set { LastFreeDate = value == DateTime.MinValue ? null : value; }
		}

		public override DateTime? PerDiemDate { get; set; }

		[DBColumn(Name = "PerDiemDate")]
		public DateTime? PerDiemDate_convert
		{
			get { return PerDiemDate == null ? DateTime.MinValue : PerDiemDate; }
			set { PerDiemDate = value == DateTime.MinValue ? null : value; }
		}

		[DBColumn(Name = "DeliveryZone")]
		public override string DeliveryZone { get; set; }

		[DBColumn(Name = "Driver")]
		public override string PullDriverName { get; set; }

		[DBColumn(Name = "ShageDriver")]
		public override string CommitDriverName { get; set; }

		[DBColumn(Name = "ReturnDriver")]
		public override string ReturnDriverName { get; set; }

		[DBColumn(Name = "SealNumber")]
		public override string SealNumber { get; set; }
		
		public override DateTime? PullDate { get; set; }

		[DBColumn(Name = "PullDate")]
		public DateTime? PullDate_convert
		{
			get { return PullDate == null ? DateTime.MinValue : PullDate; }
			set { PullDate = value == DateTime.MinValue ? null : value; }
		}

		[DBColumn(Name = "Note")]
		public override string Note { get; set; }

		[DBColumn(Name = "ContainerCarrier")]
		public override string Carrier { get; set; }

		[DBColumn(Name = "ContainerSize")]
		public override string ContainerSize { get; set; }

		[DBColumn(Name = "ShageNotes")]
		public override string ShagNotes { get; set; }

		[DBColumn(Name = "LotNotes")]
		public override string LotNotes { get; set; }

		[DBColumn(Name = "ReturnNotes")]
		public override string ReturnNotes { get; set; }

		[DBColumn(Name = "LotLocation")]
		public override string LotLocation { get; set; }
	}
}