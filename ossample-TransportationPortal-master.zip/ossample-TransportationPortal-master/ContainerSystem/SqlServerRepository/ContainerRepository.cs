﻿using ContainerSystem.Interfaces;
using ContainerSystem.Models;
using HobbyLobby.HLUtil.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using ContainerSystem.Service;

namespace ContainerSystem.SqlServerRepository
{
	internal class ContainerRepository : OleDBAccess, IContainerService
	{
		readonly string SP_GET_CONTAINER = "usp_get_container";
		readonly string SP_GET_CONTAINER_LIST = "usp_get_container_list";
		readonly string SP_UPDATE_CONTAINER = "usp_update_container";

		public ContainerRepository(string connectionString)
			: base(connectionString)
		{ }

		public Models.ContainerInfo GetContainer(string containerNumber)
		{
			if (string.IsNullOrWhiteSpace(containerNumber))
			{
				throw new ArgumentException("Container Number argument is not valid");
			}

			InitCommand(SP_GET_CONTAINER);

			AddParm("@container_number", OleDbType.VarChar, containerNumber);

			ContainerInfo containerInfo = null;

			using (IDataReader reader = ExecuteReader())
			{
				if (reader.Read() == true)
				{
					containerInfo = reader.Harvest<ContainerInfo>();
				}
			}

			return containerInfo;
		}

		public IEnumerable<Models.ContainerInfo> GetContainerList(IEnumerable<string> statusCodes)
		{
			if (statusCodes == null || statusCodes.Count() == 0)
			{
				yield break;
			}

			if (statusCodes.All(x => string.IsNullOrWhiteSpace(x)))
			{
				yield break;
			}

			InitCommand(SP_GET_CONTAINER_LIST);

			int parmnum = 1;
			foreach (string code in statusCodes.Where(x => string.IsNullOrEmpty(x) == false))
			{
				AddParm(string.Format("@status_code_{0:D2}", parmnum++), OleDbType.VarChar, code);
			}

			using (IDataReader reader = ExecuteReader())
			{
				while (reader.Read())
				{
					ContainerInfo containerInfo = reader.Harvest<ContainerInfo>();
					yield return containerInfo;
				}
			}
		}

		public IEnumerable<Models.ContainerInfo> GetContainerListByNumber(IEnumerable<string> containerNumbers)
		{
			if (containerNumbers == null || containerNumbers.Count() == 0)
			{
				yield break;
			}

			if (containerNumbers.All(x => string.IsNullOrWhiteSpace(x)))
			{
				yield break;
			}

			foreach (string containerNumber in containerNumbers)
			{
				Models.ContainerInfo containerInfo = GetContainer(containerNumber);
				yield return containerInfo;
			}
		}

		public int UpdateContainer(string containerNumber, Dictionary<UpdateColumn, object> updateColumns)
		{
			if (string.IsNullOrWhiteSpace(containerNumber))
			{
				throw new ArgumentException("Container Number argument is not valid");
			}

			InitCommand(SP_UPDATE_CONTAINER);
			
			AddParm("@container_number", OleDbType.VarChar, containerNumber);
			AddParm("@driver", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.PullDriverName) ? updateColumns[UpdateColumn.PullDriverName] : null);
			AddParm("@PICKUPLOCATION", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.PickupLocation) ? updateColumns[UpdateColumn.PickupLocation] : null);
			AddParm("@SHAGNOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.ShagNotes) ? updateColumns[UpdateColumn.ShagNotes] : null);
			AddParm("@LOTNOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.LotNotes) ? updateColumns[UpdateColumn.LotNotes] : null);
			AddParm("@LOTLOCATION", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.LotLocation) ? updateColumns[UpdateColumn.LotLocation] : null);
			AddParm("@RETURNNOTES", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.ReturnNotes) ? updateColumns[UpdateColumn.ReturnNotes] : null);
			AddParm("@note", OleDbType.VarChar, updateColumns.ContainsKey(UpdateColumn.Notes) ? updateColumns[UpdateColumn.Notes] : null);
			AddOutputParm("@return", OleDbType.Integer);

			int rowsAffected = ExecuteNonQuery();

			int returnCode = (int)GetOutputParmValue("@return");

			return returnCode;
		}

		public int UpdateContainers(IEnumerable<string> containerNumbers, Dictionary<UpdateColumn, object> updateColumns) 
		{
			int returnCode = 0;

			foreach (string containerNumber in containerNumbers)
			{
				returnCode += UpdateContainer(containerNumber, updateColumns);
			}

			return returnCode;
		}


		public IEnumerable<ContainerActionResult> ContainerAction(string actionCode, IEnumerable<string> containerNumbers, string driverName, DateTime? actionDate)
		{
			return Enumerable.Empty<ContainerActionResult>();
		}
	}
}
