﻿using System;
using System.Collections.Generic;
using HobbyLobby.HLUtil.DataAccess;

namespace ContainerSystem.SqlServerRepository
{
	internal class ContainerInfo : Models.ContainerInfo
	{
		[DBColumn(Name = "ContainerNumber")]
		public override string ContainerNumber { get; set; }

		[DBColumn(Name = "StatusCode")]
		public override string StatusCode { get; set; }

		[DBColumn(Name = "StatusDate")]
		public override DateTime? StatusDate { get; set; }

		[DBColumn(Name = "PickupNumber")]
		public override string PickupNumber { get; set; }

		[DBColumn(Name = "PickupLocation")]
		public override string PickupLocation { get; set; }

		[DBColumn(Name = "Hot")]
		public override bool Hot { get; set; }

		[DBColumn(Name = "LastFreeDate")]
		public override DateTime? LastFreeDate { get; set; }

		[DBColumn(Name = "PerDiemDate")]
		public override DateTime? PerDiemDate { get; set; }

		[DBColumn(Name = "DeliveryZone")]
		public override string DeliveryZone { get; set; }
		
		[DBColumn(Name = "Driver")]
		public override string PullDriverName { get; set; }

		[DBColumn(Name = "PullDate")]
		public override DateTime? PullDate { get; set; }

		[DBColumn(Name = "SealNumber")]
		public override string SealNumber { get; set; }

		[DBColumn(Name = "Note")]
		public override string Note { get; set; }

		[DBColumn(Name = "ContainerCarrier")]
		public override string Carrier { get; set; }

		[DBColumn(Name = "ContainerSize")]
		public override string ContainerSize { get; set; }

		[DBColumn(Name = "ShagNotes")]
		public override string ShagNotes { get; set; }

		[DBColumn(Name = "LotNotes")]
		public override string LotNotes { get; set; }

		[DBColumn(Name = "ReturnNotes")]
		public override string ReturnNotes { get; set; }

		[DBColumn(Name = "LotLocation")]
		public override string LotLocation { get; set; }

	}
}