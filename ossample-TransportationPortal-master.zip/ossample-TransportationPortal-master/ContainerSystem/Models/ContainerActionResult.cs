﻿using System;

namespace ContainerSystem.Models
{
	public class ContainerActionResult
	{
		public virtual string ContainerNumber { get; set; }

		public virtual string Error { get; set; }
	}
}