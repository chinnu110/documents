﻿using System;

namespace ContainerSystem.Models
{
    public static class ActionCodeValues
    {
        /// <summary>
        /// Set Pull Date (01)
        /// </summary>
        public const string SET_PULL_DATE = "01";

        /// <summary>
        /// Assign Commit To OKC Driver (02)
        /// </summary>
        public const string ASSIGN_COMMIT_TO_OKC_DRIVER = "02";

		/// <summary>
		/// Assign Empty Return Driver (03)
		/// </summary>
		public const string ASSIGN_EMPTY_RETURN_DRIVER = "03";

		/// <summary>
		/// Add Hemispheres Return Driver (04)
		/// </summary>
		public const string ASSIGN_HEMISPHERES_RETURN_DRIVER = "04";

		/// <summary>
		/// Container Arrived at Hemispheres (05)
		/// </summary>
		public const string CONTAINER_ARRIVED_AT_HEMISPHERES = "05";

		/// <summary>
		/// Container Empty at Hemispheres (06)
		/// </summary>
		public const string CONTAINER_EMPTY_AT_HEMISPHERES = "06";
	}
}
