﻿using System;

namespace ContainerSystem.Models
{
	public class ContainerInfo
	{
		public virtual string ContainerNumber { get; set; }

		public virtual string StatusCode { get; set; }

		public virtual DateTime? StatusDate { get; set; }

		public virtual string PickupNumber { get; set; }

		public virtual string PickupLocation { get; set; }

		public virtual bool Hot { get; set; }

		public virtual DateTime? LastFreeDate { get; set; }

		public virtual DateTime? PerDiemDate { get; set; }

		public virtual string DeliveryZone { get; set; }

		public virtual string PullDriverName { get; set; }

		public virtual string CommitDriverName { get; set; }

		public virtual string ReturnDriverName { get; set; }

		public virtual string SealNumber { get; set; }

		public virtual DateTime? PullDate { get; set; }

		public virtual string Note { get; set; }

		public virtual string Carrier { get; set; }

		public virtual string ContainerSize { get; set; }

		public virtual string ShagNotes { get; set; }

		public virtual string LotNotes { get; set; }

		public virtual string ReturnNotes { get; set; }

		public virtual string LotLocation { get; set; }
	}
}