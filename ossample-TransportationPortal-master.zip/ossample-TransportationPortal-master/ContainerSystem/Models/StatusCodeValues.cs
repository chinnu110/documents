﻿using System;

namespace ContainerSystem.Models
{
    public static class StatusCodeValues
    {
        /// <summary>
        /// Evans and Wood Notification (EW)
        /// </summary>
        public const string EW_NOTIFICATION = "EW";

        /// <summary>
        /// Dallas Yard (20)
        /// </summary>
        public const string ARRIVED_DALLAS_YARD = "20";

		/// <summary>
		/// Southwest Freight Yard (23)
		/// </summary>
		public const string SOUTHWEST_FREIGHT_YARD = "23";

		/// <summary>
		/// Return to OKC Yard (25)
		/// </summary>
		public const string RETURN_TO_OKC_YARD = "25";

		/// <summary>
		/// Dallas Yard (26)
		/// </summary>
		public const string ARRIVED_HEMISPHERES_YARD = "26";

		/// <summary>
		/// Committed to Arrive OKC (27)
		/// </summary>
		public const string COMMITTED_TO_ARRIVE_OKC = "27";

		/// <summary>
		/// OKC Yard (28)
		/// </summary>
		public const string ARRIVED_OKC_YARD = "28";

		/// <summary>
        /// Empty Container at Hemispheres (33)
        /// </summary>
        public const string EMPTY_CONTAINER_HEMISPHERES = "33";

		/// <summary>
		/// Empty Container (34)
		/// </summary>
		public const string EMPTY_CONTAINER = "34";

		/// <summary>
		/// Loaded Hobby Lobby (36)
		/// </summary>
		public const string LOADING_HOBBYLOBBY_STORE = "36";

		/// <summary>
		/// Committed Return (40)
		/// </summary>
		public const string COMMITTED_RETURN = "40";

		/// <summary>
		/// Return a text description of the value;
		/// </summary>
		/// <param name="statusCode">Status Code value</param>
		/// <returns>Text description</returns>
		public static string GetText(string statusCode)
		{
			return GetTextOnly(statusCode) + " (" + statusCode + ")";
		}

		public static string GetTextOnly(string statusCode)
		{
			switch (statusCode)
			{
				case EW_NOTIFICATION:
					return "Release";
				case ARRIVED_DALLAS_YARD:
					return "Dallas";
				case SOUTHWEST_FREIGHT_YARD:
					return "SW Yard";
				case RETURN_TO_OKC_YARD:
					return "Return to OKC";
				case ARRIVED_HEMISPHERES_YARD:
					return "Hemispheres";
				case COMMITTED_TO_ARRIVE_OKC:
					return "Committed OKC";
				case ARRIVED_OKC_YARD:
					return "Arrived OKC";
				case EMPTY_CONTAINER:
					return "Empty";
				case EMPTY_CONTAINER_HEMISPHERES:
					return "Empty HM";
				case LOADING_HOBBYLOBBY_STORE:
					return "Loading HL";
				case COMMITTED_RETURN:
					return "Committed Return";
				default:
					return "Unknown";
			}
		}
	}
}
