﻿using System;
using System.Collections.Generic;
using ContainerSystem.Interfaces;
using ContainerSystem.Models;

namespace ContainerSystem.Service
{
	public enum ContainerRepository
	{
		ISeries = 1,
		SqlServer = 2
	}

	public enum UpdateColumn
	{
		/// <summary>
		/// Default value. No column.
		/// </summary>
		None,

		/// <summary>
		/// Pull Driver Name (string)
		/// </summary>
		PullDriverName,

		/// <summary>
		/// Commit Driver Name (string)
		/// </summary>
		CommitDriverName,

		/// <summary>
		/// Return Driver Name (string)
		/// </summary>
		ReturnDriverName,

		/// <summary>
		/// General Notes (string)
		/// </summary>
		Notes,
		
		/// <summary>
		/// Rail Pickup Notes (string)
		/// </summary>
		PickupLocation,

		/// <summary>
		/// Shag Notes (string)
		/// </summary>
		ShagNotes,

		/// <summary>
		/// Lot Notes (string)
		/// </summary>
		LotNotes,

		/// <summary>
		/// Return Notes (string)
		/// </summary>
		ReturnNotes,

		/// <summary>
		/// Lot Location (string)
		/// </summary>
		LotLocation	
	}

	public class ContainerService : IContainerService
	{
		/// <summary>
		/// Repository type behind this service instance.
		/// </summary>
		public ContainerRepository RepositoryType { get; private set; }

		/// <summary>
		/// Repository instantiated.
		/// </summary>
		private IContainerService Repository { get; set; }

		/// <summary>
		/// Create a ContainerService for querying the remote container source.
		/// </summary>
		/// <param name="repository"></param>
		/// <param name="connectionString"></param>
		public ContainerService(ContainerRepository repository, string connectionString)
		{
			RepositoryType = repository;

			if (RepositoryType == ContainerRepository.ISeries)
			{
				Repository = new ISeriesRepository.ContainerRepository(connectionString);
			}
			else if (RepositoryType == ContainerRepository.SqlServer)
			{
				Repository = new SqlServerRepository.ContainerRepository(connectionString);
			}
			else
			{
				throw new ArgumentException("Unknown Repository Enum value.");
			}
		}

		// IContainerService implementation.

		/// <summary>
		/// Get container information for a single container.
		/// </summary>
		/// <param name="containerNumber">Container number</param>
		/// <returns></returns>
		public ContainerInfo GetContainer(string containerNumber)
		{
			return Repository.GetContainer(containerNumber);
		}

		/// <summary>
		/// Get list of containers for the requested status codes.
		/// </summary>
		/// <param name="statusCodes">List of status codes</param>
		/// <returns>List of containers in the requested status codes.</returns>
		public IEnumerable<ContainerInfo> GetContainerList(IEnumerable<string> statusCodes)
		{
			return Repository.GetContainerList(statusCodes);
		}
		
		/// <summary>
		/// Update columns for a single container.
		/// </summary>
		/// <param name="containerNumber">Container number</param>
		/// <param name="updateColumns">Column name/value pairs</param>
		/// <returns></returns>
		public int UpdateContainer(string containerNumber, Dictionary<UpdateColumn, object> updateColumns)
		{
			return Repository.UpdateContainer(containerNumber, updateColumns);
		}

		/// <summary>
		/// Update columns for multiple containers.
		/// </summary>
		/// <param name="containerNumbers">List of container numbers</param>
		/// <param name="updateColumns">Column name/value pairs</param>
		/// <returns></returns>
		public int UpdateContainers(IEnumerable<string> containerNumbers, Dictionary<UpdateColumn, object> updateColumns)
		{
			return Repository.UpdateContainers(containerNumbers, updateColumns);
		}

		/// <summary>
		/// Get a list of ContainerInfo records from a list of container numbers.
		/// </summary>
		/// <param name="containerNumbers"></param>
		/// <returns></returns>
		public IEnumerable<ContainerInfo> GetContainerListByNumber(IEnumerable<string> containerNumbers)
		{
			return Repository.GetContainerListByNumber(containerNumbers);
		}


		public IEnumerable<ContainerActionResult> ContainerAction(string actionCode, IEnumerable<string> containerNumbers, string driverName = null, DateTime? actionDate = null)
		{
			return Repository.ContainerAction(actionCode, containerNumbers, driverName, actionDate);
		}
	}
}
