﻿using System;
using System.Configuration;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Collections.Generic;
using HobbyLobby.HLUtil.Logging;
using Avatar;
using TransportationPortal.Controllers;

namespace TransportationPortal
{
	/// <summary>
	/// Provide isolation, mapping, relay, and testing capability for application authorization.
	/// The controller types are mapped to view names in Avatar. This provides isolation from Avatar for the physical 
	/// construction of the site. By using a LibConfig value to disengage Avatar, the security setup can be tested in isolation.
	/// Use this class to embed authorization checking and determination in code.
	/// Use AppAuthorizationFilter to decorate action methods for minimum permissions allowed.
	/// </summary>
	public static class AppAuthorization
	{
		/// <summary>
		/// Engage Avatar Authorization? Pulled from LibConfig at static initialization.
		/// </summary>
		public static readonly bool AvatarEngage;

		/// <summary>
		/// AvatarName AppSetting for this application. Pulled from root web.config at static initialization.
		/// </summary>
		public static readonly string ApplicationName;

		/// <summary>
		/// Constructed dictionary of Controller Types to Avatar View names.
		/// </summary>
		private static Dictionary<Type, String> ControllerToAvatarView = null;

		private const string ROOT_WEB_CONFIG = @"/";

		private const string AVATAR_NAME_APPSETTINGS_KEY = "AvatarName";

		/// <summary>
		/// AppAuthorization static initializer. Called once at class load time.
		/// </summary>
		static AppAuthorization()
		{
			AvatarEngage = LibConfigProperties.Settings.AvatarEngage;

			if (AvatarEngage == true)
			{
				{
					//KeyValueConfigurationElement element = rootWebConfig.AppSettings.Settings[AVATAR_NAME_APPSETTINGS_KEY];
					string element = WebConfigurationManager.AppSettings[AVATAR_NAME_APPSETTINGS_KEY];
					if (!string.IsNullOrEmpty(element))
					{
						if (!string.IsNullOrWhiteSpace(element/*.Value*/))
						{
							ApplicationName = element; //.Value;
							HLLogging.Info("Avatar authorization is engaged.");
						}
						else
						{
							AvatarEngage = false;
							HLLogging.Error(string.Format("Avatar authorization is disengaged because AppSettings key {0} is empty.", AVATAR_NAME_APPSETTINGS_KEY));
						}
					}
					else
					{
						AvatarEngage = false;
						HLLogging.Error(string.Format("Avatar authorization is disengaged because AppSettings key {0} not found.", AVATAR_NAME_APPSETTINGS_KEY));
					}
				}
			}
			else
			{
				HLLogging.Warn("Avatar authorization is manually disengaged. (LibConfig/Security/AvatarEngage=False)");
			}
			
			ControllerToAvatarView = new Dictionary<Type,string>();

			/*
			 * Create mapping of controller types to Avatar view names.
			 */ 
			ControllerToAvatarView.Add(typeof(AdminSettingsController),		"AdminSettings");
			ControllerToAvatarView.Add(typeof(BrokerLoadController),		"BrokerLoad");
			ControllerToAvatarView.Add(typeof(CarrierController),			"Carrier");
			ControllerToAvatarView.Add(typeof(CarrierRateUpdateController), "CarrierRateUpdate");
			ControllerToAvatarView.Add(typeof(CleanupLoadController),		"CleanupLoad");
			ControllerToAvatarView.Add(typeof(CleanupPlanningController),	"CleanupPlanning");
			ControllerToAvatarView.Add(typeof(CleanupScheduleController),	"CleanupSchedule");
			ControllerToAvatarView.Add(typeof(ContainerDispatchController), "ContainerDispatch");
			ControllerToAvatarView.Add(typeof(ContainerReviewController),   "ContainerReview");
			ControllerToAvatarView.Add(typeof(DailyDispatchController),		"DailyDispatch");
			ControllerToAvatarView.Add(typeof(DispatchDateController),		"DispatchDate");
			ControllerToAvatarView.Add(typeof(DispatcherController),		"Dispatcher");
			ControllerToAvatarView.Add(typeof(DriverController),			"Driver");
			ControllerToAvatarView.Add(typeof(FuelSurchargeController),		"FuelSurcharge");
			ControllerToAvatarView.Add(typeof(InboundPlanningController),	"InboundPlanning");
			ControllerToAvatarView.Add(typeof(LoadCompanyController),		"LoadCompany");
			ControllerToAvatarView.Add(typeof(OutboundRouteController),		"OutboundSchedule");
			ControllerToAvatarView.Add(typeof(ReportController),			"Report");
			ControllerToAvatarView.Add(typeof(StoreController),				"Store");
			ControllerToAvatarView.Add(typeof(StoreLoadController),			"StoreLoad");
			ControllerToAvatarView.Add(typeof(VendorBackhaulController),	"VendorBackhaul");
		}

		/// <summary>
		/// Authorize this current user to this controller by mapping the controller name to a view name.
		/// The returned PermissionLevel is from the Avatar View PermissionLevel for whatever group this user is a member of.
		/// </summary>
		/// <param name="controller">The current controller instance. The Controller Type will be used for Avatar lookup</param>
		/// /// <param name="controllerTypeForAuth">The Controller Type for Avatar lookup, instead of 'this" controller.</param>
		/// <returns>PermissionLevel</returns>
		public static PermissionLevel ViewPermission(Controller controller, Type controllerTypeForAuth = null)
		{
			Type controllerType = controllerTypeForAuth == null ? controller.GetType() : controllerTypeForAuth;

			string viewName = null;

			bool viewFound = ControllerToAvatarView.TryGetValue(controllerType, out viewName);

			if (!viewFound)
			{
				throw new Exception("Application error: Controller not found in Controller to Avatar map.");
			}
			
			if (AvatarEngage)
			{
				AuthorizationResponse authResponse = Authorization.IsAuthorizedToView(controller.User.Identity.Name, ApplicationName, viewName);
				if (authResponse.IsAuthorized == false)
				{
					authResponse = Authorization.IsAuthorizedToApplication(controller.User.Identity.Name, ApplicationName);
					if (authResponse.IsAuthorized == false)
					{
						authResponse.PermissionLevel = PermissionLevel.None;
					}
				}
				return authResponse.PermissionLevel;
			}
			else
			{
				return PermissionLevel.Full;
			}
		}

		/// <summary>
		/// Authorize this current user to this controller by mapping the controller name to a view name.
		/// The returned PermissionLevel is from the Avatar Element PermissionLevel for whatever group this user is a member of.
		/// </summary>
		/// <param name="controller">The current controller instance. "this"</param>
		/// <param name="elementName">Element name within the Avatar view.</param>
		/// <returns></returns>
		public static PermissionLevel ElementPermission(Controller controller, string elementName)
		{
			Type controllerType = controller.GetType();

			string viewName = null;

			bool viewFound = ControllerToAvatarView.TryGetValue(controllerType, out viewName);

			if (!viewFound)
			{
				throw new Exception("Application error: Controller not found in Controller to Avatar map.");
			}

			if (AvatarEngage)
			{
				AuthorizationResponse authResponse = Authorization.IsAuthorizedToElement(controller.User.Identity.Name, ApplicationName, viewName, elementName);
				if (authResponse.IsAuthorized == false)
				{
					authResponse = Authorization.IsAuthorizedToView(controller.User.Identity.Name, ApplicationName, viewName);
					if (authResponse.IsAuthorized == false)
					{
						authResponse = Authorization.IsAuthorizedToApplication(controller.User.Identity.Name, ApplicationName);
						if (authResponse.IsAuthorized == false)
						{
							authResponse.PermissionLevel = PermissionLevel.None;
						}
					}
				}
				return authResponse.PermissionLevel;
			}
			else
			{
				return PermissionLevel.Full;
			}
		}

		/// <summary>
		/// Test the specified PermissionLevel against the minimum PermissionLevel desired.
		/// </summary>
		/// <param name="specifiedPermissionLevel">PermissionLevel to test.</param>
		/// <param name="minimumPermissionLevel">Minimum PermissionLevel desired.</param>
		/// <returns>True if the specified PermissionLevel is at least the value of the minimum PermissionLevel; otherwise False.</returns>
		public static bool AtLeast(this PermissionLevel specifiedPermissionLevel, PermissionLevel minimumPermissionLevel)
		{
			switch (specifiedPermissionLevel)
			{
				case PermissionLevel.Full:
					return (
						minimumPermissionLevel == PermissionLevel.Full || 
						minimumPermissionLevel == PermissionLevel.Modify || 
						minimumPermissionLevel == PermissionLevel.Read
						) ? true : false;
				case PermissionLevel.Modify:
					return (
						minimumPermissionLevel == PermissionLevel.Modify || 
						minimumPermissionLevel == PermissionLevel.Read
						) ? true : false;
				case PermissionLevel.Read:
					return (
						minimumPermissionLevel == PermissionLevel.Read
						) ? true : false;
				default:
					return false;
			}
		}
	}
}