﻿using System;
using System.Web;
using System.Web.Mvc;
using HobbyLobby.HLUtil.Logging;

namespace TransportationPortal
{
	/// <summary>
	/// This attribute class should be placed above the controller class to provide exception handling and display of unhandled exceptions.
	/// </summary>
	public class HandleApplicationError : FilterAttribute, IExceptionFilter
	{
		public void OnException(ExceptionContext filterContext)
		{
			string controllerName = filterContext.Controller.GetType().Name;
			string unhandledException = filterContext.Exception.GetType().Name;
			string baseException = "none";
			string username;
			
			try
			{
				username = filterContext.RequestContext.HttpContext.User.Identity.Name;
			}
			catch (Exception)
			{
				username = "unknown";
			}

			if (filterContext.Exception.GetBaseException() != null)
			{
				baseException = filterContext.Exception.GetBaseException().GetType().Name;
			}

			string message = string.Format("Controller={0} User={3} Exception={1} BaseException={2}", 
				controllerName, unhandledException, baseException, username);

			HLLogging.Error(message, filterContext.Exception);
		}
	}
}