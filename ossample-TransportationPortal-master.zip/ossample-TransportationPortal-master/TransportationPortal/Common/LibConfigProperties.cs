﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HobbyLobby.HLUtil.Configuration;
using ContainerSystem.Service;

namespace TransportationPortal
{
	/// <summary>
	/// Provide a single place to retrieve LibConfig values.
	/// </summary>
	public class LibConfigProperties
	{
		private static readonly LibConfigProperties _Config = new LibConfigProperties();
		public static LibConfigProperties Settings { get { return _Config; } }

		public string DispatchConnectionString 
		{
			get	{ return HLConfig.GetString("Database", "DispatchConnectionString"); }
		}

		public int MaximumDispatchDatesActive
		{
			get { return HLConfig.GetIntDefault("Process", "MaximumDispatchDatesActive", 21); }
		}

		public string ReportServerUrl
		{
			get { return HLConfig.GetString("Report", "ReportServerUrl"); }
		}

		public string ReportServerDomain
		{
			get { return HLConfig.GetString("Report", "ReportServerDomain"); }
		}

		public string ReportServerUsername
		{
			get { return HLConfig.GetString("Report", "ReportServerUsername"); }
		}

		public string ReportServerPassword
		{
			get { return HLConfig.GetString("Report", "ReportServerPassword"); }
		}

		public string ReportFolder
		{
			get { return HLConfig.GetString("Report", "ReportFolder"); }
		}

		public string ReportFormat
		{
			get { return HLConfig.GetString("Report", "ReportFormat"); }
		}

		public int ReportTimeout
		{
			get { return HLConfig.GetIntDefault("Report", "ReportTimeout", 60000); }
		}

		public bool SapEngage
		{
			get { return HLConfig.GetBoolDefault("SapConnection", "SapEngage", true); }
		}

		public string SapEnvironment
		{
			get { return HLConfig.GetString("SapConnection", "SapEnvironment"); }
		}

        public string DispatchContext
        {
            get { return HLConfig.GetString("Database", "TransportationPortalAreasDispatch.Repositories.DispatchContext"); }
        }

        public string DispatchOLEDB
        {
            get { return HLConfig.GetString("Database", "TransportationDispatch.OLEDB"); }
        }

        public ContainerRepository ContainerRepositoryType
        {
            get
            {
                string repositoryType = HLConfig.GetString("ContainerSource", "RepositoryType");
                ContainerRepository containerRepository = (ContainerRepository)Enum.Parse(typeof(ContainerRepository), repositoryType, true);
                return containerRepository;
            }
        }

        public string ContainerSourceConnection
        {
            get 
            {
                string connectionStringName = HLConfig.GetString("ContainerSource", "ConnectionStringName");
                return HLConfig.GetString("Database", connectionStringName); 
            }
        }

        /// <summary>
		/// Sets the type of notification for Carrier Dispatch Requests.
		/// PRINT = The pdf will be created and displayed.
		/// EMAIL = An email message will be created with the pdf attached. The email can then be edited and sent.
		/// NONE = A notification is not automatically created. The print link in the DailyDispatch index view can be used to create it manually.
		/// </summary>
		public string CarrierDispatchNotificationType
		{
			get	{ return HLConfig.GetStringDefault("Process", "CarrierDispatchNotificationType", "EMAIL"); }
		}

		/// <summary>
		/// Number of days out from today where a change to a dispatch would trigger a print when updated.
		/// 0 = Don't automatically print. 
		/// 1 = Print if changed for today's dispatch. 
		/// 2 = Print if changed for today's dispatch or the next dispatch day.
		/// 3 = Print if changed for today's dispatch or the next 2 dispatch days.
		/// -1 = Always print.
		/// </summary>
		public int DriverPaysheetPrintHorizonDays
		{
			get { return HLConfig.GetIntDefault("Process", "DriverPaysheetPrintHorizonDays", -1); }
		}

		public bool AvatarEngage
		{
			get { return HLConfig.GetBoolDefault("Security", "AvatarEngage", true); }
		}

		public string NewBrokerEmailSubject
		{
			get { return HLConfig.GetStringDefault("Process", "NewBrokerEmailSubject", "New broker/customer request *** TEST ***"); }
		}

		public string NewBrokerEmailAddress
		{
			get { return HLConfig.GetStringDefault("Process", "NewBrokerEmailAddress", "addressbookrequest@hobbylobby.com"); }
		}

		public string CarrierAdvisementSpreadsheetName
		{
			get { return HLConfig.GetStringDefault("Names", "CarrierAdvisementSpreadsheet", "Hobby Lobby Reference Numbers"); }
		}

		public string FreightInvoiceReportName
		{
			get { return HLConfig.GetStringDefault("Names", "FreightInvoiceReportName", "Freight Invoice"); }
		}

		public string DriverPaysheetOTRReportName
		{
			get { return HLConfig.GetStringDefault("Names", "DriverPaysheetOTRReportName", "Driver Paysheet"); }
		}

		public string DriverPaysheetCTNReportName
		{
			get { return HLConfig.GetStringDefault("Names", "DriverPaysheetCTNReportName", "Driver Paysheet CTN"); }
		}

		public string CarrierDispatchReportName
		{
			get { return HLConfig.GetStringDefault("Names", "CarrierDispatchReportName", "Carrier Dispatch"); }
		}

		public int ReadonlyHorizonDaysForDispatches
		{
			get { return HLConfig.GetIntDefault("Process", "ReadonlyHorizonDaysForDispatches", 60); }
		}

		public string InboundLoadFuelSurchargeDate
		{
			get { return HLConfig.GetStringDefault("Process", "InboundLoadFuelSurchargeDate", "PickupDate"); }
		}

		public int InboundLoadFuelSurchargeDateAdjust
		{
			get { return HLConfig.GetIntDefault("Process", "InboundLoadFuelSurchargeDateAdjust", 0); }
		}

        public int SliderToteMax
        {
            get { return HLConfig.GetIntDefault("StoreScheduler", "SliderToteMax", 0); }
        }

        public int SliderPalletMax
        {
            get { return HLConfig.GetIntDefault("StoreScheduler", "SliderPalletMax", 0); }
        }
        public int SliderLoadLockMax
        {
            get { return HLConfig.GetIntDefault("StoreScheduler", "SliderLoadLockMax", 0); }
        }
        public int SliderCartonMax
        {
            get { return HLConfig.GetIntDefault("StoreScheduler", "SliderCartonMax", 0); }
        }
        

        public int PalletMax
        {
            get { return HLConfig.GetIntDefault("Opportunity", "PalletMax", 0); }
        }

        public int LoadLockMax
        {
            get { return HLConfig.GetIntDefault("Opportunity", "LoadLockMax", 0); }
        }

        public int CartonMax
        {
            get { return HLConfig.GetIntDefault("Opportunity", "CartonMax", 0); }
        }

        public int ToteMax
        {
            get { return HLConfig.GetIntDefault("Opportunity", "ToteMax", 0); }
        }

        public string MaxColor
        {
            get { return HLConfig.GetStringDefault("Opportunity", "MaxColor", ""); }
        }

        public string MinColor
        {
            get { return HLConfig.GetStringDefault("Opportunity", "MinColor", ""); }
        }


        public string UnattachedCleanup
        {
            get { return HLConfig.GetStringDefault("Opportunity", "UnattachedCleanup", ""); }
        }

        public string Chains 
        {
            get { return HLConfig.GetStringDefault("StoreScheduler", "Chains", ""); }
        }

        public string VerdeHostName 
        {
            get { return HLConfig.GetString("StoreScheduler", "VerdeHostName"); }
        }

        public int ChangeDateHours { get { return HLConfig.GetInt("StoreScheduler", "ChangeDateHours"); } }
    }
}