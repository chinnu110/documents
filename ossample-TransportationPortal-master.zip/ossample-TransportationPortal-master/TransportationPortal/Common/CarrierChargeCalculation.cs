﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;

namespace TransportationPortal
{
    public static class CarrierChargeCalculation
    {
        public enum MileageCalcEnum
        {
            UseRatePerMile = 0,
            UseFlatRate,
        }

        public class Parts
        {
            public int? Miles { get; set; }
            public decimal? Rate { get; set; }
            public decimal? FlatRate { get; set; }
            public MileageCalcEnum MileageCalcType { get; set; } 
            public decimal? StopCharge1 { get; set; }
            public bool StopCharge1Used { get; set; }
            public decimal? StopCharge2 { get; set; }
            public bool StopCharge2Used { get; set; }
            public decimal? FuelSurcharge { get; set; }
            public decimal? ExtraCharge { get; set; }
            public int? LoadCount { get; set; }
            public decimal? TotalCharge { get; set; }
        }

        /// <summary>
        /// Determine the carrier charges using the supplied values and load counts and return the 
        /// Charge object with only those parts that contributed to the total.
        /// This method may replace the input values. If a simple total is needed, use the Total method.
        /// </summary>
        /// <param name="input">Charge object</param>
        /// <returns>Charge object</returns>
        static public Parts Calculate(Parts input)
        {
            Parts output = new Parts
            {
                Miles = input.Miles,
                Rate = input.Rate,
                FlatRate = input.FlatRate,
                MileageCalcType = input.MileageCalcType,
                FuelSurcharge = input.FuelSurcharge,
                StopCharge1 = input.StopCharge1,
                StopCharge2 = input.StopCharge2,
                ExtraCharge = input.ExtraCharge,
                LoadCount = input.LoadCount
            };

            // If rate or miles or fuel surcharge are missing, total will be null.
            if (input.MileageCalcType == MileageCalcEnum.UseRatePerMile)
            {
                output.TotalCharge = (input.Rate * input.Miles) + (input.FuelSurcharge * input.Miles);
            }
            else 
            {
                output.TotalCharge = input.FlatRate + (input.FuelSurcharge * input.Miles);
            }

            if (input.LoadCount.HasValue && input.LoadCount > 1)
            {
                output.TotalCharge += (input.StopCharge1 ?? 0);
                output.StopCharge1Used = true;
            }

            if (input.LoadCount.HasValue && input.LoadCount > 2)
            {
                output.TotalCharge += (input.StopCharge2 ?? 0);
                output.StopCharge2Used = true;
            }

            output.TotalCharge += (input.ExtraCharge ?? 0);

            if (output.TotalCharge.HasValue == false)
            {
                if (input.TotalCharge.HasValue)
                {
                    output.TotalCharge = input.TotalCharge;
                }
            }

            return output;
        }

        /// <summary>
        /// Total carrier charge inputs and return the Charge object with all input parts unchanged.
        /// </summary>
        /// <param name="input">Charge object</param>
        /// <returns>Charge object</returns>
        static public Parts Total(Parts input)
        {
            Parts output = new Parts
            {
                Miles = input.Miles,
                Rate = input.Rate,
                FuelSurcharge = input.FuelSurcharge,
                StopCharge1 = input.StopCharge1,
                StopCharge2 = input.StopCharge2,
                ExtraCharge = input.ExtraCharge
            };

            if (input.MileageCalcType == MileageCalcEnum.UseRatePerMile)
            {
                output.TotalCharge = (input.Rate * input.Miles) + (input.FuelSurcharge * input.Miles);
            }
            else
            {
                output.TotalCharge = input.FlatRate + (input.FuelSurcharge * input.Miles);
            }

            output.TotalCharge += (input.StopCharge1 ?? 0);

            output.TotalCharge += (input.StopCharge2 ?? 0);

            output.TotalCharge += (input.ExtraCharge ?? 0);

            return output;
        }
    }
}