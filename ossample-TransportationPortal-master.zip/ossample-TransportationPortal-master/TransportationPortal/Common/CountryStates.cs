﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;

namespace TransportationPortal
{
	public class CountryStates
	{
		public static Dictionary<string, string> USStates
		{
			get
			{
				return _USAStateList;
			}
		}

		public static Dictionary<string, string> GetStatesForCountry(string country)
		{
			switch (country)
			{
				case "USA":
					return _USAStateList;
				case "CAN":
					return _CANProvinceList;
				default:
					return _EmptyList;
			}
		}

		public static Dictionary<string, string> GetCountryCodes()
		{
			return _CountryCodes;
		}

		private static Dictionary<string, string> _CountryCodes = new Dictionary<string, string>();

		private static Dictionary<string, string> _USAStateList = new Dictionary<string, string>();

		private static Dictionary<string, string> _CANProvinceList = new Dictionary<string, string>();

		private static Dictionary<string, string> _EmptyList = new Dictionary<string, string>();

		static CountryStates()
		{
			_CountryCodes.Add("USA", "United States");
			_CountryCodes.Add("CAN", "Canada");
			_CountryCodes.Add("MEX", "Mexico");

			_USAStateList.Add("AL", "Alabama");
			_USAStateList.Add("AK", "Alaska");
			_USAStateList.Add("AZ", "Arizona");
			_USAStateList.Add("AR", "Arkansas");
			_USAStateList.Add("CA", "California");
			_USAStateList.Add("CO", "Colorado");
			_USAStateList.Add("CT", "Connecticut");
			_USAStateList.Add("DE", "Delaware");
			_USAStateList.Add("DC", "District of Columbia");
			_USAStateList.Add("FL", "Florida");
			_USAStateList.Add("GA", "Georgia");
			_USAStateList.Add("HI", "Hawaii");
			_USAStateList.Add("ID", "Idaho");
			_USAStateList.Add("IL", "Illinois");
			_USAStateList.Add("IN", "Indiana");
			_USAStateList.Add("IA", "Iowa");
			_USAStateList.Add("KS", "Kansas");
			_USAStateList.Add("KY", "Kentucky");
			_USAStateList.Add("LA", "Louisiana");
			_USAStateList.Add("ME", "Maine");
			_USAStateList.Add("MD", "Maryland");
			_USAStateList.Add("MA", "Massachusetts");
			_USAStateList.Add("MI", "Michigan");
			_USAStateList.Add("MN", "Minnesota");
			_USAStateList.Add("MS", "Mississippi");
			_USAStateList.Add("MO", "Missouri");
			_USAStateList.Add("MT", "Montana");
			_USAStateList.Add("NE", "Nebraska");
			_USAStateList.Add("NV", "Nevada");
			_USAStateList.Add("NH", "New Hampshire");
			_USAStateList.Add("NJ", "New Jersey");
			_USAStateList.Add("NM", "New Mexico");
			_USAStateList.Add("NY", "New York");
			_USAStateList.Add("NC", "North Carolina");
			_USAStateList.Add("ND", "North Dakota");
			_USAStateList.Add("OH", "Ohio");
			_USAStateList.Add("OK", "Oklahoma");
			_USAStateList.Add("OR", "Oregon");
			_USAStateList.Add("PA", "Pennsylvania");
			_USAStateList.Add("RI", "Rhode Island");
			_USAStateList.Add("SC", "South Carolina");
			_USAStateList.Add("SD", "South Dakota");
			_USAStateList.Add("TN", "Tennessee");
			_USAStateList.Add("TX", "Texas");
			_USAStateList.Add("UT", "Utah");
			_USAStateList.Add("VT", "Vermont");
			_USAStateList.Add("VA", "Virginia");
			_USAStateList.Add("WA", "Washington");
			_USAStateList.Add("WV", "West Virginia");
			_USAStateList.Add("WI", "Wisconsin");
			_USAStateList.Add("WY", "Wyoming");

			_CANProvinceList.Add("AB", "Alberta");
			_CANProvinceList.Add("BC", "British Columbia");
			_CANProvinceList.Add("MB", "Manitoba");
			_CANProvinceList.Add("NF", "Newfoundland");
			_CANProvinceList.Add("NB", "New Brunswick");
			_CANProvinceList.Add("NS", "Nova Scotia");
			_CANProvinceList.Add("NT", "Northwest Territories");
			_CANProvinceList.Add("NU", "Nunavut");
			_CANProvinceList.Add("ON", "Ontario");
			_CANProvinceList.Add("PE", "Prince Edward Island");
			_CANProvinceList.Add("QC", "Quebec");
			_CANProvinceList.Add("SK", "Saskatchewan");
			_CANProvinceList.Add("YT", "Yukon Territory");
		}
	}
}