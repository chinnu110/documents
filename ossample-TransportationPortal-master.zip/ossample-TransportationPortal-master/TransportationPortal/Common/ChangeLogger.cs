﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity.Infrastructure;
using System.Web.Mvc;
using HobbyLobby.HLUtil.Logging;

namespace TransportationPortal
{
	/// <summary>
	/// This class performs logging of add/change/delete information.
	/// Adds and changes to entities are handled by putting the user and date into the appropriate fields in the record.
	/// Deletes are handled by writing the record field contents into the log file.
	/// </summary>
	public class ChangeLogger
	{
		public const string CREATE_DATE = "CreateDate";
		public const string CREATE_USER = "CreateUser";

		public const string CHANGE_DATE = "ChangeDate";
		public const string CHANGE_USER = "ChangeUser";

		public const string DELETE_DATE = "DeleteDate";
		public const string DELETE_USER = "DeleteUser";

		/// <summary>
		/// This method will "touch" the specified entry by updating the CreateUser and CreateDate fields in an added entry and
		/// updating the ChangeUser and ChangeDate fields in a changed entry, even if no actual changes to fields have been made.
		/// Log the entry content for a deleted entry.
		/// </summary>
		/// <param name="controller">The current controller (usually 'this')</param>
		/// <param name="entry">Entry to touch. Use context.Entry(record).</param>
		public static void LogChange(Controller controller, DbEntityEntry entry, DateTime? CommonDateTime = null)
		{
			DateTime dateTime = CommonDateTime ?? DateTime.Now;

			if (entry.State == System.Data.EntityState.Deleted)
			{
				// There will be no record to save the User and Date for a delete, so log the entire record.
				var propertyList = entry.OriginalValues.PropertyNames
					.Select(x => new
					{
						name = x,
						value = entry.OriginalValues[x]
					});
				var changeList = propertyList
					.Where(x => x.value != null)
					.Select(x => string.Format("{0}={1}", x.name, x.value.ToString()));
				string recordIdent = string.Format("{0} [{1}]", entry.Entity.GetType().Name, string.Join(",", changeList));
				string message = string.Format("Record deleted by {0}: {1}", controller.User.Identity.Name, recordIdent);
				HLLogging.Info(message);
			}
			else
			{
				object currentUser = entry.Property(CREATE_USER).CurrentValue;
				if (currentUser == null)
				{
					entry.Property(CREATE_USER).CurrentValue = controller.User.Identity.Name;
					entry.Property(CREATE_DATE).CurrentValue = dateTime;
				}
				else
				{
					entry.Property(CHANGE_USER).CurrentValue = controller.User.Identity.Name;
					entry.Property(CHANGE_DATE).CurrentValue = dateTime;
				}
			}
		}

		/// <summary>
		/// Mark the record as logically deleted.
		/// </summary>
		/// <param name="controller"></param>
		/// <param name="entry"></param>
		public static void LogLogicalDelete(Controller controller, DbEntityEntry entry, string message)
		{
			entry.Property(DELETE_USER).CurrentValue = controller.User.Identity.Name;
			entry.Property(DELETE_DATE).CurrentValue = DateTime.Now;
			HLLogging.Info(message);
		}
	}
}