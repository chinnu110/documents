﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Controllers;
using TransportationPortal.ViewModels;

namespace TransportationPortal
{
    public static class Extensions
    {
        /// <summary>
        /// Returns the next business date (weekday) from the date. Friday, Saturday, and Sunday return Monday.
        /// Any time component is retained.
        /// </summary>
        /// <param name="theDate"></param>
        /// <returns></returns>
        public static DateTime GetNextBusinessDate(this DateTime theDate)
        {
            DateTime nextDate = theDate;

            switch (theDate.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    nextDate = theDate.AddDays(1);
                    break;
                case DayOfWeek.Monday:
                    nextDate = theDate.AddDays(1);
                    break;
                case DayOfWeek.Tuesday:
                    nextDate = theDate.AddDays(1);
                    break;
                case DayOfWeek.Wednesday:
                    nextDate = theDate.AddDays(1);
                    break;
                case DayOfWeek.Thursday:
                    nextDate = theDate.AddDays(1);
                    break;
                case DayOfWeek.Friday:
                    nextDate = theDate.AddDays(3);
                    break;
                case DayOfWeek.Saturday:
                    nextDate = theDate.AddDays(2);
                    break;
            }

            return nextDate;
        }

        /// <summary>
        /// Builds a SelectList from an Enum. To provide readability, underscores in the Enum name are replaced with spaces.
        /// </summary>
        /// <typeparam name="T">Enum</typeparam>
        /// <param name="selectedValue">Value or Values for marking list items with the selected attribute.</param>
        /// <returns></returns>
        public static SelectList BuildSelectList<T>(object selectedValue = null)
        {
            Type enumType = typeof(T);

            Array names = Enum.GetValues(enumType);

            List<SelectListItem> items = new List<SelectListItem>();

            foreach (var value in names)
            {
                items.Add(new SelectListItem
                {
                    Value = value.ToString(),
                    Text = Enum.Format(enumType, value, "G").Replace('_', ' ')
                });
            }

            SelectList selectList = new SelectList(items, "Value", "Text", selectedValue);

            return selectList;
        }

        /// <summary> 
        /// Generates a fully qualified URL to an action method by using 
        /// the specified action name, controller name and route values. 
        /// </summary> 
        /// <param name="url">The URL helper.</param> 
        /// <param name="actionName">The name of the action method.</param> 
        /// <param name="controllerName">The name of the controller.</param> 
        /// <param name="routeValues">The route values.</param> 
        /// <returns>Absolute URL of the full action and path.</returns> 
        public static string AbsoluteAction(
            this UrlHelper url,
            string actionName, 
            string controllerName, 
            object routeValues = null)
        {
            string scheme = url.RequestContext.HttpContext.Request.Url.Scheme;

            return url.Action(actionName, controllerName, routeValues, scheme);
        }

        /// <summary> 
        /// Generates a fully qualified URL to an action method by using 
        /// the specified action name, controller name and route values. 
        /// Useful when needing to reference an action with a manually built remainder path.
        /// </summary> 
        /// <param name="url">The URL helper.</param> 
        /// <param name="actionName">The name of the action method.</param> 
        /// <param name="controllerName">The name of the controller.</param> 
        /// <returns>Absolute URL up to the action.</returns> 
        public static string AbsoluteActionPrefix(
            this UrlHelper url,
            string actionName, 
            string controllerName)
        {
            string scheme = url.RequestContext.HttpContext.Request.Url.Scheme;

            return url.Action(actionName, controllerName, null, scheme);
        } 

        /// <summary>
        /// Obtain the Display Name attribute value. This is the same text as for a label element, but inside a span.
        /// </summary>
        /// <typeparam name="TModel">View model</typeparam>
        /// <typeparam name="TProperty">View model property for binding</typeparam>
        /// <param name="htmlHelper">HTML helper object</param>
        /// <param name="expression">Lambda expression for binding target</param>
        /// <returns>HTML string</returns>
        public static MvcHtmlString LabelTextFor<TModel, TProperty>(
                    this HtmlHelper<TModel> htmlHelper,
                    Expression<Func<TModel, TProperty>> expression)
        {
            ModelMetadata metadata = ModelMetadata.FromLambdaExpression<TModel, TProperty>(expression, htmlHelper.ViewData);

            string fieldDisplayName = metadata.DisplayName;

            TagBuilder tag = new TagBuilder("span");
            tag.SetInnerText(HttpUtility.HtmlEncode(fieldDisplayName));

            return MvcHtmlString.Create(tag.ToString());
        }

        /// <summary>
        /// Build a list of checkboxes with value binding to a collection. 
        /// Each checkbox is built from the MultiSelectList items.
        /// This is for any array of int's and you must have the previous array of int's to compare for addtions and removals.
        /// Only the values are important. Array element position means nothing.
        /// </summary>
        /// <typeparam name="TModel">View model</typeparam>
        /// <typeparam name="TProperty">View model property for binding</typeparam>
        /// <param name="htmlHelper">HTML helper object</param>
        /// <param name="expression">Lambda expression for binding target</param>
        /// <param name="listOfValues">MultiSelectList of options and selected status to build the list.</param>
        /// <returns>HTML string</returns>
        public static MvcHtmlString CheckBoxListFor<TModel, TProperty>(
                    this HtmlHelper<TModel> htmlHelper,
                    Expression<Func<TModel, TProperty>> expression,
                    IEnumerable<SelectListItem> listOfValues)
        {
            if (listOfValues == null)
            {
                return MvcHtmlString.Empty;
            }

            var sb = new StringBuilder();

            string fieldExpression = ExpressionHelper.GetExpressionText(expression);
            string fieldName = htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldId(fieldExpression);

            foreach (var item in listOfValues)
            {
                var cb = new TagBuilder("input");
                cb.MergeAttribute("type", "checkbox");
                cb.MergeAttribute("name", fieldName);
                cb.MergeAttribute("value", item.Value);
                cb.MergeAttribute("id", string.Format("{0}_{1}", fieldName, item.Value));
                if (item.Selected)
                {
                    cb.MergeAttribute("checked", "checked");
                }
                
                cb.SetInnerText(item.Text);
                sb.Append(cb.ToString());

                sb.Append("<br />\r\n");
            }

            return MvcHtmlString.Create(sb.ToString());
        }

        /// <summary>
        /// Returns an IEnumerable of every Nth item in the source enumerable, starting at the indicated offset.
        /// This can be used with the CheckBoxListFor() to build a multi-column checkbox list.
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="source">Source enumerable</param>
        /// <param name="startIndex">Offset of the first element to take.</param>
        /// <param name="n">Take every Nth element.</param>
        /// <returns></returns>
        public static IEnumerable<TSource> TakeEveryNth<TSource>(
            this IEnumerable<TSource> source,
            int startIndex,
            int n)
        {
            int index = startIndex;

            int size = source.Count();

            while (index < size)
            {
                TSource resultObject = source.ElementAt(index);
                yield return resultObject;
                index += n;
            }
        }

        /// <summary>
        /// Helper to locate the AdminSettings Session object.
        /// </summary>
        /// <param name="controller">Usually 'this'.</param>
        /// <returns>The current session object. If one does not exist, it will be created.</returns>
        public static AdminSettingsViewModel AdministrativeSettings(this Controller controller)
        {
            AdminSettingsViewModel adminSettings = controller.Session[AdminSettingsController.SessionDataName] as AdminSettingsViewModel;

            if (adminSettings == null)
            {
                adminSettings = new AdminSettingsViewModel
                {
                    AdminEditMode = false
                };

                // Save the settings.
                controller.Session[AdminSettingsController.SessionDataName] = adminSettings;
            }

            return adminSettings;
        }

        /// <summary>
        /// Returns a formatted datetime value as "Day hh:mmA" if today or not more than 6 days in the future. 
        /// Otherwise it prepends the month and day.
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static string FormatNearDate(this DateTime dt)
        {
            if (dt.Date >= DateTime.Today && dt.Date < DateTime.Today.AddDays(7))
            {
                return dt.ToString("ddd h:mmt");
            }
            else
            {
                return dt.ToString("M/d ddd h:mmt");
            }
        }

        /// <summary>
        /// This method can be included in the code after a complete IQueryable is built in order to extract the generated SQL.
        /// The SQL generated from this method can be copied into a SSMS query window and directly executed.
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="queryable">IQueryable</param>
        /// <returns></returns>
        public static string ToExecutableSqlString<TEntity>(this IQueryable<TEntity> queryable) where TEntity : class
        {
            try
            {
                var executedQuery = queryable as DbQuery<TEntity>;

                // get the IInternalQuery internal variable from the DbQuery object
                var internalQueryproperty = executedQuery.GetType().GetProperty("InternalQuery", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);

                var iq = internalQueryproperty.GetValue(executedQuery, null);

                // get the ObjectQuery internal variable from the IInternalQuery object
                var objectQueryProperty = iq.GetType().GetProperty("ObjectQuery", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);

                var oq = objectQueryProperty.GetValue(iq, null);

                var objectQuery = oq as ObjectQuery<TEntity>;

                string querystring = objectQuery.ToTraceString();

                StringBuilder query = new StringBuilder();

                // Insert parameter declarations.
                foreach (var objectParam in objectQuery.Parameters)
                {
                    if (objectParam.ParameterType == typeof(DateTime) || objectParam.ParameterType == typeof(DateTime?))
                    {
                        string formattedValue = ((DateTime)objectParam.Value).ToString("s");
                        query.AppendLine(string.Format("declare @{0} datetime2 = '{1}'", objectParam.Name, formattedValue));
                    }
                    else if (objectParam.ParameterType == typeof(string))
                    {
                        query.AppendLine(string.Format("declare @{0} varchar(50) = '{1}'", objectParam.Name, objectParam.Value.ToString()));
                    }
                    else if (objectParam.ParameterType == typeof(bool) || objectParam.ParameterType == typeof(bool?))
                    {
                        bool val;
                        if (bool.TryParse(objectParam.Value.ToString(), out val))
                        {
                            query.AppendLine(string.Format("declare @{0} bit = {1}", objectParam.Name, val ? 1 : 0));
                        }
                    }
                    else if (objectParam.ParameterType == typeof(short) || objectParam.ParameterType == typeof(short?) ||
                             objectParam.ParameterType == typeof(int) || objectParam.ParameterType == typeof(int?))
                    {
                        query.AppendLine(string.Format("declare @{0} integer = {1}", objectParam.Name, objectParam.Value.ToString()));
                    }
                }

                query.AppendLine();

                // Insert SQL statement.
                query.AppendLine(querystring);

                // Insert command to drop the execution plan after execution to provide a consistent execution time.
                // Remove if timing measurements are not needed and this will speed up subsequent queries.
                query.AppendLine("OPTION (RECOMPILE)");

                return query.ToString();
            }
            catch (Exception)
            {
                return null;
            }
        } 
    }
}