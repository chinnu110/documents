﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;

namespace TransportationPortal
{
	public enum ContainerAction
	{
		None = 0,
		Pull = 1,
		CommitToOKC = 2,
		EmptyReturn = 3
	}
}