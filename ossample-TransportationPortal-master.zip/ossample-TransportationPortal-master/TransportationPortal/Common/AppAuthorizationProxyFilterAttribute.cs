﻿using System;
using System.Web;
using System.Web.Mvc;
using Avatar;

namespace TransportationPortal
{
	/// <summary>
	/// This attribute class calls the AppAuthorization.ApplicationPermission() method to determine if the current uset is authorized to the application object.
	/// </summary>
	public class AppAuthorizationFilter : FilterAttribute, IAuthorizationFilter
	{
		/// <summary>
		/// Minimum PermissionLevel to authorize. Default is READ.
		/// </summary>
		public PermissionLevel MinimumPermissionRequired { get; set; }
		
		public AppAuthorizationFilter()
		{
			if (MinimumPermissionRequired == PermissionLevel.None)
			{
				MinimumPermissionRequired = PermissionLevel.Read;
			}
		}

		#region IAuthorizationFilter Members

		public void OnAuthorization(AuthorizationContext filterContext)
		{
			Controller controller = filterContext.Controller as Controller;

			PermissionLevel permissionLevel = AppAuthorization.ViewPermission(controller);

			if (permissionLevel.AtLeast(MinimumPermissionRequired) == false)
			{
				throw new Exception("You are not authorized to this feature.");
			}
		}

		#endregion
	}
}