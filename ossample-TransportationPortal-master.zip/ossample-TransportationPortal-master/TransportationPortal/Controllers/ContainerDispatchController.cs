﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Objects.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using Avatar;
using HobbyLobby.HLUtil.Logging;
using TransportationPortal.Models;
using TransportationPortal.Repositories;
using TransportationPortal.ViewModels;
using ContainerSystem.Service;
using ContainerSystem.Models;


namespace TransportationPortal.Controllers
{
	[HandleApplicationError]
	public class ContainerDispatchController : DailyDispatchController
	{
		/// <summary>
		/// Session element name for remembering filter values when returning to this controller.
		/// </summary>
		private string FilterSessionName
		{
			get { return this.GetType().Name + ".Filter"; }
		}


		#region Index view and related methods

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public override ViewResult Index(int? id)
		{
			DailyDispatchIndexViewModel newViewModel;

			DailyDispatchIndexViewModel viewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
			if (viewModel == null)
			{
				viewModel = new DailyDispatchIndexViewModel();
				viewModel.FromDate = DateTime.Today;
				viewModel.Paging = new PagingViewModel
				{
					Page = 1,
					PageSize = 50,
					LinksBeforeCurrentPage = 4,
					LinksAfterCurrentPage = 4,
				};
				newViewModel = GenerateViewModel(viewModel);
			}
			else if (id.HasValue)
			{
				if (viewModel.Paging.Page != id.Value)
				{
					ViewBag.OverrideSavedPosition = "0_0";
				}
				viewModel.Paging.Page = id.Value;
				newViewModel = GenerateViewModel(viewModel);
			}
			else if (viewModel.Dispatches == null)
			{
				newViewModel = GenerateViewModel(viewModel);
			}
			else
			{
				newViewModel = viewModel;
				
				object changedDispatchIDobject = TempData[TEMPDATA_LASTDAILYDISPATCHID];
				if (changedDispatchIDobject != null)
				{
					int changedDispatchID = 0;
					if (Int32.TryParse(changedDispatchIDobject.ToString(), out changedDispatchID) && changedDispatchID > 0)
					{
						UpdateDispatchIndexList(changedDispatchID);
					}
				}
			}

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public override ViewResult Index(DailyDispatchIndexViewModel viewModel)
		{
			// Copy any items needed that were not returned.
			DailyDispatchIndexViewModel previousViewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
			if (previousViewModel != null)
			{
				viewModel.Paging = previousViewModel.Paging;
				viewModel.Paging.Page = 1;
			}
			else
			{
				viewModel.Paging = new PagingViewModel
				{
					Page = 1,
					PageSize = 50,
					LinksBeforeCurrentPage = 4,
					LinksAfterCurrentPage = 4,
				};
			}

			// Generate the new view model.
			DailyDispatchIndexViewModel newViewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		private DailyDispatchIndexViewModel GenerateViewModel(DailyDispatchIndexViewModel viewModel)
		{
			Db = new DispatchContext();

			// Initialization of ViewModel

			if (viewModel.DispatcherListData == null)
			{
				viewModel.DispatcherListData = Db.Dispatcher
					.OrderBy(x => x.FirstName)
					.ThenBy(x => x.LastName)
					.ToList()
					.Select(x => new SelectListItem
					{
						Value = x.DispatcherID.ToString(),
						Text = x.FullName
					});
			}

			viewModel.DispatcherList = new SelectList(viewModel.DispatcherListData, "Value", "Text", viewModel.DispatcherID);

			// Determine access to the Notes and Trailers update feature on the Index page.

			if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Modify) ||
				AppAuthorization.ElementPermission(this, "Notes").AtLeast(PermissionLevel.Modify))
			{
				viewModel.CanUseNoteUpdateMode = true;
			}
			else
			{
				viewModel.CanUseNoteUpdateMode = false;
			}

			if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Modify) ||
				AppAuthorization.ElementPermission(this, "Trailers").AtLeast(PermissionLevel.Modify))
			{
				viewModel.CanUseTrailerUpdateMode = true;
			}
			else
			{
				viewModel.CanUseTrailerUpdateMode = false;
			}


			// Begin query argument processing

			IQueryable<DailyDispatch> list = null;

			// AdminViewMode dependent processing

			if (viewModel.AdminViewMode)
			{
				list = Db.DailyDispatch;

				if (viewModel.FromDate.HasValue)
				{
					list = list.Where(x => x.DispatchDate >= viewModel.FromDate.Value);
				}

				if (viewModel.ThruDate.HasValue)
				{
					list = list.Where(x => x.DispatchDate <= viewModel.ThruDate.Value);
				}
			}
			else
			{
				list = Db.DailyDispatch.Where(x =>x.InboundDate == viewModel.FromDate.Value);
			}

			/*
			 * Includes.
			 */

			list = list.AsNoTracking()
				.Include(x => x.Driver1)
				.Include(x => x.Driver2)
				.Include(x => x.Carrier)
				.Include(x => x.Loads)
				.Include(x => x.Loads.Select(a => a.Store))
				.Include(x => x.Loads.Select(a => a.PickupCompany))
				.Include(x => x.Containers)
				.Where(x => x.DispatchGroup == DatabaseLists.DISPATCH_GROUP_DALLAS);

			/*
			 * Selectors
			 */
			
			if (viewModel.DriverShiftDay != viewModel.DriverShiftNight)
			{
				if (viewModel.DriverShiftDay)
				{
					list = list.Where(x => x.Driver1.DriverShift == DriverShift.Day);
				}
				if (viewModel.DriverShiftNight)
				{
					list = list.Where(x => x.Driver1.DriverShift == DriverShift.Night);
				}
			}

			if (viewModel.DriverShiftStartDallas != viewModel.DriverShiftStartOKC)
			{
				if (viewModel.DriverShiftStartDallas)
				{
					list = list.Where(x => x.Driver1.DriverShiftStart == DriverShiftStart.Dallas);
				}
				if (viewModel.DriverShiftStartOKC)
				{
					list = list.Where(x => x.Driver1.DriverShiftStart == DriverShiftStart.OKC);
				}
			}

			if (viewModel.DriverFullTime != viewModel.DriverPartTime)
			{
				if (viewModel.DriverFullTime)
				{
					list = list.Where(x => x.Driver1.PartTime == false);
				}
				if (viewModel.DriverPartTime)
				{
					list = list.Where(x => x.Driver1.PartTime == true);
				}
			}

			if (viewModel.CarrierSelect == true || viewModel.CompanySelect == true || viewModel.NoCarrierOrCompanySelect == true)
			{
				if (viewModel.CarrierID.HasValue)
				{
					list = list.Where(x =>
						(viewModel.CarrierSelect == true && (x.CarrierID.HasValue && x.CarrierID == viewModel.CarrierID.Value))
						|| (viewModel.CompanySelect == true && (x.Driver1ID.HasValue || x.Driver2ID.HasValue))
						|| (viewModel.NoCarrierOrCompanySelect == true && (x.CarrierID.HasValue == false && x.Driver1ID.HasValue == false && x.Driver2ID.HasValue == false))
					);
				}
				else
				{
					list = list.Where(x =>
						(viewModel.CarrierSelect == true && x.CarrierID.HasValue)
						|| (viewModel.CompanySelect == true && (x.Driver1ID.HasValue || x.Driver2ID.HasValue))
						|| (viewModel.NoCarrierOrCompanySelect == true && (x.CarrierID.HasValue == false && x.Driver1ID.HasValue == false && x.Driver2ID.HasValue == false))
						);
				}
			}

			/*
			 * Filters
			 */

			if (viewModel.DispatcherID.HasValue)
			{
				list = list.Where(x =>
					(x.Driver1.DispatcherID == viewModel.DispatcherID) ||
					(x.Driver2.DispatcherID == viewModel.DispatcherID));
			}

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim();
				int intValue = 0;
				bool isNumber = Int32.TryParse(textValue, out intValue);

				if (isNumber && intValue > 0)
				{
					list = list.Where(x =>
						x.DailyDispatchID == intValue
						|| x.TractorNumber == textValue
						|| x.Loads.Any(y => y.Store.StoreNumber == intValue)
						|| x.Comment.Contains(textValue)
						|| x.Trailer.Contains(textValue)
						|| x.TrailerIn.Contains(textValue)
						|| x.Containers.Any(y => y.ContainerNumber.Contains(textValue))
						);
				}
				else
				{
					list = list.Where(x =>
						(x.Driver1.FirstName.Contains(textValue) || x.Driver1.LastName.Contains(textValue))
						|| (x.Driver2.FirstName.Contains(textValue) || x.Driver2.LastName.Contains(textValue))
						|| x.Comment.Contains(textValue)
						|| x.Trailer.Contains(textValue)
						|| x.TrailerIn.Contains(textValue)
						|| x.Containers.Any(y => y.ContainerNumber.Contains(textValue))
						);
				}
			}

			/*
			 * Sorting
			 */
			list = list.Sort(DispatchSortColumn.Driver1, 1);
			/*
			if (!string.IsNullOrEmpty(viewModel.SortingID))
			{
				string[] sorting = viewModel.SortingID.Split(',');
				if (sorting.Length == 2)
				{
					DispatchSortColumn sortColumn;
					if (!Enum.TryParse(sorting[0], out sortColumn))
					{
						sortColumn = DispatchSortColumn.DispatchDepart;
					}
					int sortDirection = sorting[1].ToUpper() == "A" ? 1 : -1;
					list = list.Sort(sortColumn, sortDirection);
				}
			}
			 */

			/*
			 * Output determination: All or Paged.
			 */

			if (viewModel.AdminViewMode)
			{
				list = list.Skip((viewModel.Paging.Page - 1) * viewModel.Paging.PageSize)
					.Take(viewModel.Paging.PageSize);
			}

			// Uncomment and use debug to capture an executable SQL statement. 
			//string sqltrace = list.ToExecutableSqlString();

			if (viewModel.OldestOpenDispatchDate == null)
			{
				viewModel.OldestOpenDispatchDate = Db.OpenDispatchDates().OldestDispatchDate();
			}

			viewModel.Dispatches = list
				.ToList()
				.Select(x => new DispatchViewModel(x))
				.ToList();

			return viewModel;
		}

		#endregion

		#region Ajax helper methods

		/// <summary>
		/// Create driver information popup
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public ActionResult GetContainerInfo(string ContainerNumber)
		{
			ContainerService = ContainerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

			ContainerInfo containerInfo = ContainerService.GetContainer(ContainerNumber);

			ContainerViewModel viewModel = new ContainerViewModel(containerInfo);

			return PartialView("_ContainerDetailsPopup", viewModel);
		}

		#endregion
	}
}