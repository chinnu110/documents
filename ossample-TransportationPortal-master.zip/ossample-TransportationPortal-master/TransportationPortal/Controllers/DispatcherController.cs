﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.Repositories;
using TransportationPortal.ViewModels;
using System.Collections;
using Avatar;

namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class DispatcherController : Controller
	{
		private DispatchContext db = new DispatchContext();

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index()
		{
			DispatcherViewModel viewModel = new DispatcherViewModel();

			viewModel.Dispatchers = db.Dispatcher
				.OrderBy(x => x.FirstName)
				.ThenBy(x => x.LastName)
				.ToList()
				.Select(x => new DispatcherViewModel.Dispatcher
				{
					DispatcherID = x.DispatcherID,
					FirstName = x.FirstName,
					LastName = x.LastName
				});

			return View(viewModel);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Details(int id)
		{
			Dispatcher model = db.Dispatcher.Find(id);
			db.Entry(model).Collection(x => x.Drivers).Load();
			return View(model);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Create()
		{
			return View(CreateViewModel());
		} 

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Create(DispatcherUpdateViewModel screen)
		{
			if (db.Dispatcher.Any(x => x.FirstName.ToUpper() == screen.FirstName.ToUpper() && x.LastName.ToUpper() == screen.LastName.ToUpper()) == true)
			{
				ModelState.AddModelError(string.Empty, string.Format("Dispatcher '{0} {1}' already exists.", screen.FirstName, screen.LastName));
			}

			if (!ModelState.IsValid)
			{
				return View(CreateViewModel(inputViewModel: screen));
			}

			Dispatcher model = new Dispatcher();
			model.FirstName = screen.FirstName;
			model.LastName = screen.LastName;
			model.Drivers = new List<Driver>();

			// If no drivers selected, the list is empty
			if (screen.DriverSelect != null)
			{
				var driversToBeAssigned = db.Driver.ActiveFilter().Where(x => screen.DriverSelect.Contains(x.DriverID));
				foreach (Driver driver in driversToBeAssigned)
				{
					model.Drivers.Add(driver);
				}
			}

			db.Dispatcher.Add(model);
			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Dispatcher {0} created.", model.FullName);
			return RedirectToAction("Index");  
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult Edit(int id)
		{
			Dispatcher model = db.Dispatcher.Find(id);
			return View(CreateViewModel(model: model));
		}
		
		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult Edit(DispatcherUpdateViewModel screen)
		{
			Dispatcher model = db.Dispatcher.Find(screen.DispatcherID);

			UInt64 screenTimestamp = BitConverter.ToUInt64(screen.Timestamp, 0);
			UInt64 modelTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

			if (screenTimestamp != modelTimestamp)
			{
				ModelState.Clear();
				ModelState.AddModelError(string.Empty,
					"The record you attempted to edit was modified after you got the original value.\r\n" +
					"The edit operation was canceled and the current values in the database have been displayed.\r\n" +
					"If you still want to edit this record, make the changes again and click the Save button.\r\n" +
					"Otherwise click Back to List.");
				return View(CreateViewModel(model: model));
			}

			if (db.Dispatcher.Any(x => x.FirstName.ToUpper() == screen.FirstName.ToUpper() && x.LastName.ToUpper() == screen.LastName.ToUpper() &&
				x.DispatcherID != screen.DispatcherID) == true)
			{
				ModelState.AddModelError(string.Empty, string.Format("Dispatcher '{0} {1}' already exists.", screen.FirstName, screen.LastName));
			}

			if (!ModelState.IsValid)
			{
				return View(CreateViewModel(inputViewModel: screen));
			}

			model.FirstName = screen.FirstName;
			model.LastName = screen.LastName;

			// If no drivers unselected, the list is empty
			if (screen.DriverSelect == null)
			{
				screen.DriverSelect = new List<int>();
			}

			// Load the drivers assigned to this dispatcher
			db.Entry(model).Collection(x => x.Drivers).Load();

			// Remove drivers from the current assigned list if they are not in the new assigned list.
			var driversNoLongerAssigned = model.Drivers.Where(x => screen.DriverSelect.Contains(x.DriverID) != true);
			foreach (Driver driver in driversNoLongerAssigned.ToList())
			{
				model.Drivers.Remove(driver);
			}

			// Add new drivers to the assigned list if they are not in the current assigned list.
			var driversToBeAssigned = screen.DriverSelect.Where(x => model.Drivers.Any(y => y.DriverID == x) != true);
			foreach (Driver driver in db.Driver.ActiveFilter().Where(x => driversToBeAssigned.Contains(x.DriverID)))
			{
				model.Drivers.Add(driver);
			}

			ChangeLogger.LogChange(this, db.Entry(model));

			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Dispatcher {0} updated.", model.FullName);
			return RedirectToAction("Index");
		}

		private DispatcherUpdateViewModel CreateViewModel(DispatcherUpdateViewModel inputViewModel = null, Dispatcher model = null)
		{
			var DriverList = db.Driver
				.ActiveFilter()
				.OrderBy(x => x.FirstName)
				.ThenBy(x => x.LastName)
				.ToList()
				.Select(x => new
				{
					DriverID = x.DriverID,
					FullName = string.Format("{0} {1} {2} {3}", x.FirstName, x.MiddleName, x.LastName, x.Suffix).Replace("  ", " ").Trim()
				});

			DispatcherUpdateViewModel viewModel = inputViewModel ?? new DispatcherUpdateViewModel();

			if (model == null)
			{
				viewModel.Drivers = new MultiSelectList(DriverList, "DriverID", "FullName", viewModel.DriverSelect);
			}
			else
			{
				viewModel.DispatcherID = model.DispatcherID;
				viewModel.FirstName = model.FirstName;
				viewModel.LastName = model.LastName;
				viewModel.Timestamp = model.Timestamp;
				viewModel.CreateDate = model.CreateDate;
				viewModel.CreateUser = model.CreateUser;
				viewModel.ChangeDate = model.ChangeDate;
				viewModel.ChangeUser = model.ChangeUser;
				if (viewModel.DriverSelect == null)
				{
					db.Entry(model).Collection(x => x.Drivers).Load();
					viewModel.DriverSelect = model.Drivers.Select(x => x.DriverID).ToList();
				}
				viewModel.Drivers = new MultiSelectList(DriverList, "DriverID", "FullName", viewModel.DriverSelect);
			}

			return viewModel;
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Delete(int id)
		{
			Dispatcher model = db.Dispatcher.Find(id);

			db.Entry(model).Collection(x => x.Drivers).Load();
			model.Drivers.Clear();

			db.Dispatcher.Remove(model);

			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Dispatcher {0} deleted.", model.FullName);
			return RedirectToAction("Index");
		}

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}
