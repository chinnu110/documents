﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using System.Data.Objects.SqlClient;
using System.Text;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class VendorBackhaulController : LoadController
	{
		public readonly static string TEMPDATA_RETURN_URL = typeof(VendorBackhaulController).Name + ".ReturnURL";

		public override string GetControllerLoadType
		{
			get
			{
				return DatabaseLists.INBOUND_VENDOR_BACKHAUL;
			}
		}

		public override string GetControllerLoadName
		{
			get
			{
				return "Vendor Backhaul";
			}
		}
		
		public override Load GetInitialLoadForCreate
		{
			get
			{

				return new Load
				{
					ReadyDate = DateTime.Today
				};
			}
		}
				
		protected override LoadIndexViewModel GenerateViewModel(IQueryable<Load> query, LoadIndexViewModel viewModel)
		{
			// Load viewbag.

			var vendors = db.LoadCompanies(isVendor: true)
				.OrderBy(x => x.Name)
				.ToList()
				.Select(x => new SelectListItem
				{
					Text = x.Name,
					Value = x.LoadCompanyID.ToString()
				});

			if (viewModel.PickupCompanyID.HasValue)
			{
				ViewBag.PickupCompanyID = new SelectList(vendors, "Value", "Text", viewModel.PickupCompanyID.Value.ToString());
			}
			else
			{
				ViewBag.PickupCompanyID = new SelectList(vendors, "Value", "Text");
			}

			var carriers = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .AsNoTracking()
                .OrderBy(x => x.Name)
				.Select(x => new
				{
					Text = x.Name,
					Value = x.CarrierID
				});

			if (viewModel.CarrierID.HasValue)
			{
				ViewBag.CarrierID = new SelectList(carriers, "Value", "Text", viewModel.CarrierID);
			}
			else
			{
				ViewBag.CarrierID = new SelectList(carriers, "Value", "Text");
			}


			var subsetSortTypes = SortTypes
				.Where(x => x.Value.Contains(Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.StoreLocation)) == false);

			if (string.IsNullOrEmpty(viewModel.SortingID))
			{
				viewModel.SortingID = subsetSortTypes.ElementAt(0).Value;
			}

			ViewBag.SortingID = new SelectList(subsetSortTypes, "Value", "Text", viewModel.SortingID);

			// Apply filters.

			if (viewModel.PickupCompanyID.HasValue)
			{
				query = query.Where(x => x.PickupCompanyID == viewModel.PickupCompanyID);
			}

			if (viewModel.CarrierID.HasValue)
			{
				query = query.Where(x => x.DailyDispatch.CarrierID == viewModel.CarrierID);
			}

			if (viewModel.FromDate.HasValue)
			{
				switch (viewModel.DateType)
				{
					case 1:
						query = query.Where(x => x.ReadyDate >= viewModel.FromDate.Value);
						break;
					case 2:
						query = query.Where(x => x.WorkDate >= viewModel.FromDate.Value);
						break;
					case 0:
					default:
						query = query.Where(x => x.PickupDate >= viewModel.FromDate.Value);
						break;
				}
			}

			if (viewModel.ThruDate.HasValue)
			{
				switch (viewModel.DateType)
				{
					case 1:
						query = query.Where(x => x.ReadyDate <= viewModel.ThruDate.Value);
						break;
					case 2:
						query = query.Where(x => x.WorkDate <= viewModel.ThruDate.Value);
						break;
					case 0:
					default:
						query = query.Where(x => x.PickupDate <= viewModel.ThruDate.Value);
						break;
				}
			}

			if (viewModel.WorkStatus == 1)
			{
				query = query.Where(x => x.WorkDate.HasValue == false);
			}
			else if (viewModel.WorkStatus == 2)
			{
				query = query.Where(x => x.WorkDate.HasValue == true);
			}

			if (viewModel.ChargeStatus == 1)
			{
				query = query.Where(x => x.DailyDispatch.CarrierTotalCharge.HasValue == false);
			}
			else if (viewModel.ChargeStatus == 2)
			{
				query = query.Where(x => x.DailyDispatch.CarrierTotalCharge.HasValue == true);
			}

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim();

				Int64 intValue = 0;
				decimal decValue = 0m;
				bool isNumber = Decimal.TryParse(textValue, out decValue);
				if (isNumber)
				{
					intValue = Decimal.ToInt64(decValue);
				}

				if (isNumber && intValue > 0)
				{
					query = query.Where(x =>
						(x.LoadID == intValue && x.LoadType == GetControllerLoadType)
						|| x.PickupContact.Contains(textValue)
						|| x.PO1.Contains(textValue)
						|| x.PO2.Contains(textValue)
						|| x.Confirmation.Contains(textValue)
						|| x.Class.Contains(textValue)
						|| x.Comment.Contains(textValue)
						|| x.DailyDispatch.TrailerIn.Contains(textValue)
						|| x.PickupCompany.Name.Contains(textValue)
						|| x.PickupCompany.City.Contains(textValue)
						);
				}
				else
				{
					query = query.Where(x =>
						x.PickupContact.Contains(textValue)
						|| x.PO1.Contains(textValue)
						|| x.PO2.Contains(textValue)
						|| x.Confirmation.Contains(textValue)
						|| x.Class.Contains(textValue)
						|| x.Comment.Contains(textValue)
						|| x.DailyDispatch.TrailerIn.Contains(textValue)
						|| x.PickupCompany.Name.Contains(textValue)
						|| x.PickupCompany.City.Contains(textValue)
						);
				}
			}

			return base.GenerateViewModel(query, viewModel);
		}

		public override void LoadTypeValidation(LoadViewModel viewModel, Load existingLoad)
		{
			viewModel.Load.LoadCompanyID = null;

			if (viewModel.Pickup == null || viewModel.Pickup.LoadCompanyID.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "Pickup Company must be specified");
			}

			if (string.IsNullOrEmpty(viewModel.Load.DeliveryType))
			{
				ModelState.AddModelError(string.Empty, "Delivery Transfer Type must be specified.");
			}
			else if (viewModel.Load.DeliveryType == DatabaseLists.LOAD_DELIVERY_TYPE_WAREHOUSE)
			{
				viewModel.Load.DeliveryCompanyID = null;
			}
			else if (viewModel.Delivery == null || viewModel.Delivery.LoadCompanyID.HasValue  == false)
			{
				ModelState.AddModelError(string.Empty, "Delivery Company must be specified");
			}

			if (existingLoad != null && existingLoad.DailyDispatchID.HasValue)
			{
				if (viewModel.Load.PickupDate.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Pickup Date must be specified when Load is attached to a Dispatch.");
				}
			}

			if (!ModelState.IsValid)
			{
				return;
			}

			viewModel.Load.BrokerLoadNumber = null;
			viewModel.Load.LoadContact = null;
			viewModel.Load.PickupContact = null;
			viewModel.Load.PickupAddress = null;
			viewModel.Load.PickupStops = 1;
			viewModel.Load.DeliveryStops = 1;
		}

		public override ActionResult Edit(int id)
		{
			Load model = db.Load
				.Include(x => x.DailyDispatch)
				.Include(x => x.DailyDispatch.Loads)
				.Single(x => x.LoadID == id);

			if (model.DailyDispatchID.HasValue && model.DailyDispatch.Loads.Count() == 1)
			{
				ViewBag.CarrierTotalCharge = model.DailyDispatch.CarrierTotalCharge ?? 0.00m;
			}

			return base.Edit(id);
		}
	}
}