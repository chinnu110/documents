﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using System.Data.Objects.SqlClient;
using System.Text;
using HobbyLobby.SAP.Proxy.Soap.TransDispatch;
using HobbyLobby.HLUtil.Logging;
using Avatar;
using Avatar.Mvc;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class BrokerLoadController : LoadController
	{
		public readonly static string TEMPDATA_RETURN_URL = typeof(BrokerLoadController).Name + ".ReturnURL";

		public override string GetControllerLoadType
		{
			get
			{
				return DatabaseLists.INBOUND_BROKER_LOAD;
			}
		}

		public override string GetControllerLoadName
		{
			get
			{
				return "Broker Load";
			}
		}

		public override Load GetInitialLoadForCreate
		{
			get
			{
				return new Load
				{
					ReadyDate = DateTime.Today
				};
			}
		}

		public string SendInvoiceNonceSessionName
		{
			get { return typeof(BrokerLoadController).Name + ".SendInvoiceNonce"; }
		}

		
		protected override LoadIndexViewModel GenerateViewModel(IQueryable<Load> query, LoadIndexViewModel viewModel)
		{
			// Load viewbag.

			var brokers = db.LoadCompanies(isBroker: true)
				.OrderBy(x => x.Name)
				.ToList()
				.Select(x => new SelectListItem
				{
					Text = x.Name,
					Value = x.LoadCompanyID.ToString()
				});

			if (viewModel.LoadCompanyID.HasValue)
			{
				ViewBag.LoadCompanyID = new SelectList(brokers, "Value", "Text", viewModel.LoadCompanyID.Value.ToString());
			}
			else
			{
				ViewBag.LoadCompanyID = new SelectList(brokers, "Value", "Text");
			}

			var subsetSortTypes = SortTypes
				.Where(x => x.Value.Contains(Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.StoreLocation)) == false);

			if (string.IsNullOrEmpty(viewModel.SortingID))
			{
				viewModel.SortingID = subsetSortTypes.ElementAt(0).Value;
			}

			ViewBag.SortingID = new SelectList(subsetSortTypes, "Value", "Text", viewModel.SortingID);

			// Apply filters.

			if (viewModel.LoadCompanyID.HasValue)
			{
				query = query.Where(x => x.LoadCompanyID == viewModel.LoadCompanyID);
			}

			if (viewModel.FromDate.HasValue)
			{
				query = query.Where(x => x.PickupDate >= viewModel.FromDate.Value);
			}

			if (viewModel.ThruDate.HasValue)
			{
				DateTime thruDate = viewModel.ThruDate.Value.Date.AddDays(1);
				query = query.Where(x => x.PickupDate < thruDate);
			}


			if (viewModel.InvoiceStatus != 0)
			{
				DateTime oldestOpenDispatchDate = db.OpenDispatchDates().OldestDispatchDate();
				if (viewModel.InvoiceStatus == 1)
				{
					query = query.Where(x => x.DailyDispatchID.HasValue == true && x.InvoiceDate.HasValue == false && x.DailyDispatch.DispatchDate < oldestOpenDispatchDate);
				}
				else if (viewModel.InvoiceStatus == 2)
				{
					query = query.Where(x => x.DailyDispatchID.HasValue == true && x.InvoiceDate.HasValue == false && x.DailyDispatch.DispatchDate >= oldestOpenDispatchDate);
				}
				else if (viewModel.InvoiceStatus == 3)
				{
					query = query.Where(x => x.DailyDispatchID.HasValue == true && x.InvoiceDate.HasValue == true);
				}
			}

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim();

				Int64 intValue = 0;
				decimal decValue = 0m;
				bool isNumber = Decimal.TryParse(textValue, out decValue);
				if (isNumber)
				{
					intValue = Decimal.ToInt64(decValue);
				}

				if (isNumber && intValue > 0)
				{
					query = query.Where(x =>
						(x.LoadID == intValue && x.LoadType == GetControllerLoadType)
						|| x.BrokerLoadNumber.Contains(textValue)
						|| x.LoadContact.Contains(textValue)
						|| x.PO1.Contains(textValue)
						|| x.PO2.Contains(textValue)
						|| x.Confirmation.Contains(textValue)
						|| x.Class.Contains(textValue)
						|| x.Comment.Contains(textValue)
						|| x.Trailer.Contains(textValue)
						|| x.Rate == decValue
						);
				}
				else
				{
					query = query.Where(x =>
						x.BrokerLoadNumber.Contains(textValue)
						|| x.LoadContact.Contains(textValue)
						|| x.PO1.Contains(textValue)
						|| x.PO2.Contains(textValue)
						|| x.Confirmation.Contains(textValue)
						|| x.Class.Contains(textValue)
						|| x.Comment.Contains(textValue)
						|| x.Trailer.Contains(textValue)
						);
				}
			}

			return base.GenerateViewModel(query, viewModel);
		}

		public override void LoadTypeValidation(LoadViewModel viewModel, Load existingLoad)
		{
			if (viewModel.Broker == null || viewModel.Broker.LoadCompanyID.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "Broker Company must be specified.");
			}

			if (viewModel.Pickup == null || viewModel.Pickup.LoadCompanyID.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "Pickup Company must be specified.");
			}
	
			if (viewModel.Delivery == null || viewModel.Delivery.LoadCompanyID.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "Delivery Company must be specified.");
			}
			
			if (string.IsNullOrEmpty(viewModel.Load.DeliveryType))
			{
				ModelState.AddModelError(string.Empty, "Delivery Transfer Type must be specified.");
			}

			if (viewModel.Load.PickupDate.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "Pickup Date must be specified.");
			}

			if (viewModel.Load.EtaDate.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "ETA Date must be specified.");
			}
		}

		public override ActionResult Details(int id)
		{
			Load model = db.Load.Find(id);
			
			if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Modify) == true)
			{
				if (model.InvoiceDate.HasValue == false || this.AdministrativeSettings().AdminEditMode)
				{
					ViewBag.AllowInvoicing = true;
				}
			}

			return base.Details(id);
		}

		public override ActionResult Edit(int id)
		{
			Load model = db.Load.Find(id);

			if (model.InvoiceDate.HasValue == false || this.AdministrativeSettings().AdminEditMode)
			{
				ViewBag.AllowInvoicing = true;
			}

			return base.Edit(id);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult SendInvoice(int id)
		{
			ScreenMessagesViewModel screenMessages = new ScreenMessagesViewModel();

			Load model = db.Load
				.Include(x => x.DailyDispatch)
				.Include(x => x.LoadCompany)
				.Include(x => x.PickupCompany)
				.Include(x => x.DeliveryCompany)
				.Single(x => x.LoadID == id);

			bool allowInvoicing;

			// If never invoiced, allow editing and initialize fields.
			if (model.InvoiceDate.HasValue == false)
			{
				allowInvoicing = true;
				model.InvoiceDate = DateTime.Today;
				model.InvoiceNumber = InvoiceNumber(model);
			}
			// If already invoiced and in Admin mode, allow editing.
			else if (this.AdministrativeSettings().AdminEditMode)
			{
				allowInvoicing = true;
			}
			else
			{
				allowInvoicing = false;
				screenMessages.Add(new ScreenMessagesViewModel.Message
				{
					Text = "This Broker Load has already been invoiced.",
					Key = "AlreadyInvoiced",
					ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ShowOnly
				});
			}

			long nonce = DateTime.Now.Ticks;
			Session[SendInvoiceNonceSessionName] = nonce;
			ViewBag.Nonce = nonce;

			ViewBag.AllowInvoicing = allowInvoicing;
			ViewBag.ScreenMessages = screenMessages;
			return View(model);
		}


		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult SendInvoice(Load screen, ScreenMessagesViewModel screenMessages, long? screenNonce)
		{
			this.ModelState.Remove("ScreenNonce");

			screenMessages = new ScreenMessagesViewModel(screenMessages);

			Load model = db.Load
				.Include(x => x.DailyDispatch)
				.Include(x => x.LoadCompany)
				.Single(x => x.LoadID == screen.LoadID);

			ViewBag.AllowInvoicing = true;

			if (model.DailyDispatchID.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "Broker Load must be assigned to a Dispatch before it can be invoiced.");
			}
			else
			{
				//DispatchDateControl dispatchDateControl = db.DispatchDateControl.Find(model.DailyDispatch.DispatchDate);
				//if (dispatchDateControl.Closed == false)
				//{
				//	ModelState.AddModelError(string.Empty, "Dispatch for this Broker Load must be closed before it can be invoiced.");
				//}
			}
			
			if (screen.InvoiceAmount.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "The Invoice Amount must be entered.");
			}
			else if (screen.InvoiceAmount <= 0)
			{
				ModelState.AddModelError(string.Empty, "The Invoice Amount cannot be zero or negative.");
			}

			if (!ModelState.IsValid)
			{
				long nonce = DateTime.Now.Ticks;
				Session[SendInvoiceNonceSessionName] = nonce;
				ViewBag.Nonce = nonce;

				ViewBag.ScreenMessages = screenMessages;
				return View(screen);
			}

			model.InvoiceAmount = screen.InvoiceAmount;
			model.InvoiceComment = screen.InvoiceComment;
			model.InvoiceDate = screen.InvoiceDate;
			model.InvoiceNumber = screen.InvoiceNumber;
			model.ProNumber = screen.ProNumber;
			model.BLNumber = screen.BLNumber;
			model.InvoiceCount = model.InvoiceCount + 1;
			
			screenMessages.Add(new ScreenMessagesViewModel.Message
			{
				Text = "Broker Load prepared for sending to SAP and printing. Check OK to complete.",
				Key = "PreparedForInvoicing",
				ActionNeeded = ScreenMessagesViewModel.ActionNeeded.NeedAck
			});

			if (screenMessages.AllMessagesFixedOrAcknowledged() == false)
			{
				long nonce = DateTime.Now.Ticks;
				Session[SendInvoiceNonceSessionName] = nonce;
				ViewBag.Nonce = nonce;

				ViewBag.ScreenMessages = screenMessages;
				return View(screen);
			}

			BrokerInvoiceInput brokerInvoiceInput = new BrokerInvoiceInput
			{
				Amount = model.InvoiceAmount.ToString(),
				CustomerNumber = model.LoadCompany.SapEntity,
				HeaderText = string.Empty,
				InvoiceDate = model.InvoiceDate.Value.ToString("yyyyMMdd"),
				InvoiceNumber = model.InvoiceNumber
			};

			if (!string.IsNullOrWhiteSpace(model.BrokerLoadNumber))
			{
				if (model.BrokerLoadNumber.Length > 12)
				{
					brokerInvoiceInput.Reference1 = model.BrokerLoadNumber.Substring(0, 12);
				}
				else
				{
					brokerInvoiceInput.Reference1 = model.BrokerLoadNumber;
				}
			}

			if (model.EtaDate.HasValue)
			{
				brokerInvoiceInput.Reference2 = model.EtaDate.Value.ToShortDateString();
			}

			// Attempt one send of the invoice into SAP.

			long? sessionNonce = Session[SendInvoiceNonceSessionName] as long?;
			if (sessionNonce.HasValue)
			{
				if (screenNonce.HasValue)
				{
					lock (Session.SyncRoot)
					{
						if (screenNonce == sessionNonce)
						{
							Session.Remove(SendInvoiceNonceSessionName);
							if (LibConfigProperties.Settings.SapEngage == true)
							{
								ZFITransDispatchProxy sapProxy = new ZFITransDispatchProxy(LibConfigProperties.Settings.SapEnvironment);
								sapProxy.WriteInvoice(brokerInvoiceInput);
							}
							ChangeLogger.LogChange(this, db.Entry(model));
							db.SaveChanges();
							string message = string.Format("Invoice for {0} ({1}) sent to SAP. {2}",
								model.LoadCompany.Name,
								model.LoadName,
								LibConfigProperties.Settings.SapEngage == true ? "" : "(SapEngage=False)");
							TempData["LastGoodMessage"] = message;
							HLLogging.DebugFormat("{0} {1} {2}", message, GetControllerLoadName, this.User.Identity.Name);
							SetPostRedirectAction(model);
						}
						else
						{
							string message = "Button clicked more than once. Check invoice send count.";
							TempData["LastGoodMessage"] = message;
							HLLogging.DebugFormat("{0} {1} {2} (ScreenNonce != SessionNonce)", message, GetControllerLoadName, this.User.Identity.Name);
						}
					}
				}
				else
				{
					string message = "Button clicked more than once. Check invoice send count.";
					TempData["LastGoodMessage"] = message;
					HLLogging.DebugFormat("{0} {1} {2} (ScreenNonce missing)", message, GetControllerLoadName, this.User.Identity.Name);
				}
			}
			else
			{
				string message = "Button clicked more than once. Check invoice send count.";
				TempData["LastGoodMessage"] = message;
				HLLogging.DebugFormat("{0} {1} {2} (SessionNonce missing)", message, GetControllerLoadName, this.User.Identity.Name);
			}


			return RedirectToAction("Index");
		}

		private void SetPostRedirectAction(Load model)
		{
			NotifySettings notifySettings = new NotifySettings
			{
				Url = this.Url.Action("PrintBrokerLoadInvoice", "Report", new { id = model.LoadID }),
				Type = "print"

			};

			if (!string.IsNullOrWhiteSpace(notifySettings.Type))
			{
				TempData["NotifySettings"] = System.Web.Helpers.Json.Encode(notifySettings);
			}
		}

		private string InvoiceNumber(Load load)
		{
			return string.Format("BH{0}", load.LoadID);
		}
	}
}