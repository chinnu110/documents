﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using System.Data.Objects.SqlClient;
using System.Text;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class CleanupLoadController : LoadController
	{
		public readonly static string TEMPDATA_RETURN_URL = typeof(CleanupLoadController).Name + ".ReturnURL";

		public override string GetControllerLoadType
		{
			get
			{
				return "C";
			}
		}

		public override string GetControllerLoadName
		{
			get
			{
				return "Cleanup Load";
			}
		}
				
		protected override LoadIndexViewModel GenerateViewModel(IQueryable<Load> query, LoadIndexViewModel viewModel)
		{
			// Load viewbag.

			var stores = db.Store.ActiveFilter().AsNoTracking()
				.OrderBy(x => x.CompanyID)
				.ThenBy(x => x.StoreNumber)
				.ToList()
				.Select(x => new SelectListItem
				{
					Text = x.StoreAndCompanyLong,
					Value = x.StoreID.ToString()
				});

			if (viewModel.StoreID.HasValue)
			{
				ViewBag.StoreID = new SelectList(stores, "Value", "Text", viewModel.StoreID.Value.ToString());
			}
			else
			{
				ViewBag.StoreID = new SelectList(stores, "Value", "Text");
			}

			var subsetSortTypes = SortTypes
				.Where(x =>
					x.Value.Contains(Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.PickupLocation)) == false &&
					x.Value.Contains(Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.DeliveryLocation)) == false);

			if (string.IsNullOrEmpty(viewModel.SortingID))
			{
				viewModel.SortingID = subsetSortTypes.ElementAt(0).Value;
			}

			ViewBag.SortingID = new SelectList(subsetSortTypes, "Value", "Text", viewModel.SortingID);

			// Apply filters.
			if (viewModel.DispatchStatus == 4)
			{
				if (viewModel.StoreID.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Store must be specified.");
				}
				if (viewModel.FromDate.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "From Date must be specified.");
				}
				if (ModelState.IsValid)
				{
					query = query.FutureScheduledCleanupLoads(viewModel.StoreID.Value, viewModel.FromDate.Value);
				}
			}
			else
			{
				if (viewModel.StoreID.HasValue)
				{
					query = query.Where(x => x.StoreID == viewModel.StoreID);
				}

				if (viewModel.FromDate.HasValue)
				{
					query = query.Where(x => x.ReadyDate >= viewModel.FromDate.Value);
				}

				if (viewModel.ThruDate.HasValue)
				{
					query = query.Where(x => x.ReadyDate <= viewModel.ThruDate.Value);
				}
			}

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim();

				Int64 intValue = 0;
				decimal decValue = 0m;
				bool isNumber = Decimal.TryParse(textValue, out decValue);
				if (isNumber)
				{
					intValue = Decimal.ToInt64(decValue);
				}

				if (isNumber && intValue > 0)
				{
					query = query.Where(x =>
						(x.LoadID == intValue && x.LoadType == GetControllerLoadType)
						|| x.Comment.Contains(textValue)
						|| x.Store.StoreNumber == intValue
						|| x.Store.City.Contains(textValue)
						|| x.Store.StateCode == textValue
						);
				}
				else
				{
					query = query.Where(x =>
						x.Comment.Contains(textValue)
						|| x.Store.City.Contains(textValue)
						|| x.Store.StateCode == textValue
						);
				}
			}
			
			return base.GenerateViewModel(query, viewModel);
		}


		public override void LoadTypeValidation(LoadViewModel viewModel, Load existingLoad)
		{
			if (viewModel.Load.PickupDate.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "Pickup Date must be specified.");
			}

			if (existingLoad == null)
			{
				if (viewModel.Load.StoreID.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Store must be specified.");
				}
			}
		}

		protected override void LoadViewBag(LoadViewModel viewModel = null)
		{
			ViewBag.StoreCleanupStatus = Extensions.BuildSelectList<StoreCleanupStatus>(viewModel.Load.StoreCleanupStatus);

			ViewBag.DispatchCleanupStatus = Extensions.BuildSelectList<DispatchCleanupStatus>(viewModel.Load.DispatchCleanupStatus);

			ViewBag.PerformedCleanupStatus = Extensions.BuildSelectList<PerformedCleanupStatus>(viewModel.Load.PerformedCleanupStatus);

			if (viewModel.Load.LoadID == 0)
			{
				var StoreList = db.Store.ActiveFilter().AsNoTracking()
					.OrderBy(x => x.CompanyID)
					.ThenBy(x => x.StoreNumber)
					.ToList()
					.Select(x => new
					{
						Value = x.StoreID,
						Text = x.StoreAndCompanyLong
					});

				if (viewModel == null)
				{
					ViewBag.StoreID = new SelectList(StoreList, "Value", "Text");
				}
				else
				{
					ViewBag.StoreID = new SelectList(StoreList, "Value", "Text", viewModel.Load.StoreID);
				}
			}
			else
			{
				viewModel.Load.Store = db.Store.AsNoTracking().Single(x => x.StoreID == viewModel.Load.StoreID);
			}

			base.LoadViewBag(viewModel);
		}

		public override ActionResult Create()
		{
			ActionResult actionResult = base.Create();

			ViewResult viewResult = actionResult as ViewResult;
			if (viewResult != null)
			{
				viewResult.ViewName = "CreateSimple";
			}

			return actionResult;
		}

		public override ActionResult Create(LoadViewModel screen)
		{
			ActionResult actionResult = base.Create(screen);

			ViewResult viewResult = actionResult as ViewResult;
			if (viewResult != null)
			{
				viewResult.ViewName = "CreateSimple";
			}

			return actionResult;
		}

		public override ActionResult Edit(int id)
		{
			ActionResult actionResult = base.Edit(id);

			ViewResult viewResult = actionResult as ViewResult;
			if (viewResult != null)
			{
				Load load = db.Load.Find(id);
				//viewResult.ViewName = (load.Generated) ? "EditGenerated" : "EditSimple";
				viewResult.ViewName = "EditGenerated";
			}

			return actionResult;
		}

		public override ActionResult Edit(LoadViewModel screen, decimal? CarrierTotalCharge = null)
		{
			ActionResult actionResult = base.Edit(screen, CarrierTotalCharge);

			ViewResult viewResult = actionResult as ViewResult;
			if (viewResult != null)
			{
				Load load = db.Load.Find(screen.Load.LoadID);
				//viewResult.ViewName = (load.Generated) ? "EditGenerated" : "EditSimple";
				viewResult.ViewName = "EditGenerated";
			}

			return actionResult;
		}

	}
}