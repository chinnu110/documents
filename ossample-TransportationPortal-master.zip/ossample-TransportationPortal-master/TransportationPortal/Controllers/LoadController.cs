﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using Avatar;
using System.ComponentModel.DataAnnotations;
using HobbyLobby.HLUtil.Logging;

namespace TransportationPortal.Controllers
{
	[HandleApplicationError]
	public class LoadController : Controller
	{
		protected DispatchContext db = new DispatchContext();

		public SelectListItem[] DeliveryTypes = 
		{
			new SelectListItem { Value = DatabaseLists.LOAD_DELIVERY_TYPE_WAREHOUSE, Text = "Warehouse" },
			new SelectListItem { Value = DatabaseLists.LOAD_DELIVERY_TYPE_OKC_DISPATCH, Text = "OKC Dispatch" },
			new SelectListItem { Value = DatabaseLists.LOAD_DELIVERY_TYPE_DALLAS_DISPATCH, Text = "Dallas Dispatch"},
			new SelectListItem { Value = DatabaseLists.LOAD_DELIVERY_TYPE_DIRECT, Text = "Direct Delivery" }
		};

		public SelectListItem[] SortTypes = 
		{
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.CreateDate) + ",D", Text = "Creation - most recent first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.CreateDate) + ",A", Text = "Creation - oldest first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.PickupDate) + ",D", Text = "Pickup - most recent first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.PickupDate) + ",A", Text = "Pickup - oldest first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.ReadyDate) + ",D", Text = "Ready - most recent first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.ReadyDate) + ",A", Text = "Ready - oldest first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.DispatchDate) + ",D", Text = "Dispatch - most recent first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.DispatchDate) + ",A", Text = "Dispatch - oldest first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.EtaDate) + ",D", Text = "ETA - most recent first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.EtaDate) + ",A", Text = "ETA - oldest first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.PickupLocation) + ",A", Text = "Pickup location - A to Z" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.PickupLocation) + ",D", Text = "Pickup location - Z to A" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.DeliveryLocation) + ",A", Text = "Delivery location - A to Z" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.DeliveryLocation) + ",D", Text = "Delivery location - Z to A" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.StoreLocation) + ",A", Text = "Store location - A to Z" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.StoreLocation) + ",D", Text = "Store location - Z to A" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.NoseLoadDeliveryDate) + ",A", Text = "Nose Load Delivery - oldest first" },
			new SelectListItem { Value = Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.NoseLoadDeliveryDate) + ",D", Text = "Nose Load Delivery - newest first" }
		};

		public SelectListItem[] SelectedActionTypes = 
		{
			new SelectListItem { Value = "A", Text = "action for selected..."},
			new SelectListItem { Value = "B", Text = "DELETE SELECTED"}
		};

		public const string TEMPDATA_LASTLOADID = "LastLoadID";

		public virtual string GetControllerLoadType
		{
			get
			{
				throw new Exception("LoadController virtual property 'ControllerLoadType' must be overridden in subclass to specify a valid LoadType value for the method invoked.");
			}
		}

		public virtual string GetControllerLoadName
		{
			get
			{
				throw new Exception("LoadController virtual property 'ControllerLoadName' must be overridden in subclass to specify a valid descriptive name for the method invoked.");
			}
		}

		public virtual Load GetInitialLoadForCreate
		{
			get
			{
				return new Load
				{
					ReadyDate = DateTime.Today
				};
			}
		}

		public virtual void LoadTypeValidation(LoadViewModel load, Load existingLoad)
		{
			return;
		}

		public virtual string FilterSessionName
		{
			get { return this.GetType().Name + ".Filter"; }
		}

		public string ReturnUrlTempDataKeyName
		{
			get { return this.GetType().Name + ".ReturnURL"; }
		}

		public string NonceSessionName
		{
			get { return typeof(LoadController).Name + ".Nonces"; }
		}

		#region Index views

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index(int? id)
		{
			LoadIndexViewModel viewModel = Session[FilterSessionName] as LoadIndexViewModel;
			if (viewModel == null)
			{
				viewModel = new LoadIndexViewModel();
				//viewModel.FromDate = DateTime.Today;
				viewModel.Paging = new PagingViewModel
				{
					Page = 1,
					PageSize = 50,
					LinksBeforeCurrentPage = 4,
					LinksAfterCurrentPage = 4,
				};
			}
			else if (id.HasValue)
			{
				if (viewModel.Paging.Page != id.Value)
				{
					ViewBag.OverrideSavedPosition = "0_0";
				}
				viewModel.Paging.Page = id.Value;
			}

			// Generate the new view model.
			LoadIndexViewModel newViewModel = GenerateViewModel(db.Load.LoadSelectedTypes(new string[] { GetControllerLoadType }), viewModel);

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ActionResult Index(LoadIndexViewModel viewModel)
		{
			// Copy any items needed that were not returned.
			LoadIndexViewModel savedViewModel = Session[FilterSessionName] as LoadIndexViewModel;
			if (savedViewModel != null)
			{
				viewModel.Paging = savedViewModel.Paging;
				viewModel.Paging.Page = 1;
			}

			if (!string.IsNullOrEmpty(viewModel.SelectedActionGoButton))
			{
				if (!string.IsNullOrEmpty(viewModel.ActionSelection))
				{
					switch (viewModel.ActionSelection)
					{
						case "DELETE":
							if (Delete(viewModel.LoadSelect) == true)
							{
								viewModel.LoadSelect = null;
							}
							break;
					}
				}
			}

			// Generate the new view model.
			LoadIndexViewModel newViewModel = GenerateViewModel(db.Load.LoadSelectedTypes(new string[] { GetControllerLoadType }), viewModel);

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		protected virtual LoadIndexViewModel GenerateViewModel(IQueryable<Load> query, LoadIndexViewModel viewModel)
		{
			// load viewbag.

			// Apply filters.

			if (viewModel.DispatchStatus != 0)
			{
				DateTime oldestOpenDispatchDate = db.OpenDispatchDates().OldestDispatchDate();
				if (viewModel.DispatchStatus == 1)
				{
					query = query.Where(x => x.DailyDispatchID.HasValue == false);
				}
				else if (viewModel.DispatchStatus == 2)
				{
					query = query.Where(x => x.DailyDispatchID.HasValue == true && x.DailyDispatch.DispatchDate >= oldestOpenDispatchDate);
				}
				else if (viewModel.DispatchStatus == 3)
				{
					query = query.Where(x => x.DailyDispatchID.HasValue == true && x.DailyDispatch.DispatchDate < oldestOpenDispatchDate);
				}
			}

			
			if (!string.IsNullOrWhiteSpace(viewModel.SortingID))
			{
				string[] sorting = viewModel.SortingID.Split(',');
				if (sorting.Length == 2)
				{
					LoadSortColumn sortColumn;
					if (!Enum.TryParse(sorting[0], out sortColumn))
					{
						sortColumn = LoadSortColumn.CreateDate;
					}
					int sortDirection = sorting[1].ToUpper() == "A" ? 1 : -1;
					query = query.Sort(sortColumn, sortDirection);
				}
			}

			var loadlist = query
				.Include(x => x.LoadCompany)
				.Include(x => x.PickupCompany)
				.Include(x => x.DeliveryCompany)
				.Include(x => x.DailyDispatch)
				.Include(x => x.DailyDispatch.Loads)
				.Include(x => x.Store)
				.Skip((viewModel.Paging.Page - 1) * viewModel.Paging.PageSize)
				.Take(viewModel.Paging.PageSize)
				.ToList();

			viewModel.Loads = loadlist
				.Select(x => new LoadIndexViewModel.Load
				{
					LoadID = x.LoadID,
					LoadName = x.LoadName,
					LoadType = x.LoadType,
					StoreLoadType = x.StoreLoadType,
					DeliveryType = x.DeliveryType,
					ReadyDate = x.ReadyDate,
					PickupDate = x.PickupDate,
					LoadCompanyName = x.LoadCompany != null ? x.LoadCompany.Name : string.Empty,
					LoadContact = x.LoadContact,
					PickupCompanyName = x.PickupCompany != null ? x.PickupCompany.Name : string.Empty,
					PickupContact = x.PickupCompany != null ? x.PickupCompany.Contact : string.Empty,
					DispatchDate = x.DailyDispatch != null ? x.DailyDispatch.DispatchDate : (DateTime?)null,
					DailyDispatchID = x.DailyDispatchID,
					LoadStoreName = x.Store != null ? x.Store.StoreAndCompany : string.Empty,
					LoadStoreCity = x.Store != null ? x.Store.City : string.Empty,
					LoadStoreStateCode = x.Store != null ? x.Store.StateCode : string.Empty,
					City = x.PickupCompany != null ? x.PickupCompany.City : string.Empty,
					StateCode = x.PickupCompany != null ? x.PickupCompany.StateCode : string.Empty,
					PO1 = x.PO1,
					PO2 = x.PO2,
					DeliveryCity = x.DeliveryCompany != null ? x.DeliveryCompany.City : string.Empty,
					DeliveryStateCode = x.DeliveryCompany != null ? x.DeliveryCompany.StateCode : string.Empty
				});

			viewModel.Paging.TotalRecords = query.Count();

			return viewModel;
		}

		#endregion

		#region Find, Create, and Update methods

		public ActionResult Find(int id)
		{
			Load model = db.Load
				.Include(x => x.DailyDispatch)
				.Single(x => x.LoadID == id);

			if (model == null)
			{
				throw new Exception(string.Format("Unable to locate InboundLoad {0}", id));
			}
			
			switch (model.LoadType)
			{
				case DatabaseLists.INBOUND_BROKER_LOAD:
					return RedirectToAction("Edit", "BrokerLoad", new { id = id });
				case DatabaseLists.INBOUND_VENDOR_BACKHAUL:
					return RedirectToAction("Edit", "VendorBackhaul", new { id = id });
				case DatabaseLists.INBOUND_STORE_CLEANUP:
					return RedirectToAction("Edit", "CleanupLoad", new { id = id });
				case DatabaseLists.OUTBOUND_STORE_LOAD:
					return RedirectToAction("Edit", "StoreLoad", new { id = id });
			}

			throw new Exception(string.Format("Invalid Load Type for Load {0}.",id));
		}


		public virtual ActionResult Details(int id)
		{
			TempData[ReturnUrlTempDataKeyName] = HttpContext.Request.UrlReferrer == null ? this.Url.Action("Index") : HttpContext.Request.UrlReferrer.ToString();

			if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Read) == false)
			{
				TempData["LastGoodMessage"] = string.Format("You cannot view this load {0}.", id);
				return RedirectToAction("Index");
			}

			Load model = db.Load
				.Include(x => x.DailyDispatch)
				.Include(x => x.DailyDispatch.Carrier)
				.Include(x => x.DailyDispatch.Driver1)
				.Include(x => x.DailyDispatch.Driver2)
				.Include(x => x.DailyDispatch.Loads)
				.Include(x => x.DailyDispatch.Loads.Select(a => a.Store))
				.Include(x => x.DailyDispatch.Loads.Select(a => a.PickupCompany))
				.Include(x => x.DailyDispatch.Loads.Select(a => a.DeliveryCompany))
				.Include(x => x.Store)
				.Include(x => x.LoadCompany)
				.Include(x => x.PickupCompany)
				.Include(x => x.DeliveryCompany)
				.Single(x => x.LoadID == id);
	
			LoadViewModel viewModel = new LoadViewModel(model);

			return View("Details", viewModel);
		}


		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public virtual ActionResult Create()
		{
			HLLogging.DebugFormat("Load Create GET: {0}", this.User.Identity.Name);

			TempData[ReturnUrlTempDataKeyName] = HttpContext.Request.UrlReferrer == null ? this.Url.Action("Index") : HttpContext.Request.UrlReferrer.ToString();
			TempData.Keep(ReturnUrlTempDataKeyName);

			LoadViewModel viewModel = new LoadViewModel(GetInitialLoadForCreate);

			List<long> nonces = Session[NonceSessionName] as List<long>;
			if (nonces == null)
			{
				nonces = new List<long>();
				Session[NonceSessionName] = nonces;
			}
			long nonce = DateTime.Now.Ticks;
			viewModel.Nonce = nonce;
			nonces.Add(nonce);

			LoadViewBag(viewModel);
			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public virtual ActionResult Create(LoadViewModel screen)
		{
			HLLogging.DebugFormat("Load Create POST: {0}", this.User.Identity.Name);

			TempData.Keep(ReturnUrlTempDataKeyName);

			LoadTypeValidation(screen, null);

			if (!ModelState.IsValid)
			{
				LoadViewBag(screen);
				return View(screen);
			}

			Load model = new Load
			{
				LoadType = GetControllerLoadType,
				Class = screen.Load.Class,
				Comment = screen.Load.Comment,
				Confirmation = screen.Load.Confirmation,
				Cube = screen.Load.Cube,
				DeliveryType = screen.Load.DeliveryType,
				Truckload = screen.Load.Truckload,
				DoubleStack = screen.Load.DoubleStack,
				DownStack = screen.Load.DownStack,
				LinearFeet = screen.Load.LinearFeet,
				Pallets = screen.Load.Pallets,
				Cartons = screen.Load.Cartons,
				Totes = screen.Load.Totes,
				LoadLocks = screen.Load.LoadLocks,
				StoreCleanupStatus = screen.Load.StoreCleanupStatus,
				DispatchCleanupStatus = screen.Load.DispatchCleanupStatus,
				PerformedCleanupStatus = screen.Load.PerformedCleanupStatus,
				BrokerLoadNumber = screen.Load.BrokerLoadNumber,
				ProNumber = screen.Load.ProNumber,
				BLNumber = screen.Load.BLNumber,
				InvoiceAmount = screen.Load.InvoiceAmount,
				InvoiceComment = screen.Load.InvoiceComment,
				Rate = screen.Load.Rate,
				ReadyDate = screen.Load.ReadyDate,
				ScheduledDate = screen.Load.ScheduledDate,
				PickupDate = screen.Load.PickupDate,
				StoreID = screen.Load.StoreID,
				StoreLoadType = screen.Load.StoreLoadType,
				StoreOpening = screen.Load.StoreOpening,
				LoadValue = screen.Load.LoadValue,
				Trailer = screen.Load.Trailer,
				Weight = screen.Load.Weight,
				WorkDate = screen.Load.WorkDate,
				Zone = screen.Load.Zone,
				LoadContact = screen.Load.LoadContact,
				PickupContact = screen.Load.PickupContact,
				PickupAddress = screen.Load.PickupAddress,
				PickupStops = screen.Load.PickupStops,
				DeliveryContact = screen.Load.DeliveryContact,
				DeliveryAddress = screen.Load.DeliveryAddress,
				DeliveryStops = screen.Load.DeliveryStops
			};

			model.PO1 = ReformatString(screen.Load.PO1);
			model.PO2 = ReformatString(screen.Load.PO2);
			
			// Load fields

			if (model.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP && model.Generated == false)
			{
				model.ScheduledDate = screen.Load.PickupDate;
			}

			if (screen.Load.PickupDate.HasValue)
			{
				if (screen.PickupTime.HasValue)
				{
					model.PickupDate = screen.Load.PickupDate.Value.Date + screen.PickupTime.Value.TimeOfDay;
				}
				else
				{
					model.PickupDate = screen.Load.PickupDate.Value.Date;
				}
			}
			else
			{
				model.PickupDate = null;
			}

			if (screen.Load.EtaDate.HasValue)
			{
				if (screen.EtaTime.HasValue)
				{
					model.EtaDate = screen.Load.EtaDate.Value.Date + screen.EtaTime.Value.TimeOfDay;
				}
				else
				{
					model.EtaDate = screen.Load.EtaDate.Value.Date;
				}
			}
			else
			{
				model.EtaDate = null;
			}

			// Move the ID's to the model properties.
			if (screen.Broker != null && screen.Broker.LoadCompanyID.HasValue)
			{
				model.LoadCompanyID = screen.Broker.LoadCompanyID;
			}

			if (screen.Pickup != null && screen.Pickup.LoadCompanyID.HasValue)
			{
				model.PickupCompanyID = screen.Pickup.LoadCompanyID;
			}

			bool rememberDeliveryCompany = false;

			if (model.DeliveryType == DatabaseLists.LOAD_DELIVERY_TYPE_WAREHOUSE)
			{
				if (screen.DeliveryHL != null && screen.DeliveryHL.LoadCompanyID.HasValue)
				{
					model.DeliveryCompanyID = screen.DeliveryHL.LoadCompanyID;
					if (screen.RememberDeliveryHL == true)
					{
						rememberDeliveryCompany = true;
					}
				}
				else
				{
					model.DeliveryCompanyID = null;
				}
			}
			else
			{
				if (screen.Delivery != null && screen.Delivery.LoadCompanyID.HasValue)
				{
					model.DeliveryCompanyID = screen.Delivery.LoadCompanyID;
					if (screen.RememberDelivery == true)
					{
						rememberDeliveryCompany = true;
					}
				}
				else
				{
					model.DeliveryCompanyID = null;
				}
			}

			if (rememberDeliveryCompany == true)
			{
				LoadCompany pickupCompany = db.LoadCompany.Find(model.PickupCompanyID);
				if (pickupCompany != null)
				{
					pickupCompany.DeliveryType = model.DeliveryType;
					pickupCompany.DeliveryCompanyID = model.DeliveryCompanyID;
					ChangeLogger.LogChange(this, db.Entry(pickupCompany));
				}
			}


			db.Load.Add(model);

			// Attempt one create of load.

			List<long> nonces = Session[NonceSessionName] as List<long>;
			if (nonces != null)
			{
				if (screen.Nonce.HasValue)
				{
					lock (Session.SyncRoot)
					{
						if (nonces.Contains(screen.Nonce.Value))
						{
							nonces.Remove(screen.Nonce.Value);
							ChangeLogger.LogChange(this, db.Entry(model));
							db.SaveChanges();
							string message = string.Format("{0} {1} created.", GetControllerLoadName, model.LoadID);
							TempData["LastGoodMessage"] = message;
							HLLogging.DebugFormat("{0} {1} {2}", message, GetControllerLoadName, this.User.Identity.Name);
						}
						else
						{
							string message = string.Format("Screen Nonce not found in Session Nonce table. Load not created.", NonceSessionName);
							TempData["LastGoodMessage"] = message;
							HLLogging.DebugFormat("{0} {1} {2}", message, GetControllerLoadName, this.User.Identity.Name);
						}
					}
				}
				else
				{
					string message = string.Format("Screen Nonce not in posted input data. Load not created.", NonceSessionName);
					TempData["LastGoodMessage"] = message;
					HLLogging.DebugFormat("{0} {1} {2}", message, GetControllerLoadName, this.User.Identity.Name);
				}
			}
			else
			{
				string message = string.Format("Session object for {0} not found. Load not created.", NonceSessionName);
				TempData["LastGoodMessage"] = message;
				HLLogging.DebugFormat("{0} {1} {2}", message, GetControllerLoadName, this.User.Identity.Name);
			}

			TempData[TEMPDATA_LASTLOADID] = model.LoadID.ToString();

			if (string.IsNullOrWhiteSpace((string)TempData.Peek(ReturnUrlTempDataKeyName)))
			{
				return RedirectToAction("Index");
			}
			else
			{
				return Redirect((string)TempData[ReturnUrlTempDataKeyName]);
			}
		}

		public virtual ActionResult Edit(int id)
		{
			TempData[ReturnUrlTempDataKeyName] = HttpContext.Request.UrlReferrer == null ? this.Url.Action("Index") : HttpContext.Request.UrlReferrer.ToString();
			TempData.Keep(ReturnUrlTempDataKeyName);
			
			Load model = db.Load
				.Include(x => x.DailyDispatch)
				.Include(x => x.DailyDispatch.Carrier)
				.Include(x => x.DailyDispatch.Driver1)
				.Include(x => x.DailyDispatch.Driver2)
				.Include(x => x.DailyDispatch.Loads)
				.Include(x => x.DailyDispatch.Loads.Select(a => a.Store))
				.Include(x => x.DailyDispatch.Loads.Select(a => a.PickupCompany))
				.Include(x => x.DailyDispatch.Loads.Select(a => a.DeliveryCompany))
				.Include(x => x.Store)
				.Include(x => x.LoadCompany)
				.Include(x => x.PickupCompany)
				.Include(x => x.DeliveryCompany)
				.Single(x => x.LoadID == id);

			if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Modify) == false
				//|| (model.DailyDispatch != null && model.DailyDispatch.DispatchDate < db.OpenDispatchDates().OldestDispatchDate() && this.AdministrativeSettings().AdminEditMode == false)
				)
			{
				// This load is readonly.
				return RedirectToAction("Details", new { id = id });
			}

			LoadViewModel viewModel = new LoadViewModel(model);

			viewModel.AdminMode = this.AdministrativeSettings().AdminEditMode;

			LoadViewBag(viewModel);

			return View("Edit", viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public virtual ActionResult Edit(LoadViewModel screen, decimal? CarrierTotalCharge = null)
		{
			ModelState.Clear();

			TempData.Keep(ReturnUrlTempDataKeyName);

			Load model = db.Load
				.Include(x => x.DailyDispatch)
				.Single(x => x.LoadID == screen.Load.LoadID);

			LoadTypeValidation(screen, model);

			if (!ModelState.IsValid)
			{
				LoadViewBag(screen);
				return View("Edit", screen);
			}


			UInt64 browserTimestamp = BitConverter.ToUInt64(screen.Load.Timestamp, 0);
			UInt64 databaseTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

			if (browserTimestamp != databaseTimestamp)
			{
				ModelState.Clear();
				ModelState.AddModelError(string.Empty,
					"The record you attempted to edit was modified after you got the original value.\r\n" +
					"The edit operation was canceled and the current values in the database have been displayed.\r\n" +
					"If you still want to edit this record, make the changes again and click the Save button.\r\n" +
					"Otherwise click Back to List.");
				LoadViewModel viewModel = new LoadViewModel(model);
				LoadViewBag(viewModel);
				return View("Edit", viewModel);
			}

			model.Class = screen.Load.Class;
			model.Comment = screen.Load.Comment;
			model.Confirmation = screen.Load.Confirmation;
			model.Cube = screen.Load.Cube;
			model.DeliveryType = screen.Load.DeliveryType;
			model.Truckload = screen.Load.Truckload;
			model.DoubleStack = screen.Load.DoubleStack;
			model.DownStack = screen.Load.DownStack;
			model.LinearFeet = screen.Load.LinearFeet;
			model.Pallets = screen.Load.Pallets;
			model.Pallets = screen.Load.Pallets;
			model.Cartons = screen.Load.Cartons;
			model.Totes = screen.Load.Totes;
			model.LoadLocks = screen.Load.LoadLocks;
			model.StoreCleanupStatus = screen.Load.StoreCleanupStatus;
			model.DispatchCleanupStatus = screen.Load.DispatchCleanupStatus;
			model.PerformedCleanupStatus = screen.Load.PerformedCleanupStatus;
			model.BrokerLoadNumber = screen.Load.BrokerLoadNumber;
			model.ProNumber = screen.Load.ProNumber;
			model.BLNumber = screen.Load.BLNumber;
			model.Rate = screen.Load.Rate;
			model.PickupDate = screen.Load.PickupDate;
			model.StoreLoadType = screen.Load.StoreLoadType;
			model.StoreOpening = screen.Load.StoreOpening;
			model.LoadValue = screen.Load.LoadValue;
			model.Trailer = screen.Load.Trailer;
			model.Weight = screen.Load.Weight;
			model.WorkDate = screen.Load.WorkDate;
			model.Zone = screen.Load.Zone;
			model.LoadContact = screen.Load.LoadContact;
			model.PickupContact = screen.Load.PickupContact;
			model.PickupAddress = screen.Load.PickupAddress;
			model.PickupStops = screen.Load.PickupStops;
			model.DeliveryContact = screen.Load.DeliveryContact;
			model.DeliveryAddress = screen.Load.DeliveryAddress;
			model.DeliveryStops = screen.Load.DeliveryStops;

			model.PO1 = ReformatString(screen.Load.PO1);
			model.PO2 = ReformatString(screen.Load.PO2);

			if (model.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP || model.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
			{
				// Do not allow store  to be modified after creation for store loads and store cleanups. 
			}
			else
			{
				model.StoreID = screen.Load.StoreID;
			}

			if (model.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL || model.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
			{
				model.ReadyDate = screen.Load.ReadyDate;
			}

			if (model.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP && model.Generated == false)
			{
				model.ScheduledDate = screen.Load.PickupDate;
			}

			if (model.LoadType == DatabaseLists.INBOUND_BROKER_LOAD)
			{
				model.InvoiceComment = screen.Load.InvoiceComment;

				if (model.InvoiceDate.HasValue == false || this.AdministrativeSettings().AdminEditMode == true)
				{
					model.InvoiceAmount = screen.Load.InvoiceAmount;
				}

				if (this.AdministrativeSettings().AdminEditMode == true)
				{
					model.InvoiceDate = screen.Load.InvoiceDate;
				}
			}

			if (model.LoadType == DatabaseLists.INBOUND_BROKER_LOAD)
			{
				if (!model.SourceLoadID.HasValue)
				{
					var loadCopies = db.Load.Where(x => x.SourceLoadID == model.LoadID);
					foreach (Load loadCopy in loadCopies)
					{
						loadCopy.PickupDate = model.PickupDate;
						loadCopy.EtaDate = model.EtaDate;
					}
				}
			}

			if (model.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
			{
				if (!model.SourceLoadID.HasValue)
				{
					var loadCopies = db.Load.Where(x => x.SourceLoadID == model.LoadID);
					foreach (Load loadCopy in loadCopies)
					{
						loadCopy.PickupDate = model.PickupDate;
					}
				}
			}

			if (CarrierTotalCharge.HasValue)
			{
				model.DailyDispatch.CarrierTotalCharge = CarrierTotalCharge;
				model.DailyDispatch.CarrierTotalChargeChanged = DateTime.Now;
			}
			
			// Load fields
			if (screen.Load.PickupDate.HasValue)
			{
				if (screen.PickupTime.HasValue)
				{
					model.PickupDate = screen.Load.PickupDate.Value.Date + screen.PickupTime.Value.TimeOfDay;
				}
				else
				{
					model.PickupDate = screen.Load.PickupDate.Value.Date;
				}
			}
			else
			{
				model.PickupDate = null;
			}

			if (screen.Load.EtaDate.HasValue)
			{
				if (screen.EtaTime.HasValue)
				{
					model.EtaDate = screen.Load.EtaDate.Value.Date + screen.EtaTime.Value.TimeOfDay;
				}
				else
				{
					model.EtaDate = screen.Load.EtaDate.Value.Date;
				}
			}
			else
			{
				model.EtaDate = null;
			}
						
			// Move the ID's to the model properties.
			if (screen.Broker != null && screen.Broker.LoadCompanyID.HasValue)
			{
				model.LoadCompanyID = screen.Broker.LoadCompanyID;
			}
			else
			{
				model.LoadCompanyID = null;
			}

			if (screen.Pickup != null && screen.Pickup.LoadCompanyID.HasValue)
			{
				model.PickupCompanyID = screen.Pickup.LoadCompanyID;
			}
			else
			{
				model.PickupCompanyID = null;
			}

			bool rememberDeliveryCompany = false;

			if (model.DeliveryType == DatabaseLists.LOAD_DELIVERY_TYPE_WAREHOUSE)
			{
				if (screen.DeliveryHL != null && screen.DeliveryHL.LoadCompanyID.HasValue)
				{
					model.DeliveryCompanyID = screen.DeliveryHL.LoadCompanyID;
					if (screen.RememberDeliveryHL == true)
					{
						rememberDeliveryCompany = true;
					}
				}
				else
				{
					model.DeliveryCompanyID = null;
				}
			}
			else
			{
				if (screen.Delivery != null && screen.Delivery.LoadCompanyID.HasValue)
				{
					model.DeliveryCompanyID = screen.Delivery.LoadCompanyID;
					if (screen.RememberDelivery == true)
					{
						rememberDeliveryCompany = true;
					}
				}
				else
				{
					model.DeliveryCompanyID = null;
				}
			}

			if (rememberDeliveryCompany == true)
			{
				LoadCompany pickupCompany = db.LoadCompany.Find(model.PickupCompanyID);
				if (pickupCompany != null)
				{
					pickupCompany.DeliveryType = model.DeliveryType;
					pickupCompany.DeliveryCompanyID = model.DeliveryCompanyID;
					ChangeLogger.LogChange(this, db.Entry(pickupCompany));
				}
			}
			
			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("{0} {1} updated.", GetControllerLoadName, model.LoadID);

			TempData[TEMPDATA_LASTLOADID] = model.LoadID.ToString();

			if (model.DailyDispatchID.HasValue)
			{
				TempData[DailyDispatchController.TEMPDATA_LASTDAILYDISPATCHID] = model.DailyDispatchID.ToString();
			}

			if (string.IsNullOrWhiteSpace((string)TempData.Peek(ReturnUrlTempDataKeyName)))
			{
				return RedirectToAction("Index");
			}
			else
			{
				return Redirect((string)TempData[ReturnUrlTempDataKeyName]);
			}
		}
		
		public ActionResult Delete(int id)
		{
			if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Full) == false)
			{
				TempData["LastGoodMessage"] = string.Format("You cannot delete load records.");
				return RedirectToAction("Index");
			}

			Load model = db.Load
				.Include(x => x.LoadCopies)
				.Single(x => x.LoadID == id);

			if (model.InvoiceDate.HasValue)
			{
				ModelState.AddModelError(string.Empty, "This Load has been invoiced and cannot be deleted.");
			}

			if (!ModelState.IsValid)
			{
				return Edit(id);
			}
			
			if (model.LoadCopies.Count() > 0)
			{
				List<Load> copiesToRemove = model.LoadCopies.ToList();
				foreach (Load copy in copiesToRemove)
				{
					model.LoadCopies.Remove(copy);
					db.Load.Remove(copy);
					ChangeLogger.LogChange(this, db.Entry(copy));
				}
			}

			db.Load.Remove(model);
			ChangeLogger.LogChange(this, db.Entry(model));

			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("{0} {1} deleted.", GetControllerLoadName, model.LoadID);
			return RedirectToAction("Index");
		}

		private bool Delete(IEnumerable<int> LoadIDList)
		{
			if (LoadIDList == null || LoadIDList.Count() == 0)
			{
				return true;
			}

			if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Full) == false)
			{
				TempData["LastGoodMessage"] = string.Format("You cannot delete load records.");
				return false;
			}

			foreach (int id in LoadIDList)
			{
				Load model = db.Load.Find(id);

				if (model.DailyDispatchID.HasValue)
				{
					ModelState.AddModelError(string.Empty, string.Format("Load {0} cannot be deleted because it is attached to a Dispatch.",model.LoadName));
				}

				if (model.InvoiceDate.HasValue)
				{
					ModelState.AddModelError(string.Empty, string.Format("Load {0} cannot be deleted because it has been invoiced.", model.LoadName));
				}

				if (ModelState.IsValid)
				{
					db.Load.Remove(model);
					ChangeLogger.LogChange(this, db.Entry(model));
				}
			}

			if (ModelState.IsValid)
			{
				db.SaveChanges();
				TempData["LastGoodMessage"] = "Selected loads deleted.";
				return true;
			}

			return false;
		}


		protected virtual void LoadViewBag(LoadViewModel viewModel = null)
		{

			return;
		}

		private string ReformatString(string input)
		{
			if (string.IsNullOrWhiteSpace(input))
			{
				return null;
			}

			var parsedString = input
				.Replace("\r\n", "\n")
				.Split(new char[] { '\n', ',', '/' }, StringSplitOptions.RemoveEmptyEntries)
				.Select(x => x.Trim())
				.Where(x => x.Length > 0);

			string withNewlines = string.Join(Environment.NewLine, parsedString);

			return withNewlines;
		}


		#endregion

		#region Ajax methods

		[HttpPost]
		public ActionResult SelectCompany(LoadSelectCompanyViewModel model)
		{
			if (model == null)
			{
				model = new LoadSelectCompanyViewModel();
			}

			if (!ModelState.IsValid)
			{
				model.Companies = Enumerable.Empty<LoadCompany>();
			}
			else
			{
				var companies = db.LoadCompany.AsNoTracking().AsQueryable();

				if (model.IsBroker)
				{
					companies = companies.Where(x => x.IsBroker == true);
				}
				else if (model.IsVendor)
				{
					companies = companies.Where(x => x.IsVendor == true);
				}
				else if (model.IsPickupAddress)
				{
					companies = companies.Where(x => x.IsPickupAddress == true);
				}
				else if (model.IsDeliveryAddress)
				{
					companies = companies.Where(x => x.IsDeliveryAddress == true);
				}

				if (!string.IsNullOrWhiteSpace(model.Search))
				{
					string textValue = model.Search.Trim();
					companies = companies.Where(x =>
						x.Name.Contains(textValue)
						|| x.Address1.Contains(textValue)
						|| x.Address2.Contains(textValue)
						|| x.City.Contains(textValue)
						|| x.StateCode.Contains(textValue)
						|| x.Zip.Contains(textValue)
						|| x.CountryCode.Contains(textValue)
						|| x.Contact.Contains(textValue)
						|| x.Email.Contains(textValue)
						);
				}

				model.Companies = companies.Take(100);

				if (string.IsNullOrEmpty(model.CloseDialogAction))
				{
					model.CloseDialogAction = string.Format("closeDialog('{0}')", model.DialogID);
				}
			}

			return PartialView("_SelectLoadCompany", model);
		}


		public ActionResult SelectedCompany(int id, string BindPrefix)
		{
			LoadCompany model = db.LoadCompany
				.Single(x => x.LoadCompanyID == id);

			LoadCompanyViewModel viewModel = new LoadCompanyViewModel(model);

			ViewData.TemplateInfo.HtmlFieldPrefix = BindPrefix;

			return PartialView("_SelectedLoadCompany", viewModel);
		}

		[ChildActionOnly]
		public PartialViewResult GetHLDeliveryCompanies(LoadCompanyViewModel DeliveryHL, string BindPrefix)
		{
			LoadCompanyHLViewModel viewModel = new LoadCompanyHLViewModel();
			if (DeliveryHL != null)
			{
				viewModel.LoadCompanyID = DeliveryHL.LoadCompanyID;
			}

			viewModel.Companies = db.LoadCompany
				.Where(x => x.IsCompanyAddress == true && x.IsDeliveryAddress == true)
				.OrderBy(x => x.Name)
				.ToList()
				.Select(x => new LoadCompanyViewModel(x));

			ViewData.TemplateInfo.HtmlFieldPrefix = BindPrefix;

			return PartialView("_HLCompanyList", viewModel);
		}

		#endregion

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}
