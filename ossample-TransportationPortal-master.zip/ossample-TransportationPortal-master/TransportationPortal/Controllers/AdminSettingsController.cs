﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Avatar;
using TransportationPortal.ViewModels;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using System.Data.Objects.SqlClient;
using System.Data.SqlClient;
using HobbyLobby.HLUtil.Logging;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class AdminSettingsController : Controller
	{
		public static string SessionDataName
		{
			get { return "AdminSettingsController.SessionData"; }
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult Edit()
		{
			AdminSettingsViewModel viewModel = Session[SessionDataName] as AdminSettingsViewModel;
			
			if (viewModel == null)
			{
				viewModel = new AdminSettingsViewModel 
				{
					AdminEditMode = false
				};
			}

			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult Edit(AdminSettingsViewModel viewModel)
		{
			// Save the view model
			Session[SessionDataName] = viewModel;

			HLLogging.InfoFormat("Administrative Mode for {0} is now {1}.", this.User.Identity.Name, (viewModel.AdminEditMode ? "ON" : "OFF"));

			return RedirectToRoute(new { controller = "Home", action = "Index" });
		}
	}
}