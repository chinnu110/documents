﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.Repositories;
using TransportationPortal.ViewModels;
using Avatar;

namespace TransportationPortal.Controllers
{
	[HandleApplicationError]
	public class CarrierController : Controller
	{
        private const string TEMPDATA_LASTGOODMESSAGE = "LastGoodMessage";

        private DispatchContext db = new DispatchContext();

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index()
		{
			var model = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode).
                AsNoTracking()
                .OrderBy(x => x.Name);

			return View(model);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Details(int id)
		{
			Carrier model = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode).
                AsNoTracking()
                .SingleOrDefault(x => x.CarrierID == id);

            if (model == null)
            {
                throw new ApplicationException("Carrier ID does not exist.");
            }

            return View("Details", model);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Create()
		{
			CarrierUpdateViewModel viewModel = new CarrierUpdateViewModel
			{
				Carrier = new Carrier()
			};

			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Create(CarrierUpdateViewModel screen)
		{
			Carrier model = new Carrier();
			model.StoreCarrierInfo = new List<StoreCarrierInfo>();

			if (db.Carrier.Any(x => x.Name.ToUpper() == screen.Carrier.Name.ToUpper() && !x.DeleteDate.HasValue))
			{
				ModelState.AddModelError(string.Empty, string.Format("Carrier '{0}' already exists.", screen.Carrier.Name));
			}

			if (!ModelState.IsValid)
			{
				return View(screen);
			}

			model.ContactName = screen.Carrier.ContactName;
			model.DispatchEmailAddress = screen.Carrier.DispatchEmailAddress;
			model.DispatchEmailName = screen.Carrier.DispatchEmailName;
			model.Fax = screen.Carrier.Fax;
			model.Name = screen.Carrier.Name;
			model.Notes = screen.Carrier.Notes;
			model.Phone = screen.Carrier.Phone;
			model.StopCharge1 = screen.Carrier.StopCharge1;
			model.StopCharge2 = screen.Carrier.StopCharge2;

			db.Carrier.Add(model);
			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Carrier {0} created.", model.Name);
			return RedirectToAction("Index");
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult Edit(int id)
		{
			Carrier model = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .Single(x => x.CarrierID == id);

			CarrierUpdateViewModel viewModel = new CarrierUpdateViewModel
			{
				Carrier = model
			};

            return View("Edit", viewModel);
        }

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult Edit(CarrierUpdateViewModel screen)
		{
			Carrier model = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .Include(x => x.StoreCarrierInfo)
				.SingleOrDefault(x => x.CarrierID == screen.Carrier.CarrierID);

            if (model == null)
            {
                throw new ApplicationException("Carrier ID does not exist.");
            }

            UInt64 screenTimestamp = BitConverter.ToUInt64(screen.Carrier.Timestamp, 0);
			UInt64 modelTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

			if (screenTimestamp != modelTimestamp)
			{
				ModelState.Clear();
				ModelState.AddModelError(string.Empty,
					"The record you attempted to edit was modified after you got the original value.\r\n" +
					"The edit operation was canceled and the current values in the database have been displayed.\r\n" +
					"If you still want to edit this record, make the changes again and click the Save button.\r\n" +
					"Otherwise click Back to List.");
				return View(model);
			}

			if (db.Carrier.Any(x => x.Name.ToUpper() == screen.Carrier.Name.ToUpper() && x.CarrierID != screen.Carrier.CarrierID && !x.DeleteDate.HasValue))
			{
				ModelState.AddModelError(string.Empty, string.Format("Carrier '{0}' already exists.", screen.Carrier.Name));
			}

			if (!ModelState.IsValid)
			{
				return View(screen);
			}

			model.ContactName = screen.Carrier.ContactName;
			model.DispatchEmailAddress = screen.Carrier.DispatchEmailAddress;
			model.DispatchEmailName = screen.Carrier.DispatchEmailName;
			model.Fax = screen.Carrier.Fax;
			model.Name = screen.Carrier.Name;
			model.Notes = screen.Carrier.Notes;
			model.Phone = screen.Carrier.Phone;
			model.StopCharge1 = screen.Carrier.StopCharge1;
			model.StopCharge2 = screen.Carrier.StopCharge2;

			ChangeLogger.LogChange(this, db.Entry(model));

			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Carrier {0} updated.", model.Name);
			return RedirectToAction("Index");
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Delete(int id)
		{
			Carrier model = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .SingleOrDefault(x => x.CarrierID == id);

            if (model == null)
            {
                throw new ApplicationException("Carrier ID does not exist.");
            }

            if (model.DeleteDate.HasValue)
            {
                ModelState.AddModelError("", "This Carrier has already been deleted from active use and is being retained for reporting purposes. No further action is allowed.");
                return Edit(id);
            }


            // Check if carrier is referenced in the Outbound Schedule. Cannot perform a delete if true.

            var schedulesWithCarrier = db.OutboundRoute
                .Where(x => x.CarrierID == id)
                .Include(x => x.WeekDay);

			if (schedulesWithCarrier != null)
			{
                var schedulesByWeekAndDay = schedulesWithCarrier.ToLookup(x => new { x.WeekNumber, x.WeekDay.LongName,  });

				foreach (var schedule in schedulesByWeekAndDay)
				{
					ModelState.AddModelError("", string.Format("Carrier is referenced by {2} Outbound Schedule records for Week {0} on {1}.",
						schedule.Key.WeekNumber, schedule.Key.LongName, schedule.Count()));
				}
			}

			if (!ModelState.IsValid)
			{
				return Edit(id);
			}
            
            // If carrier is still attached to records, then the carrier must be logically deleted, which retains the carrier in a hidden state.
            
            try
            {
                var storeCarrierRateRecords = db.StoreCarrierInfo.Where(x => x.CarrierID == id);
                foreach (var record in storeCarrierRateRecords)
                {
                    db.StoreCarrierInfo.Remove(record);
                }
                
                bool historicalDispatchesExist = db.DailyDispatch.Any(x => x.CarrierID == id);
                if (historicalDispatchesExist)
                {
                    ChangeLogger.LogLogicalDelete(this, db.Entry(model), string.Format("Carrier {0} [ID={1}] marked as deleted.", model.Name, model.CarrierID));
                }
                else
                {
                    db.Carrier.Remove(model);
                    ChangeLogger.LogChange(this, db.Entry(model));
                }

                TempData[TEMPDATA_LASTGOODMESSAGE] = string.Format("Carrier {0} deleted.", model.Name);

                db.SaveChanges();
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException ex)
            {
                string recordIdent = string.Format("Carrier {0} [ID={1}]", model.Name, model.CarrierID);
                string message = string.Format("Error attempting to delete: {0}. Foreign Key relationships may be preventing deletion.", recordIdent);
                throw new Exception(message, ex);
            }

			return RedirectToAction("Index");
		}

		#region Ajax Methods for displaying carrier info popups

		public ActionResult GetCarrierInfo(int id)
		{
			Carrier carrier = db.Carrier.AsNoTracking()
				.Single(x => x.CarrierID == id);

			CarrierViewModel viewModel = new CarrierViewModel(carrier);

			return PartialView("_CarrierDetailsPopup", viewModel);
		}

		public JsonResult GetCarrierData(int id)
		{
			Carrier carrier = db.Carrier.AsNoTracking()
				.Single(x => x.CarrierID == id);

			return Json(carrier, JsonRequestBehavior.AllowGet);
		}

		#endregion

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}