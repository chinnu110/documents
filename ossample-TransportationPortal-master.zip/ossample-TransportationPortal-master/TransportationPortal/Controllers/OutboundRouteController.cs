﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using Avatar;
using System.Text;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class OutboundRouteController : Controller
	{
		private DispatchContext db = new DispatchContext();

		private static object[] WeekList = new[]
		{
			new { Number = 1, Name = "Week 1"},
			new { Number = 2, Name = "Week 2"},
		};

		private string FilterSessionName
		{
			get { return this.GetType().Name + ".Filter"; }
		}

		#region Index views

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ViewResult Index()
		{
			OutboundRouteViewModel viewModel = Session[FilterSessionName] as OutboundRouteViewModel;
			if (viewModel == null)
			{
				viewModel = new OutboundRouteViewModel();
				switch (DateTime.Today.DayOfWeek)
				{
					case DayOfWeek.Sunday:
						viewModel.Week1Sunday = true;
						viewModel.Week2Sunday = true;
						break;
					case DayOfWeek.Monday:
						viewModel.Week1Monday = true;
						viewModel.Week2Monday = true;
						break;
					case DayOfWeek.Tuesday:
						viewModel.Week1Tuesday = true;
						viewModel.Week2Tuesday = true;
						break;
					case DayOfWeek.Wednesday:
						viewModel.Week1Wednesday = true;
						viewModel.Week2Wednesday = true;
						break;
					case DayOfWeek.Thursday:
						viewModel.Week1Thursday = true;
						viewModel.Week2Thursday = true;
						break;
					case DayOfWeek.Friday:
						viewModel.Week1Friday = true;
						viewModel.Week2Friday = true;
						break;
					case DayOfWeek.Saturday:
						viewModel.Week1Saturday = true;
						viewModel.Week2Saturday = true;
						break;
				}
			}

			OutboundRouteViewModel newViewModel = GenerateViewModel(viewModel);
			
			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ActionResult Index(OutboundRouteViewModel viewModel)
		{
			if (!string.IsNullOrEmpty(viewModel.CreateSubmitButton))
			{
				viewModel.CreateSubmitButton = null;
				Session[FilterSessionName] = viewModel;
				return RedirectToAction("Create");
			}

			OutboundRouteViewModel newViewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}


		private OutboundRouteViewModel GenerateViewModel(OutboundRouteViewModel viewModel)
		{
			List<int> week1days = new List<int>();
			List<int> week2days = new List<int>();

			if (viewModel.Week1Sunday)
				week1days.Add(1);
			if (viewModel.Week1Monday)
				week1days.Add(2);
			if (viewModel.Week1Tuesday)
				week1days.Add(3);
			if (viewModel.Week1Wednesday)
				week1days.Add(4);
			if (viewModel.Week1Thursday)
				week1days.Add(5);
			if (viewModel.Week1Friday)
				week1days.Add(6);
			if (viewModel.Week1Saturday)
				week1days.Add(7);

			if (viewModel.Week2Sunday)
				week2days.Add(1);
			if (viewModel.Week2Monday)
				week2days.Add(2);
			if (viewModel.Week2Tuesday)
				week2days.Add(3);
			if (viewModel.Week2Wednesday)
				week2days.Add(4);
			if (viewModel.Week2Thursday)
				week2days.Add(5);
			if (viewModel.Week2Friday)
				week2days.Add(6);
			if (viewModel.Week2Saturday)
				week2days.Add(7);

			var list = db.OutboundRoute
				.AsNoTracking()
				.Include(x => x.Load1Store)
				.Include(x => x.Load2Store)
				.Include(x => x.Driver1)
				.Include(x => x.Driver2)
				.Include(x => x.Carrier)
				.Include(x => x.WeekDay)
				.Include(x => x.InboundWeekDay)
				.Include(x => x.Load1DeliveryDay)
				.Include(x => x.Load2DeliveryDay)
				.Include(x => x.Load3DeliveryDay);

			if (week1days.Count > 0 && week2days.Count > 0)
			{
				list = list.Where(x => (x.WeekNumber == 1 && week1days.Contains(x.WeekDayID)) || (x.WeekNumber == 2 && week2days.Contains(x.WeekDayID)));
			}
			else if (week1days.Count > 0)
			{
				list = list.Where(x => (x.WeekNumber == 1 && week1days.Contains(x.WeekDayID)));
			}
			else if (week2days.Count > 0)
			{
				list = list.Where(x => (x.WeekNumber == 2 && week2days.Contains(x.WeekDayID)));
			}

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim();
				int intValue = 0;
				bool isNumber = Int32.TryParse(textValue, out intValue);

				if (isNumber && intValue > 0)
				{
					list = list.Where(x =>
						x.Carrier.Name.Contains(textValue) 
						|| x.Driver1.FirstName.Contains(textValue)
						|| x.Driver1.LastName.Contains(textValue)
						|| x.Driver2.FirstName.Contains(textValue)
						|| x.Driver2.LastName.Contains(textValue)
						|| x.City.ToUpper().Contains(textValue) 
						|| x.StateCode == textValue 
						|| x.Comment.Contains(textValue) 
						|| x.TractorNumber == textValue 
						|| x.Load1Store.StoreNumber == intValue
						|| x.Load2Store.StoreNumber == intValue
						);
				}
				else
				{
					list = list.Where(x =>
						x.Carrier.Name.Contains(textValue)
						|| x.Driver1.FirstName.Contains(textValue)
						|| x.Driver1.LastName.Contains(textValue)
						|| x.Driver2.FirstName.Contains(textValue)
						|| x.Driver2.LastName.Contains(textValue)
						|| x.City.ToUpper().Contains(textValue)
						|| x.StateCode == textValue
						|| x.Comment.Contains(textValue)
						);
				}
			}

			viewModel.OutboundRoutes = list
				.OrderBy(x => x.Load1Store.StoreNumber)
				.ThenBy(x => x.Load1Store.CompanyID)
				.ThenBy(x => x.WeekNumber)
				.ThenBy(x => x.WeekDayID)
				.ToList()
				.Select(x => new OutboundRouteViewModel.Route(x));

			return viewModel;
		}

		#endregion

		#region Browse, Create, Edit

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ViewResult Details(int id)
		{
			OutboundRoute model = db.OutboundRoute
				.Include(x => x.Carrier)
				.Include(x => x.Driver1)
				.Include(x => x.Driver2)
				.Include(x => x.WeekDay)
				.Include(x => x.Load1Store)
				.Include(x => x.Load2Store)
				.Single(x => x.OutboundRouteID == id);
			
			return View(model);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)] 
		public ActionResult Create()
		{
			OutboundRoute model = new OutboundRoute();

			OutboundRouteViewModel viewModel = Session[FilterSessionName] as OutboundRouteViewModel;
			if (viewModel != null)
			{
				if (viewModel.Week1Sunday)
				{
					model.WeekNumber = 1;
					model.WeekDayID = 1;
				}
				else if (viewModel.Week1Monday)
				{
					model.WeekNumber = 1;
					model.WeekDayID = 2;
				}
				else if (viewModel.Week1Tuesday)
				{
					model.WeekNumber = 1;
					model.WeekDayID = 3;
				}
				else if (viewModel.Week1Wednesday)
				{
					model.WeekNumber = 1;
					model.WeekDayID = 4;
				}
				else if (viewModel.Week1Thursday)
				{
					model.WeekNumber = 1;
					model.WeekDayID = 5;
				}
				else if (viewModel.Week1Friday)
				{
					model.WeekNumber = 1;
					model.WeekDayID = 6;
				}
				else if (viewModel.Week1Saturday)
				{
					model.WeekNumber = 1;
					model.WeekDayID = 7;
				}
				else if (viewModel.Week2Sunday)
				{
					model.WeekNumber = 2;
					model.WeekDayID = 1;
				}
				else if (viewModel.Week2Monday)
				{
					model.WeekNumber = 2;
					model.WeekDayID = 2;
				}
				else if (viewModel.Week2Tuesday)
				{
					model.WeekNumber = 2;
					model.WeekDayID = 3;
				}
				else if (viewModel.Week2Wednesday)
				{
					model.WeekNumber = 2;
					model.WeekDayID = 4;
				}
				else if (viewModel.Week2Thursday)
				{
					model.WeekNumber = 2;
					model.WeekDayID = 5;
				}
				else if (viewModel.Week2Friday)
				{
					model.WeekNumber = 2;
					model.WeekDayID = 6;
				}
				else if (viewModel.Week2Saturday)
				{
					model.WeekNumber = 2;
					model.WeekDayID = 7;
				}
			}
			else
			{
				model.WeekDayID = (int)DateTime.Today.DayOfWeek + 1;
			}

			LoadViewBag(model);
			
			return View(model);
		}


		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)] 
		public ActionResult Create(OutboundRoute screen)
		{
			if (screen.CarrierID.HasValue && (screen.Driver1ID.HasValue || screen.Driver2ID.HasValue))
			{
				ModelState.AddModelError(string.Empty, "Specify a Carrier or Drivers, but not both.");
			}

			if (screen.Load1StoreID.HasValue)
			{
				if (string.IsNullOrEmpty(screen.Load1Type) == true)
				{
					ModelState.AddModelError(string.Empty, "Load 1 Type must be specified.");
				}
				if (screen.Load1DeliveryDayID.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 1 Delivery Day must be specified.");
				}
				if (screen.Load1DeliveryTime.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 1 Delivery Time must be specified.");
				}
			}

			if (screen.Load2StoreID.HasValue)
			{
				if (string.IsNullOrEmpty(screen.Load2Type) == true)
				{
					ModelState.AddModelError(string.Empty, "Load 2 Type must be specified.");
				}
				if (screen.Load2DeliveryDayID.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 2 Delivery Day must be specified.");
				}
				if (screen.Load2DeliveryTime.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 2 Delivery Time must be specified.");
				}
			}

			if (screen.Load3StoreID.HasValue)
			{
				if (string.IsNullOrEmpty(screen.Load3Type) == true)
				{
					ModelState.AddModelError(string.Empty, "Load 3 Type must be specified.");
				}
				if (screen.Load3DeliveryDayID.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 3 Delivery Day must be specified.");
				}
				if (screen.Load3DeliveryTime.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 3 Delivery Time must be specified.");
				}
			}

			if (!ModelState.IsValid)
			{
				LoadViewBag(screen);
				return View(screen);
			}

			db.OutboundRoute.Add(screen);
			ChangeLogger.LogChange(this, db.Entry(screen));
			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Outbound Route Template for Week {0} Day {1} created.", screen.WeekNumber, screen.WeekDayID);
			return RedirectToAction("Index");
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)] 
		public ActionResult Edit(int id)
		{
			OutboundRoute model = db.OutboundRoute
				.Include(x => x.WeekDay)
				.Single(x => x.OutboundRouteID == id);

			LoadViewBag(model);

			return View(model);
		}


		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult Edit(OutboundRoute screen, 
			bool? ChangeDriver1,
			bool? ChangeDriver2,
			bool? ChangeCarrier,
			bool? ChangeTractor,
			bool? ChangeComment)
		{
			OutboundRoute model = db.OutboundRoute.Find(screen.OutboundRouteID);

			UInt64 screenTimestamp = BitConverter.ToUInt64(screen.Timestamp, 0);
			UInt64 modelTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

			if (screenTimestamp != modelTimestamp)
			{
				ModelState.Clear();
				ModelState.AddModelError(string.Empty,
					"The record you attempted to edit was modified after you got the original value.\r\n" +
					"The edit operation was canceled and the current values in the database have been displayed.\r\n" +
					"If you still want to edit this record, make the changes again and click the Save button.\r\n" +
					"Otherwise click Back to List.");
				LoadViewBag(screen);
				return View(screen);
			}

			if (screen.CarrierID.HasValue && (screen.Driver1ID.HasValue || screen.Driver2ID.HasValue))
			{
				ModelState.AddModelError(string.Empty, "Specify a Carrier or Drivers, but not both.");
			}
			
			if (screen.Load1StoreID.HasValue)
			{
				if (string.IsNullOrEmpty(screen.Load1Type) == true)
				{
					ModelState.AddModelError(string.Empty, "Load 1 Type must be specified.");
				}
				if (screen.Load1DeliveryDayID.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 1 Delivery Day must be specified.");
				}
				if (screen.Load1DeliveryTime.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 1 Delivery Time must be specified.");
				}
			}

			if (screen.Load2StoreID.HasValue)
			{
				if (string.IsNullOrEmpty(screen.Load2Type) == true)
				{
					ModelState.AddModelError(string.Empty, "Load 2 Type must be specified.");
				}
				if (screen.Load2DeliveryDayID.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 2 Delivery Day must be specified.");
				}
				if (screen.Load2DeliveryTime.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 2 Delivery Time must be specified.");
				}
			}

			if (screen.Load3StoreID.HasValue)
			{
				if (string.IsNullOrEmpty(screen.Load3Type) == true)
				{
					ModelState.AddModelError(string.Empty, "Load 3 Type must be specified.");
				}
				if (screen.Load3DeliveryDayID.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 3 Delivery Day must be specified.");
				}
				if (screen.Load3DeliveryTime.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Load 3 Delivery Time must be specified.");
				}
			}

			if (!ModelState.IsValid)
			{
				LoadViewBag(screen);
				return View(screen);
			}

            model.WeekDayID = screen.WeekDayID;

			model.DispatchGroup = screen.DispatchGroup;
			model.InboundWeekDayID = screen.InboundWeekDayID;

			model.CarrierID = screen.CarrierID;
			model.CarrierRate = screen.CarrierRate;
			model.CarrierStopCharge1 = screen.CarrierStopCharge1;
			model.CarrierStopCharge2 = screen.CarrierStopCharge2;
			model.CarrierExtraCharge = screen.CarrierExtraCharge;
			model.CarrierTotalChargeOverride = screen.CarrierTotalChargeOverride;
			model.City = screen.City;
			model.Comment = screen.Comment;
			model.DepartureTime = screen.DepartureTime;
			model.Driver1ID = screen.Driver1ID;
			model.Driver2ID = screen.Driver2ID;
			model.Hours = screen.Hours;
			model.Miles = screen.Miles;
			model.ScheduledArrivalTime = screen.ScheduledArrivalTime;
			model.StateCode = screen.StateCode;

			model.Load1StoreID = screen.Load1StoreID;
			model.Load2StoreID = screen.Load2StoreID;
			model.Load3StoreID = screen.Load3StoreID;

			model.Load1Type = screen.Load1Type;
			model.Load2Type = screen.Load2Type;
			model.Load3Type = screen.Load3Type;

			model.Load1DeliveryDayID = screen.Load1DeliveryDayID;
			model.Load2DeliveryDayID = screen.Load2DeliveryDayID;
			model.Load3DeliveryDayID = screen.Load3DeliveryDayID;

			model.Load1DeliveryTime = screen.Load1DeliveryTime;
			model.Load2DeliveryTime = screen.Load2DeliveryTime;
			model.Load3DeliveryTime = screen.Load3DeliveryTime;

			model.TractorNumber = screen.TractorNumber;
			
			ChangeLogger.LogChange(this, db.Entry(model));

			if (ChangeDriver1.HasValue && ChangeDriver1.Value == true)
			{
				var relatedDailyDispatch = db.OpenDispatches()
					.Where(x => x.OutboundRouteID == model.OutboundRouteID && x.DispatchDate > DateTime.Today);
				foreach (DailyDispatch dailyDispatch in relatedDailyDispatch)
				{
					dailyDispatch.Driver1ID = screen.Driver1ID;
					ChangeLogger.LogChange(this, db.Entry(dailyDispatch));
				}
			}

			if (ChangeDriver2.HasValue && ChangeDriver2.Value == true)
			{
				var relatedDailyDispatch = db.OpenDispatches()
					.Where(x => x.OutboundRouteID == model.OutboundRouteID && x.DispatchDate > DateTime.Today);
				foreach (DailyDispatch dailyDispatch in relatedDailyDispatch)
				{
					dailyDispatch.Driver2ID = screen.Driver2ID;
					ChangeLogger.LogChange(this, db.Entry(dailyDispatch));
				}
			}

			if (ChangeCarrier.HasValue && ChangeCarrier.Value == true)
			{
				var relatedDailyDispatch = db.OpenDispatches()
					.Where(x => x.OutboundRouteID == model.OutboundRouteID && x.DispatchDate > DateTime.Today);
				foreach (DailyDispatch dailyDispatch in relatedDailyDispatch)
				{
					dailyDispatch.CarrierID = screen.CarrierID;
					ChangeLogger.LogChange(this, db.Entry(dailyDispatch));
				}
			}

			if (ChangeTractor.HasValue && ChangeTractor.Value == true)
			{
				var relatedDailyDispatch = db.OpenDispatches()
					.Where(x => x.OutboundRouteID == model.OutboundRouteID && x.DispatchDate > DateTime.Today);
				foreach (DailyDispatch dailyDispatch in relatedDailyDispatch)
				{
					dailyDispatch.TractorNumber = screen.TractorNumber;
					ChangeLogger.LogChange(this, db.Entry(dailyDispatch));
				}
			}

			if (ChangeComment.HasValue && ChangeComment.Value == true)
			{
				var relatedDailyDispatch = db.OpenDispatches()
					.Where(x => x.OutboundRouteID == model.OutboundRouteID && x.DispatchDate > DateTime.Today);
				foreach (DailyDispatch dailyDispatch in relatedDailyDispatch)
				{
					dailyDispatch.Comment = screen.Comment;
					ChangeLogger.LogChange(this, db.Entry(dailyDispatch));
				}
			}

			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Outbound Route Template for Week {0} Day {1} updated.", model.WeekNumber, model.WeekDayID);
			return RedirectToAction("Index");
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Delete(int id)
		{
			OutboundRoute model = db.OutboundRoute.Find(id);
			db.OutboundRoute.Remove(model);
			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Outbound Route Template for Week {0} Day {1} deleted.", model.WeekNumber, model.WeekDayID);

			return RedirectToAction("Index");
		}

		private void LoadViewBag(OutboundRoute model = null)
		{
			var dispatchGroups = new[]
			{ 
				new { Text = "OTR", Value = DatabaseLists.DISPATCH_GROUP_OTR },
				new { Text = "Dallas", Value = DatabaseLists.DISPATCH_GROUP_DALLAS }
			};

			var LoadTypeList = new[] 
			{ 
				new {Value = "A", Text = "A-load"},
				new {Value = "B", Text = "B-load"},
				new {Value = "C", Text = "C-load"}
			};

			var StoreList = db.Store.ActiveFilter().AsNoTracking()
				.OrderBy(x => x.CompanyID)
				.ThenBy(x => x.StoreNumber)
				.ToList()
				.Select(x => new
				{
					Value = x.StoreID,
					Text = x.StoreAndCompanyLong
				});

			var CarrierList = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .AsNoTracking()
                .OrderBy(x => x.Name)
				.ToList()
				.Select(x => new
				{
					Value = x.CarrierID,
					Text = x.Name
				});

			var DriverList = db.Driver
				.ActiveFilter()
				.AsNoTracking()
				.OrderBy(x => x.FirstName)
				.ThenBy(x => x.LastName)
				.ToList()
				.Select(x => new
				{
					Value = x.DriverID,
					Text = string.Format("{0} {1} {2} {3}", x.FirstName, x.MiddleName, x.LastName, x.Suffix).Replace("  ", " ").Trim()
				});

			var WeekDayList = db.WeekDay.AsNoTracking()
				.OrderBy(x => x.WeekDayID)
				.ToList()
				.Select(x => new
				{
					Value = x.WeekDayID,
					Text = x.LongName
				});

			var states = CountryStates.USStates
				.AsEnumerable()
				.Select(x => new
				{
					Text = x.Value,
					Value = x.Key
				});

			if (model == null)
			{
				ViewBag.DispatchGroup = new SelectList(dispatchGroups, "Value", "Text");
				ViewBag.InboundWeekDayID = new SelectList(WeekDayList, "Value", "Text");
				ViewBag.Load1StoreID = new SelectList(StoreList, "Value", "Text");
				ViewBag.Load2StoreID = new SelectList(StoreList, "Value", "Text");
				ViewBag.Load3StoreID = new SelectList(StoreList, "Value", "Text");
				ViewBag.Load1Type = new SelectList(LoadTypeList, "Value", "Text");
				ViewBag.Load2Type = new SelectList(LoadTypeList, "Value", "Text");
				ViewBag.Load3Type = new SelectList(LoadTypeList, "Value", "Text");
				ViewBag.Load1DeliveryDayID = new SelectList(WeekDayList, "Value", "Text");
				ViewBag.Load2DeliveryDayID = new SelectList(WeekDayList, "Value", "Text");
				ViewBag.Load3DeliveryDayID = new SelectList(WeekDayList, "Value", "Text");
				ViewBag.CarrierID = new SelectList(CarrierList, "Value", "Text");
				ViewBag.Driver1ID = new SelectList(DriverList, "Value", "Text");
				ViewBag.Driver2ID = new SelectList(DriverList, "Value", "Text");
				ViewBag.WeekDayID = new SelectList(WeekDayList, "Value", "Text");
				ViewBag.WeekNumber = new SelectList(WeekList, "Number", "Name");
				ViewBag.StateCode = new SelectList(states, "Value", "Text");
			}
			else
			{
				ViewBag.DispatchGroup = new SelectList(dispatchGroups, "Value", "Text", model.DispatchGroup);
				ViewBag.InboundWeekDayID = new SelectList(WeekDayList, "Value", "Text", model.InboundWeekDayID);
				ViewBag.Load1StoreID = new SelectList(StoreList, "Value", "Text", model.Load1StoreID);
				ViewBag.Load2StoreID = new SelectList(StoreList, "Value", "Text", model.Load2StoreID);
				ViewBag.Load3StoreID = new SelectList(StoreList, "Value", "Text", model.Load3StoreID);
				ViewBag.Load1Type = new SelectList(LoadTypeList, "Value", "Text", model.Load1Type);
				ViewBag.Load2Type = new SelectList(LoadTypeList, "Value", "Text", model.Load2Type);
				ViewBag.Load3Type = new SelectList(LoadTypeList, "Value", "Text", model.Load3Type);
				ViewBag.Load1DeliveryDayID = new SelectList(WeekDayList, "Value", "Text", model.Load1DeliveryDayID);
				ViewBag.Load2DeliveryDayID = new SelectList(WeekDayList, "Value", "Text", model.Load2DeliveryDayID);
				ViewBag.Load3DeliveryDayID = new SelectList(WeekDayList, "Value", "Text", model.Load3DeliveryDayID);
				ViewBag.CarrierID = new SelectList(CarrierList, "Value", "Text", model.CarrierID);
				ViewBag.Driver1ID = new SelectList(DriverList, "Value", "Text", model.Driver1ID);
				ViewBag.Driver2ID = new SelectList(DriverList, "Value", "Text", model.Driver2ID);
				ViewBag.WeekDayID = new SelectList(WeekDayList, "Value", "Text", model.WeekDayID);
				ViewBag.WeekNumber = new SelectList(WeekList, "Number", "Name", model.WeekNumber);
				ViewBag.StateCode = new SelectList(states, "Value", "Text", model.StateCode);
			}
		}

		#endregion

		#region Schedule Preview

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult SchedulePreview()
		{
			OutboundRoutePreviewViewModel viewModel = new OutboundRoutePreviewViewModel();

			List<DispatchDateControl> dispatchDates = db.OpenDispatchDates().AsNoTracking().OrderBy(x => x.DispatchDate).ToList();
			DispatchDateControl lastWeek1Date = dispatchDates.Last(x => x.WeekNumber == 1);

			DateTime sundayDate = lastWeek1Date.DispatchDate;

			while (sundayDate.DayOfWeek != DayOfWeek.Sunday)
			{
				sundayDate = sundayDate.AddDays(-1);
			}

			viewModel.Week1SundayDate = sundayDate;

			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult SchedulePreview(OutboundRoutePreviewViewModel viewModel)
		{
			if (viewModel.Week1SundayDate.DayOfWeek != DayOfWeek.Sunday)
			{
				ModelState.AddModelError(string.Empty, "Date must be a Sunday.");
			}

			if (!ModelState.IsValid)
			{
				return View(viewModel);
			}

			List<DailyDispatch> dispatches = new List<DailyDispatch>();

			if (viewModel.Week1Sunday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate, 1, 1));
			}
			if (viewModel.Week1Monday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(1), 1, 2));
			}
			if (viewModel.Week1Tuesday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(2), 1, 3));
			}
			if (viewModel.Week1Wednesday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(3), 1, 4));
			}
			if (viewModel.Week1Thursday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(4), 1, 5));
			}
			if (viewModel.Week1Friday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(5), 2, 6));
			}
			if (viewModel.Week1Saturday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(6), 2, 7));
			}

			if (viewModel.Week2Sunday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(7), 2, 1));
			}
			if (viewModel.Week2Monday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(8), 2, 2));
			}
			if (viewModel.Week2Tuesday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(9), 2, 3));
			}
			if (viewModel.Week2Wednesday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(10), 2, 4));
			}
			if (viewModel.Week2Thursday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(11), 2, 5));
			}
			if (viewModel.Week2Friday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(12), 1, 6));
			}
			if (viewModel.Week2Saturday)
			{
				dispatches.AddRange(GenerateDispatches(viewModel.Week1SundayDate.AddDays(13), 1, 7));
			}

			viewModel.Dispatches = dispatches.Select(x => new DispatchViewModel(x));

			return View(viewModel);
		}

		private IEnumerable<DailyDispatch> GenerateDispatches(DateTime dispatchDate, int weekNumber, int weekDayID)
		{
			//DateTime dispatchDate = sundayDate.AddDays((weekNumber-1)*7 + (weekDayID - 1));

			return db.OutboundRoute.AsNoTracking().Where(x => x.WeekNumber == weekNumber && x.WeekDayID == weekDayID)
			.OrderBy(x => x.Load1Store.CompanyID)
			.ThenBy(x => x.Load1Store.StoreNumber)
			.ToList()
			.Select(x => DispatchDateController.BuildDailyDispatchRecord(db, x, dispatchDate, weekNumber, weekDayID));
		}

		#endregion

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}