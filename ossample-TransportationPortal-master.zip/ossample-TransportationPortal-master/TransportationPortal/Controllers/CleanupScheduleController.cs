﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using Avatar;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class CleanupScheduleController : Controller
	{
		private DispatchContext db = new DispatchContext();

		private const string OUTBOUND_ROUTE_FORMAT = "{0}O{1:0}{2:0}{3:0000}";

		private static object[] WeekList = new[]
		{
			new { Number = 1, Name = "Week 1"},
			new { Number = 2, Name = "Week 2"},
		};
		
		private string FilterSessionName
		{
			get { return this.GetType().Name + ".Filter"; }
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ViewResult Index()
		{
			CleanupScheduleViewModel viewModel = Session[FilterSessionName] as CleanupScheduleViewModel;
			if (viewModel == null)
			{
				viewModel = new CleanupScheduleViewModel();
				switch (DateTime.Today.DayOfWeek)
				{
					case DayOfWeek.Sunday:
						viewModel.Week1Sunday = true;
						viewModel.Week2Sunday = true;
						break;
					case DayOfWeek.Monday:
						viewModel.Week1Monday = true;
						viewModel.Week2Monday = true;
						break;
					case DayOfWeek.Tuesday:
						viewModel.Week1Tuesday = true;
						viewModel.Week2Tuesday = true;
						break;
					case DayOfWeek.Wednesday:
						viewModel.Week1Wednesday = true;
						viewModel.Week2Wednesday = true;
						break;
					case DayOfWeek.Thursday:
						viewModel.Week1Thursday = true;
						viewModel.Week2Thursday = true;
						break;
					case DayOfWeek.Friday:
						viewModel.Week1Friday = true;
						viewModel.Week2Friday = true;
						break;
					case DayOfWeek.Saturday:
						viewModel.Week1Saturday = true;
						viewModel.Week2Saturday = true;
						break;
				}

			}

			return View(GenerateViewModel(viewModel));
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ViewResult Index(CleanupScheduleViewModel viewModel)
		{
			// Save input values
			Session[FilterSessionName] = viewModel;

			return View(GenerateViewModel(viewModel));
		}

		private CleanupScheduleViewModel GenerateViewModel(CleanupScheduleViewModel viewModel)
		{
			var StoreList = db.Store.ActiveFilter().AsNoTracking()
				.OrderBy(x => x.CompanyID)
				.ThenBy(x => x.StoreNumber)
				.ToList()
				.Select(x => new
				{
					StoreID = x.StoreID,
					StoreAndCompany = x.StoreAndCompany
				});

			if (viewModel.SearchStoreID.HasValue)
			{
				ViewBag.SearchStoreID = new SelectList(StoreList, "StoreID", "StoreAndCompany", viewModel.SearchStoreID);
			}
			else
			{
				ViewBag.SearchStoreID = new SelectList(StoreList, "StoreID", "StoreAndCompany");
			}

			List<int> week1days = new List<int>();
			List<int> week2days = new List<int>();

			if (viewModel.Week1Sunday)
				week1days.Add(1);
			if (viewModel.Week1Monday)
				week1days.Add(2);
			if (viewModel.Week1Tuesday)
				week1days.Add(3);
			if (viewModel.Week1Wednesday)
				week1days.Add(4);
			if (viewModel.Week1Thursday)
				week1days.Add(5);
			if (viewModel.Week1Friday)
				week1days.Add(6);
			if (viewModel.Week1Saturday)
				week1days.Add(7);

			if (viewModel.Week2Sunday)
				week2days.Add(1);
			if (viewModel.Week2Monday)
				week2days.Add(2);
			if (viewModel.Week2Tuesday)
				week2days.Add(3);
			if (viewModel.Week2Wednesday)
				week2days.Add(4);
			if (viewModel.Week2Thursday)
				week2days.Add(5);
			if (viewModel.Week2Friday)
				week2days.Add(6);
			if (viewModel.Week2Saturday)
				week2days.Add(7);

			var routeList = db.OutboundRoute.Select(x => x);

			if (viewModel.SearchStoreID.HasValue)
			{
				routeList = routeList.Where(x => 
					x.Load1StoreID == viewModel.SearchStoreID.Value ||
					x.Cleanup1StoreID == viewModel.SearchStoreID.Value ||
					x.Cleanup2StoreID == viewModel.SearchStoreID.Value ||
					x.Cleanup3StoreID == viewModel.SearchStoreID.Value );
			}

			if (week1days.Count > 0 && week2days.Count > 0)
			{
				routeList = routeList.Where(x => (x.WeekNumber == 1 && week1days.Contains(x.WeekDayID)) || (x.WeekNumber == 2 && week2days.Contains(x.WeekDayID)));
			}
			else if (week1days.Count > 0)
			{
				routeList = routeList.Where(x => (x.WeekNumber == 1 && week1days.Contains(x.WeekDayID)));
			}
			else if (week2days.Count > 0)
			{
				routeList = routeList.Where(x => (x.WeekNumber == 2 && week2days.Contains(x.WeekDayID)));
			}

			viewModel.OutboundRoutes = routeList
				.Include(x => x.Load1Store)
				.Include(x => x.WeekDay)
				.Include(x => x.Cleanup1Store)
				.Include(x => x.Cleanup2Store)
				.Include(x => x.Cleanup3Store)
				.OrderBy(x => x.Load1Store.StoreNumber)
				.ThenBy(x => x.Load1Store.CompanyID)
				.ThenBy(x => x.WeekNumber)
				.ThenBy(x => x.WeekDayID)
				.Where(x => x.Load1StoreID.HasValue)
				.ToList()
				.Select(x => new CleanupScheduleViewModel.OutboundRoute
				{
					OutboundRouteID = x.OutboundRouteID,
					Store = x.Load1Store != null ? x.Load1Store.StoreAndCompanyLong : null,
					WeekNumber = x.WeekNumber,
					DayName = x.WeekDay.ShortName,
					Cleanup1Store = x.Cleanup1Store != null ? x.Cleanup1Store.StoreAndCompanyLong : null,
					Cleanup2Store = x.Cleanup2Store != null ? x.Cleanup2Store.StoreAndCompanyLong : null,
					Cleanup3Store = x.Cleanup3Store != null ? x.Cleanup3Store.StoreAndCompanyLong : null
				})
				;

			return viewModel;
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ViewResult Details(int id)
		{
			OutboundRoute model = db.OutboundRoute
				.Include(x => x.Load1Store)
				.Include(x => x.Cleanup1Store)
				.Include(x => x.Cleanup2Store)
				.Include(x => x.Cleanup3Store)
				.Include(x => x.WeekDay)
				.Single(x => x.OutboundRouteID == id);

			return View(model);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]  
		public ActionResult Edit(int id)
		{
			OutboundRoute model = db.OutboundRoute
				.Include(x => x.Load1Store)
				.Include(x => x.Load2Store)
				.Include(x => x.Load3Store)
				.Include(x => x.WeekDay)
				.Single(x => x.OutboundRouteID == id);

			LoadViewBag(model);
			return View(model);
		}


		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)] 
		public ActionResult Edit(OutboundRoute screen)
		{
			OutboundRoute model = db.OutboundRoute.Find(screen.OutboundRouteID);

			UInt64 screenTimestamp = BitConverter.ToUInt64(screen.Timestamp, 0);
			UInt64 modelTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

			if (screenTimestamp != modelTimestamp)
			{
				ModelState.Clear();
				ModelState.AddModelError(string.Empty,
					"The record you attempted to edit was modified after you got the original value.\r\n" +
					"The edit operation was canceled and the current values in the database have been displayed.\r\n" +
					"If you still want to edit this record, make the changes again and click the Save button.\r\n" +
					"Otherwise click Back to List.");
				LoadViewBag(model);
				return View(model);
			}

			model.Cleanup1StoreID = screen.Cleanup1StoreID;
			model.Cleanup2StoreID = screen.Cleanup2StoreID;
			model.Cleanup3StoreID = screen.Cleanup3StoreID;

			ChangeLogger.LogChange(this, db.Entry(model));

			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Cleanup Template for Week {0} Day {1} updated.", model.WeekNumber, model.WeekDayID);
			return RedirectToAction("Index");
		}

		private void LoadViewBag(OutboundRoute model = null)
		{
			var StoreList = db.Store.ActiveFilter().AsNoTracking()
				.OrderBy(x => x.CompanyID)
				.ThenBy(x => x.StoreNumber)
				.ToList()
				.Select(x => new
				{
					StoreID = x.StoreID,
					StoreAndCompany = x.StoreAndCompanyLong
				});

			if (model == null)
			{
				ViewBag.Cleanup1StoreID = new SelectList(StoreList, "StoreID", "StoreAndCompany");
				ViewBag.Cleanup2StoreID = new SelectList(StoreList, "StoreID", "StoreAndCompany");
				ViewBag.Cleanup3StoreID = new SelectList(StoreList, "StoreID", "StoreAndCompany");
			}
			else
			{
				ViewBag.Cleanup1StoreID = new SelectList(StoreList, "StoreID", "StoreAndCompany", model.Cleanup1StoreID);
				ViewBag.Cleanup2StoreID = new SelectList(StoreList, "StoreID", "StoreAndCompany", model.Cleanup2StoreID);
				ViewBag.Cleanup3StoreID = new SelectList(StoreList, "StoreID", "StoreAndCompany", model.Cleanup3StoreID);
			}
		}

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}