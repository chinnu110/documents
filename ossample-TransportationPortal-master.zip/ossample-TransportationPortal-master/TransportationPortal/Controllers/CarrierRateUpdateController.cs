﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using System.IO;
using ExcelUtil;
using Avatar;
using System.Reflection;


namespace TransportationPortal.Controllers
{
    [HandleApplicationError]
    [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
    public class CarrierRateUpdateController : Controller
    {
        private const string TEMPDATA_LASTGOODMESSAGE = "LastGoodMessage";

        public const string COLUMN_NAME_STORE = "Store";
        public const string COLUMN_NAME_MILES = "Miles";
        public const string COLUMN_NAME_RATE = "Rate";
        public const string COLUMN_NAME_FLATRATE = "FlatRate";

        public const string MESSAGE_FORMAT = "Row {0} {1} : {2}";

        public static class CarrierRateExportSpreadsheet
        {
            public const uint Store = 1;
            public const uint City = 2;
            public const uint State = 3;
            public const uint Zip = 4;
            public const uint Location = 5;
            public const uint Miles = 6;
            public const uint Rate = 7;
            public const uint FlatRate = 8;
        }

        /// <summary>
        /// Session object to hold the processed spreadsheet.
        /// This is the object to hold all the 
        /// </summary>
        class ImportRequest
        {
            public Carrier CarrierSelected { get; set; }

            public int TotalRowCount { get; set; }

            public int ActionableRowCount { get; set; }

            public Dictionary<string, uint> ColumnMap { get; set; }

            public XSpreadsheet XSpreadsheet { get; set; }

            public List<string> Messages { get; set; }

            public List<StoreCarrierInfo> Updates { get; set; }

            public ImportRequest()
            {
                ColumnMap = new Dictionary<string, uint>();
                ColumnMap.Add(COLUMN_NAME_STORE, 0);
                ColumnMap.Add(COLUMN_NAME_MILES, 0);
                ColumnMap.Add(COLUMN_NAME_RATE, 0);
                ColumnMap.Add(COLUMN_NAME_FLATRATE, 0);

                TotalRowCount = 0;
                ActionableRowCount = 0;

                Messages = new List<string>();

                Updates = new List<StoreCarrierInfo>();
            }
        }
        /// <summary>
        /// Session element name generated for unique name.
        /// </summary>
        private string ImportRequestSessionName
        {
            get { return this.GetType().Name + "." + typeof(ImportRequest).GetType().Name; }
        }

        ImportRequest currentImportRequest = null;
        
        private DispatchContext db = new DispatchContext();

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
        
        #region Carrier Rate Spreadsheet Export

        public ActionResult Export(int id)
        {
            Carrier carrier = db.Carrier.Find(id);

            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream spreadsheetTemplate = assembly.GetManifestResourceStream("TransportationPortal.Templates.Carrier Rate Export Template 1.xlsx");

            using (MemoryStream mem = new MemoryStream())
            {
                spreadsheetTemplate.CopyTo(mem);
                spreadsheetTemplate.Close();

                XSpreadsheet spreadsheet = new XSpreadsheet
                {
                    Stream = mem,
                    SheetNumber = 1,
                    RunObject = id
                };

                if (spreadsheet.Update(CreateCarrierRateSpreadsheet) == false)
                {
                //	this.ModelState.AddModelError("", "Spreadsheet generation ended prematurely.");	
                //	CarrierAdvisementViewBag(viewModel);
                //	return View(viewModel);
                }

                return File(mem.ToArray(), "application/xlsx", Path.ChangeExtension(string.Format("Hobby Lobby Carrier Rates for {0}", carrier.Name), "xlsx"));
            }
        }

        private bool CreateCarrierRateSpreadsheet(XSpreadsheet spreadsheet)
        {
            XRow templateXRow = spreadsheet[2];

            foreach (XRow template in new[] { templateXRow })
            {
                template[CarrierRateExportSpreadsheet.Store].SetValue(null);
                template[CarrierRateExportSpreadsheet.City].SetValue(null);
                template[CarrierRateExportSpreadsheet.State].SetValue(null);
                template[CarrierRateExportSpreadsheet.Zip].SetValue(null);
                template[CarrierRateExportSpreadsheet.Location].SetValue(null);
                template[CarrierRateExportSpreadsheet.Miles].SetValue(null);
                template[CarrierRateExportSpreadsheet.Rate].SetValue(null);
                template[CarrierRateExportSpreadsheet.FlatRate].SetValue(null);
            }

            uint row = 2;
            List<XRow> extraRows = spreadsheet.XRows.Where(x => x.RowNumber >= row).ToList();
            foreach (XRow xrow in extraRows)
            {
                spreadsheet.RemoveXRow(xrow);
            }

            int carrierID = (int)spreadsheet.RunObject;

            var stores = db.Store
                .ActiveFilter()
                .AsNoTracking()
                .Include(x => x.StoreCarrierInfo)
                .Include(x => x.Company)
                .Where(x => x.CompanyID == "HL")
                .OrderBy(x => x.CompanyID)
                .ThenBy(x => x.StoreNumber)
                .ThenBy(x => x.DuplicateCode);

            foreach (var store in stores)
            {
                XRow newrow = spreadsheet.AddXRow(templateXRow, row++);

                newrow[CarrierRateExportSpreadsheet.Store].SetValue(string.Format("{0}{1}", store.StoreNumber, store.DuplicateCode));
                newrow[CarrierRateExportSpreadsheet.City].SetValue(store.City);
                newrow[CarrierRateExportSpreadsheet.State].SetValue(store.StateCode);

                var zstoreRecords = db.ZStore.Where(x => x.Chain == store.Company.Chain && x.Store_Number == store.StoreNumber);

                // For this store number, look for (A)ctive store, then (F)uture store, then (N)ew store, Then (E)xpansion store, in that order.

                ZStore zstore = zstoreRecords.FirstOrDefault(x => x.Status == "A");
                if (zstore == null)
                {
                    zstore = zstoreRecords.FirstOrDefault(x => x.Status == "F");
                }
                if (zstore == null)
                {
                    zstore = zstoreRecords.FirstOrDefault(x => x.Status == "N");
                }
                if (zstore == null)
                {
                    zstore = zstoreRecords.FirstOrDefault(x => x.Status == "E");
                }

                // If store record found, put location and zip into the spreadsheet.
                if (zstore != null)
                {
                    newrow[CarrierRateExportSpreadsheet.Location].SetValue(zstore.Location);
                    newrow[CarrierRateExportSpreadsheet.Zip].SetValue(zstore.Zip_Code);
                }
                
                StoreCarrierInfo scinfo = store.StoreCarrierInfo.FirstOrDefault(x => x.CarrierID == carrierID);
                if (scinfo != null)
                {
                    newrow[CarrierRateExportSpreadsheet.Miles].SetValue(scinfo.Miles);
                    newrow[CarrierRateExportSpreadsheet.Rate].SetValue(scinfo.RatePerMile);
                    if (scinfo.MileageCalcType == 1)
                    {
                        newrow[CarrierRateExportSpreadsheet.FlatRate].SetValue(scinfo.FlatRate);
                    }
                }
            }

            return true;
        }

        #endregion

        
        #region Carrier Rate Spreadsheet Import

        public ActionResult Import(int id)
        {
            Session.Remove(ImportRequestSessionName);

            CarrierRateUpdateViewModel viewModel = new CarrierRateUpdateViewModel();
            viewModel.CarrierID = id;
            viewModel.CarrierSelected = db.Carrier.Find(id);
            
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult Import(CarrierRateUpdateViewModel viewModel)
        {
            if (viewModel.FileUpload == null)
            {
                this.ModelState.AddModelError("", "Excel spreadsheet must be selected for upload");
            }

            if (!ModelState.IsValid)
            {
                return View("Import", viewModel);
            }

            try
            {
                currentImportRequest = new ImportRequest();

                currentImportRequest.CarrierSelected = db.Carrier.Find(viewModel.CarrierID.Value);

                currentImportRequest.XSpreadsheet = new XSpreadsheet
                {
                    Stream = viewModel.FileUpload.InputStream,
                    SheetNumber = 1,
                    IsEditable = false
                };

                currentImportRequest.XSpreadsheet.Process(DetermineColumns);

                if (currentImportRequest.ColumnMap[COLUMN_NAME_STORE] == 0)
                {
                    this.ModelState.AddModelError("", string.Format("Column '{0}' not found.", COLUMN_NAME_STORE));
                }

                if (currentImportRequest.ColumnMap[COLUMN_NAME_MILES] == 0)
                {
                    this.ModelState.AddModelError("", string.Format("Column '{0}' not found.", COLUMN_NAME_MILES));
                }

                if (currentImportRequest.ColumnMap[COLUMN_NAME_RATE] == 0)
                {
                    this.ModelState.AddModelError("", string.Format("Column '{0}' not found.", COLUMN_NAME_RATE));
                }
                
                if (ModelState.IsValid)
                {
                    currentImportRequest.XSpreadsheet.Process(ExtractData);
                }
            }
            catch (Exception ex)
            {
                this.ModelState.AddModelError("", ex.Message);
            }

            if (!ModelState.IsValid)
            {
                return View("Import", viewModel);
            }

            Session[ImportRequestSessionName] = currentImportRequest;

            viewModel.CarrierSelected = currentImportRequest.CarrierSelected;
            viewModel.TotalRowCount = currentImportRequest.TotalRowCount;
            viewModel.ActionableRowCount = currentImportRequest.ActionableRowCount;
            viewModel.ColumnMap = currentImportRequest.ColumnMap;
            viewModel.Messages = currentImportRequest.Messages;
            
            return View("Confirm", viewModel);
        }

        private bool DetermineColumns(ExcelUtil.XRow r)
        {
            if (r.RowNumber == 1)
            {
                foreach (var mapKey in currentImportRequest.ColumnMap.Keys.ToList())
                {
                    ExcelUtil.XCell mapcell = r.XCells.FirstOrDefault(x => x.String == mapKey);
                    if (mapcell != null)
                    {
                        currentImportRequest.ColumnMap[mapKey] = mapcell.ColumnNumber;
                    }
                }
            }
            else
            {
                currentImportRequest.TotalRowCount++;
            }

            return true;
        }

        private bool ExtractData(ExcelUtil.XRow r)
        {
            if (r.RowNumber == 1)
            {
                return true;
            }

            /*
             * Locate the cells
             */

            ExcelUtil.XCell storeCell = r.XCells.FirstOrDefault(x => x.ColumnNumber == currentImportRequest.ColumnMap[COLUMN_NAME_STORE]);
            ExcelUtil.XCell milesCell = r.XCells.FirstOrDefault(x => x.ColumnNumber == currentImportRequest.ColumnMap[COLUMN_NAME_MILES]);
            ExcelUtil.XCell rateCell = r.XCells.FirstOrDefault(x => x.ColumnNumber == currentImportRequest.ColumnMap[COLUMN_NAME_RATE]);
            ExcelUtil.XCell flatrateCell = r.XCells.FirstOrDefault(x => x.ColumnNumber == currentImportRequest.ColumnMap[COLUMN_NAME_FLATRATE]);
                
            // Skip row silently if no significant data present.
            if ((storeCell == null || string.IsNullOrWhiteSpace(storeCell.String)) &&
                (milesCell == null || string.IsNullOrWhiteSpace(milesCell.String)) &&
                (rateCell == null || string.IsNullOrWhiteSpace(rateCell.String)))
            {
                return true;
            }
            else if (storeCell == null || string.IsNullOrWhiteSpace(storeCell.String))
            {
                currentImportRequest.Messages.Add(string.Format(MESSAGE_FORMAT, r.RowNumber, COLUMN_NAME_STORE, "Missing. Row skipped."));
                return true;
            }
            else if (milesCell == null || string.IsNullOrWhiteSpace(milesCell.String))
            {
                currentImportRequest.Messages.Add(string.Format(MESSAGE_FORMAT, r.RowNumber, COLUMN_NAME_MILES, "Missing. Row skipped."));
                return true;
            }
            else if (rateCell == null || string.IsNullOrWhiteSpace(rateCell.String))
            {
                currentImportRequest.Messages.Add(string.Format(MESSAGE_FORMAT, r.RowNumber, COLUMN_NAME_RATE, "Missing. Row skipped."));
                return true;
            }
                    
            /*
             * Determine the Store
             */

            Store store = null;

            if (storeCell.Number.HasValue)
            {
                int storeNumber = (int)storeCell.Number;
                try
                {
                    store = db.Store.ActiveFilter().AsNoTracking()
                        .SingleOrDefault(x => x.StoreNumber == storeNumber && string.IsNullOrEmpty(x.DuplicateCode) && x.CompanyID == "HL");
                }
                catch (Exception ex)
                {
                    throw new Exception(string.Format("Error occured trying SingleOrDefault to get store {0} HL", storeNumber), ex);
                }
                if (store == null)
                {
                    currentImportRequest.Messages.Add(string.Format(MESSAGE_FORMAT, r.RowNumber, COLUMN_NAME_STORE, string.Format("Store {0} not found", storeCell.String)));
                    return true;
                }
            }
            else
            {
                string workstring = storeCell.String;
                string digitChars = new string(workstring.Where(x => Char.IsDigit(x)).ToArray());
                string alphaChars = new string(workstring.Where(x => Char.IsLetter(x)).Select(x => Char.ToUpper(x)).ToArray());

                if (string.IsNullOrEmpty(digitChars))
                {
                    currentImportRequest.Messages.Add(string.Format(MESSAGE_FORMAT, r.RowNumber, COLUMN_NAME_STORE, string.Format("Store number not in cell", storeCell.String)));
                    return true;
                }
                    
                int storeNumber = 0;
                if (Int32.TryParse(digitChars, out storeNumber) == false)
                {
                    currentImportRequest.Messages.Add(string.Format(MESSAGE_FORMAT, r.RowNumber, COLUMN_NAME_STORE, string.Format("Unparsable store number in cell", storeCell.String)));
                    return true;
                }

                try
                {
                    store = db.Store.ActiveFilter().AsNoTracking()
                        .SingleOrDefault(x => x.StoreNumber == storeNumber
                            && x.CompanyID == "HL"
                            && (alphaChars.Length == 0  ? x.DuplicateCode == null : x.DuplicateCode == alphaChars));
                }
                catch (Exception ex)
                {
                    throw new Exception(string.Format("Error occured trying SingleOrDefault to get store {0}{1} HL", storeNumber, alphaChars), ex);
                }
                if (store == null)
                {
                    currentImportRequest.Messages.Add(string.Format(MESSAGE_FORMAT, r.RowNumber, COLUMN_NAME_STORE, string.Format("Store {0} not found", storeCell.String)));
                    return true;
                }
            }

            /*
             * Determine the Miles
             */

            int miles = 0;

            if (milesCell.Number.HasValue)
            {
                miles = (int)milesCell.Number.Value;
            }
            else
            {
                currentImportRequest.Messages.Add(string.Format(MESSAGE_FORMAT, r.RowNumber, COLUMN_NAME_STORE, string.Format("Miles not specified. Skipped.", storeCell.String)));
                return true;
            }
                
            /*
             * Determine the Rate
             */

            decimal rate = 0;

            if (rateCell.Number.HasValue)
            {
                rate = (decimal)rateCell.Number.Value;
            }
            else
            {
                currentImportRequest.Messages.Add(string.Format(MESSAGE_FORMAT, r.RowNumber, COLUMN_NAME_STORE, string.Format("Rate not specified. Skipped.", storeCell.String)));
                return true;
            }

            /*
             * Determine the FlatRate
             */

            decimal? flatrate = null;
            if (currentImportRequest.ColumnMap[COLUMN_NAME_FLATRATE] != 0)
            {
                if (flatrateCell != null)
                {
                    flatrate = (decimal?)flatrateCell.Number;
                }
            }

            /*
             * Build StoreCarrierInfo record
             */

            StoreCarrierInfo scinfo = new StoreCarrierInfo
            {
                StoreID = store.StoreID,
                CarrierID = currentImportRequest.CarrierSelected.CarrierID,
                Miles = miles,
                RatePerMile = rate,
                FlatRate = flatrate,
                MileageCalcType = flatrate.HasValue ? 1 : 0
            };

            currentImportRequest.Updates.Add(scinfo);

            currentImportRequest.ActionableRowCount++;

            return true;
        }

        [HttpPost]
        public ActionResult Update(CarrierRateUpdateViewModel viewModel)
        {
            try
            {
                currentImportRequest = (ImportRequest)Session[ImportRequestSessionName];

                foreach (var update in currentImportRequest.Updates)
                {
                    StoreCarrierInfo storeCarrierInfo = db.StoreCarrierInfo.Find(update.StoreID, update.CarrierID);
                    if (storeCarrierInfo != null)
                    {
                        storeCarrierInfo.Miles = update.Miles;
                        storeCarrierInfo.RatePerMile = update.RatePerMile;
                        storeCarrierInfo.FlatRate = update.FlatRate;
                        storeCarrierInfo.MileageCalcType = update.MileageCalcType;
                        ChangeLogger.LogChange(this, db.Entry(storeCarrierInfo));
                    }
                    else
                    {
                        db.StoreCarrierInfo.Add(update);
                        ChangeLogger.LogChange(this, db.Entry(update));
                    }
                }

                db.SaveChanges();
                
                TempData[TEMPDATA_LASTGOODMESSAGE] = string.Format("Carrier {0} rate import successful.", currentImportRequest.CarrierSelected.Name);
            }
            catch (Exception ex)
            {
                this.ModelState.AddModelError("", ex.Message);
            }

            if (!ModelState.IsValid)
            {
                return View("Import", viewModel);
            }

            return RedirectToAction("Index", "Carrier");
        }

        #endregion
    }
}