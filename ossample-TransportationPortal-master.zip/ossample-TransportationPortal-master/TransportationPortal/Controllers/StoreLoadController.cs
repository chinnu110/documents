﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using System.Data.Objects.SqlClient;
using System.Text;


namespace TransportationPortal.Controllers
{
	[HandleApplicationError]
	public class StoreLoadController : LoadController
	{
		public readonly static string TEMPDATA_RETURN_URL = typeof(StoreLoadController).Name + ".ReturnURL";


		public override string GetControllerLoadType
		{
			get
			{
				return "S";
			}
		}

		public override string GetControllerLoadName
		{
			get
			{
				return "Store Load";
			}
		}

		public override Load GetInitialLoadForCreate
		{
			get
			{
				return new Load
				{
					ReadyDate = DateTime.Today,
					StoreLoadType = "B"
				};
			}
		}

		protected override LoadIndexViewModel GenerateViewModel(IQueryable<Load> query, LoadIndexViewModel viewModel)
		{
			// Load viewbag.

			var stores = db.Store.ActiveFilter().AsNoTracking()
				.OrderBy(x => x.CompanyID)
				.ThenBy(x => x.StoreNumber)
				.ToList()
				.Select(x => new SelectListItem
				{
					Text = x.StoreAndCompanyLong,
					Value = x.StoreID.ToString()
				});

			if (viewModel.StoreID.HasValue)
			{
				ViewBag.StoreID = new SelectList(stores, "Value", "Text", viewModel.StoreID.Value.ToString());
			}
			else
			{
				ViewBag.StoreID = new SelectList(stores, "Value", "Text");
			}

			var subsetSortTypes = SortTypes
				.Where(x => 
					x.Value.Contains(Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.PickupLocation)) == false &&
					x.Value.Contains(Enum.GetName(typeof(LoadSortColumn), LoadSortColumn.DeliveryLocation)) == false);

			if (string.IsNullOrEmpty(viewModel.SortingID))
			{
				viewModel.SortingID = subsetSortTypes.ElementAt(0).Value;
			}

			ViewBag.SortingID = new SelectList(subsetSortTypes, "Value", "Text", viewModel.SortingID);


			// Apply filters.

			if (viewModel.StoreID.HasValue)
			{
				query = query.Where(x => x.StoreID == viewModel.StoreID);
			}

			if (viewModel.FromDate.HasValue)
			{
				query = query.Where(x => x.ReadyDate >= viewModel.FromDate.Value);
			}

			if (viewModel.ThruDate.HasValue)
			{
				query = query.Where(x => x.ReadyDate <= viewModel.ThruDate.Value);
			}
			
			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim();

				Int64 intValue = 0;
				decimal decValue = 0m;
				bool isNumber = Decimal.TryParse(textValue, out decValue);
				if (isNumber)
				{
					intValue = Decimal.ToInt64(decValue);
				}

				if (isNumber && intValue > 0)
				{
					query = query.Where(x =>
						(x.LoadID == intValue && x.LoadType == GetControllerLoadType)
						|| x.Comment.Contains(textValue)
						|| x.Store.StoreNumber == intValue
						|| x.Store.City.Contains(textValue)
						|| x.Store.StateCode == textValue
						);
				}
				else
				{
					query = query.Where(x =>
						x.Comment.Contains(textValue)
						|| x.Store.City.Contains(textValue)
						|| x.Store.StateCode == textValue
						);
				}
			}

			return base.GenerateViewModel(query, viewModel);
		}

		public override void LoadTypeValidation(LoadViewModel viewModel, Load existingLoad)
		{
			if (existingLoad == null)
			{
				if (viewModel.Load.StoreID.HasValue == false)
				{
					ModelState.AddModelError(string.Empty, "Store must be specified.");
				}
			}

			if (viewModel.Load.EtaDate.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "ETA Date must be specified.");
			}
		}

		protected override void LoadViewBag(LoadViewModel viewModel = null)
		{
			if (viewModel.Load.LoadID == 0)
			{
				var StoreList = db.Store.ActiveFilter().AsNoTracking()
					.OrderBy(x => x.CompanyID)
					.ThenBy(x => x.StoreNumber)
					.ToList()
					.Select(x => new
					{
						Value = x.StoreID,
						Text = x.StoreAndCompanyLong
					});

				if (viewModel == null)
				{
					ViewBag.StoreID = new SelectList(StoreList, "Value", "Text");
				}
				else
				{
					ViewBag.StoreID = new SelectList(StoreList, "Value", "Text", viewModel.Load.StoreID);
				}
			}
			else
			{
				viewModel.Load.Store = db.Store.AsNoTracking().Single(x => x.StoreID == viewModel.Load.StoreID);
			}

			base.LoadViewBag(viewModel);
		}
	}
}