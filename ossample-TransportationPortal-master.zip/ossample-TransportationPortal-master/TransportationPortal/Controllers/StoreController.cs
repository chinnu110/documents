﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using Avatar;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class StoreController : Controller
	{
		private DispatchContext db = new DispatchContext();

		private const string TEMPDATA_RETURN_URL = "ReturnURL";
		private const string TEMPDATA_LASTGOODMESSAGE = "LastGoodMessage";
		private const string MAIN_VIEW = "Index";

		private string FilterSessionName
		{
			get { return this.GetType().Name + ".Filter"; }
		}


		private static object[] WeekList = new[]
		{
			new { Number = 1, Name = "Week 1"},
			new { Number = 2, Name = "Week 2"},
		};

		private static object[] LastDigitList = new[]
		{
			new { Value = 1, Text = "1/6"},
			new { Value = 2, Text = "2/7"},
			new { Value = 3, Text = "3/8"},
			new { Value = 4, Text = "4/9"},
			new { Value = 5, Text = "5/0"},
		};

		#region Index views

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index(int? id)
		{
			StoreIndexViewModel viewModel = Session[FilterSessionName] as StoreIndexViewModel;
			if (viewModel == null)
			{
				viewModel = new StoreIndexViewModel();
				viewModel.Paging = new PagingViewModel
				{
					Page = 1,
					PageSize = 50,
					LinksBeforeCurrentPage = 4,
					LinksAfterCurrentPage = 4,
				};
			}
			else if (id.HasValue)
			{
				if (viewModel.Paging.Page != id.Value)
				{
					ViewBag.OverrideSavedPosition = "0_0";
				}
				viewModel.Paging.Page = id.Value;
			}

			// Generate the new view model.
			StoreIndexViewModel newViewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index(StoreIndexViewModel viewModel)
		{
			// Copy any items needed that were not returned.
			StoreIndexViewModel previousViewModel = Session[FilterSessionName] as StoreIndexViewModel;
			if (previousViewModel != null)
			{
				viewModel.Paging = previousViewModel.Paging;
				viewModel.Paging.Page = 1;
			}

			// Generate the new view model.
			viewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = viewModel;

			return View(viewModel);
		}


		private StoreIndexViewModel GenerateViewModel(StoreIndexViewModel viewModel)
		{
			// ViewBag loading

			var companyList = db.Company
				.OrderBy(x => x.CompanyID)
				.Select(x => new
				{
					Text = x.CompanyName,
					Value = x.CompanyID
				});

			if (string.IsNullOrEmpty(viewModel.CompanyID))
			{
				viewModel.CompanyList = new SelectList(companyList, "Value", "Text");
			}
			else
			{
				viewModel.CompanyList = new SelectList(companyList, "Value", "Text", viewModel.CompanyID);
			}

			var stateList = CountryStates.USStates
				.AsEnumerable()
				.Select(x => new
				{
					Text = x.Value,
					Value = x.Key
				});

			if (string.IsNullOrEmpty(viewModel.StateCode))
			{
				viewModel.StateCodeList = new SelectList(stateList, "Value", "Text");
			}
			else
			{
				viewModel.StateCodeList = new SelectList(stateList, "Value", "Text", viewModel.StateCode);
			}


			var WeekDayList = db.WeekDay
				.OrderBy(x => x.WeekDayID)
				.ToList()
				.Select(x => new
				{
					Value = x.WeekDayID,
					Text = string.Format("{0} ({1})", x.LongName, x.WeekDayID)
				});


			if (viewModel.PickDayID.HasValue)
			{
				viewModel.PickDayList = new SelectList(WeekDayList, "Value", "Text", viewModel.PickDayID.Value);
			}
			else
			{
				viewModel.PickDayList = new SelectList(WeekDayList, "Value", "Text");
			}

			if (viewModel.ArrivalDayID.HasValue)
			{
				viewModel.ArrivalDayList = new SelectList(WeekDayList, "Value", "Text", viewModel.ArrivalDayID.Value);
			}
			else
			{
				viewModel.ArrivalDayList = new SelectList(WeekDayList, "Value", "Text");
			}

			if (viewModel.LastDigitID.HasValue)
			{
				viewModel.LastDigitList = new SelectList(LastDigitList, "Value", "Text", viewModel.LastDigitID.Value);
			}
			else
			{
				viewModel.LastDigitList = new SelectList(LastDigitList, "Value", "Text");
			}


			// Begin query argument processing

			IQueryable<Store> list = db.Store
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .AsNoTracking();

			// Begin common query argument processing.			

			if (!string.IsNullOrEmpty(viewModel.CompanyID))
			{
				list = list.Where(x => x.CompanyID == viewModel.CompanyID);
			}

			if (!string.IsNullOrEmpty(viewModel.StateCode))
			{
				list = list.Where(x => x.StateCode == viewModel.StateCode);
			}

			if (viewModel.LastDigitID.HasValue)
			{
				switch (viewModel.LastDigitID.Value)
				{
					case 1:
						list = list.Where(x => (x.StoreNumber + 10) % 10 == 1 || (x.StoreNumber + 10) % 10 == 6);
						break;
					case 2:
						list = list.Where(x => (x.StoreNumber + 10) % 10 == 2 || (x.StoreNumber + 10) % 10 == 7);
						break;
					case 3:
						list = list.Where(x => (x.StoreNumber + 10) % 10 == 3 || (x.StoreNumber + 10) % 10 == 8);
						break;
					case 4:
						list = list.Where(x => (x.StoreNumber + 10) % 10 == 4 || (x.StoreNumber + 10) % 10 == 9);
						break;
					case 5:
						list = list.Where(x => (x.StoreNumber + 10) % 10 == 5 || (x.StoreNumber + 10) % 10 == 0);
						break;
				}
			}


			if (viewModel.PickDayID.HasValue)
			{
				list = list.Where(x => x.ALoadPickDayID == viewModel.PickDayID.Value);
			}

			if (viewModel.ArrivalDayID.HasValue)
			{
				list = list.Where(x => x.ALoadArrivalDayID == viewModel.ArrivalDayID.Value);
			}


			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim().ToUpper();
				int intValue = 0;
				bool isNumber = Int32.TryParse(textValue, out intValue);

				if (isNumber && intValue > 0)
				{
					list = list.Where(x =>
						x.SequenceNumber == intValue
						|| x.StoreNumber == intValue
						);
				}
				else
				{
					list = list.Where(x =>
						x.City.ToUpper().Contains(textValue)
						|| x.StateCode.ToUpper().Contains(textValue)
						);
				}
			}

			StoreSortColumn sortColumn;
			if (!Enum.TryParse(viewModel.SortColumn, out sortColumn))
			{
				sortColumn = StoreSortColumn.StoreAndCompany;
			}
			list = list.Sort(sortColumn, viewModel.SortDirection);

			// Get the total number of records for the paging functions.
			viewModel.Paging.TotalRecords = list.Count();
			// Perform skip/take
			list = list.Skip((viewModel.Paging.Page - 1) * viewModel.Paging.PageSize)
				.Take(viewModel.Paging.PageSize);

			viewModel.Stores = list.Select(x => new StoreIndexViewModel.Store
			{
				ALoadArrivalDayID = x.ALoadArrivalDayID,
				ALoadArrivalTime = x.ALoadArrivalTime,
				BLoadArrivalDayID = x.BLoadArrivalDayID,
				BLoadArrivalTime = x.BLoadArrivalTime,
				ALoadPickDayID = x.ALoadPickDayID,
				City = x.City,
				CompanyID = x.CompanyID,
				Local = x.Local,
				Miles = x.Miles,
				StateCode = x.StateCode,
				StoreID = x.StoreID,
				StoreNumber = x.StoreNumber,
				DuplicateCode = x.DuplicateCode,
				Week1 = x.Week1,
				Week2 = x.Week2,
                DeleteDate = x.DeleteDate
			});

			return viewModel;
		}

		#endregion

		#region Browse, Create, Edit, and Delete methods

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ViewResult Details(int id)
		{
			Store model = db.Store
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .AsNoTracking()
				.Include(x => x.ALoadArrivalDay)
				.Include(x => x.ALoadPickDay)
				.Include(x => x.ALoadArrivalDay)
				.Include(x => x.ALoadPickDay)
				.Include(x => x.Company)
				.Single(x => x.StoreID == id);

            if (model == null)
            {
                throw new ApplicationException("Store ID does not exist.");
            }

            return View(model);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)] 
		public ActionResult Create()
		{
			StoreUpdateViewModel viewModel = new StoreUpdateViewModel();

			LoadViewBag(viewModel);

			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Create(StoreUpdateViewModel screen)
		{
			Store model = new Store();
			model.StoreCarrierInfo = new List<StoreCarrierInfo>();

			if (!string.IsNullOrEmpty(screen.Store.DuplicateCode))
			{
				if (screen.Store.DuplicateCode.Length > 1 || Char.IsUpper(screen.Store.DuplicateCode[0]) == false) 
				{
					ModelState.AddModelError("", "Duplicate Code Suffix must be blank or an uppercase letter.");
				}
			}

			if (screen.Store.StoreNumber == 0)
			{
				ModelState.AddModelError("", "Store Number must be 1 or larger");
			}

			if (string.IsNullOrEmpty(screen.Store.DuplicateCode))
			{
				if (db.Store.ActiveFilter().AsNoTracking()
					.Any(x => 
						x.StoreNumber == screen.Store.StoreNumber && 
						string.IsNullOrEmpty(x.DuplicateCode) && 
						x.CompanyID == screen.Store.CompanyID &&
                        !x.DeleteDate.HasValue))
				{
					ModelState.AddModelError("", string.Format("{0} {1}{2} already exists.", screen.Store.CompanyID, screen.Store.StoreNumber, screen.Store.DuplicateCode));
				}
			}
			else
			{
				if (db.Store.ActiveFilter().AsNoTracking()
					.Any(x =>
						x.StoreNumber == screen.Store.StoreNumber &&
						x.DuplicateCode == screen.Store.DuplicateCode.Trim() &&
						x.CompanyID == screen.Store.CompanyID &&
                        !x.DeleteDate.HasValue))
				{
					ModelState.AddModelError("", string.Format("{0} {1}{2} already exists.", screen.Store.CompanyID, screen.Store.StoreNumber, screen.Store.DuplicateCode));
				}
			}

			if (!ModelState.IsValid)
			{
				LoadViewBag(screen);
				return View(screen);
			}

			model.City = screen.Store.City;
			model.CleanupTime = screen.Store.CleanupTime;
			model.Company = screen.Store.Company;
			model.CompanyID = screen.Store.CompanyID;
			model.Local = screen.Store.Local;
			model.Miles = screen.Store.Miles;
			model.StateCode = screen.Store.StateCode;
			model.StoreNumber = screen.Store.StoreNumber;
			model.DuplicateCode = screen.Store.DuplicateCode;
			model.Week1 = screen.Store.Week1;
			model.Week2 = screen.Store.Week2;
			model.ALoadArrivalDayID = screen.Store.ALoadArrivalDayID;
			model.ALoadArrivalTime = screen.Store.ALoadArrivalTime;
			model.BLoadArrivalDayID = screen.Store.BLoadArrivalDayID;
			model.BLoadArrivalTime = screen.Store.BLoadArrivalTime;
			model.ALoadPickDayID = screen.Store.ALoadPickDayID;
			model.SequenceNumber = screen.Store.SequenceNumber;

			foreach (var screenInfo in screen.Carriers)
			{
				if (screenInfo.RatePerMile.HasValue || screenInfo.FlatRate.HasValue || screenInfo.Miles.HasValue)
				{
					StoreCarrierInfo modelInfo = new StoreCarrierInfo
					{
						CarrierID = screenInfo.CarrierID,
						RatePerMile = screenInfo.RatePerMile,
						FlatRate = screenInfo.FlatRate,
						MileageCalcType = screenInfo.MileageCalcType,
						Miles = screenInfo.Miles
					};
					ChangeLogger.LogChange(this, db.Entry(modelInfo));
					model.StoreCarrierInfo.Add(modelInfo);
				}
			}

			db.Store.Add(model);
			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();

			TempData[TEMPDATA_LASTGOODMESSAGE] = string.Format("Store {0} created.", model.StoreAndCompany);
			return RedirectToAction(MAIN_VIEW);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult Edit(int id, string catchall = null)
		{
			Store model = db.Store
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
				.AsNoTracking()
				.Include(x => x.StoreCarrierInfo)
				.SingleOrDefault(x => x.StoreID == id);

            if (model == null)
            {
                throw new ApplicationException("Store ID does not exist.");
            }

            StoreUpdateViewModel viewModel = new StoreUpdateViewModel();
            viewModel.Store = model;

			LoadViewBag(viewModel);

			return View("Edit", viewModel);
		}


		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult Edit(StoreUpdateViewModel screen)
		{
			Store model = db.Store
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .Include(x => x.StoreCarrierInfo)
				.Single(x => x.StoreID == screen.Store.StoreID);

			UInt64 screenTimestamp = BitConverter.ToUInt64(screen.Store.Timestamp, 0);
			UInt64 modelTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

			if (screenTimestamp != modelTimestamp)
			{
				ModelState.Clear();
				ModelState.AddModelError(string.Empty,
					"The record you attempted to edit was modified after you got the original value.\r\n" +
					"The edit operation was canceled and the current values in the database have been displayed.\r\n" +
					"If you still want to edit this record, make the changes again and click the Save button.\r\n" +
					"Otherwise click Back to List.");
				StoreUpdateViewModel viewModel = new StoreUpdateViewModel();
				viewModel.Store = model;
				LoadViewBag(viewModel);
				return View(model);
			}

			if (!string.IsNullOrEmpty(screen.Store.DuplicateCode))
			{
				if (screen.Store.DuplicateCode.Length > 1 || Char.IsUpper(screen.Store.DuplicateCode[0]) == false)
				{
					ModelState.AddModelError("", "Duplicate Code Suffix must be blank or an uppercase letter.");
				}
			}

			if (screen.Store.StoreNumber == 0)
			{
				ModelState.AddModelError("", "Store Number must be 1 or larger");
			}

			if (string.IsNullOrEmpty(screen.Store.DuplicateCode))
			{
				if (db.Store.ActiveFilter()
					.AsNoTracking()
					.Any(x =>
						x.StoreNumber == screen.Store.StoreNumber &&
						string.IsNullOrEmpty(x.DuplicateCode) &&
						x.CompanyID == screen.Store.CompanyID &&
						x.StoreID != screen.Store.StoreID &&
                        !x.DeleteDate.HasValue))
				{
					ModelState.AddModelError("", string.Format("{0} {1}{2} already exists.", screen.Store.CompanyID, screen.Store.StoreNumber, screen.Store.DuplicateCode));
				}
			}
			else
			{
				if (db.Store.ActiveFilter().AsNoTracking()
					.Any(x =>
						x.StoreNumber == screen.Store.StoreNumber &&
						x.DuplicateCode == screen.Store.DuplicateCode.Trim() &&
						x.CompanyID == screen.Store.CompanyID &&
						x.StoreID != screen.Store.StoreID &&
                        !x.DeleteDate.HasValue))
				{
					ModelState.AddModelError("", string.Format("{0} {1}{2} already exists.", screen.Store.CompanyID, screen.Store.StoreNumber, screen.Store.DuplicateCode));
				}
			}

			if (!ModelState.IsValid)
			{
				LoadViewBag(screen);
				return View(screen);
			}

			model.City = screen.Store.City;
			model.CleanupTime = screen.Store.CleanupTime;
			model.Company = screen.Store.Company;
			model.CompanyID = screen.Store.CompanyID;
			model.Local = screen.Store.Local;
			model.Miles = screen.Store.Miles;
			model.StateCode = screen.Store.StateCode;
			model.StoreNumber = screen.Store.StoreNumber;
			model.DuplicateCode = screen.Store.DuplicateCode;
			model.Week1 = screen.Store.Week1;
			model.Week2 = screen.Store.Week2;
			model.ALoadArrivalDayID = screen.Store.ALoadArrivalDayID;
			model.ALoadArrivalTime = screen.Store.ALoadArrivalTime;
			model.BLoadArrivalDayID = screen.Store.BLoadArrivalDayID;
			model.BLoadArrivalTime = screen.Store.BLoadArrivalTime;
			model.ALoadPickDayID = screen.Store.ALoadPickDayID;
			model.SequenceNumber = screen.Store.SequenceNumber;

			foreach (StoreCarrierInfo modelInfo in model.StoreCarrierInfo.ToList())
			{
				var screenInfo = screen.Carriers.FirstOrDefault(x => x.CarrierID == modelInfo.CarrierID);
				if (screenInfo == null || (screenInfo.RatePerMile.HasValue == false && screenInfo.FlatRate.HasValue == false && screenInfo.Miles.HasValue == false))
				{
					model.StoreCarrierInfo.Remove(modelInfo);
				}
			}

			foreach (var screenInfo in screen.Carriers)
			{
				var modelInfo = model.StoreCarrierInfo.FirstOrDefault(x => x.CarrierID == screenInfo.CarrierID);
				if (modelInfo == null)
				{
					if (screenInfo.RatePerMile.HasValue || screenInfo.FlatRate.HasValue || screenInfo.Miles.HasValue)
					{
						modelInfo = new StoreCarrierInfo
						{
							CarrierID = screenInfo.CarrierID,
							RatePerMile = screenInfo.RatePerMile,
							FlatRate = screenInfo.FlatRate,
							MileageCalcType = screenInfo.MileageCalcType,
							Miles = screenInfo.Miles
						};
						ChangeLogger.LogChange(this, db.Entry(modelInfo));
						model.StoreCarrierInfo.Add(modelInfo);
					}
				}
				else
				{
					modelInfo.RatePerMile = screenInfo.RatePerMile;
					modelInfo.FlatRate = screenInfo.FlatRate;
					modelInfo.MileageCalcType = screenInfo.MileageCalcType;
					modelInfo.Miles = screenInfo.Miles;
					ChangeLogger.LogChange(this, db.Entry(modelInfo));
				}
			}

			ChangeLogger.LogChange(this, db.Entry(model));

			db.SaveChanges();

			TempData[TEMPDATA_LASTGOODMESSAGE] = string.Format("Store {0} updated.", model.StoreAndCompany);
			return RedirectToAction(MAIN_VIEW);
		}

		private void LoadViewBag(StoreUpdateViewModel viewModel)
		{
			var CompanyList = db.Company
				.AsNoTracking()
				.OrderBy(x => x.CompanyID)
				.Select(x => new
				{
					Value = x.CompanyID,
					Text = x.CompanyName
				});

			var states = CountryStates.USStates
				.AsEnumerable()
				.Select(x => new
				{
					Text = x.Value,
					Value = x.Key
				});

			var WeekDayList = db.WeekDay
				.AsNoTracking()
				.OrderBy(x => x.WeekDayID)
				.ToList()
				.Select(x => new
				{
					Value = x.WeekDayID,
					Text = string.Format("{0} ({1})", x.LongName, x.WeekDayID)
				});

			if (viewModel.Store == null)
			{
				ViewBag.CompanyID = new SelectList(CompanyList, "Value", "Text");
				ViewBag.StateCode = new SelectList(states, "Value", "Text");
				ViewBag.ALoadPickDayID = new SelectList(WeekDayList, "Value", "Text");
				ViewBag.ALoadArrivalDayID = new SelectList(WeekDayList, "Value", "Text");
				ViewBag.BLoadArrivalDayID = new SelectList(WeekDayList, "Value", "Text");
			}
			else
			{
				ViewBag.CompanyID = new SelectList(CompanyList, "Value", "Text", viewModel.Store.CompanyID);
				ViewBag.StateCode = new SelectList(states, "Value", "Text", viewModel.Store.StateCode);
				ViewBag.ALoadPickDayID = new SelectList(WeekDayList, "Value", "Text", viewModel.Store.ALoadPickDayID);
				ViewBag.ALoadArrivalDayID = new SelectList(WeekDayList, "Value", "Text", viewModel.Store.ALoadArrivalDayID);
				ViewBag.BLoadArrivalDayID = new SelectList(WeekDayList, "Value", "Text", viewModel.Store.BLoadArrivalDayID);
			}

			var carriers = db.Carrier
                .ActiveFilter()
                .OrderBy(x => x.Name)
				.Select(x => new StoreUpdateViewModel.CarrierInfo
				{
					CarrierID = x.CarrierID,
					Name = x.Name
				})
				.ToList();

			if (viewModel.Store != null && viewModel.Store.StoreCarrierInfo != null)
			{
				foreach (var carrier in carriers)
				{
					StoreCarrierInfo sci = viewModel.Store.StoreCarrierInfo.FirstOrDefault(x => x.CarrierID == carrier.CarrierID);
					if (sci != null)
					{
						carrier.RatePerMile = sci.RatePerMile;
						carrier.FlatRate = sci.FlatRate;
						carrier.MileageCalcType = sci.MileageCalcType;
						carrier.Miles = sci.Miles;
					}
				}
			}
			else if (viewModel.Store != null)
			{
				foreach (var carrier in carriers)
				{
					StoreUpdateViewModel.CarrierInfo sci = viewModel.Carriers.FirstOrDefault(x => x.CarrierID == carrier.CarrierID);
					if (sci != null)
					{
						carrier.RatePerMile = sci.RatePerMile;
						carrier.FlatRate = sci.FlatRate;
						carrier.MileageCalcType = sci.MileageCalcType;
						carrier.Miles = sci.Miles;
					}
				}
			}

			viewModel.Carriers = carriers;
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Delete(int id)
		{
			DateTime oldestOpenDispatchDate = db.OpenDispatchDates().OldestDispatchDate();

			Store model = db.Store
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .SingleOrDefault(x => x.StoreID == id);

            if (model == null)
            {
                throw new ApplicationException("Store ID does not exist.");
            }

            db.Entry(model).Collection(x => x.AssignedAsLoad1).Load();
			if (model.AssignedAsLoad1 != null)
			{
				foreach (var schedule in model.AssignedAsLoad1)
				{
					ModelState.AddModelError("", string.Format("Store is assigned to an Outbound Schedule for Week {0} Day {1} and must be removed first.",
						schedule.WeekNumber, schedule.WeekDayID));
				}
			}

			db.Entry(model).Collection(x => x.AssignedAsLoad2).Load();
			if (model.AssignedAsLoad2 != null)
			{
				foreach (var schedule in model.AssignedAsLoad2)
				{
					ModelState.AddModelError("", string.Format("Store is assigned to an Outbound Schedule for Week {0} Day {1} and must be removed first.",
						schedule.WeekNumber, schedule.WeekDayID));
				}
			}

			db.Entry(model).Collection(x => x.AssignedAsLoad3).Load();
			if (model.AssignedAsLoad3 != null)
			{
				foreach (var schedule in model.AssignedAsLoad3)
				{
					ModelState.AddModelError("", string.Format("Store is assigned to an Outbound Schedule for Week {0} Day {1} and must be removed first.",
						schedule.WeekNumber, schedule.WeekDayID));
				}
			}

			db.Entry(model).Collection(x => x.Loads).Query()
				.Where(x => x.DailyDispatchID.HasValue == false || x.DailyDispatch.DispatchDate >= oldestOpenDispatchDate)
				.Load();
			if (model.Loads != null)
			{
				foreach (var load in model.Loads)
				{
					if (load.DailyDispatchID.HasValue)
					{
						db.Entry(load).Reference(x => x.DailyDispatch).Load();
						ModelState.AddModelError("", string.Format("Store is referenced by Load {0} on active Dispatch {1} for {2}.",
							load.LoadName, load.DailyDispatchID, load.DailyDispatch.DispatchDate.ToShortDateString()));
					}
					else
					{
						ModelState.AddModelError("", string.Format("Store is referenced by Load {0} which is not assigned to a Dispatch.",
							load.LoadName));
					}
				}
			}

			if (!ModelState.IsValid)
			{
				return Edit(id);
			}

			// Remove the references to OutboundRoutes from the record. This will remove the store from the CleanupXStores in the OutboundRoute.
			
			db.Entry(model).Collection(x => x.AssignedAsCleanup1).Load();
			if (model.AssignedAsCleanup1 != null)
			{
				model.AssignedAsCleanup1.Clear();
			}

			db.Entry(model).Collection(x => x.AssignedAsCleanup2).Load();
			if (model.AssignedAsCleanup2 != null)
			{
				model.AssignedAsCleanup2.Clear();
			}
			
			db.Entry(model).Collection(x => x.AssignedAsCleanup3).Load();
			if (model.AssignedAsCleanup3 != null)
			{
				model.AssignedAsCleanup3.Clear();
			}

			// if store is still attached to loads on closed dispatches, then the record must be logically deleted, which retains the record in a hidden state.

			bool historicalLoadsExist = db.Load
				.Include(x => x.DailyDispatch)
				.Where(x => x.DailyDispatch.DispatchDate < oldestOpenDispatchDate)
				.Any(x => x.StoreID == model.StoreID);

			bool linkedDataToRetainExists = db.StoreCarrierInfo
				.Any(x => x.StoreID == model.StoreID);

			TempData[TEMPDATA_LASTGOODMESSAGE] = string.Format("Store {0} deleted.", model.StoreAndCompany);

			try
			{
				if (historicalLoadsExist || linkedDataToRetainExists)
				{
					ChangeLogger.LogLogicalDelete(this, db.Entry(model), string.Format("Store {0} [ID={1}] marked as deleted.", model.StoreAndCompanyLong, model.StoreID));
				}
				else
				{
					db.Store.Remove(model);
					ChangeLogger.LogChange(this, db.Entry(model));
				}
				db.SaveChanges();
			}
			catch (System.Data.Entity.Infrastructure.DbUpdateException ex)
			{
				string recordIdent = string.Format("Store {0} [ID={1}]", model.StoreAndCompanyLong, model.StoreID);
				string message = string.Format("Error attempting to delete: {0}. Foreign Key relationships may be preventing deletion.", recordIdent);
				throw new Exception(message, ex);
			}

			return RedirectToAction(MAIN_VIEW);
		}

		#endregion

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}