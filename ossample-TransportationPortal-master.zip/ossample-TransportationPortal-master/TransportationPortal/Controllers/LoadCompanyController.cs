﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using HobbyLobby.SAP.Proxy.Soap.TransDispatch;
using HobbyLobby.HLUtil.Logging;
using Avatar;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class LoadCompanyController : Controller
	{
		private DispatchContext db = new DispatchContext();

		public SelectListItem[] DeliveryTypes = 
		{
			new SelectListItem { Value = DatabaseLists.LOAD_DELIVERY_TYPE_WAREHOUSE, Text = "Warehouse" },
			new SelectListItem { Value = DatabaseLists.LOAD_DELIVERY_TYPE_OKC_DISPATCH, Text = "OKC Dispatch" },
			new SelectListItem { Value = DatabaseLists.LOAD_DELIVERY_TYPE_DALLAS_DISPATCH, Text = "Dallas Dispatch"},
			new SelectListItem { Value = DatabaseLists.LOAD_DELIVERY_TYPE_DIRECT, Text = "Direct Delivery" }
		};

		public string FilterSessionName
		{
			get { return this.GetType().Name + ".Filter"; }
		}

		#region Index methods

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ViewResult Index(int? id)
		{
			LoadCompanyIndexViewModel viewModel = Session[FilterSessionName] as LoadCompanyIndexViewModel;
			if (viewModel == null)
			{
				viewModel = new LoadCompanyIndexViewModel
				{
					IsBroker = null,
					IsVendor = null,
					IsPickupAddress = null,
					IsDeliveryAddress = null
				};
				viewModel.Paging = new PagingViewModel
				{
					Page = 1,
					PageSize = 50,
					LinksBeforeCurrentPage = 4,
					LinksAfterCurrentPage = 4,
				};
			}
			else if (id.HasValue)
			{
				if (viewModel.Paging.Page != id.Value)
				{
					ViewBag.OverrideSavedPosition = "0_0";
				}
				viewModel.Paging.Page = id.Value;
			}

			// Generate the new view model.
			viewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = viewModel;

			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ViewResult Index(LoadCompanyIndexViewModel viewModel)
		{
			// Copy any items needed that were not returned.
			LoadCompanyIndexViewModel previousViewModel = Session[FilterSessionName] as LoadCompanyIndexViewModel;
			if (previousViewModel != null)
			{
				viewModel.Paging = previousViewModel.Paging;
				viewModel.Paging.Page = 1;
			}

			// Generate the new view model.
			viewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = viewModel;

			return View(viewModel);
		}

		protected LoadCompanyIndexViewModel GenerateViewModel(LoadCompanyIndexViewModel viewModel)
		{
			var list = db.LoadCompanies(
				isBroker: viewModel.IsBroker,
				isVendor: viewModel.IsVendor,
				isPickupAddress: viewModel.IsPickupAddress,
				isDeliveryAddress: viewModel.IsDeliveryAddress,
				isHLCompany: viewModel.IsHLCompany)
				.AsNoTracking();

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim();
				Int64 intValue = 0;
				decimal decValue = 0m;
				bool isNumber = Decimal.TryParse(textValue, out decValue);
				if (isNumber)
				{
					intValue = Decimal.ToInt64(decValue);
				}

				if (isNumber && intValue > 0)
				{
					list = list.Where(x =>
						x.LoadCompanyID == intValue
						|| x.SapEntity == textValue
						|| x.Name.Contains(textValue)
						|| x.Address1.Contains(textValue)
						|| x.Address2.Contains(textValue)
						|| x.City.Contains(textValue)
						|| x.StateCode.Contains(textValue)
						|| x.Zip.Contains(textValue)
						|| x.Contact.Contains(textValue)
						|| x.Email.Contains(textValue)
						);
				}
				else
				{
					list = list.Where(x =>
						x.Name.Contains(textValue)
						|| x.Address1.Contains(textValue)
						|| x.Address2.Contains(textValue)
						|| x.City.Contains(textValue)
						|| x.StateCode.Contains(textValue)
						|| x.Zip.Contains(textValue)
						|| x.Contact.Contains(textValue)
						|| x.Email.Contains(textValue)
						|| x.SapEntity.Contains(textValue)
						);
				}
			}

			viewModel.Companies = list
				.OrderBy(x => x.Name)
				.Skip((viewModel.Paging.Page - 1) * viewModel.Paging.PageSize)
				.Take(viewModel.Paging.PageSize)
				.ToList()
				.Select(x => new LoadCompanyViewModel(x));

			// Paging setup.
			viewModel.Paging.TotalRecords = list.Count();

			return viewModel;
		}

		#endregion

		#region Details, Create, and Update

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)] 
		public ViewResult Details(int id)
		{
			LoadCompany model = db.LoadCompany.Find(id);

			return View(model);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)] 
		public ActionResult Create()
		{
			LoadCompanyEditViewModel viewModel = new LoadCompanyEditViewModel
			{
				LoadCompany = new LoadCompany()
			};

			LoadViewBag(viewModel);

			return View("Create", viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)] 
		public ActionResult Create(LoadCompanyEditViewModel model)
		{
			if (string.IsNullOrWhiteSpace(model.LoadCompany.Name))
			{
				ModelState.AddModelError("", "Name is required.");
			}

			if (db.LoadCompany.Any(x => x.Name.Trim().ToUpper() == model.LoadCompany.Name.Trim().ToUpper()))
			{
				ModelState.AddModelError("", string.Format("{0} already exists.", model.LoadCompany.Name));
			}

			if (model.LoadCompany.IsBroker)
			{
				if (string.IsNullOrWhiteSpace(model.LoadCompany.Address1))
				{
					ModelState.AddModelError("", "Address1 is required for Brokers.");
				}
				if (string.IsNullOrWhiteSpace(model.LoadCompany.City))
				{
					ModelState.AddModelError("", "City is required for Brokers.");
				}
				if (string.IsNullOrWhiteSpace(model.LoadCompany.StateCode))
				{
					ModelState.AddModelError("", "State is required for Brokers.");
				}
				if (string.IsNullOrWhiteSpace(model.LoadCompany.Zip))
				{
					ModelState.AddModelError("", "Zip is required for Brokers.");
				}
			}

			if (!ModelState.IsValid)
			{
				LoadViewBag(model);
				return View(model);
			}

			switch (model.LoadCompany.DeliveryType)
			{
				case DatabaseLists.LOAD_DELIVERY_TYPE_WAREHOUSE:
					model.LoadCompany.DeliveryCompanyID = model.DeliveryCompanyHL.LoadCompanyID;
					break;
				case DatabaseLists.LOAD_DELIVERY_TYPE_DALLAS_DISPATCH:
				case DatabaseLists.LOAD_DELIVERY_TYPE_DIRECT:
				case DatabaseLists.LOAD_DELIVERY_TYPE_OKC_DISPATCH:
					model.LoadCompany.DeliveryCompanyID = model.DeliveryCompany.LoadCompanyID;
					break;
				default:
					model.LoadCompany.DeliveryCompanyID = null;
					break;
			}


			db.LoadCompany.Add(model.LoadCompany);
			ChangeLogger.LogChange(this, db.Entry(model.LoadCompany));
			db.SaveChanges();
			TempData["LastGoodMessage"] = string.Format("Load Company record {0} added.", model.LoadCompany.LoadCompanyID);
			return RedirectToAction("Index");
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)] 
		public ActionResult Edit(int id)
		{
			LoadCompany model = db.LoadCompany
				.AsNoTracking()
				.Include(x => x.DeliveryCompany)
				.Single(x => x.LoadCompanyID == id);

			LoadCompanyEditViewModel viewModel = new LoadCompanyEditViewModel(model);

			LoadViewBag(viewModel);

			return View("Edit", viewModel);
		}


		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)] 
		public ActionResult Edit(LoadCompanyEditViewModel screen)
		{
			LoadCompany model = db.LoadCompany.Find(screen.LoadCompany.LoadCompanyID);

			UInt64 screenTimestamp = BitConverter.ToUInt64(screen.LoadCompany.Timestamp, 0);
			UInt64 modelTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

			if (screenTimestamp != modelTimestamp)
			{
				ModelState.Clear();
				ModelState.AddModelError(string.Empty,
					"The record you attempted to edit was modified after you got the original value.\r\n" +
					"The edit operation was canceled and the current values in the database have been displayed.\r\n" +
					"If you still want to edit this record, make the changes again and click the Save button.\r\n" +
					"Otherwise click Back to List.");
				LoadViewBag(screen);
				return View(screen);
			}

			if (string.IsNullOrWhiteSpace(screen.LoadCompany.Name))
			{
				ModelState.AddModelError("", "Name is required.");
			}

			if (db.LoadCompany.Any(x => x.Name.Trim().ToUpper() == screen.LoadCompany.Name.Trim().ToUpper() && x.LoadCompanyID != screen.LoadCompany.LoadCompanyID))
			{
				ModelState.AddModelError("", string.Format("{0} already exists.", screen.LoadCompany.Name));
			}

			if (screen.LoadCompany.IsBroker)
			{
				if (string.IsNullOrWhiteSpace(screen.LoadCompany.Address1))
				{
					ModelState.AddModelError("", "Address1 is required for Brokers.");
				}
				if (string.IsNullOrWhiteSpace(screen.LoadCompany.City))
				{
					ModelState.AddModelError("", "City is required for Brokers.");
				}
				if (string.IsNullOrWhiteSpace(screen.LoadCompany.StateCode))
				{
					ModelState.AddModelError("", "State is required for Brokers.");
				}
				if (string.IsNullOrWhiteSpace(screen.LoadCompany.Zip))
				{
					ModelState.AddModelError("", "Zip is required for Brokers.");
				}
			}
			
			if (!ModelState.IsValid)
			{
				LoadViewBag(screen);
				return View(screen);
			}

			model.IsBroker = screen.LoadCompany.IsBroker;
			model.IsVendor = screen.LoadCompany.IsVendor;
			model.IsPickupAddress = screen.LoadCompany.IsPickupAddress;
			model.IsDeliveryAddress = screen.LoadCompany.IsDeliveryAddress;
			model.IsCompanyAddress = screen.LoadCompany.IsCompanyAddress;

			model.Address1 = screen.LoadCompany.Address1;
			model.Address2 = screen.LoadCompany.Address2;
			model.City = screen.LoadCompany.City;
			model.Class = screen.LoadCompany.Class;
			model.CompanyRef = screen.LoadCompany.CompanyRef;
			model.Contact = screen.LoadCompany.Contact;
			model.CountryCode = screen.LoadCompany.CountryCode;
			model.Miles = screen.LoadCompany.Miles;
			model.Name = screen.LoadCompany.Name;
			model.Phone = screen.LoadCompany.Phone;
			model.Reference = screen.LoadCompany.Reference;
			model.SapEntity = screen.LoadCompany.SapEntity;
			model.SapEntityName = screen.LoadCompany.SapEntityName;
			model.StateCode = screen.LoadCompany.StateCode;
			model.Zip = screen.LoadCompany.Zip;
			model.Zone = screen.LoadCompany.Zone;
			model.AvailableTimes = screen.LoadCompany.AvailableTimes;
			model.Email = screen.LoadCompany.Email;
			model.Type = screen.LoadCompany.Type;

			model.DeliveryType = screen.LoadCompany.DeliveryType;

			switch (model.DeliveryType)
			{
				case DatabaseLists.LOAD_DELIVERY_TYPE_WAREHOUSE:
					model.DeliveryCompanyID = screen.DeliveryCompanyHL.LoadCompanyID;
					break;
				case DatabaseLists.LOAD_DELIVERY_TYPE_DALLAS_DISPATCH:
				case DatabaseLists.LOAD_DELIVERY_TYPE_DIRECT:
				case DatabaseLists.LOAD_DELIVERY_TYPE_OKC_DISPATCH:
					model.DeliveryCompanyID = screen.DeliveryCompany.LoadCompanyID;
					break;
				default:
					model.DeliveryCompanyID = null;
					break;
			}

			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();
			TempData["LastGoodMessage"] = string.Format("Load Company record {0} updated.", model.LoadCompanyID);
			return RedirectToAction("Index");
		}

		private void LoadViewBag(LoadCompanyEditViewModel viewModel = null)
		{
			if (viewModel.LoadCompany == null)
			{
				ViewBag.DeliveryType = new SelectList(DeliveryTypes, "Value", "Text");
			}
			else
			{
				ViewBag.DeliveryType = new SelectList(DeliveryTypes, "Value", "Text", viewModel.LoadCompany.DeliveryType);
			}

			var countries = CountryStates.GetCountryCodes()
				.AsEnumerable()
				.Select(x => new
				{
					Text = x.Value,
					Value = x.Key
				});

			if (viewModel.LoadCompany == null)
			{
				ViewBag.CountryCode = new SelectList(countries, "Value", "Text");
			}
			else
			{
				ViewBag.CountryCode = new SelectList(countries, "Value", "Text", viewModel.LoadCompany.CountryCode);
			}

			ViewBag.NewBrokerEmailAddress = LibConfigProperties.Settings.NewBrokerEmailAddress;
			ViewBag.NewBrokerEmailSubject = LibConfigProperties.Settings.NewBrokerEmailSubject;
		}
		
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Delete(int id)
		{
			LoadCompany model = db.LoadCompany.Find(id);
			db.Entry(model).Collection(x => x.AssignedAsBroker).Load();
			db.Entry(model).Collection(x => x.AssignedAsPickup).Load();
			db.Entry(model).Collection(x => x.AssignedAsDelivery).Load();

			if (model.AssignedAsBroker.Count > 0)
			{
				ModelState.AddModelError(string.Empty, "This Company has one or more Inbound Loads referencing this Company as Broker. Cannot delete.");
			}

			if (model.AssignedAsPickup.Count > 0)
			{
				ModelState.AddModelError(string.Empty, "This Company has one or more Inbound Loads referencing this Company as Pickup location. Cannot delete.");
			}

			if (model.AssignedAsDelivery.Count > 0)
			{
				ModelState.AddModelError(string.Empty, "This Company has one or more Inbound Loads referencing this Company as Delivery location. Cannot delete.");
			}

			if (!ModelState.IsValid)
			{
				return RedirectToAction("Edit", new { id = id });
			}

			db.LoadCompany.Remove(model);
			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();
			return RedirectToAction("Index");
		}

		#endregion

		#region Ajax Methods

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)] 
		public PartialViewResult VerifySapEntity(string id)
		{
			LoadCompany viewModel = new LoadCompany();

			try
			{
				ZFITransDispatchProxy sapProxy = new ZFITransDispatchProxy(LibConfigProperties.Settings.SapEnvironment);
				var brokerList = sapProxy.GetBroker(id, string.Empty);
				if (brokerList != null && brokerList.Count == 1)
				{
					viewModel.SapEntityName = brokerList[0].CustomerName;
				}
				else
				{
					viewModel.SapEntityName = "Not Matched";
				}
			}
			catch (System.Web.Services.Protocols.SoapException e)
			{
				viewModel.SapEntityName = e.Message;
			}
			catch (Exception e)
			{
				HLLogging.Error(e.Message, e);
				viewModel.SapEntityName = "Error occurred during lookup.";
			}

			return PartialView("_SapEntityName", viewModel);
		}


		[ChildActionOnly]
		public PartialViewResult GetCountryStateCodes(LoadCompany LoadCompany)
		{
			if (LoadCompany != null && !string.IsNullOrEmpty(LoadCompany.CountryCode) && !string.IsNullOrEmpty(LoadCompany.StateCode))
			{
				return CountryStateCodes(LoadCompany.CountryCode, LoadCompany.StateCode);
			}
			else
			{
				return CountryStateCodes("USA");
			}
		}

		[HttpPost]
		public PartialViewResult UpdateCountryStateCodes(string CountryCode)
		{
			return CountryStateCodes(CountryCode);
		}

		private PartialViewResult CountryStateCodes(string CountryCode, string StateCode = null)
		{
			SelectList response = null;

			try
			{
				var states = CountryStates.GetStatesForCountry(CountryCode)
					.AsEnumerable()
					.Select(x => new
					{
						Text = x.Value,
						Value = x.Key
					});

				if (StateCode == null)
				{
					response = new SelectList(states, "Value", "Text");
				}
				else
				{
					response = new SelectList(states, "Value", "Text", StateCode);
				}
			}
			catch (Exception ex)
			{
				HLLogging.Error("Error in CreateCountryStateCodes Ajax method", ex);
			}

			return response != null ? PartialView("_StateCodeSelect", response) : PartialView("_StateCodeSelect");
		}

		[HttpPost]
		public ActionResult SelectCompany(LoadSelectCompanyViewModel model)
		{
			if (model == null)
			{
				model = new LoadSelectCompanyViewModel();
			}

			if (!ModelState.IsValid)
			{
				model.Companies = Enumerable.Empty<LoadCompany>();
			}
			else
			{
				var companies = db.LoadCompany.AsNoTracking().AsQueryable();

				if (model.IsBroker)
				{
					companies = companies.Where(x => x.IsBroker == true);
				}
				else if (model.IsVendor)
				{
					companies = companies.Where(x => x.IsVendor == true);
				}
				else if (model.IsPickupAddress)
				{
					companies = companies.Where(x => x.IsPickupAddress == true);
				}
				else if (model.IsDeliveryAddress)
				{
					companies = companies.Where(x => x.IsDeliveryAddress == true);
				}

				if (!string.IsNullOrWhiteSpace(model.Search))
				{
					string textValue = model.Search.Trim();
					companies = companies.Where(x =>
						x.Name.Contains(textValue)
						|| x.Address1.Contains(textValue)
						|| x.Address2.Contains(textValue)
						|| x.City.Contains(textValue)
						|| x.StateCode.Contains(textValue)
						|| x.Zip.Contains(textValue)
						|| x.CountryCode.Contains(textValue)
						|| x.Contact.Contains(textValue)
						|| x.Email.Contains(textValue)
						);
				}

				model.Companies = companies.Take(100);
			}

			return PartialView("_SelectLoadCompany", model);
		}


		public ActionResult SelectedCompany(int id, string BindPrefix)
		{
			LoadCompany model = db.LoadCompany
				.Single(x => x.LoadCompanyID == id);

			LoadCompanyViewModel viewModel = new LoadCompanyViewModel(model);

			ViewData.TemplateInfo.HtmlFieldPrefix = BindPrefix;

			return PartialView("_SelectedLoadCompany", viewModel);
		}

		[ChildActionOnly]
		public PartialViewResult GetHLDeliveryCompanies(LoadCompanyViewModel DeliveryHL, string BindPrefix)
		{
			LoadCompanyHLViewModel viewModel = new LoadCompanyHLViewModel();
			if (DeliveryHL != null)
			{
				viewModel.LoadCompanyID = DeliveryHL.LoadCompanyID;
			}

			viewModel.Companies = db.LoadCompany
				.Where(x => x.IsCompanyAddress == true && x.IsDeliveryAddress == true)
				.OrderBy(x => x.Name)
				.ToList()
				.Select(x => new LoadCompanyViewModel(x));

			ViewData.TemplateInfo.HtmlFieldPrefix = BindPrefix;

			return PartialView("_HLCompanyList", viewModel);
		}

		#endregion



		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}