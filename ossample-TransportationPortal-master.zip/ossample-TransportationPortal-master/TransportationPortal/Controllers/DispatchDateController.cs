﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using System.Data.Objects.SqlClient;
using System.Data.SqlClient;
using Avatar;
using System.Threading.Tasks;
using System.Threading;
using HobbyLobby.HLUtil.Logging;
using System.Text;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class DispatchDateController : AsyncController
	{
		private DispatchContext db = new DispatchContext();

		private static object[] WeekList = new[]
		{
			new { Number = 1, Name = "Week 1"},
			new { Number = 2, Name = "Week 2"},
		};

		/// <summary>
		/// This date is a Sunday and a Week 1. 
		/// The first date inserted into the DispatchDateControl table will have the week number calculated relative to this date.
		/// </summary>
		private DateTime WEEK_NUMBER_ONE_ANCHOR_DATE = new DateTime(2012, 5, 20);

		private string FilterSessionName
		{
			get { return this.GetType().Name + ".Filter"; }
		}

		public string NonceSessionName
		{
			get { return this.GetType().Name + ".Nonces"; }
		}

		#region Index view

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index()
		{
			DispatchDateIndexViewModel viewModel = Session[FilterSessionName] as DispatchDateIndexViewModel;
			if (viewModel == null)
			{
				viewModel = new DispatchDateIndexViewModel();
			}

			// Generate the new view model.
			DispatchDateIndexViewModel newViewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index(DispatchDateIndexViewModel viewModel)
		{
			// Copy any items needed that were not returned.
			DispatchDateIndexViewModel savedViewModel = Session[FilterSessionName] as DispatchDateIndexViewModel;
			if (savedViewModel != null)
			{
			}

			// Generate the new view model.
			DispatchDateIndexViewModel newViewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		private DispatchDateIndexViewModel GenerateViewModel(DispatchDateIndexViewModel viewModel)
		{
			var list = db.DispatchDateControl.AsNoTracking().AsQueryable();

			viewModel.DispatchDates = list
				.Where(x => x.Closed == false)
				.OrderBy(x => x.DispatchDate)
				.Include(x => x.WeekDay)
				.Include(x => x.TemplateWeekDay)
				.Select(x => new DispatchDateIndexViewModel.DispatchDate
				{
					Date = x.DispatchDate,
					WeekNumber = x.WeekNumber,
					WeekDayID = x.WeekDayID,
					WeekDayName = x.WeekDay.LongName,
					TemplateWeekNumber = x.TemplateWeekNumber,
					TemplateWeekDayID = x.TemplateWeekDayID,
					TemplateWeekDayName = x.TemplateWeekDay.LongName,
				});
			 
			return viewModel;
		}

		#endregion

		#region Create new dispatch date

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Create()
		{
			int activeDispatchDates = db.DispatchDateControl.Count(x => x.Closed == false);
			if (activeDispatchDates >= LibConfigProperties.Settings.MaximumDispatchDatesActive)
			{
				TempData["LastGoodMessage"] = string.Format("Maximum number of {0} active dispatch dates already exists.", LibConfigProperties.Settings.MaximumDispatchDatesActive);
				return RedirectToAction("Index");
			}

			DispatchDateControl model = new DispatchDateControl();

			if (db.DispatchDateControl.Count() > 0)
			{
				DateTime maxDispatchDate = db.DispatchDateControl.Max(x => x.DispatchDate);

				DispatchDateControl currentDispatchDate = db.DispatchDateControl.Find(maxDispatchDate);

				/*
				 * Build the next dispatch control record. Skip Saturday and Sunday.
				 */

				switch (currentDispatchDate.WeekDayID)
				{
					case 1:		// Sunday
						model.DispatchDate = currentDispatchDate.DispatchDate.AddDays(1);
						model.WeekNumber = currentDispatchDate.WeekNumber;
						model.WeekDayID = 2;
						break;
					case 2:		// Monday
						model.DispatchDate = currentDispatchDate.DispatchDate.AddDays(1);
						model.WeekNumber = currentDispatchDate.WeekNumber;
						model.WeekDayID = 3;
						break;
					case 3:		// Tueday
						model.DispatchDate = currentDispatchDate.DispatchDate.AddDays(1);
						model.WeekNumber = currentDispatchDate.WeekNumber;
						model.WeekDayID = 4;
						break;
					case 4:		// Wednesday
						model.DispatchDate = currentDispatchDate.DispatchDate.AddDays(1);
						model.WeekNumber = currentDispatchDate.WeekNumber;
						model.WeekDayID = 5;
						break;
					case 5:		// Thursday
						model.DispatchDate = currentDispatchDate.DispatchDate.AddDays(1);
						model.WeekNumber = currentDispatchDate.WeekNumber == 1 ? 2 : 1;
						model.WeekDayID = 6;
						break;
					case 6:		// Friday
						model.DispatchDate = currentDispatchDate.DispatchDate.AddDays(3);
						model.WeekNumber = currentDispatchDate.WeekNumber;
						model.WeekDayID = 2;
						break;
					case 7:		// Saturday
						model.DispatchDate = currentDispatchDate.DispatchDate.AddDays(2);
						model.WeekNumber = currentDispatchDate.WeekNumber;
						model.WeekDayID = 2;
						break;
				}

				model.WeekDay = db.WeekDay.Find(model.WeekDayID);
			}
			else
			{
				model.DispatchDate = DateTime.Today;
				model.WeekDayID = (int)model.DispatchDate.DayOfWeek + 1;

				// Calculate the week number (1 or 2) for the dispatch date.
				TimeSpan timespanSinceAnchorDate = model.DispatchDate - WEEK_NUMBER_ONE_ANCHOR_DATE;
				int weeksWhole = (int)timespanSinceAnchorDate.TotalDays / 7;
				int weekNumber = (weeksWhole % 2) == 0 ? 1 : 2;

				model.WeekNumber = weekNumber;

				model.WeekDay = db.WeekDay.Find(model.WeekDayID);
			}

			model.TemplateWeekNumber = model.WeekNumber;
			model.TemplateWeekDayID = model.WeekDayID;
			model.TemplateWeekDay = model.TemplateWeekDay;

			DispatchDateCreateViewModel viewModel = new DispatchDateCreateViewModel();
			viewModel.DispatchDateControl = model;

			// Create nonce to ensure only one Create happens.
			List<long> nonces = Session[NonceSessionName] as List<long>;
			if (nonces == null)
			{
				nonces = new List<long>();
				Session[NonceSessionName] = nonces;
			}
			long nonce = DateTime.Now.Ticks;
			viewModel.Nonce = nonce;
			nonces.Add(nonce);

			LoadViewBag(viewModel);

			return View(viewModel);
		}

		/// <summary>
		/// Async method to start to the Dispatch Date Creation. CreateComplete is called upon completion of all started tasks or if no tasks were started.
		/// The ViewModel is always passed to the CreateComplete method. It contains a flag to indicate completion and a message if an error occured.
		/// </summary>
		/// <param name="viewModel"></param>
		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		[AsyncTimeout(300000)]
		public void CreateAsync(DispatchDateCreateViewModel viewModel)
		{
			// Always send the viewModel to the CreateComplete method.
			AsyncManager.Parameters["viewModel"] = viewModel;

			List<long> nonces = Session[NonceSessionName] as List<long>;
			if (nonces != null)
			{
				if (viewModel.Nonce.HasValue)
				{
					lock (Session.SyncRoot)
					{
						if (nonces.Contains(viewModel.Nonce.Value))
						{
							nonces.Remove(viewModel.Nonce.Value);
							DispatchDateControl dispatchDateControl = db.DispatchDateControl.SingleOrDefault(x => x.DispatchDate == viewModel.DispatchDateControl.DispatchDate);
							if (dispatchDateControl != null)
							{
								viewModel.Message = "Dispatch Date Control Record already created (Record Exists).";
							}
							else
							{
								AsyncManager.OutstandingOperations.Increment(2);

								Task primaryTask = Task.Factory.StartNew(() =>
								{
									CreateTheDispatchDate(viewModel);
									AsyncManager.OutstandingOperations.Decrement();
								});

								Task.Factory.StartNew(() =>
								{
									DoKeepAlive(primaryTask);
									AsyncManager.OutstandingOperations.Decrement();
								});
							}
						}
						else
						{
							viewModel.Message = "Dispatch Date Control Record already created (Screen Nonce not found).";
						}
					}
				}
				else
				{
					viewModel.Message = "Dispatch Date Control Record already created (Screen Nonce not in input data).";
				}
			}
			else
			{
				viewModel.Message = string.Format("Session object for {0} not found. Execution aborted.", NonceSessionName);
			}
		}

		public ViewResult CreateCompleted(DispatchDateCreateViewModel viewModel)
		{
			if (viewModel.Complete)
			{
				viewModel.DispatchDateControl = db.DispatchDateControl
					.Include(x => x.WeekDay)
					.Single(x => x.DispatchDate == viewModel.DispatchDateControl.DispatchDate);

				string message = string.Format("Dispatch Date {0:d} created by {1}.", viewModel.DispatchDateControl.DispatchDate, this.User.Identity.Name);
				TempData["LastGoodMessage"] = message;
				HLLogging.Info(message);
			}
			else
			{
				TempData["LastGoodMessage"] = viewModel.Message;
				HLLogging.ErrorFormat("{0} {1}", viewModel.Message, this.User.Identity.Name);
			}

			LoadViewBag(viewModel);
			return View(viewModel);
		}
		
		#endregion

		#region Re-create the dispatch date

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Recreate(long id)
		{
			DateTime dispatchDate = DateTime.FromBinary(id);

			DispatchDateControl model = db.DispatchDateControl
				.Include(x => x.WeekDay)
				.Single(x => x.DispatchDate == dispatchDate);
				
			DispatchDateCreateViewModel viewModel = new DispatchDateCreateViewModel();

			viewModel.DispatchDateControl = model;
			viewModel.DeleteCreatedRoutes = false;
			viewModel.DeleteGeneratedButModifiedRoutes = false;

			LoadViewBag(viewModel);
			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		[AsyncTimeout(300000)]
		public void RecreateAsync(DispatchDateCreateViewModel viewModel)
		{
			AsyncManager.Parameters["viewModel"] = viewModel;

			AsyncManager.OutstandingOperations.Increment(2);

			Task primaryTask = Task.Factory.StartNew(() => 
			{
				RecreateTheDispatchDate(viewModel);
				AsyncManager.OutstandingOperations.Decrement();
			});

			Task.Factory.StartNew(() => 
			{
				DoKeepAlive(primaryTask);
				AsyncManager.OutstandingOperations.Decrement();
			});
		}

		public ViewResult RecreateCompleted(DispatchDateCreateViewModel viewModel)
		{
			TempData["LastGoodMessage"] = "Dispatch Date Control Record recreated.";

			viewModel.DispatchDateControl = db.DispatchDateControl
				.Include(x => x.WeekDay)
				.Single(x => x.DispatchDate == viewModel.DispatchDateControl.DispatchDate);

			string message = string.Format("Dispatch Date {0:d} recreated by {1}.", viewModel.DispatchDateControl.DispatchDate, this.User.Identity.Name);
			HLLogging.Info(message);

			LoadViewBag(viewModel);
			return View(viewModel);
		}


		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult DateClose()
		{
			DateTime? minDispatchDate = db.DispatchDateControl.Where(x => x.Closed == false).Min(x => x.DispatchDate);

			DispatchDateControl model = db.DispatchDateControl.Find(minDispatchDate.Value);
			db.Entry(model).Reference(x => x.WeekDay).Load();

			return View(model);
		}

		[HttpPost, ActionName("DateClose")]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult DateCloseConfirmed(DispatchDateControl screen)
		{
			DispatchDateControl model = db.DispatchDateControl.Find(screen.DispatchDate);
			db.Entry(model).Reference(x => x.WeekDay).Load();

			if (model.Closed == true || model.DispatchDate >= DateTime.Today)
			{
				ModelState.AddModelError("", "Cannot close a Dispatch Date until it has passed.");
			}

			if (!ModelState.IsValid)
			{
				return View(model);
			}

			model.Closed = true;

			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Dispatch Date Control Record for {0:d} closed.", model.DispatchDate);
			return RedirectToAction("Index");
		}

		private void LoadViewBag(DispatchDateCreateViewModel viewModel)
		{
			viewModel.WeekNumberSelectList = new SelectList(WeekList, "Number", "Name", viewModel.DispatchDateControl.WeekNumber);

			var WeekDayList = db.WeekDay
				.OrderBy(x => x.WeekDayID)
				.ToList()
				.Select(x => new
				{
					WeekDayID = x.WeekDayID,
					Name = string.Format("{0} ({1})", x.LongName, x.WeekDayID)
				});

			viewModel.WeekDayIDSelectList = new SelectList(WeekDayList, "WeekDayID", "Name", viewModel.DispatchDateControl.WeekDayID);
		}


		#endregion

		#region Methods for creating the dispatch date

		public void DoKeepAlive(Task primaryTask)
		{
			try
			{
				while (true)
				{
					if (primaryTask.Status == TaskStatus.Canceled || primaryTask.Status == TaskStatus.Faulted || primaryTask.Status == TaskStatus.RanToCompletion)
					{
						break;
					}
					else 
					{
						Response.Write(" ");
						Response.Flush();
						Thread.Sleep(5000);
					}
				}
			}
			catch (Exception ex)
			{
				HLLogging.Error("Error occurred in DoKeepAlive() Task", ex);
			} 
		}


		private void CreateTheDispatchDate(DispatchDateCreateViewModel viewModel)
		{
			try
			{
				db.DispatchDateControl.Add(viewModel.DispatchDateControl);
				ChangeLogger.LogChange(this, db.Entry(viewModel.DispatchDateControl));

				var templateRoutes = db.OutboundRoute
					.Where(x => x.WeekNumber == viewModel.DispatchDateControl.TemplateWeekNumber && x.WeekDayID == viewModel.DispatchDateControl.TemplateWeekDayID);



				foreach (var templateRoute in templateRoutes)
				{
					DailyDispatch dailyDispatch = BuildDailyDispatchRecord(db,
						templateRoute,
						viewModel.DispatchDateControl.DispatchDate,
						viewModel.DispatchDateControl.TemplateWeekNumber,
						viewModel.DispatchDateControl.TemplateWeekDayID);
					foreach (Load load in dailyDispatch.Loads)
					{
						ChangeLogger.LogChange(this, db.Entry(load));
					}
					db.DailyDispatch.Add(dailyDispatch);
					ChangeLogger.LogChange(this, db.Entry(dailyDispatch));
				}

				db.SaveChanges();

				LogGeneratedDate(viewModel.DispatchDateControl.DispatchDate);

				viewModel.Complete = true;
			}
			catch (Exception ex)
			{
				viewModel.Message = ex.Message;
				HLLogging.Error("Error occurred in CreateTheDispatchDate() Task", ex);
			}
		}
		
		private void LogGeneratedDate(DateTime dispatchDate)
		{
			StringBuilder log = new StringBuilder();

			log.AppendFormat("*** Dispatch Date Generation for {0:D} ***\n", dispatchDate);

			foreach (DbEntityEntry<DailyDispatch> dispatchEntry in db.ChangeTracker.Entries<DailyDispatch>())
			{
				DailyDispatch dispatch = dispatchEntry.Entity;

				log.AppendFormat("Dispatch({0}): ", dispatch.DailyDispatchID);

				if (dispatch.Driver1 != null)
				{
					log.AppendFormat(" Driver1:{0}", dispatch.Driver1.FullName);
				}

				if (dispatch.Driver2 != null)
				{
					log.AppendFormat(" Driver2:{0}", dispatch.Driver2.FullName);
				}

				if (dispatch.Carrier != null)
				{
					log.AppendFormat(" Carrier:{0}", dispatch.Carrier.Name);
				}

				if (dispatch.Loads != null)
				{
					var deliveries = dispatch.Loads.Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD);
					if (deliveries.Count() > 0)
					{
						log.Append("; Deliveries:");
						foreach (Load load in deliveries)
						{
							log.AppendFormat(" {0}({1}) Delv={2:g}", load.LoadDescription, load.LoadID, load.EtaDate);
						}
					}

					var cleanups = dispatch.Loads.Where(x => x.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP);
					if (cleanups.Count() > 0)
					{
						log.Append("; Cleanups:");
						foreach (Load load in cleanups)
						{
							log.AppendFormat(" {0}({1})", load.LoadDescription, load.LoadID);
						}
					}
				}

				log.AppendLine();
			}

			log.AppendFormat("*** Dispatch Date Generation Complete ***\n");

			HLLogging.Info(log);
		}

		private void RecreateTheDispatchDate(DispatchDateCreateViewModel viewModel)
		{
			try
			{
				DateTime dateTime = DateTime.Now;

				List<DailyDispatch> dispatches = db.DailyDispatch
					.Where(x => x.DispatchDate == viewModel.DispatchDateControl.DispatchDate)
					.Include(x => x.Loads)
					.ToList();

				List<DailyDispatch> dispatchesToBeDeleted = new List<DailyDispatch>();

				// If "delete manually created records" flag is true, delete any records not generated by system.
				if (viewModel.DeleteCreatedRoutes)
				{
					foreach (var dispatch in dispatches.Where(x => x.Generated == false))
					{
						dispatchesToBeDeleted.Add(dispatch);
					}
				}

				// If "delete generated but modified records" flag is true, delete any generated records modified after creation.
				if (viewModel.DeleteGeneratedButModifiedRoutes)
				{
					foreach (var dispatch in dispatches.Where(x => x.Generated == true))
					{
						if (dispatch.ChangeDate.HasValue == true)
						{
							dispatchesToBeDeleted.Add(dispatch);
						}
						else
						{
							bool anyModifiedGeneratedLoads = dispatch.Loads
								.LoadSelectedTypes(new string[] { DatabaseLists.OUTBOUND_STORE_LOAD, DatabaseLists.INBOUND_STORE_CLEANUP })
								.Any(x => x.ChangeDate.HasValue == true);
							if (anyModifiedGeneratedLoads)
							{
								dispatchesToBeDeleted.Add(dispatch);
							}
						}
					}
				}

				// Always delete generated records that have not been changed.
				foreach (var dispatch in dispatches.Where(x => x.Generated == true))
				{
					bool anyModifiedGeneratedLoads = dispatch.Loads
						.LoadSelectedTypes(new string[] { DatabaseLists.OUTBOUND_STORE_LOAD, DatabaseLists.INBOUND_STORE_CLEANUP })
						.Any(x => x.ChangeDate.HasValue == true);
					if (dispatch.ChangeDate.HasValue == false && anyModifiedGeneratedLoads == false)
					{
						dispatchesToBeDeleted.Add(dispatch);
					}
				}

				// Delete the dispatches.
				foreach (var dispatch in dispatchesToBeDeleted.Distinct())
				{
					foreach (var load in dispatch.Loads.ToArray())
					{
						// Delete the Load records from the database if they are generated automatically. 
						if (load.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD || load.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
						{
							db.Load.Remove(load);
							//ChangeLogger.LogChange(this, db.Entry(load), dateTime);
						}
					}
					// Remove any remaining loads from this dispatch. This will unassign the load and it must be reassigned.
					dispatch.Loads.Clear();
					// Remove the entry from the current dispatch list.
					dispatches.Remove(dispatch);
					// Delete the dispatch from the database.
					db.DailyDispatch.Remove(dispatch);
					//ChangeLogger.LogChange(this, db.Entry(dispatch), dateTime);
				}

				// Build a list of outbound routes to be inserted that are not still in the DailyDispatch table for the specified date.
				var templateRoutes = db.OutboundRoute
					.Where(x => x.WeekNumber == viewModel.DispatchDateControl.TemplateWeekNumber && x.WeekDayID == viewModel.DispatchDateControl.TemplateWeekDayID);

				// Build a single list of all loads in the remaining dispatches.
				var allLoadsForDispatches = dispatches.SelectMany(x => x.Loads);

				foreach (var templateRoute in templateRoutes)
				{
					{
						DailyDispatch dispatch = BuildDailyDispatchRecord(db,
							templateRoute,
							viewModel.DispatchDateControl.DispatchDate,
							viewModel.DispatchDateControl.TemplateWeekNumber,
							viewModel.DispatchDateControl.TemplateWeekDayID);
						foreach (Load load in dispatch.Loads)
						{
							ChangeLogger.LogChange(this, db.Entry(load), dateTime);
						}
						db.DailyDispatch.Add(dispatch);
						ChangeLogger.LogChange(this, db.Entry(dispatch), dateTime);
					}
				}

				DispatchDateControl model = db.DispatchDateControl.Find(viewModel.DispatchDateControl.DispatchDate);
				model.TemplateWeekDayID = viewModel.DispatchDateControl.TemplateWeekDayID;
				model.TemplateWeekNumber = viewModel.DispatchDateControl.TemplateWeekNumber;

				ChangeLogger.LogChange(this, db.Entry(model), dateTime);

				db.SaveChanges();

				LogGeneratedDate(viewModel.DispatchDateControl.DispatchDate);
			}
			catch (Exception ex)
			{
				HLLogging.Error("Error occurred in RecreateTheDispatchDate() Task", ex);
			}
		}
		
		/// <summary>
		/// Create a single DailyDispatch record with generated Store Loads and Store Cleanups from the Outbound Schedule.
		/// </summary>
		/// <param name="db">Current DispatchContext</param>
		/// <param name="route">OutboundRoute record to generate</param>
		/// <param name="DispatchDate">Dispatch Date to use</param>
		/// <param name="WeekNumber"></param>
		/// <param name="WeekDayID"></param>
		/// <returns></returns>
		internal static DailyDispatch BuildDailyDispatchRecord(DispatchContext db, OutboundRoute route, DateTime DispatchDate, int WeekNumber, int WeekDayID)
		{
			Carrier carrier = route.CarrierID.HasValue ? db.Carrier.Single(x => x.CarrierID == route.CarrierID) : null;
			Driver driver1 = route.Driver1ID.HasValue ? db.Driver.Single(x => x.DriverID == route.Driver1ID) : null;
			Driver driver2 = route.Driver2ID.HasValue ? db.Driver.Single(x => x.DriverID == route.Driver2ID) : null;

			DailyDispatch dailyDispatch = new DailyDispatch
			{
				DispatchDate = DispatchDate,
				Weeknumber = WeekNumber,
				WeekDayID = WeekDayID,
				DispatchGroup = route.DispatchGroup,
				Generated = true,
				OutboundRouteID = route.OutboundRouteID,
				CarrierID = route.CarrierID,
				Carrier = carrier,
				Driver1ID = route.Driver1ID,
				Driver1 = driver1,
				Driver2ID = route.Driver2ID,
				Driver2 = driver2,
				//TractorNumber = route.TractorNumber,
				DepartureTime = DispatchDate + (route.DepartureTime.HasValue ? route.DepartureTime.Value.TimeOfDay : DateTime.MinValue.TimeOfDay),
				Miles = route.Miles,
				Comment = route.Comment,
				Loads = new List<Load>(),
				LoadHistory = new List<DispatchLoadLinkHistory>()
			};


			// Fill in the route tractor number or the driver1 tractor number.
			if (!string.IsNullOrEmpty(route.TractorNumber))
			{
				dailyDispatch.TractorNumber = route.TractorNumber;
			}
			else if (driver1 != null && !string.IsNullOrEmpty(driver1.TractorNumber))
			{
				dailyDispatch.TractorNumber = driver1.TractorNumber;
			}


			int outboundDispatchLoadOrder = 1;

			if (route.Load1StoreID.HasValue && route.Load1Type != null && route.Load1DeliveryDayID.HasValue && route.Load1DeliveryTime.HasValue)
			{
				Store store = db.Store.Single(x => x.StoreID == route.Load1StoreID);

				if (!dailyDispatch.Miles.HasValue)
				{
					dailyDispatch.Miles = store.Miles;
				}

				int etaoffset = route.Load1DeliveryDayID.Value - route.WeekDayID;
				if (etaoffset < 0)
				{
					etaoffset += 7;
				}

				Load load = new Load
				{
					Generated = true,
					DispatchLoadOrder = outboundDispatchLoadOrder++,
					LoadType = DatabaseLists.OUTBOUND_STORE_LOAD,
					StoreLoadType = route.Load1Type,
					ReadyDate = dailyDispatch.DispatchDate,
					StoreID = route.Load1StoreID,
					Store = store, // Loaded for Preview
					EtaDate = dailyDispatch.DispatchDate.Date.AddDays(etaoffset) + route.Load1DeliveryTime.Value.TimeOfDay
				};
				dailyDispatch.Loads.Add(load);

				dailyDispatch.InboundDate = load.EtaDate.Value;

				dailyDispatch.LoadHistory.Add(new DispatchLoadLinkHistory
				{
					DailyDispatch = dailyDispatch,
					Load = load,
					Status = 0,
					LoadType = load.LoadType,
					StoreID = load.StoreID,
					EtaDate = load.EtaDate
				});
			}

			if (route.Load2StoreID.HasValue && route.Load2Type != null && route.Load2DeliveryDayID.HasValue && route.Load2DeliveryTime.HasValue)
			{
				Store store = db.Store.Single(x => x.StoreID == route.Load2StoreID);

				if (!dailyDispatch.Miles.HasValue)
				{
					dailyDispatch.Miles = store.Miles;
				}

				int etaoffset = route.Load2DeliveryDayID.Value - route.WeekDayID;
				if (etaoffset < 0)
				{
					etaoffset += 7;
				}

				Load load = new Load
				{
					Generated = true,
					DispatchLoadOrder = outboundDispatchLoadOrder++,
					LoadType = DatabaseLists.OUTBOUND_STORE_LOAD,
					StoreLoadType = route.Load2Type,
					ReadyDate = dailyDispatch.DispatchDate,
					PickupDate = dailyDispatch.DispatchDate,
					StoreID = route.Load2StoreID,
					Store = store, // Loaded for Preview
					EtaDate = dailyDispatch.DispatchDate.Date.AddDays(etaoffset) + route.Load2DeliveryTime.Value.TimeOfDay
				};
				dailyDispatch.Loads.Add(load);

				dailyDispatch.LoadHistory.Add(new DispatchLoadLinkHistory
				{
					DailyDispatch = dailyDispatch,
					Load = load,
					Status = 0,
					LoadType = load.LoadType,
					StoreID = load.StoreID,
					EtaDate = load.EtaDate
				});
			}

			if (route.Load3StoreID.HasValue && route.Load3Type != null && route.Load3DeliveryDayID.HasValue && route.Load3DeliveryTime.HasValue)
			{
				Store store = db.Store.Single(x => x.StoreID == route.Load3StoreID);

				if (!dailyDispatch.Miles.HasValue)
				{
					dailyDispatch.Miles = store.Miles;
				}

				int etaoffset = route.Load3DeliveryDayID.Value - route.WeekDayID;
				if (etaoffset < 0)
				{
					etaoffset += 7;
				}

				Load load = new Load
				{
					Generated = true,
					DispatchLoadOrder = outboundDispatchLoadOrder++,
					LoadType = DatabaseLists.OUTBOUND_STORE_LOAD,
					StoreLoadType = route.Load3Type,
					ReadyDate = dailyDispatch.DispatchDate,
					PickupDate = dailyDispatch.DispatchDate,
					StoreID = route.Load3StoreID,
					Store = store, // Loaded for Preview
					EtaDate = dailyDispatch.DispatchDate.Date.AddDays(etaoffset) + route.Load3DeliveryTime.Value.TimeOfDay
				};
				dailyDispatch.Loads.Add(load);

				dailyDispatch.LoadHistory.Add(new DispatchLoadLinkHistory
				{
					DailyDispatch = dailyDispatch,
					Load = load,
					Status = 0,
					LoadType = load.LoadType,
					StoreID = load.StoreID,
					EtaDate = load.EtaDate
				});
			}

			// Set inbound date to the explicit value or from the nose load.

			if (route.InboundWeekDayID.HasValue)
			{
				int inboundoffset = 0;
				if (route.InboundWeekDayID.Value >= route.WeekDayID)
				{
					inboundoffset = route.InboundWeekDayID.Value - route.WeekDayID;
				}
				else
				{
					inboundoffset = (7 + route.InboundWeekDayID.Value) - route.WeekDayID;
				}
				dailyDispatch.InboundDate = DispatchDate.AddDays(inboundoffset).Date;
			}
			else 
			{
				Load noseload = dailyDispatch.Loads.FirstOrDefault();
				if (noseload != null)
				{
					dailyDispatch.InboundDate = noseload.EtaDate.Value.Date;
				}
				else
				{
					dailyDispatch.InboundDate = dailyDispatch.DispatchDate.GetNextBusinessDate().Date;
				}
			}

			// Calculate carrier charges

			if (dailyDispatch.CarrierID.HasValue && (dailyDispatch != null && dailyDispatch.Loads.Count > 0))
			{
				Load noseLoad = dailyDispatch.Loads.ElementAt(0);

				StoreCarrierInfo scinfo = db.StoreCarrierInfo.SingleOrDefault(x => x.CarrierID == dailyDispatch.CarrierID.Value && x.StoreID == noseLoad.StoreID.Value);
				if (scinfo != null)
				{
					FuelSurcharge fuelSurcharge = db.FuelSurcharge.GetFuelSurchargeForDate(noseLoad.EtaDate.Value);
					if (fuelSurcharge != null)
					{
						dailyDispatch.FuelSurcharge = fuelSurcharge.Amount;
					}

					// Calculate Carrier Charge
					CarrierChargeCalculation.Parts carrierCharge = CarrierChargeCalculation.Calculate(new CarrierChargeCalculation.Parts
					{
						Miles = scinfo.Miles,
						Rate = scinfo.RatePerMile,
						FlatRate = scinfo.FlatRate,
						MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)scinfo.MileageCalcType,
						StopCharge1 = carrier.StopCharge1,
						StopCharge2 = carrier.StopCharge2,
						FuelSurcharge = dailyDispatch.FuelSurcharge,
						ExtraCharge = null,
						LoadCount = dailyDispatch.Loads.Count
					});
					dailyDispatch.CarrierMiles = carrierCharge.Miles;
					dailyDispatch.CarrierRate = carrierCharge.Rate;
					dailyDispatch.CarrierFlatRate = carrierCharge.FlatRate;
					dailyDispatch.MileageCalcType = (int)carrierCharge.MileageCalcType;
					dailyDispatch.CarrierStopCharge1 = carrierCharge.StopCharge1Used ? carrierCharge.StopCharge1 : null;
					dailyDispatch.CarrierStopCharge2 = carrierCharge.StopCharge2Used ? carrierCharge.StopCharge2 : null;
					dailyDispatch.CarrierTotalCharge = carrierCharge.TotalCharge;
				}
			}

			// Add cleanup loads

			int inboundDispatchLoadOrder = 1;

			if (route.Cleanup1StoreID.HasValue)
			{
				Store store = db.Store.Single(x => x.StoreID == route.Cleanup1StoreID);

				Load load = new Load
				{
					Generated = true,
					DispatchLoadOrder = inboundDispatchLoadOrder++,
					LoadType = DatabaseLists.INBOUND_STORE_CLEANUP,
					ReadyDate = dailyDispatch.DispatchDate,
					PickupDate = dailyDispatch.InboundDate,
					ScheduledDate = dailyDispatch.InboundDate,
					StoreID = route.Cleanup1StoreID,
					Store = store // Loaded for Preview
				};

				dailyDispatch.Loads.Add(load);
			}

			if (route.Cleanup2StoreID.HasValue)
			{
				Store store = db.Store.Single(x => x.StoreID == route.Cleanup2StoreID);

				Load load = new Load
				{
					Generated = true,
					DispatchLoadOrder = inboundDispatchLoadOrder++,
					LoadType = DatabaseLists.INBOUND_STORE_CLEANUP,
					ReadyDate = dailyDispatch.DispatchDate,
					PickupDate = dailyDispatch.InboundDate,
					ScheduledDate = dailyDispatch.InboundDate,
					StoreID = route.Cleanup2StoreID,
					Store = store // Loaded for Preview
				};

				dailyDispatch.Loads.Add(load);
			}

			if (route.Cleanup3StoreID.HasValue)
			{
				Store store = db.Store.Single(x => x.StoreID == route.Cleanup3StoreID);

				Load load = new Load
				{
					Generated = true,
					DispatchLoadOrder = inboundDispatchLoadOrder++,
					LoadType = DatabaseLists.INBOUND_STORE_CLEANUP,
					ReadyDate = dailyDispatch.DispatchDate,
					PickupDate = dailyDispatch.InboundDate,
					ScheduledDate = dailyDispatch.InboundDate,
					StoreID = route.Cleanup3StoreID,
					Store = store // Loaded for Preview
				};
				
				dailyDispatch.Loads.Add(load);
			}

			return dailyDispatch;
		}

		#endregion

		

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}