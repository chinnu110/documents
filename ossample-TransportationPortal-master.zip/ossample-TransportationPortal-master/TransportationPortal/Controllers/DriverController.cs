﻿using System;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HobbyLobby.SAP.Proxy.Soap.TransDispatch;
using TransportationPortal.Models;
using TransportationPortal.Repositories;
using TransportationPortal.ViewModels;
using Avatar;

namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class DriverController : Controller
	{
		private const string MAIN_VIEW = "Index";

		private const string TEMPDATA_LASTGOODMESSAGE = "LastGoodMessage";

		/// <summary>
		/// Session element name for remembering filter values when returning to this controller.
		/// </summary>
		private string FilterSessionName
		{
			get { return this.GetType().Name + ".Filter"; }
		}

		private DispatchContext db = new DispatchContext();

		#region Index and List methods

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index(int? id)
		{
			DriverIndexViewModel newViewModel;

			DriverIndexViewModel viewModel = Session[FilterSessionName] as DriverIndexViewModel;
			if (viewModel == null)
			{
				viewModel = new DriverIndexViewModel();
				newViewModel = GenerateViewModel(viewModel);
			}
			else
			{
				newViewModel = GenerateViewModel(viewModel);
			}

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index(DriverIndexViewModel viewModel)
		{
			// Copy any items needed that were not returned.
			//DriverIndexViewModel previousViewModel = Session[FilterSessionName] as DriverIndexViewModel;
			if (viewModel == null)
			{
				viewModel = new DriverIndexViewModel();
			}

			// Generate the new view model.
			DriverIndexViewModel newViewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		private DriverIndexViewModel GenerateViewModel(DriverIndexViewModel viewModel)
		{

			var dispatcherListData = db.Dispatcher
				.OrderBy(x => x.FirstName)
				.ThenBy(x => x.LastName)
				.ToList()
				.Select(x => new SelectListItem
				{
					Value = x.DispatcherID.ToString(),
					Text = x.FullName
				});

			viewModel.DispatcherList = new SelectList(dispatcherListData, "Value", "Text", viewModel.DispatcherID);


			var driverList = db.Driver
				.ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
				.OrderBy(x => x.FirstName)
				.ThenBy(x => x.LastName)
				.Include(x => x.Dispatcher)
				.Include(x => x.TeamPartner);

			if (viewModel.DispatcherID.HasValue)
			{
				driverList = driverList.Where(x => x.DispatcherID == viewModel.DispatcherID);
			}

			viewModel.Drivers = driverList
				.OrderBy(x => x.FirstName)
				.ThenBy(x => x.LastName)
				.ToList()
				.Select(x => new DriverViewModel(x));

			return viewModel;
		}


		#endregion

		#region Details, Create, and Edit methods

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Details(int id)
		{
			Driver model = db.Driver
				.ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
				.Single(x => x.DriverID == id);

			db.Entry(model).Reference(x => x.Dispatcher).Load();
			db.Entry(model).Reference(x => x.TeamPartner).Load();

			return View(model);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Create()
		{
			LoadViewBag();
			return View();
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
		public ActionResult Create(Driver model)
		{
			if (db.Driver.ActiveFilter().AsNoTracking()
				.Any(x => 
					x.FirstName.ToUpper() == model.FirstName.ToUpper() &&
					x.MiddleName.ToUpper() == model.MiddleName.ToUpper() && 
					x.LastName.ToUpper() == model.LastName.ToUpper() &&
					x.Suffix.ToUpper() == model.Suffix.ToUpper())
				)
			{
				ModelState.AddModelError(string.Empty, string.Format("Driver '{0}' already exists.", model.FullName));
			}

			if (model.TeamPartnerID.HasValue)
			{
				Driver requestedTeamPartner = db.Driver.ActiveFilter().SingleOrDefault(x => x.DriverID == model.TeamPartnerID);
				if (requestedTeamPartner != null && requestedTeamPartner.TeamPartnerID.HasValue)
				{
					ModelState.AddModelError(string.Empty, string.Format("Requested Team Partner '{0}' already has a Team Partner.", requestedTeamPartner.FullName));
				}
			}

			if (!ModelState.IsValid)
			{
				LoadViewBag();
				return View(model);
			}

			db.Driver.Add(model);
			ChangeLogger.LogChange(this, db.Entry(model));
			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Driver {0} created.", model.FullName);
			return RedirectToAction("Index");
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)] 
		public ActionResult Edit(int id)
		{
			Driver model = db.Driver
				.ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
				.Single(x => x.DriverID == id);

			LoadViewBag(model);
			return View("Edit", model);
		}


		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)] 
		public ActionResult Edit(Driver screen)
		{
			Driver model = db.Driver
				.ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
				.Single(x => x.DriverID == screen.DriverID);

			UInt64 screenTimestamp = BitConverter.ToUInt64(screen.Timestamp, 0);
			UInt64 modelTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

			if (screenTimestamp != modelTimestamp)
			{
				ModelState.Clear();
				ModelState.AddModelError(string.Empty,
					"The record you attempted to edit was modified after you got the original value.\r\n" +
					"The edit operation was canceled and the current values in the database have been displayed.\r\n" +
					"If you still want to edit this record, make the changes again and click the Save button.\r\n" +
					"Otherwise click Back to List.");
				LoadViewBag(model);
				return View(model);
			}

			if (db.Driver.ActiveFilter().Any(x =>
				x.FirstName.ToUpper() == model.FirstName.ToUpper() &&
				x.MiddleName.ToUpper() == model.MiddleName.ToUpper() &&
				x.LastName.ToUpper() == model.LastName.ToUpper() &&
				x.Suffix.ToUpper() == model.Suffix.ToUpper() &&
				x.DriverID != model.DriverID ))
			{
				ModelState.AddModelError(string.Empty, string.Format("Driver '{0} {1}' already exists.", model.FirstName, model.LastName));
			}

			if (model.TeamPartnerID != screen.TeamPartnerID)
			{
				if (screen.TeamPartnerID.HasValue)
				{
					Driver requestedTeamPartner = db.Driver.ActiveFilter().SingleOrDefault(x => x.DriverID == screen.TeamPartnerID);
					if (requestedTeamPartner != null && requestedTeamPartner.TeamPartnerID.HasValue)
					{
						ModelState.AddModelError(string.Empty, string.Format("Requested Team Partner '{0}' already has a Team Partner.", requestedTeamPartner.FullName));
					}
					else
					{
						requestedTeamPartner.TeamPartnerID = screen.DriverID;
					}
				}
				if (model.TeamPartnerID.HasValue)
				{
					Driver requestedTeamPartner = db.Driver.ActiveFilter().SingleOrDefault(x => x.DriverID == model.TeamPartnerID);
					if (requestedTeamPartner != null && requestedTeamPartner.TeamPartnerID.HasValue)
					{
						requestedTeamPartner.TeamPartnerID = null;
					}
				}
			}

			if (!ModelState.IsValid)
			{
				LoadViewBag(screen);
				return View(screen);
			}

			model.Dispatcher = screen.Dispatcher;
			model.DispatcherID = screen.DispatcherID;
			model.FirstName = screen.FirstName;
			model.MiddleName = screen.MiddleName;
			model.LastName = screen.LastName;
			model.Suffix = screen.Suffix;
			model.TractorNumber = screen.TractorNumber;
			model.Notes = screen.Notes;
			model.Phone = screen.Phone;
			model.Smoker = screen.Smoker;
			model.DriveHours = screen.DriveHours;
			model.TeamPartnerID = screen.TeamPartnerID;
			model.DriverShift = screen.DriverShift;
			model.DriverShiftStart = screen.DriverShiftStart;
			model.DispatchGroup = screen.DispatchGroup;
			model.PartTime = screen.PartTime;

			ChangeLogger.LogChange(this, db.Entry(model));

			db.SaveChanges();

			TempData["LastGoodMessage"] = string.Format("Driver {0} updated.", model.FullName);
			return RedirectToAction("Index");
		}

		private void LoadViewBag(Driver model = null)
		{
			var dispatchGroups = new[]
			{ 
				new { Text = "OTR", Value = DatabaseLists.DISPATCH_GROUP_OTR },
				new { Text = "Dallas", Value = DatabaseLists.DISPATCH_GROUP_DALLAS },
				new { Text = "OKC", Value = DatabaseLists.DISPATCH_GROUP_OKC }
			};

			var DispatcherList = db.Dispatcher
				.OrderBy(x => x.FirstName)
				.ThenBy(x => x.LastName)
				.ToList()
				.Select(x => new
				{
					Value = x.DispatcherID,
					Text = string.Format("{0} {1}", x.FirstName, x.LastName)
				});

			if (model == null)
			{
				ViewBag.DispatcherID = new SelectList(DispatcherList, "Value", "Text");
				ViewBag.DispatchGroup = new SelectList(dispatchGroups, "Value", "Text");
			}
			else
			{
				ViewBag.DispatcherID = new SelectList(DispatcherList, "Value", "Text", model.DispatcherID);
				ViewBag.DispatchGroup = new SelectList(dispatchGroups, "Value", "Text", model.DispatchGroup);
			}


			int excludeSelfID = model == null ? 0 : model.DriverID;

			var TeamPartnerList = db.Driver
				.ActiveFilter()
				.Where(x => x.DriverID != excludeSelfID)
				.OrderBy(x => x.FirstName)
				.ThenBy(x => x.LastName)
				.ToList()
				.Select(x => new
				{
					Value = x.DriverID,
					Text = string.Format("{0} {1}", x.FirstName, x.LastName)
				});

			if (model == null)
			{
				ViewBag.TeamPartnerID = new SelectList(TeamPartnerList, "Value", "Text");
				ViewBag.DriverShift = Extensions.BuildSelectList<DriverShift>();
				ViewBag.DriverShiftStart = Extensions.BuildSelectList<DriverShiftStart>();
				ViewBag.DispatchGroup = new SelectList(dispatchGroups, "Value", "Text");
			}
			else
			{
				ViewBag.TeamPartnerID = new SelectList(TeamPartnerList, "Value", "Text", model.TeamPartnerID);
				ViewBag.DriverShift = Extensions.BuildSelectList<DriverShift>(model.DriverShift);
				ViewBag.DriverShiftStart = Extensions.BuildSelectList<DriverShiftStart>(model.DriverShiftStart);
				ViewBag.DispatchGroup = new SelectList(dispatchGroups, "Value", "Text", model.DispatchGroup);
			}
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)] 
		public PartialViewResult VerifySapDriver(string id)
		{
			Driver viewModel = new Driver();
			viewModel.SapDriverName = "Not found";
			viewModel.SapDriverID = string.Empty;
			
			string[] nameParts = id.Split('+');

			if (nameParts.Length == 2)
			{
				TransDispatchDriverProxy sapProxy = new TransDispatchDriverProxy(LibConfigProperties.Settings.SapEnvironment);
				var driverList = sapProxy.GetDrivers(first_name: nameParts[0], last_name: nameParts[1]);
				if (driverList != null && driverList.Count() > 0)
				{
					viewModel.SapDriverName = string.Format("{0} {1}", driverList[0].FirstName, driverList[0].LastName);
					viewModel.SapDriverID = driverList[0].PersonnelNumber;
				}
			}

			return PartialView("_SapDriverName", viewModel);
		}

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)] 
		public ActionResult Delete(int id)
		{
			DateTime oldestOpenDispatchDate = db.OpenDispatchDates().OldestDispatchDate();

			Driver model = db.Driver
				.ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
				.Single(x => x.DriverID == id);

			var openDispatchesWithDriver = db.OpenDispatchesOrAnyOpenDeliveries(oldestOpenDispatchDate)
				.Where(x => x.Driver1ID == model.DriverID || x.Driver2ID == model.DriverID);
			if (openDispatchesWithDriver != null)
			{
				foreach (var dispatch in openDispatchesWithDriver)
				{
					ModelState.AddModelError("", string.Format("Driver is referenced by open Dispatch {0} on Departure date {1}. Either remove the Driver or wait until the Dispatch is closed.",
						dispatch.DailyDispatchID, dispatch.DispatchDate.ToShortDateString()));
				}
			}

			if (!ModelState.IsValid)
			{
				return Edit(id);
			}

			// Remove the references to the driver.

			db.Entry(model).Reference(x => x.TeamPartner).Load();
			if (model.TeamPartner != null)
			{
				model.TeamPartner = null;
			}

			db.Entry(model).Reference(x => x.Dispatcher).Load();
			if (model.Dispatcher != null)
			{
				model.Dispatcher = null;
			}
			
			db.Entry(model).Collection(x => x.AssignedAsDriver1).Load();
			if (model.AssignedAsDriver1 != null)
			{
				model.AssignedAsDriver1.Clear();
			}

			db.Entry(model).Collection(x => x.AssignedAsDriver2).Load();
			if (model.AssignedAsDriver2 != null)
			{
				model.AssignedAsDriver2.Clear();
			}

			// if store is still attached to loads on closed dispatches, then the record must be logically deleted, which retains the record in a hidden state.

			bool historicalDispatchesExist = db.DailyDispatch
				.Where(x => x.DispatchDate < oldestOpenDispatchDate)
				.Any(x => x.Driver1ID == model.DriverID || x.Driver2ID == model.DriverID);

			TempData[TEMPDATA_LASTGOODMESSAGE] = string.Format("Driver {0} deleted.", model.FullName);

			try
			{
				if (historicalDispatchesExist)
				{
					ChangeLogger.LogLogicalDelete(this, db.Entry(model), string.Format("Driver {0} [ID={1}] marked as deleted.", model.FullName, model.DriverID));
				}
				else
				{
					db.Driver.Remove(model);
					ChangeLogger.LogChange(this, db.Entry(model));
				}
				db.SaveChanges();
			}
			catch (System.Data.Entity.Infrastructure.DbUpdateException ex)
			{
				string recordIdent = string.Format("Driver {0} [ID={1}]", model.FullName, model.DriverID);
				string message = string.Format("Error attempting to delete: {0}. Foreign Key relationships may be preventing deletion.", recordIdent);
				throw new Exception(message, ex);
			}

			return RedirectToAction(MAIN_VIEW);
		}

		#endregion

		#region Ajax Methods

		/// <summary>
		/// Create driver information popup
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public ActionResult GetDriverInfo(int id)
		{
			Driver driver = db.Driver.ActiveFilter().AsNoTracking()
				.Include(x => x.TeamPartner)
				.Include(x => x.Dispatcher)
				.Single(x => x.DriverID == id);

			DriverViewModel viewModel = new DriverViewModel(driver);

			return PartialView("_DriverDetailsPopup", viewModel);
		}

		#endregion
		
		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}