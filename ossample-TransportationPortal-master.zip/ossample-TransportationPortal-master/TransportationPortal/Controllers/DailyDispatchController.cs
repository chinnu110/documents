﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Objects.SqlClient;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using Avatar;
using ContainerSystem.Models;
using ContainerSystem.Service;
using HobbyLobby.HLUtil.Logging;
using TransportationPortal.Models;
using TransportationPortal.Repositories;
using TransportationPortal.ViewModels;

namespace TransportationPortal.Controllers
{
    [HandleApplicationError]
    public class DailyDispatchController : Controller
    {
        protected DispatchContext Db { get; set; }

        protected DispatchSlimContext DbSlim { get; set; }

        protected ContainerService ContainerService { get; set; }

        private const string _SqlQueryByArrival = "exec [dbo].[usp_Dispatches_QueryByArrival] @SelectionDateFrom, @SelectionDateThru";

        private const string _SqlQueryByDeparture = "exec [dbo].[usp_Dispatches_QueryByDeparture] @SelectionDateFrom, @SelectionDateThru";
        
        private const string _SqlSearchByDeparture = "exec [dbo].[usp_Dispatches_SearchByDeparture] @SelectionDateFrom, @SelectionDateThru, @CarrierID, @Trailer, @DispatchID, @DriverID, @Tractor, @StoreIDs";

        private Regex _historyStoreSpecificationPattern = new Regex(@"\b(?<company>HL|MD|HM)?(?<store>\d+){1}(?<suffix>\w)?\b");

        private SelectListItem[] _sortTypes = 
        {
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundStore) + ",A", Text = "Outbound Store" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundArrival) + ",A", Text = "Outbound Arrival" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchDepart) + ",A", Text = "Outbound Departure" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundLocation) + ",A", Text = "Outbound Location" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.CarrierThenStore) + ",A", Text = "Carrier,Store" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.InboundLocation) + ",A", Text = "Inbound Location" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.TractorNumber) + ",A", Text = "Tractor# - A to Z" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.TractorNumber) + ",D", Text = "Tractor# - Z to A" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchID) + ",A", Text = "Dispatch ID" }
            
            // new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchCreated) + ",D", Text = "Dispatch Created - Newest First" },
            // new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchCreated) + ",A", Text = "Dispatch Created - Oldest First" },
            // new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchChanged) + ",D", Text = "Dispatch Changed - Newest First" },
            // new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchChanged) + ",A", Text = "Dispatch Changed - Oldest First" },
        };

        private SelectListItem[] _sortTypesForHistory = 
        {
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundStore) + ",A", Text = "Outbound Store - A to Z" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundStore) + ",D", Text = "Outbound Store - Z to A" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundArrival) + ",A", Text = "Outbound Arrival - A to Z" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundArrival) + ",D", Text = "Outbound Arrival - Z to A" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchDepart) + ",A", Text = "Outbound Departure - A to Z" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchDepart) + ",D", Text = "Outbound Departure - Z to A" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundLocation) + ",A", Text = "Outbound Location - A to Z" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundLocation) + ",D", Text = "Outbound Location - Z to A" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.CarrierThenStore) + ",A", Text = "Carrier,Store - A to Z" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.CarrierThenStore) + ",D", Text = "Carrier,Store - Z to A" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.InboundLocation) + ",A", Text = "Inbound Location - A to Z" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.InboundLocation) + ",D", Text = "Inbound Location - Z to A" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.TractorNumber) + ",A", Text = "Tractor# - A to Z" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.TractorNumber) + ",D", Text = "Tractor# - Z to A" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchID) + ",A", Text = "Dispatch ID" }
            
            // new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchCreated) + ",D", Text = "Dispatch Created - Newest First" },
            // new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchCreated) + ",A", Text = "Dispatch Created - Oldest First" },
            // new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchChanged) + ",D", Text = "Dispatch Changed - Newest First" },
            // new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchChanged) + ",A", Text = "Dispatch Changed - Oldest First" },
        };

        /// <summary>
        /// ReturnURL TempData element name.
        /// </summary>
        public static readonly string TEMPDATA_RETURN_URL = typeof(DailyDispatchController).Name + ".ReturnURL";

        /// <summary>
        /// Last Good Message TempData element name.
        /// </summary>
        public const string TEMPDATA_LASTGOODMESSAGE = "LastGoodMessage";

        public const string TEMPDATA_LASTDAILYDISPATCHID = "LastDailyDispatchID";

        public const string TEMPDATA_FROMSCROLLMETHOD = "FromScrollMethod";

        public const string TEMPDATA_ENABLESCROLL = "EnableScroll";

        /// <summary>
        /// Entry view name for this controller.
        /// </summary>
        protected const string MAIN_VIEW = "Index";

        private const string _ConcurrentEditErrorMessage = 
            "The record you attempted to edit was modified after you got the original value.\r\n" +
            "The edit operation was canceled and the current values in the database have been displayed.\r\n" +
            "If you still want to edit this record, make the changes again and click the Save button.\r\n" +
            "Otherwise click Back to List.";
        
        /// <summary>
        /// Session element name for remembering filter values when returning to this controller.
        /// </summary>
        private string FilterSessionName
        {
            get { return this.GetType().Name + ".Filter"; }
        }

        /// <summary>
        /// Session element to hold ad-hoc loads added to Dispatch for creation when the Dispatch is saved.
        /// These loads will be keyed uniquely with negative numbers.
        /// </summary>
        protected class DispatchEdit
        {
            public int? DailyDispatchID { get; set; }

            public int LastTempID { get; set; }

            public List<Load> TempInboundLoads { get; set; }

            public List<Load> TempOutboundLoads { get; set; }

            public DispatchEdit()
            {
                LastTempID = -1;
                TempInboundLoads = new List<Load>();
                TempOutboundLoads = new List<Load>();
            }
        }

        /// <summary>
        /// Session element name for keeping the temporary load class.
        /// </summary>
        protected string DispatchEditSessionName
        {
            get { return this.GetType().Name + "." + typeof(DispatchEdit).GetType().Name; }
        }

        public static readonly string[] ALLOWED_CONTAINER_STATUS_FOR_PULL = 
        { 
            StatusCodeValues.EW_NOTIFICATION, StatusCodeValues.ARRIVED_DALLAS_YARD
        };

        public static readonly string[] ALLOWED_CONTAINER_STATUS_FOR_OKC_COMMIT = 
        { 
            StatusCodeValues.EW_NOTIFICATION, StatusCodeValues.ARRIVED_DALLAS_YARD, StatusCodeValues.COMMITTED_TO_ARRIVE_OKC, StatusCodeValues.RETURN_TO_OKC_YARD, StatusCodeValues.SOUTHWEST_FREIGHT_YARD
        };

        public static readonly string[] ALLOWED_CONTAINER_STATUS_EMPTY_RETURN = 
        { 
            StatusCodeValues.EMPTY_CONTAINER, StatusCodeValues.EMPTY_CONTAINER_HEMISPHERES, StatusCodeValues.LOADING_HOBBYLOBBY_STORE, StatusCodeValues.COMMITTED_RETURN
        };

        #region Index view and related methods

        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
        public virtual ViewResult Index(int? id)
        {
            DailyDispatchIndexViewModel newViewModel;

            DailyDispatchIndexViewModel viewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
            if (viewModel == null)
            {
                HLLogging.InfoFormat("Initializing session object DailyDispatchIndexViewModel for {0}", this.User.Identity.Name);

                viewModel = new DailyDispatchIndexViewModel();
                viewModel.SelectDate = DateTime.Today;
                viewModel.Paging = new PagingViewModel
                {
                    Page = 1,
                    PageSize = 100,
                    LinksBeforeCurrentPage = 4,
                    LinksAfterCurrentPage = 4,
                };
                viewModel.ThruDate = DateTime.Today;
                viewModel.FromDate = viewModel.ThruDate.Value.AddDays(-7);
                newViewModel = GenerateViewModel(viewModel);
            }
            else if (id.HasValue)
            {
                if (viewModel.Paging.Page != id.Value)
                {
                    ViewBag.OverrideSavedPosition = "0_0";
                }

                viewModel.Paging.Page = id.Value;
                newViewModel = GenerateViewModel(viewModel);
            }
            else if (viewModel.Dispatches == null)
            {
                newViewModel = GenerateViewModel(viewModel);
            }
            else
            {
                newViewModel = viewModel;
                
                object changedDispatchIDobject = TempData[TEMPDATA_LASTDAILYDISPATCHID];
                if (changedDispatchIDobject != null)
                {
                    int changedDispatchID = 0;
                    if (int.TryParse(changedDispatchIDobject.ToString(), out changedDispatchID) && changedDispatchID > 0)
                    {
                        UpdateDispatchIndexList(changedDispatchID);
                    }
                }
            }

            // Save the view model
            Session[FilterSessionName] = newViewModel;

            return View(newViewModel);
        }

        [HttpPost]
        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
        public virtual ViewResult Index(DailyDispatchIndexViewModel viewModel)
        {
            // Copy any items needed that were not returned.
            DailyDispatchIndexViewModel previousViewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
            if (previousViewModel == null)
            {
                HLLogging.WarnFormat("Missing session object DailyDispatchIndexViewModel for {0}", this.User.Identity.Name);
            }

            if (previousViewModel != null)
            {
                viewModel.DispatchWeeks = previousViewModel.DispatchWeeks;
                viewModel.SelectedDates = previousViewModel.SelectedDates;
                viewModel.Paging = previousViewModel.Paging;
                viewModel.Paging.Page = 1;
                if (!viewModel.AdminViewMode)
                {
                    viewModel.FromDate = previousViewModel.FromDate;
                    viewModel.ThruDate = previousViewModel.ThruDate;
                }
            }
            else
            {
                viewModel.SelectDate = DateTime.Today;
                viewModel.Paging = new PagingViewModel
                {
                    Page = 1,
                    PageSize = 50,
                    LinksBeforeCurrentPage = 4,
                    LinksAfterCurrentPage = 4,
                };
            }

            // Generate the new view model.
            DailyDispatchIndexViewModel newViewModel = GenerateViewModel(viewModel);

            // Save the view model
            Session[FilterSessionName] = newViewModel;

            return View(newViewModel);
        }

        private DailyDispatchIndexViewModel GenerateViewModel(DailyDispatchIndexViewModel viewModel)
        {
            Db = Db ?? new DispatchContext();

            // Initialization of ViewModel
            viewModel.LoadListFilterSelectList = Extensions.BuildSelectList<DailyDispatchIndexViewModel.LoadListFilterEnum>((int)viewModel.LoadListFilterSelect);

            IEnumerable<SelectListItem> sortList = viewModel.AdminViewMode ? _sortTypesForHistory : _sortTypes;

            if (string.IsNullOrEmpty(viewModel.SortingID))
            {
                viewModel.SortingID = sortList.First().Value;
            }

            viewModel.SortingList = new SelectList(sortList, "Value", "Text", viewModel.SortingID);

            if (viewModel.DispatcherListData == null)
            {
                viewModel.DispatcherListData = Db.Dispatcher
                    .OrderBy(x => x.FirstName)
                    .ThenBy(x => x.LastName)
                    .ToList()
                    .Select(x => new SelectListItem
                    {
                        Value = x.DispatcherID.ToString(),
                        Text = x.FullName
                    });
            }

            viewModel.DispatcherList = new SelectList(viewModel.DispatcherListData, "Value", "Text", viewModel.DispatcherID);

            if (viewModel.DriverListData == null)
            {
                viewModel.DriverListData = Db.Driver
                    .OrderBy(x => x.FirstName)
                    .ThenBy(x => x.LastName)
                    .ToList()
                    .Select(x => new SelectListItem
                    {
                        Value = x.DriverID.ToString(),
                        Text = x.FullName
                    });
            }

            viewModel.DriverList = new SelectList(viewModel.DriverListData, "Value", "Text", viewModel.DriverID);

            if (viewModel.CarrierListData == null)
            {
                viewModel.CarrierListData = Db.Carrier
                    .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                    .OrderBy(x => x.Name)
                    .ToList()
                    .Select(x => new SelectListItem
                    {
                        Text = string.Format("{0}{1}", x.Name, x.DeleteDate.HasValue ? " (deleted)" : string.Empty),
                        Value = x.CarrierID.ToString()
                    });
            }

            viewModel.CarrierList = new SelectList(viewModel.CarrierListData, "Value", "Text", viewModel.CarrierID);

            if (viewModel.SelectedDates == null)
            {
                viewModel.SelectedDates = new List<DateTime>();
            }

            // Determine access to the Notes and Trailers update feature on the Index page.
            if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Modify) ||
                AppAuthorization.ElementPermission(this, "Notes").AtLeast(PermissionLevel.Modify))
            {
                viewModel.CanUseNoteUpdateMode = true;
            }
            else
            {
                viewModel.CanUseNoteUpdateMode = false;
            }

            if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Modify) ||
                AppAuthorization.ElementPermission(this, "Trailers").AtLeast(PermissionLevel.Modify))
            {
                viewModel.CanUseTrailerUpdateMode = true;
            }
            else
            {
                viewModel.CanUseTrailerUpdateMode = false;
            }

            if (AppAuthorization.ViewPermission(this, typeof(CleanupLoadController)).AtLeast(Avatar.PermissionLevel.Modify))
            {
                viewModel.CanUseCleanupUpdateMode = true;
            }
            else
            {
                viewModel.CanUseCleanupUpdateMode = false;
            }

            /*
             * Output determination: All or Paged.
             * This should be done only in History mode.
             */

            IEnumerable<DispatchViewModel> dispatches = Enumerable.Empty<DispatchViewModel>();

            if (viewModel.AdminViewMode)
            {
                bool entryError = false;

                object searchFromDate = DBNull.Value;
                object searchThruDate = DBNull.Value;
                object searchDispatchID = DBNull.Value;
                object searchCarrierID = DBNull.Value;
                object searchStoreID = DBNull.Value;
                object searchTrailerNumber = DBNull.Value;
                object searchDriverID = DBNull.Value;
                object searchTractorNumber = DBNull.Value;

                if (viewModel.FromDate.HasValue)
                {
                    searchFromDate = viewModel.FromDate.Value;
                }

                if (viewModel.ThruDate.HasValue)
                {
                    searchThruDate = viewModel.ThruDate.Value;
                }

                if (viewModel.CarrierID.HasValue)
                {
                    searchCarrierID = viewModel.CarrierID.Value;
                }

                if (viewModel.DailyDispatchID.HasValue)
                {
                    searchDispatchID = viewModel.DailyDispatchID.Value;
                }

                if (viewModel.DriverID.HasValue)
                {
                    searchDriverID = viewModel.DriverID.Value;
                }

                if (!string.IsNullOrWhiteSpace(viewModel.TrailerNumber))
                {
                    searchTrailerNumber = string.Format("%{0}%", viewModel.TrailerNumber.Trim());
                }

                if (!string.IsNullOrWhiteSpace(viewModel.TractorNumber))
                {
                    searchTractorNumber = string.Format("%{0}%", viewModel.TractorNumber.Trim());
                }

                if (!string.IsNullOrWhiteSpace(viewModel.StoreNumber))
                {
                    viewModel.StoreNumber = viewModel.StoreNumber.ToUpper();

                    Match storeSpecificationMatch = _historyStoreSpecificationPattern.Match(viewModel.StoreNumber);
                    if (!storeSpecificationMatch.Success)
                    {
                        entryError = true;
                        ModelState.AddModelError(string.Empty, "Invalid store lookup string. Use [HL|MD|HM]9999[R]");
                    }
                    else
                    {
                        string companyCodeMatch = storeSpecificationMatch.Groups["company"].Value.Trim();
                        string storeNumberMatch = storeSpecificationMatch.Groups["store"].Value.Trim();
                        string storeSuffixMatch = storeSpecificationMatch.Groups["suffix"].Value.Trim();

                        int storeNumberMatchValue = 0;

                        int.TryParse(storeNumberMatch, out storeNumberMatchValue);

                        if (storeNumberMatchValue == 0)
                        {
                            entryError = true;
                            ModelState.AddModelError(string.Empty, "Invalid store lookup string. Use [HL|MD|HM]9999[R]");
                        }
                        else
                        {
                            if (companyCodeMatch.Length == 0)
                            {
                                companyCodeMatch = "HL";
                            }

                            var stores = Db.Store.Where(x => x.StoreNumber == storeNumberMatchValue && x.CompanyID == companyCodeMatch && (storeSuffixMatch.Length == 0 ? x.DuplicateCode == null : x.DuplicateCode == storeSuffixMatch));
                            if (stores != null && stores.Any())
                            {
                                searchStoreID = string.Join(",", stores.Select(x => x.StoreID));
                            }
                            else
                            {
                                entryError = true;
                                ModelState.AddModelError(string.Empty, string.Format("Store {0}{1} not found for company {2}.", storeNumberMatchValue, storeSuffixMatch, companyCodeMatch));
                            }
                        }
                    }
                }

                if (searchFromDate != DBNull.Value && searchThruDate != DBNull.Value)
                {
                    if (searchDispatchID != DBNull.Value)
                    {
                        entryError = true;
                        ModelState.AddModelError(string.Empty, "Select dates and/or carrier, trailer, or store, or a single Dispatch number.");
                    }
                }
                else if (searchDispatchID != DBNull.Value)
                {
                    if (searchFromDate != DBNull.Value ||
                        searchThruDate != DBNull.Value ||
                        searchCarrierID != DBNull.Value ||
                        searchStoreID != DBNull.Value)
                    {
                        entryError = true;
                        ModelState.AddModelError(string.Empty, "Select dates and/or carrier, trailer, or store, or a single Dispatch number.");
                    }
                }
                else
                {
                    entryError = true;
                    ModelState.AddModelError(string.Empty, "Select dates and/or carrier, trailer, or store, or a single Dispatch number.");
                }

                if (!entryError)
                {
                    var dispatchAndLoadList = Db.Database.SqlQuery<DispatchAndLoad>(
                        _SqlSearchByDeparture,
                        new SqlParameter("@SelectionDateFrom", SqlDbType.Date) { IsNullable = true, Value = searchFromDate },
                        new SqlParameter("@SelectionDateThru", SqlDbType.Date) { IsNullable = true, Value = searchThruDate },
                        new SqlParameter("@CarrierID", SqlDbType.Int) { IsNullable = true, Value = searchCarrierID },
                        new SqlParameter("@Trailer", SqlDbType.VarChar) { IsNullable = true, Value = searchTrailerNumber },
                        new SqlParameter("@DispatchID", SqlDbType.Int) { IsNullable = true, Value = searchDispatchID },
                        new SqlParameter("@DriverID", SqlDbType.Int) { IsNullable = true, Value = searchDriverID },
                        new SqlParameter("@Tractor", SqlDbType.VarChar) { IsNullable = true, Value = searchTractorNumber },
                        new SqlParameter("@StoreIDs", SqlDbType.VarChar) { IsNullable = true, Value = searchStoreID });

                    dispatches = BuildDispatchViewModelList(dispatchAndLoadList);
                }
            }
            else
            {
                List<DispatchDateControl> dispatchDateControlRecords = Db.OpenDispatchDates().OrderBy(x => x.DispatchDate).ToList();

                DispatchDateControl oldestOpenDispatchDateRecord = dispatchDateControlRecords.First();
                DispatchDateControl newestOpenDispatchDateRecord = dispatchDateControlRecords.Last();

                viewModel.OldestOpenDispatchDate = oldestOpenDispatchDateRecord.DispatchDate;
                DateTime newestOpenDispatchDate = newestOpenDispatchDateRecord.DispatchDate;

                int openDays = (newestOpenDispatchDate - (viewModel.OldestOpenDispatchDate ?? newestOpenDispatchDate)).Days + 1;
                openDays += 3; // to see two-day or even three deliveries, plus Friday dispatches with Monday deliveries

                var dateList = Enumerable.Range(0, openDays).Select(x => viewModel.OldestOpenDispatchDate.Value.AddDays(x));

                viewModel.DispatchWeeks = new List<DailyDispatchIndexViewModel.DispatchWeek>();

                int theWeek = oldestOpenDispatchDateRecord.WeekNumber;
                int theDay = oldestOpenDispatchDateRecord.WeekDayID;

                foreach (DateTime workdate in dateList)
                {
                    if (viewModel.DispatchWeeks.Count() == 0 || viewModel.DispatchWeeks.Last().WeekNumber != theWeek)
                    {
                        viewModel.DispatchWeeks.Add(new DailyDispatchIndexViewModel.DispatchWeek
                        {
                            WeekNumber = theWeek,
                            WeekDay = new DateTime?[7]
                        });
                    }

                    viewModel.DispatchWeeks.Last().WeekDay[theDay - 1] = workdate;
                    if (theDay == 7)
                    {
                        theDay = 1;
                        theWeek = theWeek == 1 ? 2 : 1;
                    }
                    else
                    {
                        theDay++;
                    }
                }

                // if any open dates are now closed, then make sure they are removed from the filter list.
                List<DateTime> pastDates = viewModel.SelectedDates.Except(dateList).ToList();
                pastDates.ForEach(x => viewModel.SelectedDates.Remove(x));

                if (viewModel.MultipleDateSelect)
                {
                    // For a multiple date selection, presence of the date is a toggle; if there, delete it, if not, add it.
                    if (viewModel.SelectDate.HasValue)
                    {
                        if (dateList.Any(x => x == viewModel.SelectDate.Value))
                        {
                            if (viewModel.SelectedDates.Contains(viewModel.SelectDate.Value))
                            {
                                viewModel.SelectedDates.Remove(viewModel.SelectDate.Value);
                            }
                            else
                            {
                                viewModel.SelectedDates.Add(viewModel.SelectDate.Value);
                            }
                        }
                        else
                        {
                            viewModel.SelectDate = dateList.Min();
                            viewModel.SelectedDates.Add(viewModel.SelectDate.Value);
                        }
                    }

                    viewModel.SelectDate = null;
                }
                else
                {
                    // for a single date selection, clear any existing date and add just this one date.
                    if (viewModel.SelectDate.HasValue)
                    {
                        if (dateList.Any(x => x == viewModel.SelectDate.Value))
                        {
                            viewModel.SelectedDates.Clear();
                            viewModel.SelectedDates.Add(viewModel.SelectDate.Value);
                        }
                        else
                        {
                            if (dateList.Any())
                            {
                                viewModel.SelectDate = dateList.Min();
                                viewModel.SelectedDates.Add(viewModel.SelectDate.Value);
                            }
                        }
                    }
                    else
                    {
                        if (viewModel.SelectedDates.Count > 1)
                        {
                            DateTime firstDate = viewModel.SelectedDates.Min();
                            viewModel.SelectedDates.Clear();
                            viewModel.SelectedDates.Add(firstDate);
                        }
                    }
                }

                if (viewModel.DateTypeSelect == DailyDispatchIndexViewModel.DateTypeSelectEnum.ArrivalDate)
                {
                    DateTime fromDate = viewModel.SelectedDates.Min();
                    DateTime thruDate = viewModel.SelectedDates.Max();
                    DateTime thruDatePlus1 = thruDate.AddDays(1).Date;

                    viewModel.LatestSelectedDeliveryDate = thruDate;

                    if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Outbound_Loads_and_Transit)
                    {
                        var dispatchAndLoadList = Db.Database.SqlQuery<DispatchAndLoad>(
                            _SqlQueryByArrival,
                            new SqlParameter("@SelectionDateFrom", fromDate),
                            new SqlParameter("@SelectionDateThru", thruDatePlus1));

                        dispatches = BuildDispatchViewModelList(dispatchAndLoadList);
                    }
                    else
                    {
                        var dispatchAndLoadList = Db.Database.SqlQuery<DispatchAndLoad>(
                            _SqlQueryByArrival,
                            new SqlParameter("@SelectionDateFrom", fromDate),
                            new SqlParameter("@SelectionDateThru", thruDate));

                        dispatches = BuildDispatchViewModelList(dispatchAndLoadList);
                    }

                    /*
                     * Filter, selection and sorting.
                     */

                    if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.All)
                    {
                        // Show all loads. No LoadType filtering.
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Any_Loads)
                    {
                        dispatches = dispatches
                            .Where(x => x.Loads.Any()
                                && (
                                x.Loads.Where(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                                    .Any(y => viewModel.SelectedDates.Contains(y.EtaDate.HasValue ? y.EtaDate.Value.Date : DateTime.MinValue.Date))
                                    ||
                                    x.LoadHistory.Where(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                                        .Any(y => y.DailyDispatchID == x.DailyDispatchID && viewModel.SelectedDates.Contains(y.ArrivalTime.HasValue ? y.ArrivalTime.Value.Date : DateTime.MinValue.Date))
                                    ||
                                    x.Loads.Where(y => y.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || y.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                                        .Any(y => viewModel.SelectedDates.Contains(y.PickupDate.HasValue ? y.PickupDate.Value.Date : DateTime.MinValue.Date))));
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Outbound_Loads)
                    {
                        dispatches = dispatches.Where(x => x.Loads.Any(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType)));

                        dispatches = dispatches
                            .Where(x =>
                                x.Loads.Where(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                                    .Any(y => viewModel.SelectedDates.Contains(y.EtaDate.HasValue ? y.EtaDate.Value.Date : DateTime.MinValue.Date))
                                ||
                                x.LoadHistory.Where(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                                    .Any(y => y.DailyDispatchID == x.DailyDispatchID && viewModel.SelectedDates.Contains(y.ArrivalTime.HasValue ? y.ArrivalTime.Value.Date : DateTime.MinValue.Date)));
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Outbound_Loads_and_Transit)
                    {
                        int lastSelectedDateDOW;

                        switch (thruDate.DayOfWeek)
                        {
                            case DayOfWeek.Monday:
                                lastSelectedDateDOW = 1;    // Monday
                                break;
                            case DayOfWeek.Tuesday:
                                lastSelectedDateDOW = 2;    // Tuesday
                                break;
                            case DayOfWeek.Wednesday:
                                lastSelectedDateDOW = 3;    // Wednesday
                                break;
                            case DayOfWeek.Thursday:
                                lastSelectedDateDOW = 4;    // Thursday
                                break;
                            default:
                                lastSelectedDateDOW = 0;    // Friday
                                break;
                        }

                        dispatches = dispatches.Where(x =>
                            x.Loads.Where(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                                    .Any(y => viewModel.SelectedDates.Contains(y.EtaDate ?? DateTime.MinValue.Date))
                                ||
                                x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                                    .Any(y => thruDatePlus1 == (y.EtaDate.HasValue ? y.EtaDate.Value.Date : DateTime.MinValue.Date)
                                        && ((y.StoreNumber + 5) % 5) == lastSelectedDateDOW
                                        && y.StoreLoadType == "A")
                                ||
                                x.LoadHistory.Where(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                                    .Any(y => y.DailyDispatchID == x.DailyDispatchID && viewModel.SelectedDates.Contains(y.ArrivalTime.HasValue ? y.ArrivalTime.Value.Date : DateTime.MinValue)));

                        foreach (var dispatch in dispatches)
                        {
                            if (dispatch.Loads.Any(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD) &&
                                dispatch.Loads.Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).All(x => x.EtaDate.Value.Date > thruDate))
                            {
                                dispatch.InTransitOnRegularDeliveryDay = true;
                            }
                        }
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Outbound_Loads_Only)
                    {
                        dispatches = dispatches
                            .Where(x =>
                                x.Loads.All(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                                &&
                                x.LoadHistory.All(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                                && (
                                    x.Loads.Any(y => viewModel.SelectedDates.Contains(y.EtaDate.HasValue ? y.EtaDate.Value.Date : DateTime.MinValue.Date))
                                    ||
                                    x.LoadHistory.Any(y => y.DailyDispatchID == x.DailyDispatchID && viewModel.SelectedDates.Contains(y.ArrivalTime.HasValue ? y.ArrivalTime.Value.Date : DateTime.MinValue))));
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Inbound_Loads)
                    {
                        dispatches = dispatches
                            .Where(x => 
                                x.Loads.Where(y => DatabaseLists.INBOUND_LOAD_TYPES.Contains(y.LoadType))
                                .Any(y => viewModel.SelectedDates.Contains(y.PickupDate.HasValue ? y.PickupDate.Value.Date : DateTime.MinValue.Date)));
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Inbound_Loads_Only)
                    {
                        dispatches = dispatches
                            .Where(x =>
                                x.Loads.All(y => DatabaseLists.INBOUND_LOAD_TYPES.Contains(y.LoadType)) 
                                &&
                                x.Loads.Any(y => viewModel.SelectedDates.Contains(y.PickupDate.HasValue ? y.PickupDate.Value.Date : DateTime.MinValue.Date)));
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.Without_Loads)
                    {
                        dispatches = dispatches.Where(x => !x.Loads.Any());
                    }
                    else
                    {
                        throw new Exception("Cannot determine Dispatch type for load inclusion.");
                    }
                }
                else if (viewModel.DateTypeSelect == DailyDispatchIndexViewModel.DateTypeSelectEnum.DepartureDate)
                {
                    var dispatchAndLoadList = Db.Database.SqlQuery<DispatchAndLoad>(
                            _SqlQueryByDeparture,
                            new SqlParameter("@SelectionDateFrom", viewModel.SelectedDates.Min()),
                            new SqlParameter("@SelectionDateThru", viewModel.SelectedDates.Max()));
                    dispatches = BuildDispatchViewModelList(dispatchAndLoadList);

                    if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.All)
                    {
                        // Show all loads. No LoadType filtering.
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Any_Loads)
                    {
                        dispatches = dispatches.Where(x => x.Loads.Any());
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Outbound_Loads)
                    {
                        dispatches = dispatches.Where(x =>
                            x.Loads.Any(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                            ||
                            x.LoadHistory.Any(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType)));
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Outbound_Loads_Only)
                    {
                        dispatches = dispatches.Where(x =>
                            x.Loads.All(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                            &&
                            x.LoadHistory.All(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType)));
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Inbound_Loads)
                    {
                        dispatches = dispatches.Where(x => x.Loads.Any(y => DatabaseLists.INBOUND_LOAD_TYPES.Contains(y.LoadType)));
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.With_Inbound_Loads_Only)
                    {
                        dispatches = dispatches.Where(x =>
                            x.Loads.All(y => DatabaseLists.INBOUND_LOAD_TYPES.Contains(y.LoadType))
                            &&
                            !x.LoadHistory.All(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType)));
                    }
                    else if (viewModel.LoadListFilterSelect == DailyDispatchIndexViewModel.LoadListFilterEnum.Without_Loads)
                    {
                        dispatches = dispatches.Where(x => !x.Loads.Any());
                    }
                }
                else
                {
                    throw new Exception("Cannot determine display mode. Valid modes: Arrivals, Departures, History.");
                }

                /*
                 * Filters
                 */

                if (viewModel.CarrierSelect == true || viewModel.CompanySelect == true || viewModel.NoCarrierOrCompanySelect == true)
                {
                    if (viewModel.CarrierID.HasValue)
                    {
                        dispatches = dispatches.Where(x =>
                            (viewModel.CarrierSelect == true && (x.CarrierID.HasValue && x.CarrierID == viewModel.CarrierID.Value))
                            || (viewModel.CompanySelect == true && (x.Driver1ID.HasValue || x.Driver2ID.HasValue))
                            || (viewModel.NoCarrierOrCompanySelect == true && (x.CarrierID.HasValue == false && x.Driver1ID.HasValue == false && x.Driver2ID.HasValue == false)));
                    }
                    else
                    {
                        dispatches = dispatches.Where(x =>
                            (viewModel.CarrierSelect == true && x.CarrierID.HasValue)
                            || (viewModel.CompanySelect == true && (x.Driver1ID.HasValue || x.Driver2ID.HasValue))
                            || (viewModel.NoCarrierOrCompanySelect == true && (x.CarrierID.HasValue == false && x.Driver1ID.HasValue == false && x.Driver2ID.HasValue == false)));
                    }
                }

                if (viewModel.DispatcherID.HasValue)
                {
                    dispatches = dispatches.Where(x =>
                        x.Driver1DispatcherID == viewModel.DispatcherID || x.Driver2DispatcherID == viewModel.DispatcherID);
                }

                if (viewModel.DispatchesWithWarnings == true)
                {
                    dispatches = dispatches.Where(x => (
                        x.CarrierID.HasValue
                        && x.CarrierTotalCharge.HasValue == false
                        && (
                            x.CarrierRate.HasValue == false
                            || x.CarrierRate == 0m
                            || x.CarrierMiles.HasValue == false
                            || x.CarrierMiles == 0
                            || x.FuelSurcharge.HasValue == false
                            || x.FuelSurcharge == 0m))
                    || x.Loads.Where(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP).Any(y => y.LinearFeet.HasValue == false));
                }

                if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
                {
                    string textValue = viewModel.SearchField.Trim().ToLower();
                    int intValue = 0;
                    bool isNumber = int.TryParse(textValue, out intValue);

                    if (isNumber && intValue > 0)
                    {
                        dispatches = dispatches.Where(x =>
                            x.DailyDispatchID == intValue
                            || (x.TractorNumber != null && x.TractorNumber == textValue)
                            || (x.Loads != null && x.Loads.Any(y => y.StoreNumber.HasValue && y.StoreNumber == intValue))
                            || (x.Comment != null && x.Comment.ToLower().Contains(textValue))
                            || (x.Trailer != null && x.Trailer.ToLower().Contains(textValue))
                            || (x.TrailerIn != null && x.TrailerIn.ToLower().Contains(textValue)));
                    }
                    else
                    {
                        dispatches = dispatches.Where(x =>
                            (x.Driver1FirstName != null && x.Driver1FirstName.ToLower().Contains(textValue))
                            || (x.Driver1LastName != null && x.Driver1LastName.ToLower().Contains(textValue))
                            || (x.Driver2FirstName != null && x.Driver2FirstName.ToLower().Contains(textValue))
                            || (x.Driver2LastName != null && x.Driver2LastName.ToLower().Contains(textValue))
                            || (x.Comment != null && x.Comment.ToLower().Contains(textValue))
                            || (x.Trailer != null && x.Trailer.ToLower().Contains(textValue))
                            || (x.TrailerIn != null && x.TrailerIn.ToLower().Contains(textValue))
                            || (x.Loads != null && x.Loads.Any(y => y.StoreCity != null && y.StoreCity.ToLower().Contains(textValue)))
                            || (x.Loads != null && x.Loads.Any(y => y.StoreStateCode != null && y.StoreStateCode == textValue)));
                    }
                }
            }

            /*
             * Sorting
             */

            if (!string.IsNullOrEmpty(viewModel.SortingID))
            {
                string[] sorting = viewModel.SortingID.Split(',');
                if (sorting.Length == 2)
                {
                    DispatchSortColumn sortColumn;
                    if (!Enum.TryParse(sorting[0], out sortColumn))
                    {
                        sortColumn = DispatchSortColumn.DispatchDepart;
                    }

                    int sortDirection = sorting[1].ToUpper() == "A" ? 1 : -1;
                    dispatches = SortDispatchViewModelList(dispatches, sortColumn, sortDirection);
                }
            }

            if (viewModel.OldestOpenDispatchDate == null)
            {
                viewModel.OldestOpenDispatchDate = Db.OpenDispatchDates().OldestDispatchDate();
            }

            viewModel.Dispatches = dispatches.ToList();

            return viewModel;
        }

        public static List<DispatchViewModel> BuildDispatchViewModelList(IEnumerable<DispatchAndLoad> dispatchAndLoadList)
        {
            List<DispatchViewModel> dispatches = new List<DispatchViewModel>();

            int currentDailyDispatchID = 0;

            DispatchViewModel dvm = null;

            List<LoadDragDropViewModel> loadList = null;

            List<DispatchLoadLinkViewModel> loadHistory = null;

            foreach (DispatchAndLoad rec in dispatchAndLoadList)
            {
                if (rec.DailyDispatchID != currentDailyDispatchID)
                {
                    if (dvm != null)
                    {
                        dvm.Loads = loadList;
                        dvm.LoadHistory = loadHistory;
                        dvm.SetFinalInstantiationValues();
                        dispatches.Add(dvm);
                    }

                    currentDailyDispatchID = rec.DailyDispatchID;

                    dvm = new DispatchViewModel
                    {
                        CarrierID = rec.CarrierID,
                        CarrierMiles = rec.CarrierMiles,
                        CarrierName = rec.CarrierName,
                        CarrierRate = rec.CarrierRate,
                        CarrierTotalCharge = rec.CarrierTotalCharge,
                        LockCarrierTotalCharge = rec.LockCarrierTotalCharge,
                        Comment = rec.Comment,
                        DailyDispatchID = rec.DailyDispatchID,
                        DepartureTime = rec.DepartureTime,
                        DispatchDate = rec.DispatchDate,
                        Driver1ID = rec.Driver1ID,
                        Driver1FirstName = rec.Driver1FirstName,
                        Driver1LastName = rec.Driver1LastName,
                        Driver1Name = string.Format("{0} {1} {2}", rec.Driver1FirstName ?? string.Empty, rec.Driver1LastName ?? string.Empty, rec.Driver1Suffix ?? string.Empty),
                        Driver1DispatcherID = rec.Driver1DispatcherID,
                        Driver2ID = rec.Driver2ID,
                        Driver2FirstName = rec.Driver2FirstName,
                        Driver2LastName = rec.Driver2LastName,
                        Driver2Name = string.Format("{0} {1} {2}", rec.Driver2FirstName ?? string.Empty, rec.Driver2LastName ?? string.Empty, rec.Driver2Suffix ?? string.Empty),
                        Driver2DispatcherID = rec.Driver2DispatcherID,
                        FuelSurcharge = rec.FuelSurcharge,
                        Generated = rec.Generated,
                        TractorNumber = rec.TractorNumber,
                        Trailer = rec.Trailer,
                        TrailerIn = rec.TrailerIn
                    };

                    loadList = new List<LoadDragDropViewModel>();
                    loadHistory = new List<DispatchLoadLinkViewModel>();
                }

                if (rec.HistoryLoadID > 0)
                {
                    loadHistory.Add(new DispatchLoadLinkViewModel
                    {
                        ArrivalTime = rec.EtaDate,
                        DailyDispatchID = rec.DailyDispatchID,
                        DeliveryType = rec.DeliveryType,
                        DepartureTime = rec.DepartureTime,
                        LoadDeliveryCity = rec.StoreCity,
                        LoadDeliveryStateCode = rec.StoreStateCode,
                        LoadDescription = rec.LoadDescription,
                        LoadID = rec.HistoryLoadID ?? 0,
                        LoadName = rec.LoadName,
                        LoadPickupCity = rec.LoadPickupCity,
                        LoadPickupStateCode = rec.LoadPickupStateCode,
                        LoadType = rec.HistoryLoadType
                    });
                }
                else
                {
                    loadList.Add(new LoadDragDropViewModel
                    {
                        Cartons = rec.Cartons,
                        Comment = rec.LoadComment,
                        DailyDispatchID = rec.DailyDispatchID,
                        DeliveryType = rec.DeliveryType,
                        DispatchLoadOrder = rec.DispatchLoadOrder ?? 0,
                        EtaDate = rec.EtaDate,
                        EtaTime = rec.EtaDate,
                        LinearFeet = rec.LinearFeet,
                        LoadDeliveryCity = rec.LoadDeliveryCity,
                        LoadDeliveryStateCode = rec.LoadDeliveryStateCode,
                        LoadDescription = rec.LoadDescription,
                        LoadID = rec.LoadID ?? 0,
                        LoadLocks = rec.LoadLocks,
                        LoadName = rec.LoadName,
                        LoadPickupCity = rec.LoadPickupCity,
                        LoadPickupStateCode = rec.LoadPickupStateCode,
                        LoadType = rec.LoadType,
                        Pallets = rec.Pallets,
                        PickupDate = rec.PickupDate,
                        PickupTime = rec.PickupDate,
                        StoreAndCompany = rec.StoreAndCompany,
                        StoreCity = rec.StoreCity,
                        StoreCompanyID = rec.StoreCompanyID,
                        StoreLoadType = rec.StoreLoadType,
                        StoreNumber = rec.StoreNumber,
                        StoreOpening = rec.StoreOpening ?? false,
                        StoreStateCode = rec.StoreStateCode,
                        Totes = rec.Totes
                    });
                }
            }

            if (dvm != null)
            {
                dvm.Loads = loadList;
                dvm.LoadHistory = loadHistory;
                dvm.SetFinalInstantiationValues();
                dispatches.Add(dvm);
            }

            return dispatches;
        }

        public static IOrderedEnumerable<DispatchViewModel> SortDispatchViewModelList(IEnumerable<DispatchViewModel> query, DispatchSortColumn sortColumn, int sortDirection)
        {
            LoadDragDropViewModel empty = new LoadDragDropViewModel
            {
                Cartons = 0,
                Comment = string.Empty,
                Cube = 0,
                DailyDispatchID = 0,
                DeliveryType = string.Empty,
                DisableRemoveButton = false,
                DispatchLoadOrder = 0,
                DoubleStack = false,
                DownStack = false,
                EtaDate = DateTime.MinValue,
                EtaTime = DateTime.MinValue,
                LinearFeet = 0,
                LoadDeliveryCity = string.Empty,
                LoadDeliveryStateCode = string.Empty,
                LoadDescription = string.Empty,
                LoadID = 0,
                LoadLocks = 0,
                LoadName = string.Empty,
                LoadPickupCity = string.Empty,
                LoadPickupStateCode = string.Empty,
                LoadPickupZip = string.Empty,
                LoadType = string.Empty,
                Pallets = 0,
                PickupDate = DateTime.MinValue,
                PickupTime = DateTime.MinValue,
                ReadyDate = DateTime.MinValue,
                StoreAndCompany = string.Empty,
                StoreCity = string.Empty,
                StoreCompanyID = string.Empty,
                StoreDeliveries = string.Empty,
                StoreLoadType = string.Empty,
                StoreNumber = 0,
                StoreOpening = false,
                StoreStateCode = string.Empty,
                Totes = 0,
                Truckload = false,
                ViewStatus = string.Empty,
                Weight = 0
            };

            switch (sortColumn)
            {
                case DispatchSortColumn.OutboundStore:
                    return sortDirection >= 0
                        ? query
                        .OrderBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).DefaultIfEmpty(empty).FirstOrDefault().StoreCompanyID)
                        .ThenBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).DefaultIfEmpty(empty).FirstOrDefault().StoreNumber)
                        : query
                        .OrderByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).DefaultIfEmpty(empty).FirstOrDefault().StoreCompanyID)
                        .ThenByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).DefaultIfEmpty(empty).FirstOrDefault().StoreNumber);
                case DispatchSortColumn.OutboundArrival:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).DefaultIfEmpty(empty).Select(y => y.EtaDate).Min())
                        : query.OrderByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).DefaultIfEmpty(empty).Select(y => y.EtaDate).Min());
                case DispatchSortColumn.OutboundLocation:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                            .DefaultIfEmpty(empty)
                            .Select(y => new 
                            {
                                LoadOrder = y.DispatchLoadOrder, Location = y.StoreStateCode + y.StoreCity 
                            })
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location)
                        : query.OrderByDescending(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                            .DefaultIfEmpty(empty)
                            .Select(y => new 
                            { 
                                LoadOrder = y.DispatchLoadOrder, Location = y.StoreStateCode + y.StoreCity 
                            })
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location);
                case DispatchSortColumn.CarrierThenStore:
                    return sortDirection >= 0
                        ? query
                        .OrderBy(x => x.CarrierName)
                        .ThenBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).DefaultIfEmpty(empty).FirstOrDefault().StoreCompanyID)
                        .ThenBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).DefaultIfEmpty(empty).FirstOrDefault().StoreNumber)
                        : query
                        .OrderByDescending(x => x.CarrierName)
                        .ThenByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).DefaultIfEmpty(empty).FirstOrDefault().StoreCompanyID)
                        .ThenByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).DefaultIfEmpty(empty).FirstOrDefault().StoreNumber);
                case DispatchSortColumn.InboundLocation:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || y.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                            .DefaultIfEmpty(empty)
                            .Select(y => new 
                            { 
                                LoadOrder = y.DispatchLoadOrder, Location = y.LoadPickupStateCode + y.LoadPickupCity 
                            })
                            .Concat(x.Loads
                                .Where(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                                .Select(y => new 
                                { 
                                    LoadOrder = y.DispatchLoadOrder, Location = y.StoreStateCode + y.StoreCity 
                                }))
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location)
                        : query.OrderByDescending(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || y.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                            .DefaultIfEmpty(empty)
                            .Select(y => new 
                            { 
                                LoadOrder = y.DispatchLoadOrder, Location = y.LoadPickupStateCode + y.LoadPickupCity 
                            })
                            .Concat(x.Loads
                                .Where(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                                .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.StoreStateCode + y.StoreCity }))
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location);
                case DispatchSortColumn.TractorNumber:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.TractorNumber)
                        : query.OrderByDescending(x => x.TractorNumber);
                case DispatchSortColumn.DispatchID:
                    return sortDirection >= 0 
                        ? query.OrderBy(x => x.DailyDispatchID)
                        : query.OrderByDescending(x => x.DailyDispatchID);
                case DispatchSortColumn.CreatedThenGenerated:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Generated)
                        : query.OrderByDescending(x => x.Generated);
                case DispatchSortColumn.DispatchDepart:
                default:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.DispatchDate).ThenBy(x => x.DepartureTime)
                        : query.OrderByDescending(x => x.DispatchDate).ThenByDescending(x => x.DepartureTime);
            }
        }

        /// <summary>
        /// This method is called to get the currently displayed list of Dispatches that have a Driver Paysheet associated with them
        /// and give the list of DispatchIDs to the print controller to print all of them at once.
        /// </summary>
        /// <returns></returns>
        public ActionResult PrintListedPaysheets(string paysheetType = null)
        {
            DailyDispatchIndexViewModel viewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
            if (viewModel != null)
            {
                var driverPaysheetIDs = viewModel.Dispatches
                    .Where(x => x.CarrierID.HasValue == false)
                    .Where(x => x.Loads.Any() || (x.Containers != null && x.Containers.Any()))
                    .Select(x => x.DailyDispatchID.ToString());

                TempData[ReportController.REPORT_ELEMENTS_TEMPDATA_NAME] = string.Join(",", driverPaysheetIDs);

                if (string.IsNullOrWhiteSpace(paysheetType))
                {
                    paysheetType = DatabaseLists.DISPATCH_GROUP_OTR;
                }

                return RedirectToAction("PrintListedPaysheets", "Report", new { paysheetType = paysheetType });
            }
            else
            {
                return new EmptyResult();
            }
        }

        /// <summary>
        /// Update the saved Dispatch list to allow the list to be recreated without a full database reload.
        /// This method should be called after SaveChanges() has been called.
        /// </summary>
        /// <param name="dailyDispatchID">Dispatch ID to add or refresh</param>
        protected void UpdateDispatchIndexList(int dailyDispatchID, bool existingOnly = false)
        {
            Db = Db ?? new DispatchContext();

            DailyDispatchIndexViewModel viewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;

            if (viewModel != null && viewModel.Dispatches != null)
            {
                int index = 0;
                
                DispatchViewModel dispatchViewModel = viewModel.Dispatches.FirstOrDefault(x => x.DailyDispatchID == dailyDispatchID);

                if (dispatchViewModel != null)
                {
                    index = viewModel.Dispatches.IndexOf(dispatchViewModel);
                    if (index >= 0)
                    {
                        viewModel.Dispatches.RemoveAt(index);
                    }
                    else
                    {
                        index = 0;
                    }
                }
                else if (existingOnly)
                {
                    return;
                }

                DailyDispatch updatedDispatch = Db.DailyDispatch
                    .AsNoTracking()
                    .Include(x => x.Driver1)
                    .Include(x => x.Driver2)
                    .Include(x => x.Carrier)
                    .Include(x => x.Loads)
                    .Include(x => x.Loads.Select(a => a.Store))
                    .Include(x => x.Loads.Select(a => a.PickupCompany))
                    .Include(x => x.Containers)
                    .Include(x => x.LoadHistory.Select(a => a.Load).Select(a => a.Store))
                    .Single(x => x.DailyDispatchID == dailyDispatchID);
                DispatchViewModel replacementViewModel = new DispatchViewModel(updatedDispatch);
                viewModel.Dispatches.Insert(index, replacementViewModel);
            }
        }

        #endregion

        #region Display, Create, Edit, and Delete methods

        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
        public ActionResult Details(int id)
        {
            Db = Db ?? new DispatchContext();

            DailyDispatch model = Db.DailyDispatch
                .Include(x => x.Carrier)
                .Include(x => x.Driver1)
                .Include(x => x.Driver2)
                .Include(x => x.Loads)
                .Include(x => x.Loads.Select(a => a.PickupCompany))
                .Include(x => x.Loads.Select(a => a.Store))
                .Single(x => x.DailyDispatchID == id);

            ViewBag.InboundLoads = BagInboundLoads(model.Loads.InboundOnly().Select(x => x.LoadID), id);
            ViewBag.OutboundLoads = BagOutboundLoads(model.Loads.OutboundOnly().Select(x => x.LoadID), id);

            return View(model);
        }

        /// <summary>
        /// Initial Create method for a Dispatch.
        /// </summary>
        /// <param name="id">If present, it is a LoadID of a load dragged from another Dispatch on the Index view.</param>
        /// <returns></returns>
        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
        public ActionResult Create(int? id = null, string catchall = null)
        {
            Db = Db ?? new DispatchContext();

            TempData[TEMPDATA_RETURN_URL] = HttpContext.Request.UrlReferrer == null ? this.Url.Action("Index") : HttpContext.Request.UrlReferrer.ToString();

            ScreenMessagesViewModel screenMessages = new ScreenMessagesViewModel();

            DailyDispatch model = new DailyDispatch()
                {
                    LockCarrierTotalCharge = true
                };

            DailyDispatchIndexViewModel savedViewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
            if (savedViewModel != null && savedViewModel.SelectedDates != null && savedViewModel.SelectedDates.Any())
            {
                model.DispatchDate = savedViewModel.SelectedDates.Min();
            }
            else
            {
                model.DispatchDate = Db.OpenDispatchDates().OldestDispatchDate();
            }

            List<int> inboundLoadIDs = new List<int>();
            List<int> outboundLoadIDs = new List<int>();

            Session[DispatchEditSessionName] = new DispatchEdit();

            DailyDispatch dragSourceForCopy = null;

            if (id.HasValue)
            {
                if (id.Value != 0)
                {
                    Load addLoad = Db.Load.Find(id.Value);
                    if (addLoad != null)
                    {
                        if (DatabaseLists.INBOUND_LOAD_TYPES.Contains(addLoad.LoadType))
                        {
                            inboundLoadIDs.Add(addLoad.LoadID);
                        }
                        else if (DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(addLoad.LoadType))
                        {
                            outboundLoadIDs.Add(addLoad.LoadID);
                        }

                        if (addLoad.DailyDispatchID.HasValue)
                        {
                            dragSourceForCopy = Db.DailyDispatch.Find(addLoad.DailyDispatchID.Value);
                        }
                    }
                }
                else if (!string.IsNullOrWhiteSpace(catchall))
                {
                    string[] extraInput = catchall.ToLower().Split(',').Select(x => x.Trim()).ToArray();
                    foreach (string input in extraInput)
                    {
                        int loadID = 0;
                        if (int.TryParse(input, out loadID))
                        {
                            Load addLoad = Db.Load.Find(loadID);
                            if (addLoad != null)
                            {
                                if (DatabaseLists.INBOUND_LOAD_TYPES.Contains(addLoad.LoadType))
                                {
                                    inboundLoadIDs.Add(addLoad.LoadID);
                                    ViewBag.DraggedLoadsAdded = true;
                                }
                                else if (DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(addLoad.LoadType))
                                {
                                    outboundLoadIDs.Add(addLoad.LoadID);
                                    ViewBag.DraggedLoadsAdded = true;
                                }
                            }
                        }
                    }
                }
            }

            // Copy these fields from the dispatch where the load was dragged from.
            if (dragSourceForCopy != null)
            {
                model.DispatchDate = dragSourceForCopy.DispatchDate;
                model.DepartureTime = dragSourceForCopy.DepartureTime;
                model.InboundDate = dragSourceForCopy.InboundDate;
                model.DispatchGroup = dragSourceForCopy.DispatchGroup;
            }
            else
            {
                if (this is ContainerDispatchController)
                {
                    model.DispatchGroup = DatabaseLists.DISPATCH_GROUP_DALLAS;
                }
            }

            ViewBag.InboundLoads = BagInboundLoads(inboundLoadIDs);
            ViewBag.OutboundLoads = BagOutboundLoads(outboundLoadIDs);

            ViewBag.ScreenMessages = screenMessages;

            LoadViewBag(model);
            return View(model);
        }

        /// <summary>
        /// Insert method for a complete dispatch. 
        /// </summary>
        /// <param name="screen">Input fields from the screen. Will be edited.</param>
        /// <param name="inboundLoadID">If present, a list of INTs representing the inbound LoadIDs that should be on the Dispatch. 
        /// Order is important, as it represents the order of the loads in the trailer, nose to tail.</param>
        /// <param name="outboundLoadID">If present, a list of INTs representing the outbound LoadIDs that should be on the Dispatch. 
        /// Order is important, as it represents the order of the loads in the trailer, nose to tail.</param>
        /// <param name="screenMessages">Turnaround ScreenMessages object, with user responses.</param>
        /// <returns></returns>
        [HttpPost]
        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
        public ActionResult Create(
            DailyDispatch model, 
            int[] inboundLoadID, 
            int[] outboundLoadID,
            Container[] containers,
            ScreenMessagesViewModel screenMessages)
        {
            Db = Db ?? new DispatchContext();

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            inboundLoadID = inboundLoadID ?? new int[] { };
            outboundLoadID = outboundLoadID ?? new int[] { };
            containers = containers ?? new Container[] { };

            TempData.Keep(TEMPDATA_RETURN_URL);

            screenMessages = new ScreenMessagesViewModel(screenMessages);

            foreach (var key in ModelState.Keys.Where(x => x.StartsWith("screenMessages")).ToList())
            {
                ModelState.Remove(key);
            }
            
            if (!ModelState.IsValid)
            {
                ViewBag.InboundLoads = BagInboundLoads(inboundLoadID, tempLoads: dispatchEdit.TempInboundLoads);
                ViewBag.OutboundLoads = BagOutboundLoads(outboundLoadID, tempLoads: dispatchEdit.TempOutboundLoads);
                ViewBag.Containers = BagContainers(containers);
                LoadViewBag(model);
                return View(model);
            }

            /*
             * Edit dispatch values.
             */

            // Set the week and day.
            SetWeekAndDay(model);

            // Edit Carrier and Driver settings
            if (model.CarrierID.HasValue && (model.Driver1ID.HasValue || model.Driver2ID.HasValue))
            {
                screenMessages.Add(new ScreenMessagesViewModel.Message
                {
                    Text = "Carrier and Drivers cannot be selected together.",
                    Key = "DriverAndCarrier",
                    ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                });
            }

            if (model.DepartureTime.HasValue)
            {
                model.DepartureTime = model.DispatchDate.Date + model.DepartureTime.Value.TimeOfDay;
            }
            else
            {
                model.DepartureTime = model.DispatchDate.Date;
            }

            if ((model.Trailer != null && model.Trailer.Trim().Contains(' ')) || 
                (model.TrailerIn != null && model.TrailerIn.Trim().Contains(' ')))
            {
                screenMessages.Add(new ScreenMessagesViewModel.Message
                {
                    Text = "Trailer numbers cannot contain spaces.",
                    Key = "TrailerSpaceCheck",
                    ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                });
            }

            if (model.Driver1ID.HasValue)
            {
                if (string.IsNullOrWhiteSpace(model.TractorNumber))
                {
                    Driver driver = Db.Driver.Single(x => x.DriverID == model.Driver1ID);
                    if (!string.IsNullOrWhiteSpace(driver.TractorNumber))
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = "Tractor Number missing. Fetch tractor number for driver?",
                            Key = "TractorNumberFetch",
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.NeedYesNo
                        });
                    }
                }
            }

            EditDispatchLoads(model, null, dispatchEdit, inboundLoadID, outboundLoadID, screenMessages);

            EditContainers(model, containers, screenMessages);

            // Check for unacknowledged update error messages.
            if (screenMessages.AllMessagesFixedOrAcknowledged() == false)
            {
                ViewBag.ScreenMessages = screenMessages;
                ViewBag.InboundLoads = BagInboundLoads(inboundLoadID, tempLoads: dispatchEdit.TempInboundLoads);
                ViewBag.OutboundLoads = BagOutboundLoads(outboundLoadID, tempLoads: dispatchEdit.TempOutboundLoads);
                ViewBag.Containers = BagContainers(containers);
                LoadViewBag(model);
                return View(model);
            }

            /*
             * REQUIRED UPDATES.
             */

            // Carrier Charge calculation
            CarrierChargeCalculation.Parts carrierCharge = CarrierChargeCalculation.Total(new CarrierChargeCalculation.Parts
            {
                Miles = model.CarrierMiles,
                Rate = model.CarrierRate,
                FlatRate = model.CarrierFlatRate,
                MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)model.MileageCalcType,
                StopCharge1 = model.CarrierStopCharge1,
                StopCharge2 = model.CarrierStopCharge2,
                FuelSurcharge = model.FuelSurcharge,
                ExtraCharge = model.CarrierExtraCharge
            });

            if (carrierCharge.TotalCharge.HasValue)
            {
                model.CarrierTotalCharge = carrierCharge.TotalCharge;
                model.CarrierTotalChargeChanged = DateTime.Now;
            }
            else
            {
                if (model.CarrierTotalCharge.HasValue && model.CarrierTotalCharge > decimal.Zero)
                {
                    model.CarrierTotalChargeChanged = DateTime.Now;
                }
            }

            // Create an empty collection.
            model.Loads = new List<Load>();
            model.Containers = new List<Container>();

            // Holds the DispatchIDs where the loads where dragged from. To allow identification of empty dispatches.
            List<int> dispatchesWithRemovedLoads = new List<int>();

            // Update Dispatch Loads
            UpdateDispatchLoads(model, outboundLoadID, inboundLoadID, dispatchEdit, dispatchesWithRemovedLoads);

            // Update Dispatch Containers
            UpdateDispatchContainers(model, containers, dispatchesWithRemovedLoads);

            /*
             * FAILABLE UPDATES.
             */

            // Update the ContainerSource
            if (model.Containers.Any())
            {
                string deliveryBy = string.Empty;

                if (model.CarrierID.HasValue)
                {
                    Carrier carrier = Db.Carrier.Find(model.CarrierID.Value);
                    deliveryBy = carrier.Name;
                }
                else if (model.Driver1ID.HasValue)
                {
                    Driver driver = Db.Driver.Find(model.Driver1ID.Value);
                    deliveryBy = string.Format("{0} {1}", driver.FirstName, driver.LastName.Substring(0, 1));
                }
                else if (model.Driver2ID.HasValue)
                {
                    Driver driver = Db.Driver.Find(model.Driver2ID.Value);
                    deliveryBy = string.Format("{0} {1}", driver.FirstName, driver.LastName.Substring(0, 1));
                }

                ContainerService = ContainerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

                foreach (Container container in model.Containers)
                {
                    try
                    {
                        ContainerInfo containerInfo = ContainerService.GetContainer(container.ContainerNumber);
                        if (container.ContainerAction == ContainerAction.Pull)
                        {
                            if (containerInfo.StatusCode == StatusCodeValues.EW_NOTIFICATION)
                            {
                                Dictionary<UpdateColumn, object> updateColumns = new Dictionary<UpdateColumn, object>();
                                updateColumns.Add(UpdateColumn.PullDriverName, deliveryBy);
                                int rowCount = ContainerService.UpdateContainer(container.ContainerNumber, updateColumns);
                                if (rowCount == 0)
                                {
                                    throw new Exception("One or more container records not updated on Container System. Row Count = 0.");
                                }
                            }
                        }
                        else if (container.ContainerAction == ContainerAction.CommitToOKC)
                        {
                            if (containerInfo.StatusCode == StatusCodeValues.EW_NOTIFICATION)
                            {
                                Dictionary<UpdateColumn, object> updateColumns = new Dictionary<UpdateColumn, object>();
                                updateColumns.Add(UpdateColumn.PullDriverName, deliveryBy);
                                int rowCount = ContainerService.UpdateContainer(container.ContainerNumber, updateColumns);
                                if (rowCount == 0)
                                {
                                    throw new Exception("One or more container records not updated on Container System. Row Count = 0.");
                                }
                            }
                            else if (containerInfo.StatusCode == StatusCodeValues.ARRIVED_DALLAS_YARD || containerInfo.StatusCode == StatusCodeValues.COMMITTED_TO_ARRIVE_OKC)
                            {
                                var results = ContainerService.ContainerAction(ActionCodeValues.ASSIGN_COMMIT_TO_OKC_DRIVER, new string[] { container.ContainerNumber }, driverName: deliveryBy);
                                if (results.Any())
                                {
                                    throw new Exception("Errors on Containers: " + string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
                                }
                            }
                        }
                        else if (container.ContainerAction == ContainerAction.EmptyReturn)
                        {
                            if (containerInfo.StatusCode == StatusCodeValues.EMPTY_CONTAINER || containerInfo.StatusCode == StatusCodeValues.LOADING_HOBBYLOBBY_STORE || containerInfo.StatusCode == StatusCodeValues.COMMITTED_RETURN)
                            {
                                var results = ContainerService.ContainerAction(ActionCodeValues.ASSIGN_EMPTY_RETURN_DRIVER, new string[] { container.ContainerNumber }, driverName: deliveryBy);
                                if (results.Any())
                                {
                                    throw new Exception("Errors on Containers: " + string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
                                }
                            }
                            else if (containerInfo.StatusCode == StatusCodeValues.EMPTY_CONTAINER_HEMISPHERES)
                            {
                                var results = ContainerService.ContainerAction(ActionCodeValues.ASSIGN_HEMISPHERES_RETURN_DRIVER, new string[] { container.ContainerNumber }, driverName: deliveryBy);
                                if (results.Any())
                                {
                                    throw new Exception("Errors on Containers: " + string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
                                }
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                    catch (Exception ex)
                    {
                        HLLogging.WarnFormat(string.Format("Dispatch {0}: Error trying to update remote Container Source. {1}", model.DailyDispatchID, ex.Message));
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = ex.Message,
                            Key = string.Format("ContainerUpdateError"),
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.NeedAck
                        });
                    }
                }
            }

            // Check for unacknowledged update error messages.
            if (screenMessages.AllMessagesFixedOrAcknowledged() == false)
            {
                ViewBag.ScreenMessages = screenMessages;
                ViewBag.InboundLoads = BagInboundLoads(inboundLoadID, tempLoads: dispatchEdit.TempInboundLoads);
                ViewBag.OutboundLoads = BagOutboundLoads(outboundLoadID, tempLoads: dispatchEdit.TempOutboundLoads);
                ViewBag.Containers = BagContainers(containers);
                LoadViewBag(model);
                return View(model);
            }

            // Process YesNo responses.
            if (screenMessages.MessageList.Any(x => x.Key == "TractorNumberFetch" && x.UserAnswer == 1))
            {
                if (model.Driver1ID.HasValue)
                {
                    Driver driver = Db.Driver.Single(x => x.DriverID == model.Driver1ID);
                    model.TractorNumber = driver.TractorNumber;
                }
            }
            
            // Process Drag and Drop side-effect actions.
            // If any loads were dragged from dispatches that are now empty, and "Delete Empty Dispatches" = YES, then delete them.
            if (screenMessages.MessageList.Any(x => x.Key == "EmptyDispatchDelete" && x.UserAnswer == 1))
            {
                var dispatchesToCheck = Db.DailyDispatch
                    .Include(x => x.Loads)
                    .Where(x => dispatchesWithRemovedLoads.Contains(x.DailyDispatchID));
                foreach (var dispatch in dispatchesToCheck)
                {
                    if (dispatch.Loads == null || dispatch.Loads.Count == 0)
                    {
                        Db.DailyDispatch.Remove(dispatch);
                    }
                }
            }

            // Complete the insert.
            Db.DailyDispatch.Add(model);
            ChangeLogger.LogChange(this, Db.Entry(model));
            Db.SaveChanges();

            foreach (var msg in screenMessages.MessageList.Where(x => x.ActionNeeded == ScreenMessagesViewModel.ActionNeeded.NeedAck))
            {
                HLLogging.Warn(string.Format("Dispatch {0}: {1}; Acknowledged by {2}.", model.DailyDispatchID, msg.Text, this.User.Identity.Name));
            }

            TempData[TEMPDATA_LASTGOODMESSAGE] = string.Format("Dispatch record {0} created.", model.DailyDispatchID);

            TempData[TEMPDATA_LASTDAILYDISPATCHID] = model.DailyDispatchID.ToString();

            UpdateDispatchIndexList(model.DailyDispatchID);
            dispatchesWithRemovedLoads.ForEach(x => UpdateDispatchIndexList(x, existingOnly: true));

            if (string.IsNullOrWhiteSpace((string)TempData.Peek(TEMPDATA_RETURN_URL)))
            {
                return RedirectToAction(MAIN_VIEW);
            }
            else
            {
                return Redirect((string)TempData[TEMPDATA_RETURN_URL]);
            }
        }

        /// <summary>
        /// Initial Edit method for a Dispatch.
        /// </summary>
        /// <param name="id">The DispatchID of the Dispatch to be editted.</param>
        /// <param name="catchall">If present, examine for a LoadID of a Load dragged from another Dispatch in the Index view.</param>
        /// <returns></returns>
        public ActionResult Edit(int id, string catchall)
        {
            TempData.Remove(TEMPDATA_ENABLESCROLL);

            Db = Db ?? new DispatchContext();

            if (TempData[TEMPDATA_FROMSCROLLMETHOD] != null)
            {
                TempData[TEMPDATA_RETURN_URL] = this.Url.Action("Index");
            }
            else 
            {
                TempData[TEMPDATA_RETURN_URL] = HttpContext.Request.UrlReferrer == null ? this.Url.Action("Index") : HttpContext.Request.UrlReferrer.ToString();
            }

            if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Modify) == false)
            {
                // This dispatch is readonly.
                return RedirectToAction("Details", new { id = id });
            }

            ScreenMessagesViewModel screenMessages = new ScreenMessagesViewModel();

            DailyDispatch model = Db.DailyDispatch
                .Include(x => x.Loads)
                .Include(x => x.Loads.Select(a => a.PickupCompany))
                .Include(x => x.Carrier)
                .Include(x => x.Containers)
                .Single(x => x.DailyDispatchID == id);

            // Check for read-only condition due to age of the dispatch.
            DateTime readonlyHorizonDate = Db.OpenDispatchDates().OldestDispatchDate();

            readonlyHorizonDate = readonlyHorizonDate.AddDays(-LibConfigProperties.Settings.ReadonlyHorizonDaysForDispatches);

            if (this.AdministrativeSettings().AdminEditMode == false)
            {
                if (model.DispatchDate < readonlyHorizonDate)
                {
                    // This dispatch is readonly.
                    return RedirectToAction("Details", new { id = id });
                }
            }

            if (model.Generated == false)
            {
                ViewBag.AllowDelete = true;
            }

            List<int> inboundLoadIDs = model.Loads
                .Where(x => DatabaseLists.INBOUND_LOAD_TYPES.Contains(x.LoadType))
                .OrderBy(x => x.DispatchLoadOrder)
                .Select(x => x.LoadID)
                .ToList();

            List<int> outboundLoadIDs = model.Loads
                .Where(x => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(x.LoadType))
                .OrderBy(x => x.DispatchLoadOrder)
                .Select(x => x.LoadID)
                .ToList();

            List<Container> containers = model.Containers
                .OrderBy(x => x.DispatchOrder)
                .ToList();

            Session[DispatchEditSessionName] = new DispatchEdit { DailyDispatchID = id };

            if (!string.IsNullOrWhiteSpace(catchall))
            {
                string[] extraInput = catchall.ToLower().Split(',').Select(x => x.Trim()).ToArray();
                foreach (string input in extraInput)
                {
                    int loadID;
                    if (int.TryParse(input, out loadID))
                    {
                        Load addLoad = Db.Load.Find(loadID);
                        if (addLoad != null)
                        {
                            if (DatabaseLists.INBOUND_LOAD_TYPES.Contains(addLoad.LoadType))
                            {
                                inboundLoadIDs.Add(addLoad.LoadID);
                                ViewBag.DraggedLoadsAdded = true;
                            }
                            else if (DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(addLoad.LoadType))
                            {
                                outboundLoadIDs.Add(addLoad.LoadID);
                                ViewBag.DraggedLoadsAdded = true;
                            }
                        }
                    }
                }
            }

            ViewBag.InboundLoads = BagInboundLoads(inboundLoadIDs, currentDispatchID: id);
            ViewBag.OutboundLoads = BagOutboundLoads(outboundLoadIDs, currentDispatchID: id);
            ViewBag.Containers = BagContainers(containers, currentDispatchID: id);

            ViewBag.ScreenMessages = screenMessages;

            LoadViewBag(model);

            return View("Edit", model);
        }

        public ActionResult Edit2(int id, string catchall)
        {
            ActionResult result = Edit(id, catchall);

            TempData[TEMPDATA_ENABLESCROLL] = bool.TrueString;

            return result;
        }

        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
        public ActionResult NextDispatch(int id)
        {
            DailyDispatchIndexViewModel viewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
            if (viewModel == null || viewModel.Dispatches == null)
            {
                return RedirectToAction("Index");
            }

            DispatchViewModel dispatch = null;
            for (int i = 0; i < viewModel.Dispatches.Count(); i++)
            {
                if (viewModel.Dispatches.ElementAt(i).DailyDispatchID == id)
                {
                    dispatch = viewModel.Dispatches.ElementAtOrDefault(i + 1);
                    break;
                }
            }

            if (dispatch == null)
            {
                return RedirectToAction("Index");
            }

            TempData[TEMPDATA_FROMSCROLLMETHOD] = bool.TrueString;

            return RedirectToAction("Edit2", new { id = dispatch.DailyDispatchID });
        }

        public ActionResult PreviousDispatch(int id)
        {
            DailyDispatchIndexViewModel viewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
            if (viewModel == null || viewModel.Dispatches == null)
            {
                return RedirectToAction("Index");
            }

            DispatchViewModel dispatch = null;
            for (int i = 0; i < viewModel.Dispatches.Count(); i++)
            {
                if (viewModel.Dispatches.ElementAt(i).DailyDispatchID == id)
                {
                    dispatch = viewModel.Dispatches.ElementAtOrDefault(i - 1);
                    break;
                }
            }

            if (dispatch == null)
            {
                return RedirectToAction("Index");
            }

            TempData[TEMPDATA_FROMSCROLLMETHOD] = bool.TrueString;

            return RedirectToAction("Edit2", new { id = dispatch.DailyDispatchID });
        }

        /// <summary>
        /// Update method for a complete dispatch. 
        /// </summary>
        /// <param name="screen">Input fields from the screen. Will be edited and copied to the matching db field.</param>
        /// <param name="inboundLoadID">If present, a list of INTs representing the inbound LoadIDs that should be on the Dispatch. 
        /// Order is important, as it represents the order of the loads in the trailer, nose to tail.</param>
        /// <param name="outboundLoadID">If present, a list of INTs representing the outbound LoadIDs that should be on the Dispatch. 
        /// Order is important, as it represents the order of the loads in the trailer, nose to tail.</param>
        /// <param name="screenMessages">Turnaround ScreenMessages object, with user responses.</param>
        /// <returns></returns>
        [HttpPost]
        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
        public ActionResult Edit(
            DailyDispatch screen, 
            int[] inboundLoadID, 
            int[] outboundLoadID, 
            Container[] containers,
            ScreenMessagesViewModel screenMessages, 
            string submitActionSaveNext)
        {
            Db = Db ?? new DispatchContext();

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            inboundLoadID = inboundLoadID ?? new int[] { };
            outboundLoadID = outboundLoadID ?? new int[] { };
            containers = containers ?? new Container[] { };

            TempData.Keep(TEMPDATA_RETURN_URL);

            TempData.Keep(TEMPDATA_ENABLESCROLL);

            screenMessages = new ScreenMessagesViewModel(screenMessages);

            foreach (var key in ModelState.Keys.Where(x => x.StartsWith("screenMessages")).ToList())
            {
                ModelState.Remove(key);
            }

            DailyDispatch model = Db.DailyDispatch
                .Include(x => x.Loads)
                .Include(x => x.Loads.Select(a => a.PickupCompany))
                .Include(x => x.Containers)
                .Single(x => x.DailyDispatchID == screen.DailyDispatchID);

            ulong screenTimestamp = BitConverter.ToUInt64(screen.Timestamp, 0);
            ulong modelTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

            if (screenTimestamp != modelTimestamp)
            {
                ModelState.Clear();
                ModelState.AddModelError(string.Empty, _ConcurrentEditErrorMessage);
                List<int> inboundLoadIDs = model.Loads
                    .Where(x => DatabaseLists.INBOUND_LOAD_TYPES.Contains(x.LoadType))
                    .OrderBy(x => x.DispatchLoadOrder)
                    .Select(x => x.LoadID)
                    .ToList();
                List<int> outboundLoadIDs = model.Loads
                    .Where(x => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(x.LoadType))
                    .OrderBy(x => x.DispatchLoadOrder)
                    .Select(x => x.LoadID)
                    .ToList();
                List<Container> containerList = model.Containers
                    .OrderBy(x => x.DispatchOrder)
                    .ToList();
                Session[DispatchEditSessionName] = new DispatchEdit { DailyDispatchID = screen.DailyDispatchID };
                ViewBag.InboundLoads = BagInboundLoads(inboundLoadIDs, model.DailyDispatchID);
                ViewBag.OutboundLoads = BagOutboundLoads(outboundLoadIDs, model.DailyDispatchID);
                ViewBag.Containers = BagContainers(containerList, model.DailyDispatchID);
                LoadViewBag(model);
                return View(model);
            }

            if (!ModelState.IsValid)
            {
                ViewBag.InboundLoads = BagInboundLoads(inboundLoadID, currentDispatchID: screen.DailyDispatchID, tempLoads: dispatchEdit.TempInboundLoads);
                ViewBag.OutboundLoads = BagOutboundLoads(outboundLoadID, currentDispatchID: screen.DailyDispatchID, tempLoads: dispatchEdit.TempOutboundLoads);
                ViewBag.Containers = BagContainers(containers, currentDispatchID: screen.DailyDispatchID);
                screen.DispatchDate = model.DispatchDate;
                LoadViewBag(screen);
                return View(screen);
            }

            /*
                * Edit Dispatch values.
                */

            if (model.Generated == true)
            {
                if (model.CarrierID.HasValue)
                {
                    if (screen.CarrierID.HasValue == false || model.CarrierID.Value != screen.CarrierID.Value)
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = "Carrier cannot be changed or removed from generated Dispatch. If load(s) must be removed, create a new Dispatch to hold the loads.",
                            Key = "GeneratedDispatchCarrier",
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                        });
                    }
                }
            }

            if (screen.CarrierID.HasValue && (screen.Driver1ID.HasValue || screen.Driver2ID.HasValue))
            {
                screenMessages.Add(new ScreenMessagesViewModel.Message
                {
                    Text = "Carrier and Drivers cannot be selected together.",
                    Key = "DriverAndCarrier",
                    ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                });
            }

            if (screen.DepartureTime.HasValue)
            {
                model.DepartureTime = model.DispatchDate.Date + screen.DepartureTime.Value.TimeOfDay;
            }
            else
            {
                model.DepartureTime = model.DispatchDate.Date;
            }

            if ((screen.Trailer != null && screen.Trailer.Trim().Contains(' ')) ||
                (screen.TrailerIn != null && screen.TrailerIn.Trim().Contains(' ')))
            {
                screenMessages.Add(new ScreenMessagesViewModel.Message
                {
                    Text = "Trailer numbers cannot contain spaces.",
                    Key = "TrailerSpaceCheck",
                    ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                });
            }

            if (screen.Driver1ID.HasValue)
            {
                if (string.IsNullOrWhiteSpace(screen.TractorNumber))
                {
                    Driver driver = Db.Driver.Single(x => x.DriverID == screen.Driver1ID);
                    if (!string.IsNullOrWhiteSpace(driver.TractorNumber))
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = "Tractor Number missing. Fetch tractor number for driver?",
                            Key = "TractorNumberFetch",
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.NeedYesNo
                        });
                    }
                }
            }

            EditDispatchLoads(screen, model, dispatchEdit, inboundLoadID, outboundLoadID, screenMessages);

            EditContainers(model, containers, screenMessages);

            /*
             * REQUIRED UPDATES.
             */

            // Carrier Charge calculation
            model.CarrierMiles = screen.CarrierMiles;
            model.CarrierRate = screen.CarrierRate;
            model.CarrierFlatRate = screen.CarrierFlatRate;
            model.MileageCalcType = screen.MileageCalcType;
            model.CarrierStopCharge1 = screen.CarrierStopCharge1;
            model.CarrierStopCharge2 = screen.CarrierStopCharge2;
            model.CarrierExtraCharge = screen.CarrierExtraCharge;
            model.FuelSurcharge = screen.FuelSurcharge;

            model.CarrierComment = screen.CarrierComment;
            model.LockCarrierTotalCharge = screen.LockCarrierTotalCharge;

            // Calculate Carrier Charge
            CarrierChargeCalculation.Parts carrierCharge = CarrierChargeCalculation.Total(new CarrierChargeCalculation.Parts
            {
                Miles = model.CarrierMiles,
                Rate = model.CarrierRate,
                FlatRate = model.CarrierFlatRate,
                MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)model.MileageCalcType,
                StopCharge1 = model.CarrierStopCharge1,
                StopCharge2 = model.CarrierStopCharge2,
                FuelSurcharge = model.FuelSurcharge,
                ExtraCharge = model.CarrierExtraCharge
            });

            if (carrierCharge.TotalCharge.HasValue)
            {
                if (model.CarrierTotalCharge != carrierCharge.TotalCharge)
                {
                    model.CarrierTotalChargeChanged = DateTime.Now;
                }

                model.CarrierTotalCharge = carrierCharge.TotalCharge;
            }
            else
            {
                if (model.CarrierTotalCharge != screen.CarrierTotalCharge)
                {
                    model.CarrierTotalChargeChanged = DateTime.Now;
                }

                model.CarrierTotalCharge = screen.CarrierTotalCharge;
            }

            model.CarrierTotalChargeOverride = screen.CarrierTotalChargeOverride;

            // Basic fields.
            model.DispatchDate = screen.DispatchDate;

            // Set the week and day.
            SetWeekAndDay(model);

            model.InboundDate = screen.InboundDate;
            model.Comment = screen.Comment;

            if (this.AdministrativeSettings().AdminEditMode)
            {
                model.DispatchGroup = screen.DispatchGroup;
            }
            else if (model.DispatchGroup != screen.DispatchGroup)
            {
                screenMessages.Add(new ScreenMessagesViewModel.Message
                {
                    Text = "Dispatch Group can only be changed in Administrative Mode.",
                    Key = "DispatchGroupChange",
                    ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                });
            }
            
            model.CarrierID = screen.CarrierID;
            model.Driver1ID = screen.Driver1ID;
            model.Driver2ID = screen.Driver2ID;

            model.Miles = screen.Miles;
            model.TractorNumber = screen.TractorNumber;
            model.Trailer = screen.Trailer;
            model.TrailerIn = screen.TrailerIn;

            // Load updates

            // Holds the DispatchIDs where the loads where dragged from. To allow identification of empty dispatches.
            List<int> dispatchesWithRemovedLoads = new List<int>();

            // Update Dispatch Loads
            UpdateDispatchLoads(model, outboundLoadID, inboundLoadID, dispatchEdit, dispatchesWithRemovedLoads);

            // Update Dispatch Containers
            UpdateDispatchContainers(model, containers, dispatchesWithRemovedLoads);

            /*
             * FAILABLE UPDATES.
             */

            // Update the ContainerSource
            if (model.Containers.Any())
            {
                string deliveryBy = string.Empty;

                if (model.CarrierID.HasValue)
                {
                    Carrier carrier = Db.Carrier.Find(model.CarrierID.Value);
                    deliveryBy = carrier.Name;
                }
                else if (model.Driver1ID.HasValue)
                {
                    Driver driver = Db.Driver.Find(model.Driver1ID.Value);
                    deliveryBy = string.Format("{0} {1}", driver.FirstName, driver.LastName.Substring(0, 1));
                }
                else if (model.Driver2ID.HasValue)
                {
                    Driver driver = Db.Driver.Find(model.Driver2ID.Value);
                    deliveryBy = string.Format("{0} {1}", driver.FirstName, driver.LastName.Substring(0, 1));
                }

                ContainerService = ContainerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

                foreach (Container container in model.Containers)
                {
                    try
                    {
                        ContainerInfo containerInfo = ContainerService.GetContainer(container.ContainerNumber);
                        if (container.ContainerAction == ContainerAction.Pull)
                        {
                            if (containerInfo.StatusCode == StatusCodeValues.EW_NOTIFICATION)
                            {
                                Dictionary<UpdateColumn, object> updateColumns = new Dictionary<UpdateColumn, object>();
                                updateColumns.Add(UpdateColumn.PullDriverName, deliveryBy);
                                int rowCount = ContainerService.UpdateContainer(container.ContainerNumber, updateColumns);
                                if (rowCount == 0)
                                {
                                    throw new Exception("One or more container records not updated on Container System. Row Count = 0.");
                                }
                            }
                        }
                        else if (container.ContainerAction == ContainerAction.CommitToOKC)
                        {
                            if (containerInfo.StatusCode == StatusCodeValues.EW_NOTIFICATION)
                            {
                                Dictionary<UpdateColumn, object> updateColumns = new Dictionary<UpdateColumn, object>();
                                updateColumns.Add(UpdateColumn.PullDriverName, deliveryBy);
                                int rowCount = ContainerService.UpdateContainer(container.ContainerNumber, updateColumns);
                                if (rowCount == 0)
                                {
                                    throw new Exception("One or more container records not updated on Container System. Row Count = 0.");
                                }
                            }
                            else if (containerInfo.StatusCode == StatusCodeValues.ARRIVED_DALLAS_YARD || containerInfo.StatusCode == StatusCodeValues.COMMITTED_TO_ARRIVE_OKC)
                            {
                                var results = ContainerService.ContainerAction(ActionCodeValues.ASSIGN_COMMIT_TO_OKC_DRIVER, new string[] { container.ContainerNumber }, driverName: deliveryBy);
                                if (results.Any())
                                {
                                    throw new Exception("Errors on Containers: " + string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
                                }
                            }
                        }
                        else if (container.ContainerAction == ContainerAction.EmptyReturn)
                        {
                            if (containerInfo.StatusCode == StatusCodeValues.EMPTY_CONTAINER || containerInfo.StatusCode == StatusCodeValues.LOADING_HOBBYLOBBY_STORE || containerInfo.StatusCode == StatusCodeValues.COMMITTED_RETURN)
                            {
                                var results = ContainerService.ContainerAction(ActionCodeValues.ASSIGN_EMPTY_RETURN_DRIVER, new string[] { container.ContainerNumber }, driverName: deliveryBy);
                                if (results.Any())
                                {
                                    throw new Exception("Errors on Containers: " + string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
                                }
                            }
                            else if (containerInfo.StatusCode == StatusCodeValues.EMPTY_CONTAINER_HEMISPHERES)
                            {
                                var results = ContainerService.ContainerAction(ActionCodeValues.ASSIGN_HEMISPHERES_RETURN_DRIVER, new string[] { container.ContainerNumber }, driverName: deliveryBy);
                                if (results.Any())
                                {
                                    throw new Exception("Errors on Containers: " + string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
                                }
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                    catch (Exception ex)
                    {
                        HLLogging.WarnFormat(string.Format("Dispatch {0}: Error trying to update remote Container Source. {1}", model.DailyDispatchID, ex.Message));
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = ex.Message,
                            Key = string.Format("ContainerUpdateError"),
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.NeedAck
                        });
                    }
                }
            }

            // Check for unacknowledged update error messages.
            if (screenMessages.AllMessagesFixedOrAcknowledged() == false)
            {
                ViewBag.ScreenMessages = screenMessages;
                ViewBag.InboundLoads = BagInboundLoads(inboundLoadID, tempLoads: dispatchEdit.TempInboundLoads);
                ViewBag.OutboundLoads = BagOutboundLoads(outboundLoadID, tempLoads: dispatchEdit.TempOutboundLoads);
                ViewBag.Containers = BagContainers(containers);
                LoadViewBag(model);
                return View(model);
            }

            // Process YesNo responses.
            if (screenMessages.MessageList.Any(x => x.Key == "TractorNumberFetch" && x.UserAnswer == 1))
            {
                if (model.Driver1ID.HasValue)
                {
                    Driver driver = Db.Driver.Single(x => x.DriverID == model.Driver1ID);
                    model.TractorNumber = driver.TractorNumber;
                }
            }

            // Process Drag and Drop side-effect actions.
            // If any loads were dragged from dispatches that are now empty, and "Delete Empty Dispatches" = YES, then delete them.
            var deleteEmptyDispatch = screenMessages.MessageList.FirstOrDefault(x => x.Key == "EmptyDispatchDelete");
            if (deleteEmptyDispatch != null)
            {
                if (deleteEmptyDispatch.UserAnswer == 1)
                {
                    var dispatchesToCheck = Db.DailyDispatch
                        .Include(x => x.Loads)
                        .Where(x => dispatchesWithRemovedLoads.Contains(x.DailyDispatchID));
                    foreach (var dispatch in dispatchesToCheck)
                    {
                        if (dispatch.Loads == null || dispatch.Loads.Count == 0)
                        {
                            Db.DailyDispatch.Remove(dispatch);
                        }
                    }
                }
            }

            // Complete the update.
            ChangeLogger.LogChange(this, Db.Entry(model));
            Db.SaveChanges();

            foreach (var msg in screenMessages.MessageList.Where(x => x.ActionNeeded == ScreenMessagesViewModel.ActionNeeded.NeedAck))
            {
                HLLogging.Warn(string.Format("Dispatch {0}: {1}; Acknowledged by {2}.", model.DailyDispatchID, msg.Text, this.User.Identity.Name));
            }

            TempData[TEMPDATA_LASTGOODMESSAGE] = string.Format("Dispatch record {0} updated.", model.DailyDispatchID);

            TempData[TEMPDATA_LASTDAILYDISPATCHID] = model.DailyDispatchID.ToString();

            UpdateDispatchIndexList(model.DailyDispatchID);
            dispatchesWithRemovedLoads.ForEach(x => UpdateDispatchIndexList(x, existingOnly: true));

            if (!string.IsNullOrEmpty(submitActionSaveNext))
            {
                return RedirectToAction("NextDispatch", new { id = model.DailyDispatchID });
            }
            else if (string.IsNullOrWhiteSpace((string)TempData.Peek(TEMPDATA_RETURN_URL)))
            {
                return RedirectToAction(MAIN_VIEW);
            }
            else
            {
                return Redirect((string)TempData[TEMPDATA_RETURN_URL]);
            }
        }

        /// <summary>
        /// Determine the dispatch week number (1 or 2) and the day of the week from the dispatch date.
        /// </summary>
        /// <param name="model"></param>
        private void SetWeekAndDay(DailyDispatch model)
        {
            DateTime fridayDispatchDate;
            int? actualWeekDayID = null;
            bool swapWeekNumber;

            switch (model.DispatchDate.DayOfWeek)
            {
                case DayOfWeek.Saturday:
                    // Go to the previous Friday to get the week number.
                    fridayDispatchDate = model.DispatchDate.AddDays(-1);
                    actualWeekDayID = 7;
                    swapWeekNumber = false;
                    break;
                case DayOfWeek.Sunday:
                    // Go to the previous Friday and swap the week number.
                    fridayDispatchDate = model.DispatchDate.AddDays(-2);
                    actualWeekDayID = 1;
                    swapWeekNumber = true;
                    break;
                default:
                    fridayDispatchDate = model.DispatchDate;
                    swapWeekNumber = false;
                    break;
            }

            DispatchDateControl dispatchDateControl = Db.DispatchDateControl.Single(x => x.DispatchDate == fridayDispatchDate);

            // set the week day ID to the actual (Saturday or Sunday) or the record weeknumber (Monday thru Friday).
            model.WeekDayID = actualWeekDayID ?? dispatchDateControl.WeekDayID;

            if (swapWeekNumber)
            {
                if (dispatchDateControl.WeekNumber == 1)
                {
                    model.Weeknumber = 2;
                }
                else
                {
                    model.Weeknumber = 1;
                }
            }
            else
            {
                model.Weeknumber = dispatchDateControl.WeekNumber;
            }
        }

        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
        public ActionResult Delete(int id)
        {
            Db = Db ?? new DispatchContext();

            DailyDispatch model = Db.DailyDispatch
                .Include(x => x.Loads)
                .Single(x => x.DailyDispatchID == id);

            if (model.Loads.Any())
            {
                model.Loads.Clear();
            }

            Db.DailyDispatch.Remove(model);
            ChangeLogger.LogChange(this, Db.Entry(model));
            Db.SaveChanges();

            // Remove deleted dispatch from the viewmodel list.
            DailyDispatchIndexViewModel viewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
            if (viewModel != null && viewModel.Dispatches != null)
            {
                DispatchViewModel dispatchViewModel = viewModel.Dispatches.FirstOrDefault(x => x.DailyDispatchID == id);
                if (dispatchViewModel != null)
                {
                    viewModel.Dispatches.Remove(dispatchViewModel);
                }
            }

            TempData[TEMPDATA_LASTGOODMESSAGE] = string.Format("Dispatch record {0} deleted.", model.DailyDispatchID);
            return RedirectToAction(MAIN_VIEW);
        }

        #endregion

        #region Load Collection Edits

        private void EditDispatchLoads(
            DailyDispatch screen,
            DailyDispatch model,
            DispatchEdit dispatchEdit,
            IEnumerable<int> inboundLoadID,
            IEnumerable<int> outboundLoadID,
            ScreenMessagesViewModel screenMessages)
        {
            /******************************************************************************************************
             * Edit Outbound Loads.
             ******************************************************************************************************/

            // Check for duplicate selections.
            if (outboundLoadID.Distinct().Count() != outboundLoadID.Count())
            {
                screenMessages.Add(new ScreenMessagesViewModel.Message
                {
                    Text = "Cannot select the same outbound load more than once.",
                    Key = "SameOutboundLoad",
                    ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                });
            }

            if (screen.CarrierID.HasValue &&
                outboundLoadID.Any() &&
                (screen.CarrierTotalCharge.HasValue == false || screen.CarrierTotalCharge == 0m))
            {
                screenMessages.Add(new ScreenMessagesViewModel.Message
                {
                    Text = "This Carrier dispatch has outbound loads. Do you need to specify the carrier charge?",
                    Key = "NoOutboundCarrierRate",
                    ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ShowOnly
                });
            }

            if (model != null)
            {
                if (screen.CarrierID.HasValue &&
                    (screen.CarrierTotalCharge.HasValue && model.CarrierTotalCharge.HasValue && screen.CarrierTotalCharge == model.CarrierTotalCharge))
                {
                    bool sameSequence = model.Loads
                        .Where(x => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(x.LoadType))
                        .OrderBy(x => x.DispatchLoadOrder)
                        .Select(x => x.LoadID)
                        .SequenceEqual(outboundLoadID);

                    if (!sameSequence)
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = "This Carrier dispatch has changed outbound loads. Do you need to change the carrier charge?",
                            Key = "OutboundLoadChange",
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ShowOnly
                        });
                    }
                }
            }

            /*
             * Ensure load delivery dates are descending for the arranged order.
             */

            bool storeLoadsInCorrectOrder = true;

            if (outboundLoadID.Count() > 1)
            {
                List<Load> orderCheck = new List<Load>();

                foreach (int loadID in outboundLoadID)
                {
                    Load load = dispatchEdit.TempOutboundLoads.FirstOrDefault(x => x.LoadID == loadID) ?? Db.Load.Single(x => x.LoadID == loadID);
                    if (load.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                    {
                        orderCheck.Add(load);
                    }
                }

                int[] screenOrder = orderCheck.Select(x => x.LoadID).ToArray();
                int[] pickupOrder = orderCheck.OrderByDescending(x => x.EtaDate).Select(x => x.LoadID).ToArray();

                if (screenOrder.SequenceEqual(pickupOrder) == false)
                {
                    screenMessages.Add(new ScreenMessagesViewModel.Message
                    {
                        Text = "Store load delivery dates not in correct order.",
                        Key = "DeliveryDatesNotInOrder",
                        ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                    });
                    storeLoadsInCorrectOrder = false;
                }
            }

            /******************************************************************************************************
             * Locate nose store load, if present.
             ******************************************************************************************************/

            Load outboundNoseLoad = null;

            if (outboundLoadID.Any())
            {
                int outboundNoseLoadID = outboundLoadID.First();
                outboundNoseLoad = dispatchEdit.TempOutboundLoads.FirstOrDefault(x => x.LoadID == outboundNoseLoadID);
                if (outboundNoseLoad == null)
                {
                    outboundNoseLoad = Db.Load.Single(x => x.LoadID == outboundNoseLoadID);
                }
            }

            /******************************************************************************************************
             * Edit Inbound Loads
             ******************************************************************************************************/

            // Check for duplicate selections.
            if (inboundLoadID.Distinct().Count() != inboundLoadID.Count())
            {
                screenMessages.Add(new ScreenMessagesViewModel.Message
                {
                    Text = "Cannot select the same inbound load more than once.",
                    Key = "SameInboundLoad",
                    ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                });
            }

            if (screen.CarrierID.HasValue &&
                inboundLoadID.Any() &&
                (screen.CarrierTotalCharge.HasValue == false || screen.CarrierTotalCharge == 0m))
            {
                screenMessages.Add(new ScreenMessagesViewModel.Message
                {
                    Text = "This Carrier dispatch has inbound loads. Do you need to specify the carrier charge?",
                    Key = "NoInboundCarrierRate",
                    ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ShowOnly
                });
            }

            if (model != null)
            {
                if (screen.CarrierID.HasValue &&
                    (screen.CarrierTotalCharge.HasValue && model.CarrierTotalCharge.HasValue && screen.CarrierTotalCharge == model.CarrierTotalCharge))
                {
                    bool sameSequence = model.Loads
                        .Where(x => DatabaseLists.INBOUND_LOAD_TYPES.Contains(x.LoadType))
                        .OrderBy(x => x.DispatchLoadOrder)
                        .Select(x => x.LoadID)
                        .SequenceEqual(inboundLoadID);

                    if (!sameSequence)
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = "This Carrier dispatch has changed inbound loads. Do you need to change the carrier charge?",
                            Key = "InboundLoadChange",
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ShowOnly
                        });
                    }
                }
            }

            foreach (int loadID in inboundLoadID)
            {
                Load load = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == loadID) ?? Db.Load.Single(x => x.LoadID == loadID);

                // Edit Pickup Date
                if (load.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || load.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                {
                    if (load.PickupDate.HasValue == false)
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = string.Format("Load {0} pickup date is missing.", load.LoadName),
                            Key = string.Format("PickupDateMissing-{0}", load.LoadID),
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                        });
                    }
                    else if (outboundNoseLoad != null && storeLoadsInCorrectOrder)
                    {
                        if ((load.PickupDate.Value.TimeOfDay == TimeSpan.Zero && load.PickupDate.Value.Date < outboundNoseLoad.EtaDate.Value.Date) ||
                            (load.PickupDate.Value.TimeOfDay != TimeSpan.Zero && load.PickupDate < outboundNoseLoad.EtaDate))
                        {
                            screenMessages.Add(new ScreenMessagesViewModel.Message
                            {
                                Text = string.Format("Load {0} pickup date is before last store delivery date.", load.LoadName),
                                Key = string.Format("PickupDateBeforeLastDelv-{0}", load.LoadID),
                                ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                            });
                        }
                        else if (load.PickupDate.Value.Date > outboundNoseLoad.EtaDate.Value.Date)
                        {
                            screenMessages.Add(new ScreenMessagesViewModel.Message
                            {
                                Text = string.Format("Load {0} pickup date is after last store delivery date.", load.LoadName),
                                Key = string.Format("PickupDateNotDeliveryDate-{0}", load.LoadID),
                                ActionNeeded = ScreenMessagesViewModel.ActionNeeded.NeedAck
                            });
                        }
                    }
                }

                // Edit Eta (Delivery) Date
                if (load.LoadType == DatabaseLists.INBOUND_BROKER_LOAD)
                {
                    if (load.EtaDate.HasValue == false)
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = string.Format("Load {0} delivery date is missing.", load.LoadName),
                            Key = string.Format("DelvDateMissing-{0}", load.LoadID),
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                        });
                    }
                    else if (load.PickupDate.HasValue && load.EtaDate < load.PickupDate)
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = string.Format("Load {0} delivery date is before its pickup date.", load.LoadName),
                            Key = string.Format("DelvDateBeforePickupDate-{0}", load.LoadID),
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                        });
                    }
                }
            }

            /*
             * Ensure load pickup dates are the same as the arranged order.
             */

            if (inboundLoadID.Count() > 1)
            {
                List<Load> orderCheck = new List<Load>();

                foreach (int loadID in inboundLoadID)
                {
                    Load load = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == loadID) ?? Db.Load.Single(x => x.LoadID == loadID);
                    if (load.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || load.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                    {
                        orderCheck.Add(load);
                    }
                }

                int[] screenOrder = orderCheck.Select(x => x.LoadID).ToArray();
                int[] pickupOrder = orderCheck.OrderBy(x => x.PickupDate).Select(x => x.LoadID).ToArray();

                if (screenOrder.SequenceEqual(pickupOrder) == false)
                {
                    screenMessages.Add(new ScreenMessagesViewModel.Message
                    {
                        Text = "Pickup dates not in correct order.",
                        Key = "PickupDatesNotInOrder",
                        ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                    });
                }
            }
        }

        private void EditContainers(
            DailyDispatch dispatch,
            IEnumerable<Container> containers,
            ScreenMessagesViewModel screenMessages)
        {
            if (containers.Any())
            {
                ContainerService = ContainerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

                // Get the ContainerInfo records in one action.
                Dictionary<string, ContainerInfo> containerList = ContainerService
                    .GetContainerListByNumber(containers.Select(x => x.ContainerNumber))
                    .ToDictionary(x => x.ContainerNumber);

                foreach (Container screenContainer in containers)
                {
                    // Ensure container hasn't already been actioned by another dispatch.
                    bool actionedByAnotherDispatch = Db.Container.AsNoTracking()
                        .Any(x => x.ContainerNumber == screenContainer.ContainerNumber && 
                            x.DailyDispatchID != dispatch.DailyDispatchID && 
                            x.ContainerAction == screenContainer.ContainerAction);
                    if (actionedByAnotherDispatch)
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = string.Format(
                                "Container {0} already selected for {1} by another dispatch.",
                                screenContainer.ContainerNumber, 
                                Enum.Format(typeof(ContainerAction), screenContainer.ContainerAction, "g")),
                            Key = string.Format("ContainerAlreadyActioned-{0}", screenContainer.ContainerNumber),
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                        });
                    }

                    // Ensure container is still in the same actionable status code
                    ContainerInfo containerInfo = containerList[screenContainer.ContainerNumber];
                    if ((screenContainer.ContainerAction == ContainerAction.Pull && ALLOWED_CONTAINER_STATUS_FOR_PULL.Contains(containerInfo.StatusCode))
                        ||
                        (screenContainer.ContainerAction == ContainerAction.CommitToOKC && ALLOWED_CONTAINER_STATUS_FOR_OKC_COMMIT.Contains(containerInfo.StatusCode))
                        ||
                        (screenContainer.ContainerAction == ContainerAction.EmptyReturn && ALLOWED_CONTAINER_STATUS_EMPTY_RETURN.Contains(containerInfo.StatusCode)))
                    {
                        // Container ok for action.
                    }
                    else
                    {
                        screenMessages.Add(new ScreenMessagesViewModel.Message
                        {
                            Text = string.Format(
                                "Container {0} no longer eligible for {1}.",
                                screenContainer.ContainerNumber, 
                                Enum.Format(typeof(ContainerAction), screenContainer.ContainerAction, "g")),
                            Key = string.Format("ContainerNoLongerEligible-{0}", screenContainer.ContainerNumber),
                            ActionNeeded = ScreenMessagesViewModel.ActionNeeded.ErrorFixed
                        });
                    }
                }
            }
        }

        #endregion

        #region Load Collection Updating

        /// <summary>
        /// Updates the Dispatch record Loads collection by removing loads, adding existing loads and creating new loads.
        /// The LoadID determines the action. If the LoadID is greater than zero, it is an existing load that will be attached to the Dispatch.
        /// If the LoadID is less than zero, the load will be created and attached to the dispatch.
        /// </summary>
        /// <param name="dispatch">DailyDispatch record to update (new or existing)</param>
        /// <param name="selectedOutboundLoads">LoadID list of outbound Load records to be on the updated Dispatch record</param>
        /// <param name="selectedInboundLoads">LoadID list of inbound Load records to be on the updated Dispatch record</param>
        /// <param name="dispatchEdit">Session object for temporary Loads.</param>
        /// <param name="dragfromDispatchIDs">Collection of DailyDispatchIDs that have had loads pulled from them on this update.</param>
        private void UpdateDispatchLoads(
            DailyDispatch dispatch,
            IEnumerable<int> selectedOutboundLoads,
            IEnumerable<int> selectedInboundLoads,
            DispatchEdit dispatchEdit,
            ICollection<int> dragfromDispatchIDs)
        {
            var existingLoadIDs = selectedOutboundLoads.Concat(selectedInboundLoads).Where(x => x > 0);
            var existingLoadIDsToAdd = existingLoadIDs.Where(x => dispatch.Loads.Select(y => y.LoadID).Contains(x) == false);
            var temporaryLoadIDsToAdd = selectedOutboundLoads.Concat(selectedInboundLoads).Where(x => x < 0);

            // Remove existing Loads from the Dispatch if they are not present in the input screen. 
            // The load is not deleted, simply unassigned from the Dispatch.
            Load[] loadsToRemove = dispatch.Loads.Where(x => existingLoadIDs.Contains(x.LoadID) == false).ToArray();
            foreach (Load load in loadsToRemove)
            {
                dispatch.Loads.Remove(load);
                HLLogging.InfoFormat("Load {0} type {1} removed from Dispatch {2} ({3})", load.LoadID, load.LoadType, dispatch.DailyDispatchID, this.User.Identity.Name);
                if (load.SourceLoadID.HasValue)
                {
                    Db.Load.Remove(load);
                    ChangeLogger.LogChange(this, Db.Entry(load));
                }
            }

            // Attach existing Loads to the Dispatch if they are present in the input screen. 
            // These are existing loads that are currently unattached or attached to a different Dispatch.
            // A load copy can be made if dragging it to another dispatch of a different group as long as the delivery type matches.
            Load[] loadsToAttach = Db.Load
                .Include(x => x.DailyDispatch)
                .Include(x => x.LoadCopies)
                .Where(x => existingLoadIDsToAdd.Contains(x.LoadID) == true)
                .ToArray();
            foreach (Load load in loadsToAttach)
            {
                Load loadToAdd = null;

                if (load.DailyDispatchID.HasValue == false)
                {
                    loadToAdd = load;
                }
                else
                {
                    dragfromDispatchIDs.Add(load.DailyDispatchID.Value);
                    if (dispatch.DispatchGroup == load.DailyDispatch.DispatchGroup)
                    {
                        loadToAdd = load;
                    }
                    else
                    {
                        if (load.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD || load.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                        {
                            loadToAdd = load;
                        }
                        else if (load.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || load.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                        {
                            if (load.LoadCopies.Count() == 0 && load.SourceLoadID.HasValue == false) 
                            {
                                if ((load.DeliveryType == DatabaseLists.LOAD_DELIVERY_TYPE_DALLAS_DISPATCH && dispatch.DispatchGroup == DatabaseLists.DISPATCH_GROUP_DALLAS) ||
                                    (load.DeliveryType == DatabaseLists.LOAD_DELIVERY_TYPE_OKC_DISPATCH && dispatch.DispatchGroup == DatabaseLists.DISPATCH_GROUP_OKC))
                                {
                                    Load loadCopy = load.MakeCopy();
                                    loadCopy.LoadCompanyID = load.LoadCompanyID;
                                    loadCopy.PickupCompanyID = load.PickupCompanyID;
                                    loadCopy.SourceLoad = load;
                                    loadCopy.DailyDispatchID = null;
                                    loadCopy.DailyDispatch = dispatch;
                                    loadCopy.CreateDate = DateTime.Now;
                                    loadCopy.CreateUser = this.User.Identity.Name;
                                    loadToAdd = loadCopy;
                                }
                            }
                        }
                    }
                }

                if (loadToAdd != null)
                {
                    HLLogging.InfoFormat(
                        "Load {0} type {1} attached to Dispatch {2} from Dispatch {3} ({4})", 
                        loadToAdd.LoadID, 
                        loadToAdd.LoadType, 
                        dispatch.DailyDispatchID, 
                        loadToAdd.DailyDispatchID ?? 0, 
                        this.User.Identity.Name);
                    dispatch.Loads.Add(loadToAdd);
                }
            }

            // Add the temporary Outbound Loads to the Dispatch, if they are present in the input screen.
            // This will create a new Load attached to the Dispatch.
            foreach (Load load in dispatchEdit.TempOutboundLoads.Where(x => temporaryLoadIDsToAdd.Contains(x.LoadID)))
            {
                // These two statements make sure a reference to an existing store is used.
                // Otherwise, the detached Store entity will be added.
                if (load.Store != null)
                {
                    load.StoreID = load.Store.StoreID;
                    load.Store = null;
                }

                load.CreateDate = DateTime.Now;
                load.CreateUser = this.User.Identity.Name;
                dispatch.Loads.Add(load);
            }

            // Add the temporary Inbound Loads
            foreach (Load load in dispatchEdit.TempInboundLoads.Where(x => temporaryLoadIDsToAdd.Contains(x.LoadID)))
            {
                // These two statements make sure a reference to an existing store is used.
                // Otherwise, the detached Store entity will be added.
                if (load.Store != null)
                {
                    load.StoreID = load.Store.StoreID;
                    load.Store = null;
                }

                if (load.PickupCompany != null)
                {
                    load.PickupCompanyID = load.PickupCompany.LoadCompanyID;
                    load.PickupCompany = null;
                }

                load.CreateDate = DateTime.Now;
                load.CreateUser = this.User.Identity.Name;
                dispatch.Loads.Add(load);
            }

            // Order the Outbound loads the way they appeared on the screen.
            for (int i = 0; i < selectedOutboundLoads.Count(); i++)
            {
                int loadID = selectedOutboundLoads.ElementAt(i);
                Load load = dispatch.Loads.FirstOrDefault(x => x.LoadID == loadID);
                if (load != null)
                {
                    load.DispatchLoadOrder = i + 1;
                }
            }

            // Order the loads the way they appeared on the screen.
            for (int i = 0; i < selectedInboundLoads.Count(); i++)
            {
                int loadID = selectedInboundLoads.ElementAt(i);
                Load load = dispatch.Loads.FirstOrDefault(x => x.LoadID == loadID);
                if (load != null)
                {
                    load.DispatchLoadOrder = i + 1;
                }
            }

            // Final processing for outbound loads.
            foreach (Load load in dispatch.Loads)
            {
                if (load.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                {
                    Load changedLoad = dispatchEdit.TempOutboundLoads.FirstOrDefault(x => x.LoadID == load.LoadID);
                    if (changedLoad != null)
                    {
                        load.EtaDate = changedLoad.EtaDate;
                        load.StoreLoadType = changedLoad.StoreLoadType;
                        load.StoreOpening = changedLoad.StoreOpening;
                    }
                }
            }

            // Update the Dispatch Inbound Date
            if (dispatch.InboundDate.HasValue == false)
            {
                Load noseLoad = dispatch.Loads.Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(x => x.DispatchLoadOrder).FirstOrDefault();
                if (noseLoad != null)
                {
                    dispatch.InboundDate = noseLoad.EtaDate;
                }
                else
                {
                    noseLoad = dispatch.Loads.Where(x => DatabaseLists.INBOUND_LOAD_TYPES.Contains(x.LoadType)).OrderBy(x => x.DispatchLoadOrder).FirstOrDefault();
                    if (noseLoad != null)
                    {
                        dispatch.InboundDate = noseLoad.PickupDate;
                    }
                    else
                    {
                        dispatch.InboundDate = dispatch.DispatchDate;
                    }
                }
            }

            // Final processing for inbound loads.
            foreach (Load load in dispatch.Loads)
            {
                if (load.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                {
                    Load changedLoad = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == load.LoadID);
                    if (changedLoad != null)
                    {
                        load.PickupDate = changedLoad.PickupDate;
                        if (!load.SourceLoadID.HasValue)
                        {
                            var loadCopies = Db.Load.Where(x => x.SourceLoadID == load.LoadID);
                            foreach (Load loadCopy in loadCopies)
                            {
                                loadCopy.PickupDate = load.PickupDate;
                            }
                        }
                    }
                }
                else if (load.LoadType == DatabaseLists.INBOUND_BROKER_LOAD)
                {
                    Load changedLoad = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == load.LoadID);
                    if (changedLoad != null)
                    {
                        load.PickupDate = changedLoad.PickupDate;
                        load.EtaDate = changedLoad.EtaDate;
                        if (!load.SourceLoadID.HasValue)
                        {
                            var loadCopies = Db.Load.Where(x => x.SourceLoadID == load.LoadID);
                            foreach (Load loadCopy in loadCopies)
                            {
                                loadCopy.PickupDate = load.PickupDate;
                                loadCopy.EtaDate = load.EtaDate;
                            }
                        }
                    }
                }
                else if (load.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                {
                    Load changedLoad = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == load.LoadID);
                    if (changedLoad != null)
                    {
                        load.LinearFeet = changedLoad.LinearFeet;
                        load.Comment = changedLoad.Comment;
                    }

                    load.PickupDate = dispatch.InboundDate;
                }
            }
        }

        /// <summary>
        /// Updates the Dispatch record Containers collection.
        /// </summary>
        /// <param name="dispatch">DailyDispatch record to update (new or existing)</param>
        /// <param name="selectedContainerNumbers">ContainerNumber list to be on the updated Dispatch record</param>
        /// <param name="dragfromDispatchIDs">Collection of DailyDispatchIDs that have had containers pulled from them on this update.</param>
        private void UpdateDispatchContainers(
            DailyDispatch dispatch,
            IEnumerable<Container> containers,
            ICollection<int> dragfromDispatchIDs)
        {
            // First, remove any containers not remaining on the screen.
            Container[] containersToRemove = dispatch.Containers.Where(x => containers.Select(y => y.ContainerNumber).Contains(x.ContainerNumber) == false).ToArray();
            foreach (Container modelContainer in containersToRemove)
            {
                dispatch.Containers.Remove(modelContainer);
                ChangeLogger.LogChange(this, Db.Entry(modelContainer));
            }
            
            // Now, either add the container if not in the model, or update the container in the model.
            foreach (Container screenContainer in containers)
            {
                Container modelContainer = dispatch.Containers.FirstOrDefault(x => x.ContainerNumber == screenContainer.ContainerNumber);

                if (modelContainer == null)
                {
                    screenContainer.DailyDispatchID = dispatch.DailyDispatchID;

                    screenContainer.StatusCode = "ZZ";

                    ChangeLogger.LogChange(this, Db.Entry(screenContainer));
                    dispatch.Containers.Add(screenContainer);
                }
                else
                {
                    modelContainer.ContainerAction = screenContainer.ContainerAction;

                    screenContainer.StatusCode = "ZZ";

                    ChangeLogger.LogChange(this, Db.Entry(modelContainer));
                }
            }

            // Order the Outbound loads the way they appeared on the screen.
            int i = 1;
            foreach (Container screenContainer in containers)
            {
                Container modelContainer = dispatch.Containers.FirstOrDefault(x => x.ContainerNumber == screenContainer.ContainerNumber);
                if (modelContainer != null)
                {
                    modelContainer.DispatchOrder = (short)(i++);
                }
            }

            Container inboundContainer = dispatch.Containers.FirstOrDefault(x => x.ContainerAction == ContainerAction.CommitToOKC);
            if (inboundContainer != null)
            {
                dispatch.TrailerIn = inboundContainer.ContainerNumber;
            }

            Container outboundContainer = dispatch.Containers.FirstOrDefault(x => x.ContainerAction == ContainerAction.EmptyReturn);
            if (outboundContainer != null)
            {
                dispatch.Trailer = outboundContainer.ContainerNumber;
            }
        }

        #endregion

        #region ViewBag loading methods

        private void LoadViewBag(DailyDispatch dailyDispatch = null)
        {
            var dispatchGroups = new[]
            { 
                new { Text = "OTR", Value = DatabaseLists.DISPATCH_GROUP_OTR },
                new { Text = "Dallas", Value = DatabaseLists.DISPATCH_GROUP_DALLAS },
                new { Text = "OKC", Value = DatabaseLists.DISPATCH_GROUP_OKC }
            };

            DateTime earliestOpenDate = Db.OpenDispatchDates().AsNoTracking().Min(x => x.DispatchDate);

            DateTime latestOpenDate = Db.OpenDispatchDates().AsNoTracking().Max(x => x.DispatchDate);

            List<DateTime> dateList = new List<DateTime>();

            for (DateTime genDate = earliestOpenDate; genDate <= latestOpenDate; genDate = genDate.AddDays(1))
            {
                dateList.Add(genDate);
            }

            var dispatchDates = dateList
                .Select(x => new
                {
                    Value = x.ToString("d"),
                    Text = x.ToString("ddd M/d")
                });

            var carriers = Db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .AsNoTracking()
                .OrderBy(x => x.Name)
                .ToList()
                .Select(x => new
                {
                    Text = string.Format("{0}{1}", x.Name, x.DeleteDate.HasValue ? " (deleted)" : string.Empty),
                    Value = x.CarrierID
                })
                .ToList();

            if (dailyDispatch == null)
            {
                ViewBag.DispatchGroup = new SelectList(dispatchGroups, "Value", "Text");
                ViewBag.DispatchDate = new SelectList(dispatchDates, "Value", "Text", DateTime.Today.ToString("d"));
                ViewBag.CarrierID = new SelectList(carriers, "Value", "Text");
            }
            else
            {
                ViewBag.DispatchGroup = new SelectList(dispatchGroups, "Value", "Text", dailyDispatch.DispatchGroup);
                ViewBag.DispatchDate = new SelectList(dispatchDates, "Value", "Text", dailyDispatch.DispatchDate.ToString("d"));
                ViewBag.CarrierID = new SelectList(carriers, "Value", "Text", dailyDispatch.CarrierID);
            }
        }

        private IEnumerable<LoadDragDropViewModel> BagInboundLoads(IEnumerable<int> loadIDs, int? currentDispatchID = null, IEnumerable<Load> tempLoads = null)
        {
            List<LoadDragDropViewModel> ddloads = new List<LoadDragDropViewModel>();

            // Walk to load ID list in the order they appear on the screen.
            foreach (int loadID in loadIDs)
            {
                Load load;
                if (loadID > 0)
                {
                    load = Db.Load
                        .Include(x => x.PickupCompany)
                        .Include(x => x.DeliveryCompany)
                        .Include(x => x.Store)
                        .Single(x => x.LoadID == loadID);
                    load = MergeTemporaryEdit(load);
                }
                else
                {
                    load = tempLoads.SingleOrDefault(x => x.LoadID == loadID);
                }

                LoadDragDropViewModel ddload = new LoadDragDropViewModel(load);
                if (ddload != null)
                {
                    if (!ddload.DailyDispatchID.HasValue || !currentDispatchID.HasValue || ddload.DailyDispatchID.Value != currentDispatchID.Value)
                    {
                        ddload.ViewStatus = "New";
                    }
                }

                ddloads.Add(ddload);
            }

            return ddloads;
        }

        private IEnumerable<LoadDragDropViewModel> BagOutboundLoads(IEnumerable<int> loadIDs, int? currentDispatchID = null, IEnumerable<Load> tempLoads = null)
        {
            List<LoadDragDropViewModel> ddloads = new List<LoadDragDropViewModel>();

            // Walk to load ID list in the order they appear on the screen.
            foreach (int loadID in loadIDs)
            {
                Load load;
                if (loadID > 0)
                {
                    load = Db.Load
                        .Include(x => x.Store)
                        .Single(x => x.LoadID == loadID);
                    load = MergeTemporaryEdit(load);
                }
                else
                {
                    load = tempLoads.SingleOrDefault(x => x.LoadID == loadID);
                    if (load != null && load.StoreID.HasValue)
                    {
                        load.Store = Db.Store.AsNoTracking().Single(x => x.StoreID == load.StoreID);
                    }
                }

                LoadDragDropViewModel ddload = new LoadDragDropViewModel(load);
                if (ddload != null)
                {
                    if (!ddload.DailyDispatchID.HasValue || !currentDispatchID.HasValue || ddload.DailyDispatchID.Value != currentDispatchID.Value)
                    {
                        ddload.ViewStatus = "New";
                    }
                }

                ddloads.Add(ddload);
            }

            return ddloads;
        }

        private IEnumerable<ContainerViewModel> BagContainers(IEnumerable<Container> containers, int? currentDispatchID = null)
        {
            List<ContainerViewModel> containerViewModels = new List<ContainerViewModel>();

            ContainerService = ContainerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

            // Get the ContainerInfo records in one action.
            Dictionary<string, ContainerInfo> containerList = ContainerService
                .GetContainerListByNumber(containers.Select(x => x.ContainerNumber))
                .ToDictionary(x => x.ContainerNumber);

            // Walk to load list in the order they appear on the screen.
            foreach (Container container in containers)
            {
                ContainerViewModel viewModel = null;

                ContainerInfo containerInfo = null;
                if (containerList.TryGetValue(container.ContainerNumber, out containerInfo))
                {
                    viewModel = new ContainerViewModel(container, containerInfo);
                }
                else
                {
                    viewModel = new ContainerViewModel(container);
                }

                if (viewModel.DailyDispatchID == 0 || !currentDispatchID.HasValue || viewModel.DailyDispatchID != currentDispatchID.Value)
                {
                    viewModel.ViewStatus = "New";
                }

                containerViewModels.Add(viewModel);
            }

            return containerViewModels;
        }

        #endregion

        #region Ajax Methods for updating individual elements from the DailyDispatch Index screen to the database.

        /// <summary>
        /// This method is called for each individual field to be updated when one or more columns in the Index view are in update mode.
        /// The call is triggered by the Changed event in the html.
        /// Supports updating these fields:
        /// DailyDispatch: Trailer, TrailerIn, Comment
        /// Load: LinearFeet
        /// </summary>
        /// <param name="update">Field update object instantiated from JSON input, with record ID, field ID and new field value.</param>
        /// <returns>Count of successful updates (0 or 1).</returns>
        [HttpPost]
        public JsonResult UpdateField(FieldUpdate update)
        {
            FieldUpdateResponse response = new FieldUpdateResponse
            {
                changecount = 0
            };

            int changedDailyDispatchID = 0;
            int changedLoadID = 0;

            try
            {
                if (update != null)
                {
                    string updateValue = string.IsNullOrWhiteSpace(update.fieldvalue) ? null : update.fieldvalue.Trim();

                    int? updateValueInteger = null;

                    if (updateValue != null)
                    {
                        try
                        {
                            updateValueInteger = int.Parse(updateValue);
                        }
                        catch (Exception)
                        {
                            updateValueInteger = null;
                        }
                    }

                    Db = Db ?? new DispatchContext();

                    if (update.fieldid == FieldName.DispatchTrailer)
                    {
                        DailyDispatch dispatch = Db.DailyDispatch.Find(update.recordid);
                        if (dispatch != null)
                        {
                            dispatch.Trailer = updateValue;
                            response.changecount++;
                            changedDailyDispatchID = dispatch.DailyDispatchID;
                        }
                    }
                    else if (update.fieldid == FieldName.DispatchTrailerIn)
                    {
                        DailyDispatch dispatch = Db.DailyDispatch.Find(update.recordid);
                        if (dispatch != null)
                        {
                            dispatch.TrailerIn = updateValue;
                            response.changecount++;
                            changedDailyDispatchID = dispatch.DailyDispatchID;
                        }
                    }
                    else if (update.fieldid == FieldName.DispatchComment)
                    {
                        DailyDispatch dispatch = Db.DailyDispatch.Find(update.recordid);
                        if (dispatch != null)
                        {
                            dispatch.Comment = updateValue;
                            response.changecount++;
                            changedDailyDispatchID = dispatch.DailyDispatchID;
                        }
                    }
                    else if (update.fieldid == FieldName.LoadFeet)
                    {
                        Load load = Db.Load.Find(update.recordid);
                        if (load != null)
                        {
                            load.LinearFeet = updateValueInteger;
                            response.changecount++;
                            changedLoadID = load.LoadID;
                            changedDailyDispatchID = load.DailyDispatchID ?? 0;
                        }
                    }

                    foreach (var entry in Db.ChangeTracker.Entries())
                    {
                        if (entry.State == EntityState.Modified)
                        {
                            ChangeLogger.LogChange(this, entry);
                        }
                    }

                    // Persist changes
                    Db.SaveChanges();

                    // Update dispatch/load in saved viewmodel
                    DailyDispatchIndexViewModel viewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;
                    if (viewModel != null && viewModel.Dispatches != null)
                    {
                        DispatchViewModel dispatchViewModel = viewModel.Dispatches.FirstOrDefault(x => x.DailyDispatchID == changedDailyDispatchID);
                        if (dispatchViewModel != null)
                        {
                            if (update.fieldid == FieldName.DispatchTrailer)
                            {
                                dispatchViewModel.Trailer = updateValue;
                            }
                            else if (update.fieldid == FieldName.DispatchTrailerIn)
                            {
                                dispatchViewModel.TrailerIn = updateValue;
                            }
                            else if (update.fieldid == FieldName.DispatchComment)
                            {
                                dispatchViewModel.Comment = updateValue;
                            }
                            else if (update.fieldid == FieldName.LoadFeet)
                            {
                                LoadDragDropViewModel loadViewModel = dispatchViewModel.Loads.FirstOrDefault(x => x.LoadID == changedLoadID);
                                if (loadViewModel != null)
                                {
                                    loadViewModel.LinearFeet = updateValueInteger;
                                }
                            }
                        }
                    }

                    response.fieldvalue = updateValue;
                }
            }
            catch (Exception ex)
            {
                response.changecount = 0;
                HLLogging.Error("Error in UpdateField Ajax method", ex);
            }

            return Json(response);
        }

        #endregion

        #region Ajax Methods for loading dynamic lists (Drivers)

        public JsonResult GetDriverList()
        {
            Db = Db ?? new DispatchContext();

            var drivers = Db.Driver.ActiveFilter()
                .Include(x => x.Dispatcher)
                .AsNoTracking()
                .OrderBy(x => x.Dispatcher.FirstName)
                .ThenBy(x => x.Dispatcher.LastName)
                .ThenBy(x => x.FirstName)
                .ThenBy(x => x.LastName)
                .ToList()
                .Select(x => new
                {
                    value = x.FullName,
                    id = x.DriverID,
                    category = x.Dispatcher != null ? x.Dispatcher.FullName : string.Empty
                });

            return Json(drivers, JsonRequestBehavior.AllowGet);
        }

        public PartialViewResult GetDispatchCarrierSummary(int id)
        {
            Db = Db ?? new DispatchContext();

            DailyDispatch model = Db.DailyDispatch
                .Include(x => x.Carrier)
                .Single(x => x.DailyDispatchID == id);

            DispatchViewModel vm = new DispatchViewModel(model);

            return PartialView("_DispatchSummaryPopup", vm);
        }

        #endregion

        #region Ajax Methods for Adding Broker Loads and Vendor Backhauls to the Dispatch

        [HttpPost]
        public ActionResult SelectInboundLoad(DailyDispatchLoadViewModel viewModel)
        {
            Db = Db ?? new DispatchContext();

            if (viewModel == null)
            {
                viewModel = new DailyDispatchLoadViewModel();
            }

            if (!ModelState.IsValid)
            {
                viewModel.Loads = Enumerable.Empty<LoadDragDropViewModel>();
            }
            else
            {
                DailyDispatchIndexViewModel savedViewModel = Session[FilterSessionName] as DailyDispatchIndexViewModel;

                /*
                List<string> IncludeTypes = new List<string>();
                if (viewModel.IncludeBrokerLoads.HasValue && viewModel.IncludeBrokerLoads == true)
                {
                    IncludeTypes.Add(DatabaseLists.INBOUND_BROKER_LOAD);
                }
                if (viewModel.IncludeVendorBackhauls.HasValue && viewModel.IncludeVendorBackhauls == true)
                {
                    IncludeTypes.Add(DatabaseLists.INBOUND_VENDOR_BACKHAUL);
                }

                 * Original query before adding support for Dallas
                 * 
                var loads = db.Load
                    .UnassignedLoads()
                    .Where(x => x.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || x.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                    .LoadSelectedTypes(IncludeTypes, passQuery: true)
                    .Include(x => x.PickupCompany)
                    .Include(x => x.Store);
                 */

                var loads = Db.Load
                    .Include(x => x.PickupCompany);

                if (viewModel.DispatchGroup == DatabaseLists.DISPATCH_GROUP_DALLAS)
                {
                    loads = loads
                        .Include(x => x.DailyDispatch)
                        .Include(x => x.LoadCopies)
                        .Include(x => x.DeliveryCompany);

                    DateTime oldestOpenDispatchDate = Db.OpenDispatchDates().OldestDispatchDate();
                    if (viewModel.IncludeBrokerLoads != viewModel.IncludeVendorBackhauls)
                    {
                        if (viewModel.IncludeBrokerLoads == true)
                        {
                            loads = loads.Where(x => x.LoadType == DatabaseLists.INBOUND_BROKER_LOAD && x.PickupDate > oldestOpenDispatchDate);
                        }
                        else if (viewModel.IncludeVendorBackhauls == true)
                        {
                            loads = loads.Where(x => x.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL && x.ReadyDate > oldestOpenDispatchDate);
                        }
                    }
                    else
                    {
                        loads = loads.Where(x =>
                            (x.LoadType == DatabaseLists.INBOUND_BROKER_LOAD && x.PickupDate > oldestOpenDispatchDate) ||
                            (x.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL && x.ReadyDate > oldestOpenDispatchDate));
                    }

                    loads = loads.Where(x => x.DeliveryType == DatabaseLists.LOAD_DELIVERY_TYPE_DALLAS_DISPATCH);
                    loads = loads.Where(x =>
                        (x.DailyDispatchID.HasValue == false) ||
                        (x.DailyDispatchID.HasValue == true && x.DailyDispatch.DispatchGroup != DatabaseLists.LOAD_DELIVERY_TYPE_DALLAS_DISPATCH && x.LoadCopies.Count() == 0));
                }
                else
                {
                    if (viewModel.IncludeBrokerLoads != viewModel.IncludeVendorBackhauls)
                    {
                        if (viewModel.IncludeBrokerLoads == true)
                        {
                            loads = loads.Where(x => x.LoadType == DatabaseLists.INBOUND_BROKER_LOAD);
                        }
                        else if (viewModel.IncludeVendorBackhauls == true)
                        {
                            loads = loads.Where(x => x.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL);
                        }
                    }
                    else
                    {
                        loads = loads.Where(x =>
                            x.LoadType == DatabaseLists.INBOUND_BROKER_LOAD ||
                            x.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL);
                    }

                    loads = loads.Where(x => x.DailyDispatchID.HasValue == false);
                }
                
                if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
                {
                    string textValue = viewModel.SearchField.Trim();

                    long intValue = 0;
                    decimal decValue = 0m;
                    bool isNumber = decimal.TryParse(textValue, out decValue);
                    if (isNumber)
                    {
                        intValue = decimal.ToInt64(decValue);
                    }

                    if (isNumber && intValue > 0)
                    {
                        loads = loads.Where(x =>
                            x.LoadID == intValue
                            || x.BrokerLoadNumber.Contains(textValue)
                            || x.PO1.Contains(textValue)
                            || x.PO2.Contains(textValue)
                            || x.Comment.Contains(textValue)
                            || x.PickupCompany.Name.Contains(textValue)
                            || x.PickupCompany.Contact.Contains(textValue));
                    }
                    else
                    {
                        loads = loads.Where(x =>
                            x.BrokerLoadNumber.Contains(textValue)
                            || x.PO1.Contains(textValue)
                            || x.PO2.Contains(textValue)
                            || x.Comment.Contains(textValue)
                            || x.PickupCompany.Name.Contains(textValue)
                            || x.PickupCompany.Contact.Contains(textValue));
                    }
                }

                if (viewModel.FromDate.HasValue)
                {
                    loads = loads.Where(x => x.PickupDate >= viewModel.FromDate.Value);
                }

                if (viewModel.ThruDate.HasValue)
                {
                    loads = loads.Where(x => x.PickupDate <= viewModel.ThruDate.Value);
                }

                LoadSortColumn sortColumn;
                if (!Enum.TryParse(viewModel.SortColumn, out sortColumn))
                {
                    sortColumn = LoadSortColumn.PickupDate;
                }

                loads = loads.Sort(sortColumn, viewModel.SortDirection);

                viewModel.Loads = loads.ToList().Select(x => new LoadDragDropViewModel(x));
            }

            return PartialView("SelectInboundLoad", viewModel);
        }

        [HttpGet]
        public ActionResult SelectedInboundLoad(int id)
        {
            Db = Db ?? new DispatchContext();

            Load load = Db.Load
                .Include(x => x.PickupCompany)
                .Include(x => x.DeliveryCompany)
                .Include(x => x.Store)
                .Single(x => x.LoadID == id);

            LoadDragDropViewModel ddload = new LoadDragDropViewModel(load);

            ddload.ViewStatus = "New";

            return PartialView("_InboundLoadListItem", ddload);
        }

        #endregion

        #region Ajax Methods for Adding Cleanup Loads to Dispatch

        [HttpGet]
        public ActionResult SelectCleanupLoad()
        {
            Db = Db ?? new DispatchContext();

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            var storeList = Db.Store
                .ActiveFilter()
                .AsNoTracking()
                .OrderBy(x => x.CompanyID)
                .ThenBy(x => x.StoreNumber)
                .ToList()
                .Select(x => new
                {
                    Value = x.StoreID,
                    Text = x.StoreAndCompanyLong
                });

            ViewBag.StoreID = new SelectList(storeList, "Value", "Text");

            return PartialView("SelectCleanupLoad");
        }

        [HttpGet]
        public PartialViewResult SelectCleanupList(int id)
        {
            Db = Db ?? new DispatchContext();

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            DateTime pickupDate;

            if (dispatchEdit.DailyDispatchID.HasValue && dispatchEdit.DailyDispatchID > 0)
            {
                DailyDispatch dispatch = Db.DailyDispatch
                    .AsNoTracking()
                    .Include(x => x.Loads)
                    .Single(x => x.DailyDispatchID == dispatchEdit.DailyDispatchID.Value);

                var storeLoads = dispatch.Loads.Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD);
                if (storeLoads.Any())
                {
                    Load noseLoad = storeLoads.OrderBy(x => x.DispatchLoadOrder).First();
                    Load noseLoadOverride = dispatchEdit.TempOutboundLoads.FirstOrDefault(x => x.LoadID == noseLoad.LoadID);
                    if (noseLoadOverride != null && noseLoadOverride.EtaDate.HasValue)
                    {
                        pickupDate = noseLoadOverride.EtaDateOnly.Value;
                    }
                    else
                    {
                        pickupDate = noseLoad.EtaDateOnly.Value;
                    }
                }
                else if (dispatch.InboundDate.HasValue)
                {
                    pickupDate = dispatch.InboundDate.Value.Date;
                }
                else
                {
                    pickupDate = dispatch.DispatchDate.GetNextBusinessDate().Date;
                }
            }
            else
            {
                DateTime oldestOpenDispatchDate = Db.OpenDispatchDates().OldestDispatchDate();
                pickupDate = oldestOpenDispatchDate;
            }
            
            switch (pickupDate.DayOfWeek)
            {
                case DayOfWeek.Saturday:
                    pickupDate = pickupDate.AddDays(-1);
                    break;
                case DayOfWeek.Sunday:
                    pickupDate = pickupDate.AddDays(-2);
                    break;
                case DayOfWeek.Monday:
                    pickupDate = pickupDate.AddDays(-3);
                    break;
                case DayOfWeek.Tuesday:
                    pickupDate = pickupDate.AddDays(-1);
                    break;
                case DayOfWeek.Wednesday:
                    pickupDate = pickupDate.AddDays(-2);
                    break;
                case DayOfWeek.Thursday:
                    pickupDate = pickupDate.AddDays(-3);
                    break;
                case DayOfWeek.Friday:
                    pickupDate = pickupDate.AddDays(-4);
                    break;
            }

            int currentDispatch = dispatchEdit.DailyDispatchID ?? 0;

            List<Load> cleanupLoads = Db.Load
                .Where(x => x.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                .Where(x => x.StoreID == id)
                .Where(x => x.PickupDate >= pickupDate)
                .Where(x => x.DailyDispatchID.HasValue == false || x.DailyDispatchID != currentDispatch)
                .OrderBy(x => x.PickupDate)
                .ToList();

            DailyDispatchLoadViewModel viewModel = new DailyDispatchLoadViewModel();

            if (dispatchEdit.TempInboundLoads.Count == 0)
            {
                viewModel.Loads = cleanupLoads.Select(x => new LoadDragDropViewModel(x));
            }
            else
            {
                viewModel.Loads = cleanupLoads
                    .Where(x => dispatchEdit.TempInboundLoads.Select(y => y.LoadID).Contains(x.LoadID) == false)
                    .Select(x => new LoadDragDropViewModel(x));
            }

            return PartialView("SelectCleanupList", viewModel);
        }

        [HttpGet]
        public ActionResult SelectedCleanupLoad(int id)
        {
            Db = Db ?? new DispatchContext();

            Load load = Db.Load
                .Include(x => x.Store)
                .Single(x => x.LoadID == id);

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            dispatchEdit.TempInboundLoads.Add(load);

            LoadDragDropViewModel ddload = new LoadDragDropViewModel(load);
            if (!ddload.DailyDispatchID.HasValue || !dispatchEdit.DailyDispatchID.HasValue || ddload.DailyDispatchID.Value != dispatchEdit.DailyDispatchID.Value)
            {
                ddload.ViewStatus = "New";
            }

            return PartialView("_InboundLoadListItem", ddload);
        }

        #endregion

        #region Ajax Methods for Updating Broker Loads, Vendor Backhauls, and Cleanups on the Dispatch

        [HttpGet]
        public ActionResult UpdateInboundLoad(int id)
        {
            Db = Db ?? new DispatchContext();

            DailyDispatchLoadViewModel viewModel = new DailyDispatchLoadViewModel();

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            Load load;

            if (id > 0)
            {
                load = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == id);
                if (load != null)
                {
                    if (load.PickupCompanyID.HasValue && load.PickupCompany == null)
                    {
                        load.PickupCompany = Db.LoadCompany.Single(x => x.LoadCompanyID == load.PickupCompanyID);
                    }

                    if (load.StoreID.HasValue && load.Store == null)
                    {
                        load.Store = Db.Store.Single(x => x.StoreID == load.StoreID);
                    }
                }
                else
                {
                    load = Db.Load
                        .Include(x => x.PickupCompany)
                        .Include(x => x.Store)
                        .Single(x => x.LoadID == id);
                }
            }
            else
            {
                load = dispatchEdit.TempInboundLoads.Single(x => x.LoadID == id);
            }

            viewModel.LoadID = id;
            viewModel.LoadType = load.LoadType;
            viewModel.LoadName = load.LoadName;
            viewModel.LoadDescription = load.LoadDescription;
            viewModel.LinearFeet = load.LinearFeet;
            viewModel.Comment = load.Comment;

            if (load.PickupDate.HasValue)
            {
                viewModel.PickupDate = load.PickupDate.Value.Date;
                TimeSpan time = load.PickupDate.Value.TimeOfDay;
                if (time != TimeSpan.Zero)
                {
                    viewModel.PickupTime = DateTime.MinValue + time;
                }
                else
                {
                    viewModel.PickupTime = null;
                }
            }

            if (load.EtaDate.HasValue)
            {
                viewModel.EtaDate = load.EtaDate.Value.Date;
                TimeSpan time = load.EtaDate.Value.TimeOfDay;
                if (time != TimeSpan.Zero)
                {
                    viewModel.EtaTime = DateTime.MinValue + time;
                }
                else
                {
                    viewModel.EtaTime = null;
                }
            }

            viewModel.PickupCity = load.LoadPickupCity;
            viewModel.PickupStateCode = load.LoadPickupStateCode;

            return PartialView("UpdateInboundLoad", viewModel);
        }

        [HttpPost]
        public ActionResult UpdateInboundLoad(DailyDispatchLoadViewModel viewModel)
        {
            Db = Db ?? new DispatchContext();
            
            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            Load load;

            if (viewModel.LoadID > 0)
            {
                load = dispatchEdit.TempInboundLoads.SingleOrDefault(x => x.LoadID == viewModel.LoadID);
                if (load == null)
                {
                    load = Db.Load
                        .Include(x => x.PickupCompany)
                        .Include(x => x.Store)
                        .Single(x => x.LoadID == viewModel.LoadID);
                    dispatchEdit.TempInboundLoads.Add(load);
                }
            }
            else if (viewModel.LoadID < 0)
            {
                load = dispatchEdit.TempInboundLoads.Single(x => x.LoadID == viewModel.LoadID);
            }
            else
            {
                throw new Exception("UpdateInboundLoad invoked without a valid id.");
            }

            if (load.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
            {
                if (viewModel.PickupDate.HasValue == false)
                {
                    ModelState.AddModelError(string.Empty, "Pickup Date must be entered.");
                }
            }
            else if (load.LoadType == DatabaseLists.INBOUND_BROKER_LOAD)
            {
                if (viewModel.PickupDate.HasValue == false)
                {
                    ModelState.AddModelError(string.Empty, "Pickup Date must be entered.");
                }

                if (viewModel.PickupTime.HasValue == false)
                {
                    ModelState.AddModelError(string.Empty, "Pickup Time must be entered.");
                }

                if (viewModel.EtaDate.HasValue == false)
                {
                    ModelState.AddModelError(string.Empty, "Delivery Date must be entered.");
                }

                if (viewModel.EtaTime.HasValue == false)
                {
                    ModelState.AddModelError(string.Empty, "Delivery Time must be entered.");
                }
            }
            else if (load.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
            {
            }

            if (!ModelState.IsValid)
            {
                return PartialView("UpdateInboundLoad", viewModel);
            }

            if (viewModel.PickupDate.HasValue)
            {
                load.PickupDate = viewModel.PickupDate.Value.Date + (viewModel.PickupTime.HasValue ? viewModel.PickupTime.Value.TimeOfDay : TimeSpan.Zero);
            }

            if (viewModel.EtaDate.HasValue)
            {
                load.EtaDate = viewModel.EtaDate.Value.Date + (viewModel.EtaTime.HasValue ? viewModel.EtaTime.Value.TimeOfDay : TimeSpan.Zero);
            }

            load.LinearFeet = viewModel.LinearFeet;

            load.Comment = viewModel.Comment;

            Session[DispatchEditSessionName] = dispatchEdit;

            LoadDragDropViewModel ddload = new LoadDragDropViewModel(load);

            if (!ddload.DailyDispatchID.HasValue || !dispatchEdit.DailyDispatchID.HasValue || ddload.DailyDispatchID.Value != dispatchEdit.DailyDispatchID.Value)
            {
                ddload.ViewStatus = "New";
            }

            return PartialView("_InboundLoadListItem", ddload);
        }

        #endregion

        #region Ajax Methods for Adding Store Loads to the Dispatch

        [HttpGet]
        public ActionResult CreateOutboundLoad()
        {
            Db = Db ?? new DispatchContext();

            DailyDispatchLoadViewModel viewModel = new DailyDispatchLoadViewModel();

            var storeList = Db.Store.ActiveFilter()
                .AsNoTracking()
                .OrderBy(x => x.CompanyID)
                .ThenBy(x => x.StoreNumber)
                .ToList()
                .Select(x => new
                {
                    Value = x.StoreID,
                    Text = x.StoreAndCompanyLong
                });

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            if (dispatchEdit.DailyDispatchID.HasValue && dispatchEdit.DailyDispatchID > 0)
            {
                DailyDispatch dispatch = Db.DailyDispatch
                    .AsNoTracking()
                    .Include(x => x.Loads)
                    .Single(x => x.DailyDispatchID == dispatchEdit.DailyDispatchID.Value);

                var storeLoads = dispatch.Loads.Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD);
                if (storeLoads.Any())
                {
                    Load noseLoad = storeLoads.OrderBy(x => x.DispatchLoadOrder).First();
                    Load noseLoadOverride = dispatchEdit.TempOutboundLoads.FirstOrDefault(x => x.LoadID == noseLoad.LoadID);
                    if (noseLoadOverride != null && noseLoadOverride.EtaDate.HasValue)
                    {
                        viewModel.EtaDate = noseLoadOverride.EtaDate.Value.Date;
                    }
                    else
                    {
                        viewModel.EtaDate = noseLoad.EtaDate.Value.Date;
                    }
                }
                else if (dispatch.InboundDate.HasValue)
                {
                    viewModel.EtaDate = dispatch.InboundDate.Value.Date;
                }
                else
                {
                    viewModel.EtaDate = dispatch.DispatchDate.GetNextBusinessDate().Date;
                }
            }
            else
            {
                viewModel.EtaDate = DateTime.Today;
            }

            ViewBag.StoreID = new SelectList(storeList, "Value", "Text");
            viewModel.LoadType = DatabaseLists.OUTBOUND_STORE_LOAD;
            viewModel.StoreLoadType = "B";
            viewModel.PickupDate = DateTime.Today;

            return PartialView("CreateOutboundLoad", viewModel);
        }

        [HttpGet]
        public PartialViewResult SelectOutboundList(int id, DailyDispatchLoadViewModel activeViewModel = null)
        {
            Db = Db ?? new DispatchContext();

            DailyDispatchLoadViewModel viewModel = activeViewModel ?? new DailyDispatchLoadViewModel();

            List<Load> storeLoads = Db.Load
                .OutboundOnly()
                .UnassignedLoads()
                .Where(x => x.StoreID == id)
                .OrderBy(x => x.EtaDate)
                .ToList();

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;
            if (dispatchEdit.TempOutboundLoads.Count == 0)
            {
                viewModel.Loads = storeLoads.Select(x => new LoadDragDropViewModel(x));
            }
            else
            {
                viewModel.Loads = storeLoads
                    .Where(x => dispatchEdit.TempOutboundLoads.Select(y => y.LoadID).Contains(x.LoadID) == false)
                    .Select(x => new LoadDragDropViewModel(x));
            }

            return PartialView("SelectOutboundList", viewModel);
        }
        
        [HttpPost]
        public ActionResult CreateOutboundLoad(DailyDispatchLoadViewModel viewModel)
        {
            Db = Db ?? new DispatchContext();

            if (viewModel.StoreID.HasValue == false)
            {
                ModelState.AddModelError(string.Empty, "Store must be selected.");
            }

            if (viewModel.EtaDate.HasValue == false)
            {
                ModelState.AddModelError(string.Empty, "Delivery Date must be entered.");
            }

            if (viewModel.EtaTime.HasValue == false)
            {
                ModelState.AddModelError(string.Empty, "Delivery Time must be entered.");
            }

            if (!ModelState.IsValid)
            {
                var storeList = Db.Store.ActiveFilter()
                    .AsNoTracking()
                    .OrderBy(x => x.CompanyID)
                    .ThenBy(x => x.StoreNumber)
                    .ToList()
                    .Select(x => new
                    {
                        Value = x.StoreID,
                        Text = x.StoreAndCompanyLong
                    });

                ViewBag.StoreID = new SelectList(storeList, "Value", "Text");

                if (viewModel.StoreID.HasValue)
                {
                    SelectOutboundList(viewModel.StoreID.Value, viewModel);
                }

                return PartialView("CreateOutboundLoad", viewModel);
            }

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            Load load;
            load = new Load
            {
                LoadType = DatabaseLists.OUTBOUND_STORE_LOAD,
                ReadyDate = DateTime.Today,
                PickupDate = DateTime.Today,
                StoreID = viewModel.StoreID,
                Store = Db.Store.Find(viewModel.StoreID)
            };
            dispatchEdit.TempOutboundLoads.Add(load);

            load.EtaDate = viewModel.EtaDate.Value.Date + viewModel.EtaTime.Value.TimeOfDay;
            load.StoreLoadType = viewModel.StoreLoadType;
            load.StoreOpening = viewModel.StoreOpening;

            if (viewModel.LoadID.HasValue == false)
            {
                load.LoadID = dispatchEdit.LastTempID;
                dispatchEdit.LastTempID -= 1;
            }
            else
            {
                load.LoadID = viewModel.LoadID.Value;
            }

            Session[DispatchEditSessionName] = dispatchEdit;

            LoadDragDropViewModel ddload = new LoadDragDropViewModel(load) { ViewStatus = "New" };
            
            return PartialView("_OutboundLoadListItem", ddload);
        }

        #endregion

        #region Ajax Methods for Updating Store Loads on the Dispatch

        [HttpGet]
        public ActionResult UpdateOutboundLoad(int id)
        {
            Db = Db ?? new DispatchContext();

            DailyDispatchLoadViewModel viewModel = new DailyDispatchLoadViewModel();

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            Load load;

            if (id > 0)
            {
                load = dispatchEdit.TempOutboundLoads.FirstOrDefault(x => x.LoadID == id);
                if (load != null)
                {
                    load.Store = Db.Store.Single(x => x.StoreID == load.StoreID);
                }
                else
                {
                    load = Db.Load
                        .Include(x => x.Store)
                        .Single(x => x.LoadID == id);
                }
            }
            else
            {
                load = dispatchEdit.TempOutboundLoads.Single(x => x.LoadID == id);
                load.Store = Db.Store.Single(x => x.StoreID == load.StoreID);
            }

            viewModel.StoreName = load.Store.StoreAndCompanyLong;
            viewModel.LoadID = id;
            viewModel.StoreID = load.StoreID;
            viewModel.EtaDate = load.EtaDate.Value.Date;
            TimeSpan time = load.EtaDate.Value.TimeOfDay;
            if (time != TimeSpan.Zero)
            {
                viewModel.EtaTime = DateTime.MinValue + time;
            }
            else
            {
                viewModel.EtaTime = null;
            }

            viewModel.LoadType = load.LoadType;
            viewModel.StoreLoadType = load.StoreLoadType;
            viewModel.StoreOpening = load.StoreOpening;

            return PartialView("UpdateOutboundLoad", viewModel);
        }

        [HttpPost]
        public ActionResult UpdateOutboundLoad(DailyDispatchLoadViewModel viewModel)
        {
            Db = Db ?? new DispatchContext();

            if (viewModel.EtaDate.HasValue == false)
            {
                ModelState.AddModelError(string.Empty, "Delivery Date must be entered.");
            }

            if (viewModel.EtaTime.HasValue == false)
            {
                ModelState.AddModelError(string.Empty, "Delivery Time must be entered.");
            }

            if (!ModelState.IsValid)
            {
                return PartialView("UpdateOutboundLoad", viewModel);
            }

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            Load load;

            if (viewModel.LoadID > 0)
            {
                load = dispatchEdit.TempOutboundLoads.SingleOrDefault(x => x.LoadID == viewModel.LoadID);
                if (load == null)
                {
                    load = Db.Load
                        .Include(x => x.Store)
                        .Single(x => x.LoadID == viewModel.LoadID);
                    dispatchEdit.TempOutboundLoads.Add(load);
                }
            }
            else if (viewModel.LoadID < 0)
            {
                load = dispatchEdit.TempOutboundLoads.Single(x => x.LoadID == viewModel.LoadID);
            }
            else
            {
                throw new Exception("UpdateOutboundLoad invoked without a valid id.");
            }

            load.EtaDate = viewModel.EtaDate.Value.Date + viewModel.EtaTime.Value.TimeOfDay;
            load.StoreLoadType = viewModel.StoreLoadType;
            load.StoreOpening = viewModel.StoreOpening;

            Session[DispatchEditSessionName] = dispatchEdit;

            LoadDragDropViewModel ddload = new LoadDragDropViewModel(load);

            if (!ddload.DailyDispatchID.HasValue || !dispatchEdit.DailyDispatchID.HasValue || ddload.DailyDispatchID.Value != dispatchEdit.DailyDispatchID.Value)
            {
                ddload.ViewStatus = "New";
            }

            return PartialView("_OutboundLoadListItem", ddload);
        }

        #endregion

        #region Ajax Methods for Removing Loads from the Dispatch

        [HttpGet]
        public void RemoveOutboundLoad(int id)
        {
            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            Load load = dispatchEdit.TempOutboundLoads.FirstOrDefault(x => x.LoadID == id);

            if (load != null)
            {
                dispatchEdit.TempOutboundLoads.Remove(load);
            }
        }

        [HttpGet]
        public void RemoveInboundLoad(int id)
        {
            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            Load load = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == id);

            if (load != null)
            {
                dispatchEdit.TempInboundLoads.Remove(load);
            }
        }

        #endregion

        #region Ajax Methods for Carrier Dispatch Charge calculation

        /// <summary>
        /// This method is a Child Action method to populate the initial Create or Edit screen.
        /// The current values for the carrier charge fields from the DailyDispatch record (for Edit) are copied directly to the charge fields
        /// in the response object. No calculations are performed, because the last values when the UPDATE button was pressed must be restored.
        /// The carrier comparison list is built and returned as normal.
        /// </summary>
        /// <param name="dailyDispatch"></param>
        /// <param name="outboundLoads"></param>
        /// <param name="inboundLoads"></param>
        /// <returns></returns>
        [ChildActionOnly]
        public PartialViewResult CreateCarrierChargeInfo(
            DailyDispatch dailyDispatch,
            IEnumerable<LoadDragDropViewModel> outboundLoads,
            IEnumerable<LoadDragDropViewModel> inboundLoads,
            bool? updateCarrierCharges)
        {
            Db = Db ?? new DispatchContext();

            CarrierInfoResult response = new CarrierInfoResult();

            try
            {
                if (dailyDispatch != null)
                {
                    response.CarrierExtraCharge = dailyDispatch.CarrierExtraCharge;
                    response.CarrierMiles = dailyDispatch.CarrierMiles;
                    response.CarrierRate = dailyDispatch.CarrierRate;
                    response.CarrierFlatRate = dailyDispatch.CarrierFlatRate;
                    response.MileageCalcType = dailyDispatch.MileageCalcType;
                    response.CarrierStopCharge1 = dailyDispatch.CarrierStopCharge1;
                    response.CarrierStopCharge2 = dailyDispatch.CarrierStopCharge2;
                    response.CarrierTotalCharge = dailyDispatch.CarrierTotalCharge;
                    response.FuelSurcharge = dailyDispatch.FuelSurcharge;
                    response.ChosenCarrierID = dailyDispatch.CarrierID;
                    response.LockCarrierTotalCharge = dailyDispatch.LockCarrierTotalCharge;
                }

                int outboundLoadCount = outboundLoads == null ? 0 : outboundLoads.Count();
                int inboundLoadCount = inboundLoads == null ? 0 : inboundLoads.Count();

                if (dailyDispatch != null && dailyDispatch.CarrierID.HasValue && (outboundLoadCount > 0 || inboundLoadCount > 0))
                {
                    int loadCount = outboundLoadCount + inboundLoadCount;

                    Load noseLoad = null;
                    DateTime? fuelsurchargeDate = null;

                    if (outboundLoadCount > 0)
                    {
                        int noseLoadID = outboundLoads.First().LoadID;
                        if (noseLoadID > 0)
                        {
                            // Existing load
                            noseLoad = Db.Load.AsNoTracking()
                                .Include(x => x.Store)
                                .Include(x => x.Store.StoreCarrierInfo)
                                .Include(x => x.Store.StoreCarrierInfo.Select(y => y.Carrier))
                                .Single(x => x.LoadID == noseLoadID);
                        }
                        else if (noseLoadID < 0)
                        {
                            // Temporary load
                            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;
                            if (dispatchEdit == null)
                            {
                                throw new Exception("DispatchEdit session object not found when trying to obtain temporary load.");
                            }

                            noseLoad = dispatchEdit.TempOutboundLoads.Single(x => x.LoadID == noseLoadID);
                            int storeID = noseLoad.Store.StoreID;
                            noseLoad.Store = Db.Store.AsNoTracking()
                                .Include(x => x.StoreCarrierInfo)
                                .Include(x => x.StoreCarrierInfo.Select(y => y.Carrier))
                                .Single(x => x.StoreID == storeID);
                        }

                        fuelsurchargeDate = noseLoad.EtaDate;
                    }

                    if (dailyDispatch.FuelSurcharge.HasValue == false)
                    {
                        if (fuelsurchargeDate.HasValue)
                        {
                            FuelSurcharge fuelSurcharge = Db.FuelSurcharge.GetFuelSurchargeForDate(fuelsurchargeDate.Value);
                            if (fuelSurcharge != null)
                            {
                                dailyDispatch.FuelSurcharge = fuelSurcharge.Amount;
                            }
                        }
                    }

                    if (outboundLoadCount > 0 && (noseLoad != null && noseLoad.Store != null && noseLoad.Store.StoreCarrierInfo != null))
                    {
                        response.Carriers = new List<CarrierInfoResult.CarrierInfoElement>();

                        decimal lowestTotalCharge = decimal.MaxValue;

                        foreach (var info in noseLoad.Store.StoreCarrierInfo.OrderBy(x => x.Carrier.Name))
                        {
                            CarrierChargeCalculation.Parts carrierCharge = CarrierChargeCalculation.Calculate(new CarrierChargeCalculation.Parts
                            {
                                Miles = info.Miles,
                                Rate = info.RatePerMile,
                                FlatRate = info.FlatRate,
                                MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)info.MileageCalcType,
                                StopCharge1 = info.Carrier.StopCharge1,
                                StopCharge2 = info.Carrier.StopCharge2,
                                FuelSurcharge = 0m,
                                ExtraCharge = response.CarrierExtraCharge,
                                LoadCount = loadCount
                            });
                            CarrierInfoResult.CarrierInfoElement carrier = new CarrierInfoResult.CarrierInfoElement
                            {
                                Name = info.Carrier.Name,
                                CarrierID = info.CarrierID,
                                Miles = carrierCharge.Miles,
                                RatePerMile = carrierCharge.Rate,
                                FlatRate = carrierCharge.FlatRate,
                                MileageCalcType = (int)carrierCharge.MileageCalcType,
                                StopCharge1 = carrierCharge.StopCharge1,
                                IsStopCharge1Used = carrierCharge.StopCharge1Used,
                                StopCharge2 = carrierCharge.StopCharge2,
                                IsStopCharge2Used = carrierCharge.StopCharge2Used,
                                TotalCharge = carrierCharge.TotalCharge
                            };

                            if (info.CarrierID == dailyDispatch.CarrierID)
                            {
                                carrier.IsSelectedCarrier = true;
                            }

                            if (carrier.TotalCharge.HasValue && (carrier.TotalCharge < lowestTotalCharge))
                            {
                                lowestTotalCharge = carrier.TotalCharge.Value;
                            }

                            response.Carriers.Add(carrier);
                        }

                        var lowestCarrierInfoCharges = response.Carriers.Where(x => x.TotalCharge == lowestTotalCharge);
                        foreach (var info in lowestCarrierInfoCharges)
                        {
                            info.IsLowestTotalCharge = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                HLLogging.Error("Error in CreateCarrierChargeInfo Ajax method", ex);
            }

            return PartialView("_CarrierComparison", response);
        }

        /// <summary>
        /// This method is used to update the carrier charge fields when one of these events occurs on the Create or Edit screen.
        /// 1. A carrier is selected or changed.
        /// 2. The first load is selected for outbound or inbound.
        /// 3. A load is moved to a different position in the trailer, when multiple loads have been assigned.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        public PartialViewResult UpdateCarrierChargeInfo(CarrierInfoRequest request)
        {
            Db = Db ?? new DispatchContext();

            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            CarrierInfoResult response = new CarrierInfoResult();

            if (request.OutboundLoadIDs == null)
            {
                request.OutboundLoadIDs = new List<int>();
            }

            if (request.InboundLoadIDs == null)
            {
                request.InboundLoadIDs = new List<int>();
            }

            try
            {
                if (request.CarrierID.HasValue && (request.OutboundLoadIDs.Any() || request.InboundLoadIDs.Any()))
                {
                    int loadCount = request.OutboundLoadIDs.Count + request.InboundLoadIDs.Count;

                    Load noseLoad = null;
                    DateTime? fuelsurchargeDate = null;

                    if (request.OutboundLoadIDs.Any())
                    {
                        int noseLoadID = request.OutboundLoadIDs.First();
                        if (noseLoadID > 0)
                        {
                            // Existing load
                            noseLoad = Db.Load.AsNoTracking()
                                .Include(x => x.Store)
                                .Include(x => x.Store.StoreCarrierInfo)
                                .Include(x => x.Store.StoreCarrierInfo.Select(y => y.Carrier))
                                .Single(x => x.LoadID == noseLoadID);
                            noseLoad = MergeTemporaryEdit(noseLoad);
                        }
                        else if (noseLoadID < 0)
                        {
                            // Temporary load
                            noseLoad = dispatchEdit.TempOutboundLoads.Single(x => x.LoadID == noseLoadID);
                            noseLoad.Store = Db.Store.AsNoTracking()
                                .Include(x => x.StoreCarrierInfo)
                                .Include(x => x.StoreCarrierInfo.Select(y => y.Carrier))
                                .Single(x => x.StoreID == noseLoad.Store.StoreID);
                        }

                        fuelsurchargeDate = noseLoad.EtaDate;
                    }
                    else if (request.InboundLoadIDs.Any())
                    {
                        int noseLoadID = request.InboundLoadIDs.First();
                        if (noseLoadID > 0)
                        {
                            // Existing load
                            noseLoad = Db.Load.AsNoTracking()
                                .Include(x => x.PickupCompany)
                                .Single(x => x.LoadID == noseLoadID);
                            noseLoad = MergeTemporaryEdit(noseLoad);
                        }
                        else if (noseLoadID < 0)
                        {
                            // Temporary load
                            noseLoad = dispatchEdit.TempInboundLoads.Single(x => x.LoadID == noseLoadID);
                            noseLoad.PickupCompany = Db.LoadCompany.AsNoTracking()
                                .Single(x => x.LoadCompanyID == noseLoad.PickupCompany.LoadCompanyID);
                        }

                        PropertyInfo propertyForFuelSurchargeDate = noseLoad.GetType().GetProperty(LibConfigProperties.Settings.InboundLoadFuelSurchargeDate);
                        if (propertyForFuelSurchargeDate != null)
                        {
                            fuelsurchargeDate = propertyForFuelSurchargeDate.GetValue(noseLoad, null) as DateTime?;
                            if (fuelsurchargeDate.HasValue)
                            {
                                fuelsurchargeDate = fuelsurchargeDate.Value.AddDays(LibConfigProperties.Settings.InboundLoadFuelSurchargeDateAdjust);
                            }
                        }
                    }

                    if (!request.FuelSurcharge.HasValue)
                    {
                        if (fuelsurchargeDate.HasValue)
                        {
                            FuelSurcharge fuelSurcharge = Db.FuelSurcharge.GetFuelSurchargeForDate(fuelsurchargeDate.Value);
                            if (fuelSurcharge != null)
                            {
                                request.FuelSurcharge = fuelSurcharge.Amount;
                            }
                        }
                    }
                    else
                    {
                        FuelSurcharge fuelSurcharge = Db.FuelSurcharge.GetFuelSurchargeForDate(fuelsurchargeDate.Value);
                        if (fuelSurcharge == null)
                        {
                            request.FuelSurcharge = null;
                        }
                    }

                    if (request.OutboundLoadIDs.Any() && (noseLoad != null && noseLoad.Store != null && noseLoad.Store.StoreCarrierInfo != null))
                    {
                        response.Carriers = new List<CarrierInfoResult.CarrierInfoElement>();

                        decimal lowestTotalCharge = decimal.MaxValue;

                        foreach (var info in noseLoad.Store.StoreCarrierInfo.OrderBy(x => x.Carrier.Name))
                        {
                            CarrierChargeCalculation.Parts carrierCharge = CarrierChargeCalculation.Calculate(new CarrierChargeCalculation.Parts
                            {
                                Miles = info.Miles,
                                Rate = info.RatePerMile,
                                FlatRate = info.FlatRate,
                                MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)info.MileageCalcType,
                                StopCharge1 = info.Carrier.StopCharge1,
                                StopCharge2 = info.Carrier.StopCharge2,
                                FuelSurcharge = 0m, // request.FuelSurcharge,// Remove fuel surcharge from calculation.
                                ExtraCharge = request.CarrierExtraCharge,
                                LoadCount = loadCount
                            });
                            CarrierInfoResult.CarrierInfoElement carrier = new CarrierInfoResult.CarrierInfoElement
                            {
                                Name = info.Carrier.Name,
                                CarrierID = info.CarrierID,
                                Miles = carrierCharge.Miles,
                                RatePerMile = carrierCharge.Rate,
                                FlatRate = carrierCharge.FlatRate,
                                MileageCalcType = (int)carrierCharge.MileageCalcType,
                                StopCharge1 = carrierCharge.StopCharge1,
                                IsStopCharge1Used = carrierCharge.StopCharge1Used,
                                StopCharge2 = carrierCharge.StopCharge2,
                                IsStopCharge2Used = carrierCharge.StopCharge2Used,
                                TotalCharge = carrierCharge.TotalCharge
                            };

                            if (info.CarrierID == request.CarrierID)
                            {
                                carrier.IsSelectedCarrier = true;
                                response.ChosenCarrierID = request.CarrierID;
                                CarrierChargeCalculation.Parts selectedCarrierCharge;
                                if (request.CarrierID == request.ChosenCarrierID)
                                {
                                    selectedCarrierCharge = CarrierChargeCalculation.Calculate(new CarrierChargeCalculation.Parts
                                    {
                                        Miles = request.CarrierMiles ?? carrier.Miles,
                                        Rate = carrier.RatePerMile,
                                        FlatRate = carrier.FlatRate,
                                        MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)carrier.MileageCalcType,
                                        StopCharge1 = request.CarrierStopCharge1 ?? carrier.StopCharge1,
                                        StopCharge2 = request.CarrierStopCharge2 ?? carrier.StopCharge2,
                                        FuelSurcharge = request.FuelSurcharge,
                                        ExtraCharge = request.CarrierExtraCharge,
                                        LoadCount = loadCount
                                    });
                                }
                                else
                                {
                                    selectedCarrierCharge = CarrierChargeCalculation.Calculate(new CarrierChargeCalculation.Parts
                                    {
                                        Miles = carrier.Miles,
                                        Rate = carrier.RatePerMile,
                                        FlatRate = carrier.FlatRate,
                                        MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)info.MileageCalcType,
                                        StopCharge1 = carrier.StopCharge1,
                                        StopCharge2 = carrier.StopCharge2,
                                        FuelSurcharge = request.FuelSurcharge,
                                        ExtraCharge = request.CarrierExtraCharge,
                                        LoadCount = loadCount
                                    });
                                }

                                response.CarrierMiles = selectedCarrierCharge.Miles;
                                response.CarrierRate = selectedCarrierCharge.Rate;
                                response.CarrierFlatRate = selectedCarrierCharge.FlatRate;
                                response.MileageCalcType = (int)selectedCarrierCharge.MileageCalcType;
                                response.CarrierStopCharge1 = selectedCarrierCharge.StopCharge1Used ? selectedCarrierCharge.StopCharge1 : null;
                                response.CarrierStopCharge2 = selectedCarrierCharge.StopCharge2Used ? selectedCarrierCharge.StopCharge2 : null;
                                response.CarrierTotalCharge = selectedCarrierCharge.TotalCharge;
                                response.CarrierExtraCharge = selectedCarrierCharge.ExtraCharge;
                                response.FuelSurcharge = selectedCarrierCharge.FuelSurcharge;
                            }

                            if (carrier.TotalCharge.HasValue && (carrier.TotalCharge < lowestTotalCharge))
                            {
                                lowestTotalCharge = carrier.TotalCharge.Value;
                            }

                            response.Carriers.Add(carrier);
                        }

                        var lowestCarrierInfoCharges = response.Carriers.Where(x => x.TotalCharge == lowestTotalCharge);
                        foreach (var info in lowestCarrierInfoCharges)
                        {
                            info.IsLowestTotalCharge = true;
                        }
                    }
                    else if (request.InboundLoadIDs.Any() && (noseLoad != null && noseLoad.PickupCompany != null))
                    {
                        CarrierChargeCalculation.Parts charges;
                        charges = CarrierChargeCalculation.Calculate(new CarrierChargeCalculation.Parts
                        {
                            Miles = request.CarrierMiles ?? noseLoad.PickupCompany.Miles,
                            Rate = request.CarrierRate,
                            FlatRate = request.CarrierFlatRate,
                            MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)request.MileageCalcType,
                            StopCharge1 = request.CarrierStopCharge1,
                            StopCharge2 = request.CarrierStopCharge2,
                            FuelSurcharge = request.FuelSurcharge,
                            ExtraCharge = request.CarrierExtraCharge,
                            TotalCharge = request.CarrierTotalCharge,
                            LoadCount = loadCount
                        });
                        response.CarrierMiles = charges.Miles;
                        response.CarrierRate = charges.Rate;
                        response.CarrierFlatRate = charges.FlatRate;
                        response.MileageCalcType = (int)charges.MileageCalcType;
                        response.CarrierStopCharge1 = charges.StopCharge1Used ? charges.StopCharge1 : null;
                        response.CarrierStopCharge2 = charges.StopCharge2Used ? charges.StopCharge2 : null;
                        response.CarrierTotalCharge = charges.TotalCharge;
                        response.CarrierExtraCharge = charges.ExtraCharge;
                        response.FuelSurcharge = charges.FuelSurcharge;
                    }
                }
                else
                {
                    CarrierChargeCalculation.Parts charges;
                    charges = CarrierChargeCalculation.Calculate(new CarrierChargeCalculation.Parts
                    {
                        Miles = request.CarrierMiles,
                        Rate = request.CarrierRate,
                        FlatRate = request.CarrierFlatRate,
                        MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)request.MileageCalcType,
                        StopCharge1 = request.CarrierStopCharge1,
                        StopCharge2 = request.CarrierStopCharge2,
                        FuelSurcharge = request.FuelSurcharge,
                        ExtraCharge = request.CarrierExtraCharge,
                        TotalCharge = request.CarrierTotalCharge,
                        LoadCount = 0
                    });

                    response.CarrierMiles = charges.Miles;
                    response.CarrierRate = charges.Rate;
                    response.CarrierFlatRate = charges.FlatRate;
                    response.MileageCalcType = (int)charges.MileageCalcType;
                    response.CarrierStopCharge1 = charges.StopCharge1Used ? charges.StopCharge1 : null;
                    response.CarrierStopCharge2 = charges.StopCharge2Used ? charges.StopCharge2 : null;
                    response.CarrierTotalCharge = charges.TotalCharge;
                    response.CarrierExtraCharge = charges.ExtraCharge;
                    response.FuelSurcharge = charges.FuelSurcharge;
                }

                // Set 'changed' indicators.
                response.CarrierMilesChanged = response.CarrierMiles != request.CarrierMiles ? true : false;
                response.CarrierRateChanged = response.CarrierRate != request.CarrierRate ? true : false;
                response.CarrierFlatRateChanged = response.CarrierFlatRate != request.CarrierFlatRate ? true : false;
                response.CarrierStopCharge1Changed = response.CarrierStopCharge1 != request.CarrierStopCharge1 ? true : false;
                response.CarrierStopCharge2Changed = response.CarrierStopCharge2 != request.CarrierStopCharge2 ? true : false;
            }
            catch (Exception ex)
            {
                HLLogging.Error("Error in UpdateCarrierChargeInfo Ajax method", ex);
            }

            ModelState.Clear();
            
            return PartialView("_CarrierComparison", response);
        }

        #endregion

        #region Ajax Methods for Carrier Rate History

        /// <summary>
        /// This method is used to update the carrier charge fields when one of these events occurs on the Create or Edit screen.
        /// 1. A carrier is selected or changed.
        /// 2. The first load is selected for outbound or inbound.
        /// 3. A load is moved to a different position in the trailer, when multiple loads have been assigned.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PartialViewResult GetCarrierRateHistory(CarrierRateHistoryRequest request)
        {
            Db = Db ?? new DispatchContext();

            CarrierRateHistoryResponse response = new CarrierRateHistoryResponse();

            try
            {
                if (!request.CarrierID.HasValue || request.CarrierID == 0)
                {
                    throw new Exception("Carrier must be selected.");
                }

                if (request.OutboundLoadID == null || request.OutboundLoadID.Count == 0)
                {
                    throw new Exception("One or more store loads must be present.");
                }

                List<Store> lookupStores = new List<Store>();

                foreach (int loadID in request.OutboundLoadID)
                {
                    Load load;
                    if (loadID > 0)
                    {
                        load = Db.Load.AsNoTracking()
                            .Include(x => x.Store)
                            .Single(x => x.LoadID == loadID);
                    }
                    else if (loadID < 0)
                    {
                        DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;
                        if (dispatchEdit == null)
                        {
                            throw new Exception("DispatchEdit session object not found when trying to obtain temporary load.");
                        }

                        load = dispatchEdit.TempOutboundLoads.Single(x => x.LoadID == loadID);
                        load.Store = Db.Store.AsNoTracking().Single(x => x.StoreID == load.StoreID);
                    }
                    else
                    {
                        throw new Exception("Invalid LoadID of zero encountered.");
                    }

                    lookupStores.Add(load.Store);
                }

                int noseLoadStoreID = lookupStores[0].StoreID;

                var dispatches = Db.DailyDispatch
                    .AsNoTracking()
                    .Include(x => x.Carrier)
                    .Include(x => x.Loads)
                    .Include(x => x.Loads.Select(y => y.PickupCompany))
                    .Include(x => x.Loads.Select(y => y.Store))
                    .Where(x => x.DispatchDate < DateTime.Today)
                    .Where(x => x.CarrierID == request.CarrierID)
                    .Where(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                        .OrderBy(y => y.DispatchLoadOrder)
                        .FirstOrDefault().StoreID == noseLoadStoreID)
                    .OrderByDescending(x => x.DispatchDate);

                List<DispatchViewModel> responseDispatches = new List<DispatchViewModel>();

                List<int> lookupStoreIDs = lookupStores.Select(x => x.StoreID).ToList();

                response.StoreList = lookupStores.Select(x => x.StoreAndCompanyLong);

                if (dispatches.Any())
                {
                    foreach (var dispatch in dispatches)
                    {
                        List<int> dispatchStoreIDs = dispatch.Loads.Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                            .OrderBy(x => x.DispatchLoadOrder)
                            .Select(x => x.StoreID.Value)
                            .ToList();

                        if (dispatchStoreIDs.SequenceEqual(lookupStoreIDs))
                        {
                            responseDispatches.Add(new DispatchViewModel(dispatch));
                        }

                        if (responseDispatches.Count() >= 10)
                        {
                            break;
                        }
                    }

                    response.Dispatches = responseDispatches;
                }

                if (responseDispatches.Count == 0)
                {
                    response.Message = "No dispatches found for delivery combo.";
                }
            }
            catch (Exception ex)
            {
                HLLogging.Error("Error in GetCarrierRateHistory Ajax method", ex);
                response.Message = ex.Message;
            }

            ModelState.Clear();

            return PartialView("_CarrierRateHistory", response);
        }

        #endregion

        #region Ajax Methods for Adding Container actions to Dispatch (Pulls, transfers, and returns)

        [HttpPost]
        public ActionResult SelectContainer(DailyDispatchSelectContainerViewModel viewModel)
        {
            if (viewModel == null)
            {
                viewModel = new DailyDispatchSelectContainerViewModel();
            }

            if (viewModel.AlreadySelected == null)
            {
                viewModel.AlreadySelected = new string[] { };
            }
            
            if (!ModelState.IsValid)
            {
                viewModel.Containers = Enumerable.Empty<ContainerViewModel>();
            }
            else
            {
                Db = new DispatchContext();

                ContainerService = ContainerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

                string[] statusCodes;

                switch (viewModel.ContainerAction)
                {
                    case ContainerAction.Pull:
                        statusCodes = ALLOWED_CONTAINER_STATUS_FOR_PULL;
                        break;
                    case ContainerAction.CommitToOKC:
                        statusCodes = ALLOWED_CONTAINER_STATUS_FOR_OKC_COMMIT;
                        break;
                    case ContainerAction.EmptyReturn:
                        statusCodes = ALLOWED_CONTAINER_STATUS_EMPTY_RETURN;
                        break;
                    default:
                        statusCodes = new string[] { string.Empty };
                        break;
                }

                var fullContainerList = ContainerService.GetContainerList(statusCodes);

                List<ContainerInfo> actionableContainerList = new List<ContainerInfo>();

                string[] containerNumbers = fullContainerList
                    .Select(x => x.ContainerNumber)
                    .ToArray();

                var actionedContainerLookup = Db.Container.AsNoTracking()
                    .Where(x => containerNumbers.Contains(x.ContainerNumber))
                    .ToLookup(x => x.ContainerNumber);

                foreach (ContainerInfo containerInfo in fullContainerList)
                {
                    if (viewModel.AlreadySelected.Contains(containerInfo.ContainerNumber))
                    {
                        continue; // Skip if container already selected in this dispatch.
                    }
                    else
                    {
                        var actionedContainersForNumber = actionedContainerLookup[containerInfo.ContainerNumber];
                        if (actionedContainersForNumber.Any(x => x.ContainerAction == viewModel.ContainerAction))
                        {
                            continue; // Skip if container already selected for same action in another dispatch.
                        }
                    }

                    actionableContainerList.Add(containerInfo);
                }

                viewModel.Containers = actionableContainerList
                    .OrderBy(x => x.LastFreeDate)
                    .Select(x => new ContainerViewModel(x));
            }

            return PartialView("SelectContainer", viewModel);
        }

        [HttpGet]
        public ActionResult SelectedContainer(string id, ContainerAction containerAction)
        {
            ContainerService = ContainerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

            ContainerInfo containerInfo = ContainerService.GetContainer(id);

            ContainerViewModel container = new ContainerViewModel(containerInfo);
            container.ContainerAction = containerAction; 
            container.ViewStatus = "New";

            return PartialView("_ContainerListItem", container);
        }

        #endregion

        #region Helper methods

        private Load MergeTemporaryEdit(Load load)
        {
            DispatchEdit dispatchEdit = Session[DispatchEditSessionName] as DispatchEdit;

            if (dispatchEdit != null)
            {
                if (load.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                {
                    Load changedLoad = dispatchEdit.TempOutboundLoads.FirstOrDefault(x => x.LoadID == load.LoadID);
                    if (changedLoad != null)
                    {
                        load.EtaDate = changedLoad.EtaDate;
                        load.StoreLoadType = changedLoad.StoreLoadType;
                        load.StoreOpening = changedLoad.StoreOpening;
                    }
                }
                else if (load.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                {
                    Load changedLoad = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == load.LoadID);
                    if (changedLoad != null)
                    {
                        load.PickupDate = changedLoad.PickupDate;
                    }
                }
                else if (load.LoadType == DatabaseLists.INBOUND_BROKER_LOAD)
                {
                    Load changedLoad = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == load.LoadID);
                    if (changedLoad != null)
                    {
                        load.PickupDate = changedLoad.PickupDate;
                        load.EtaDate = changedLoad.EtaDate;
                    }
                }
                else if (load.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                {
                    Load changedLoad = dispatchEdit.TempInboundLoads.FirstOrDefault(x => x.LoadID == load.LoadID);
                    if (changedLoad != null)
                    {
                        load.LinearFeet = changedLoad.LinearFeet;
                        load.Comment = changedLoad.Comment;
                    }
                }
            }

            return load;
        }

        protected override void Dispose(bool disposing)
        {
            if (Db != null)
            {
                Db.Dispose();
            }

            if (DbSlim != null)
            {
                DbSlim.Dispose();
            }

            base.Dispose(disposing);
        }

        #endregion
    }
}