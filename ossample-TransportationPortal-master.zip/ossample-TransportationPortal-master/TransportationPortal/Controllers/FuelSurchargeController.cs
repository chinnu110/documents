﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Mvc;
using Avatar;
using TransportationPortal.Models;
using TransportationPortal.Repositories;
using TransportationPortal.ViewModels;

namespace TransportationPortal.Controllers
{
    [HandleApplicationError]
    public class FuelSurchargeController : Controller
    {
        private DispatchContext db = new DispatchContext();

        private const string TEMPDATA_RETURN_URL = "ReturnURL";

        private const string _SqlQueryByArrival = "exec [dbo].[usp_Dispatches_QueryByArrival] @SelectionDateFrom, @SelectionDateThru";

        private const string OptimisticConcurrencyError = "The record you attempted to edit was modified after you got the original value.\r\n" +
                    "The edit operation was canceled and the current values in the database have been displayed.\r\n" +
                    "If you still want to edit this record, make the changes again and click the Save button.\r\n" +
                    "Otherwise click Back to List.";

        private SelectListItem[] _sortTypes =
        {
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundArrival) + ",A", Text = "Outbound Arrival" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.DispatchDepart) + ",A", Text = "Outbound Departure" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.OutboundStore) + ",A", Text = "Outbound Store" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.CarrierThenStore) + ",A", Text = "Carrier,Store" },
            new SelectListItem { Value = Enum.GetName(typeof(DispatchSortColumn), DispatchSortColumn.CreatedThenGenerated) + ",A", Text = "Created/Generated" }
        };

        public virtual string FilterSessionName
        {
            get { return this.GetType().Name + ".Filter"; }
        }

        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
        public ViewResult Index(int? id)
        {
            FuelSurchargeIndexViewModel viewModel = Session[FilterSessionName] as FuelSurchargeIndexViewModel;

            if (viewModel == null)
            {
                viewModel = new FuelSurchargeIndexViewModel();
                viewModel.Paging = new PagingViewModel
                {
                    Page = 1,
                    PageSize = 50,
                    LinksBeforeCurrentPage = 4,
                    LinksAfterCurrentPage = 4,
                };
            }
            else if (id.HasValue)
            {
                if (viewModel.Paging.Page != id.Value)
                {
                    ViewBag.OverrideSavedPosition = "0_0";
                }

                viewModel.Paging.Page = id.Value;
            }

            // Generate the new view model.
            FuelSurchargeIndexViewModel newViewModel = GenerateIndexViewModel(viewModel);

            // Save the view model
            Session[FilterSessionName] = newViewModel;

            return View(newViewModel);
        }

        [HttpPost]
        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
        public ViewResult Index(FuelSurchargeIndexViewModel viewModel)
        {
            // Copy any items needed that were not returned.
            FuelSurchargeIndexViewModel savedViewModel = Session[FilterSessionName] as FuelSurchargeIndexViewModel;
            if (savedViewModel != null)
            {
                viewModel.Paging = savedViewModel.Paging;
                viewModel.Paging.Page = 1;
            }

            // Generate the new view model.
            FuelSurchargeIndexViewModel newViewModel = GenerateIndexViewModel(viewModel);

            // Save the view model
            Session[FilterSessionName] = newViewModel;

            return View(newViewModel);
        }

        protected FuelSurchargeIndexViewModel GenerateIndexViewModel(FuelSurchargeIndexViewModel viewModel)
        {
            // Apply filters.
            var query = db.FuelSurcharge.AsQueryable();

            if (viewModel.FromDate.HasValue)
            {
                query = query.Where(x => x.ActiveDate >= viewModel.FromDate.Value);
            }

            if (viewModel.ThruDate.HasValue)
            {
                query = query.Where(x => x.ActiveEndDate <= viewModel.ThruDate.Value);
            }

            viewModel.Items = query
                .OrderByDescending(x => x.ActiveDate)
                .Skip((viewModel.Paging.Page - 1) * viewModel.Paging.PageSize)
                .Take(viewModel.Paging.PageSize)
                .ToList()
                .Select(x => new FuelSurchargeIndexViewModel.FuelSurcharge
                {
                    FuelSurchargeID = x.FuelSurchargeID,
                    ActiveDate = x.ActiveDate,
                    ActiveEndDate = x.ActiveEndDate,
                    Amount = x.Amount,
                    Comment = x.Comment
                });

            viewModel.Paging.TotalRecords = query.Count();

            return viewModel;
        }

        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
        public ActionResult Details(int id)
        {
            TempData[TEMPDATA_RETURN_URL] = HttpContext.Request.UrlReferrer == null ? this.Url.Action("Index") : HttpContext.Request.UrlReferrer.ToString();

            FuelSurcharge model = db.FuelSurcharge
                .Single(x => x.FuelSurchargeID == id);

            return View(model);
        }

        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
        public ActionResult Create()
        {
            TempData[TEMPDATA_RETURN_URL] = HttpContext.Request.UrlReferrer == null ? this.Url.Action("Index") : HttpContext.Request.UrlReferrer.ToString();

            FuelSurchargeViewModel savedvm = Session[typeof(FuelSurchargeViewModel).Name] as FuelSurchargeViewModel;

            FuelSurchargeViewModel vm = savedvm ?? new FuelSurchargeViewModel();

            if (db.FuelSurcharge.Any())
            {
                DateTime maxActiveDate = db.FuelSurcharge.Max(y => y.ActiveDate);
                FuelSurcharge previous = db.FuelSurcharge.SingleOrDefault(x => x.ActiveDate == maxActiveDate);
                if (previous.ActiveEndDate.HasValue)
                {
                    vm.ActiveDate = previous.ActiveEndDate.Value.AddDays(1);
                }
                else
                {
                    vm.ActiveDate = previous.ActiveDate.AddDays(1);
                }
            }
            else
            {
                vm.ActiveDate = DateTime.Today;
            }

            vm.ActiveEndDate = vm.ActiveDate.AddDays(6);

            vm = GenerateViewModel(vm);

            Session[typeof(FuelSurchargeViewModel).Name] = vm;

            return View(vm);
        }

        [HttpPost]
        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
        public virtual ActionResult Create(FuelSurchargeViewModel vm)
        {
            TempData.Keep(TEMPDATA_RETURN_URL);

            Session[typeof(FuelSurchargeViewModel).Name] = vm;

            if (vm.SubmitButton.Equals("Refresh", StringComparison.CurrentCultureIgnoreCase))
            {
                vm = GenerateViewModel(vm);
                return View(vm);
            }
            
            if (!vm.SubmitButton.Equals("Save", StringComparison.CurrentCultureIgnoreCase))
            {
                return View(vm);
            }
            
            string dateEdit = EditDates(vm.FuelSurchargeID, vm.ActiveDate, vm.ActiveEndDate);
            if (dateEdit != null)
            {
                this.ModelState.AddModelError(string.Empty, dateEdit);
            }

            if (vm.FuelSurchargeApply == null || !vm.FuelSurchargeApply.Any())
            {
                this.ModelState.AddModelError(string.Empty, "No dispatches have New FSC to apply.");
            }

            if (!vm.Amount.HasValue)
            {
                this.ModelState.AddModelError(string.Empty, "Fuel surcharge must be entered.");
            }

            if (!ModelState.IsValid)
            {
                return View(vm);
            }

            FuelSurcharge model = new FuelSurcharge
            {
                ActiveDate = vm.ActiveDate,
                ActiveEndDate = vm.ActiveEndDate,
                Amount = vm.Amount.Value,
                Comment = vm.Comment
            };

            db.FuelSurcharge.Add(model);

            ChangeLogger.LogChange(this, db.Entry(model));

            int updateCount = 0; 

            foreach (var dispatch in vm.FuelSurchargeApply.Where(x => x.Value.HasValue))
            {
                UpdateDispatchWithFuelSurcharge(dispatch.Key, dispatch.Value.Value);
                updateCount++;
            }

            db.SaveChanges();

            Session.Remove(typeof(FuelSurchargeViewModel).Name);

            TempData["LastGoodMessage"] = string.Format("Fuel Surcharge created. {0} dispatches updated", updateCount);
            if (string.IsNullOrWhiteSpace((string)TempData.Peek(TEMPDATA_RETURN_URL)))
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Redirect((string)TempData[TEMPDATA_RETURN_URL]);
            }
        }

        public virtual ActionResult Edit(int id)
        {
            TempData[TEMPDATA_RETURN_URL] = HttpContext.Request.UrlReferrer == null ? this.Url.Action("Index") : HttpContext.Request.UrlReferrer.ToString();

            if (AppAuthorization.ViewPermission(this).AtLeast(Avatar.PermissionLevel.Modify) == false)
            {
                return RedirectToAction("Details", new { id = id });
            }

            FuelSurchargeViewModel vm = Session[typeof(FuelSurchargeViewModel).Name] as FuelSurchargeViewModel;

            if (vm == null)
            {
                FuelSurcharge model = db.FuelSurcharge
                    .Single(x => x.FuelSurchargeID == id);

                vm = new FuelSurchargeViewModel
                {
                    FuelSurchargeID = model.FuelSurchargeID,
                    ActiveDate = model.ActiveDate,
                    ActiveEndDate = model.ActiveEndDate,
                    Amount = model.Amount,
                    Comment = model.Comment,
                    Timestamp = model.Timestamp
                };
            }

            vm = GenerateViewModel(vm);

            Session[typeof(FuelSurchargeViewModel).Name] = vm;

            return View(vm);
        }

        [HttpPost]
        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
        public virtual ActionResult Edit(FuelSurchargeViewModel vm)
        {
            ModelState.Clear();

            TempData.Keep(TEMPDATA_RETURN_URL);

            Session[typeof(FuelSurchargeViewModel).Name] = vm;

            if (vm.SubmitButton.Equals("Refresh", StringComparison.CurrentCultureIgnoreCase))
            {
                vm = GenerateViewModel(vm);
                return View(vm);
            }

            if (!vm.SubmitButton.Equals("Save", StringComparison.CurrentCultureIgnoreCase))
            {
                vm = GenerateViewModel(vm);
                return View(vm);
            }

            if (!ModelState.IsValid)
            {
                vm = GenerateViewModel(vm);
                return View(vm);
            }

            FuelSurcharge model = db.FuelSurcharge.Find(vm.FuelSurchargeID);

            ulong browserTimestamp = BitConverter.ToUInt64(vm.Timestamp, 0);
            ulong databaseTimestamp = BitConverter.ToUInt64(model.Timestamp, 0);

            if (browserTimestamp != databaseTimestamp)
            {
                ModelState.Clear();
                ModelState.AddModelError(string.Empty, OptimisticConcurrencyError);
                vm = GenerateViewModel(vm);
                return View(model);
            }

            model.ActiveDate = vm.ActiveDate;
            model.ActiveEndDate = vm.ActiveEndDate;
            model.Amount = vm.Amount.Value;
            model.Comment = vm.Comment;

            ChangeLogger.LogChange(this, db.Entry(model));

            int updateCount = 0;

            foreach (var dispatch in vm.FuelSurchargeApply.Where(x => x.Value.HasValue))
            {
                UpdateDispatchWithFuelSurcharge(dispatch.Key, dispatch.Value.Value);
                updateCount++;
            }

            db.SaveChanges();

            Session.Remove(typeof(FuelSurchargeViewModel).Name);

            TempData["LastGoodMessage"] = string.Format("Fuel Surcharge updated. {0} dispatches updated", updateCount);

            if (string.IsNullOrWhiteSpace((string)TempData.Peek(TEMPDATA_RETURN_URL)))
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Redirect((string)TempData[TEMPDATA_RETURN_URL]);
            }
        }

        private string EditDates(int id, DateTime activeDate, DateTime? activeEndDate)
        {
            if (activeEndDate.HasValue && activeEndDate < activeDate)
            {
                return "Active Date End must be on or after Active Date.";
            }

            if (id == 0)
            {
                if (db.FuelSurcharge.Any(x => activeDate >= x.ActiveDate && activeDate <= x.ActiveEndDate))
                {
                    return "Active Date overlaps existing Fuel Surcharge record.";
                }

                if (activeEndDate.HasValue)
                {
                    if (db.FuelSurcharge.Any(x => activeEndDate >= x.ActiveDate && activeEndDate <= x.ActiveEndDate))
                    {
                        return "Active Date End overlaps existing Fuel Surcharge record.";
                    }
                }
            }
            else
            {
                if (db.FuelSurcharge.Any(x => activeDate >= x.ActiveDate && activeDate <= x.ActiveEndDate && x.FuelSurchargeID != id))
                {
                    return "Active Date overlaps existing Fuel Surcharge record.";
                }

                if (activeEndDate.HasValue)
                {
                    if (db.FuelSurcharge.Any(x => activeEndDate >= x.ActiveDate && activeEndDate <= x.ActiveEndDate && x.FuelSurchargeID != id))
                    {
                        return "Active Date End overlaps existing Fuel Surcharge record.";
                    }
                }
            }
            
            return null;
        }

        private FuelSurchargeViewModel GenerateViewModel(FuelSurchargeViewModel viewModel)
        {
            IEnumerable<DispatchViewModel> dispatches = Enumerable.Empty<DispatchViewModel>();

            DateTime fromDate = viewModel.ActiveDate;
            DateTime thruDate = viewModel.ActiveEndDate ?? viewModel.ActiveDate.AddDays(6);

            List<DateTime> selectedDates = new List<DateTime>();

            for (DateTime dt = fromDate; dt.Date <= thruDate.Date; dt = dt.AddDays(1))
            {
                selectedDates.Add(dt);
            }

            if (string.IsNullOrEmpty(viewModel.SortingID))
            {
                viewModel.SortingID = _sortTypes.First().Value;
            }

            viewModel.SortingList = new SelectList(_sortTypes, "Value", "Text", viewModel.SortingID);

            var dispatchAndLoadList = db.Database.SqlQuery<DispatchAndLoad>(
                _SqlQueryByArrival,
                new SqlParameter("@SelectionDateFrom", fromDate),
                new SqlParameter("@SelectionDateThru", thruDate));
            
            dispatches = DailyDispatchController.BuildDispatchViewModelList(dispatchAndLoadList);
            
            dispatches = dispatches.Where(x => x.Loads.Any(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType)));
            
            dispatches = dispatches
                .Where(x =>
                    x.Loads.Where(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                        .Any(y => selectedDates.Contains(y.EtaDate.HasValue ? y.EtaDate.Value.Date : DateTime.MinValue.Date))
                    ||
                    x.LoadHistory.Where(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
                        .Any(y => y.DailyDispatchID == x.DailyDispatchID && selectedDates.Contains(y.ArrivalTime.HasValue ? y.ArrivalTime.Value.Date : DateTime.MinValue.Date)));
            
            dispatches = dispatches.Where(x => x.CarrierID.HasValue);

            /*
             * Sorting
             */

            if (!string.IsNullOrEmpty(viewModel.SortingID))
            {
                string[] sorting = viewModel.SortingID.Split(',');
                if (sorting.Length == 2)
                {
                    DispatchSortColumn sortColumn;
                    if (!Enum.TryParse(sorting[0], out sortColumn))
                    {
                        sortColumn = DispatchSortColumn.DispatchDepart;
                    }

                    int sortDirection = sorting[1].ToUpper() == "A" ? 1 : -1;
                    dispatches = DailyDispatchController.SortDispatchViewModelList(dispatches, sortColumn, sortDirection);
                }
            }

            viewModel.Dispatches = dispatches.ToList();

            return viewModel;
        }

        private void UpdateDispatchWithFuelSurcharge(int dailyDispatchID, decimal fuelSurcharge)
        {
            DailyDispatch dailyDispatch = db.DailyDispatch
                    .Include(x => x.Loads)
                    .Single(x => x.DailyDispatchID == dailyDispatchID);

            dailyDispatch.FuelSurcharge = fuelSurcharge;

            // Calculate Carrier Charge
            CarrierChargeCalculation.Parts carrierCharge = CarrierChargeCalculation.Calculate(new CarrierChargeCalculation.Parts
            {
                Miles = dailyDispatch.CarrierMiles,
                Rate = dailyDispatch.CarrierRate,
                FlatRate = dailyDispatch.CarrierFlatRate,
                MileageCalcType = (CarrierChargeCalculation.MileageCalcEnum)dailyDispatch.MileageCalcType,
                StopCharge1 = dailyDispatch.CarrierStopCharge1,
                StopCharge2 = dailyDispatch.CarrierStopCharge2,
                FuelSurcharge = dailyDispatch.FuelSurcharge,
                ExtraCharge = dailyDispatch.CarrierExtraCharge,
                LoadCount = dailyDispatch.Loads.Count
            });

            dailyDispatch.CarrierTotalCharge = carrierCharge.TotalCharge;
        }

        [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Full)]
        public ActionResult Delete(int id)
        {
            FuelSurcharge model = db.FuelSurcharge.Find(id);

            db.FuelSurcharge.Remove(model);
            ChangeLogger.LogChange(this, db.Entry(model));
            db.SaveChanges();

            TempData["LastGoodMessage"] = "Fuel Surcharge deleted.";
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}
