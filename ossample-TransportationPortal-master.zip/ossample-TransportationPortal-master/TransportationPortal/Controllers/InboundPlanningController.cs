﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Objects.SqlClient;
using System.Linq;
using System.Web.Mvc;
using Avatar;
using TransportationPortal.Models;
using TransportationPortal.Repositories;
using TransportationPortal.ViewModels;


namespace TransportationPortal.Controllers
{
	[HandleApplicationError]
	public class InboundPlanningController : Controller
	{
		private DispatchContext db = new DispatchContext();

		/// <summary>
		/// Specifies the LoadTypes to the processed.
		/// </summary>
		public string[] LoadTypes
		{
			get
			{
				return new[] { DatabaseLists.INBOUND_VENDOR_BACKHAUL, DatabaseLists.INBOUND_BROKER_LOAD };
			}
		}

		/// <summary>
		/// Provides a SelectListItem array for generating checkboxes.
		/// </summary>
		public SelectListItem[] LoadTypesSelectList
		{
			get
			{
				return new SelectListItem[] 
				{ 
					new SelectListItem { Value = DatabaseLists.INBOUND_BROKER_LOAD, Text = "Broker Load" },
					new SelectListItem { Value = DatabaseLists.INBOUND_VENDOR_BACKHAUL, Text = "Vendor Backhaul"},
				};
			}
		}

		/// <summary>
		/// Provides the base query for all database operations. This provides an initial filtering for LoadTypes.
		/// </summary>
		public IQueryable<Load> BaseQuery
		{
			get
			{
				return db.Load.InboundOnly();
			}
		}


		private string LoadFilterSessionName
		{
			get { return this.GetType().Name + ".LoadFilter"; }
		}

		private string DispatchFilterSessionName
		{
			get { return this.GetType().Name + ".DispatchFilter"; }
		}

		#region Load List

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index(int? id)
		{
			PlanningViewModel viewModel = Session[LoadFilterSessionName] as PlanningViewModel;
			if (viewModel == null)
			{
				viewModel = new PlanningViewModel();
				viewModel.TypesSelectList = new List<SelectListItem>(LoadTypesSelectList);
				viewModel.Paging = new PagingViewModel
				{
					Page = 1,
					PageSize = 50,
					LinksBeforeCurrentPage = 4,
					LinksAfterCurrentPage = 4,
				};
			}
			else if (id.HasValue)
			{
				viewModel.Paging.Page = id.Value;
				ViewBag.OverrideSavedPosition = "0_0";
			}

			// Generate the new view model.
			viewModel = GenerateViewModel_Loads(viewModel);

			// Save the view model
			Session[LoadFilterSessionName] = viewModel;

			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ActionResult Index(PlanningViewModel viewModel)
		{
			PlanningViewModel previousViewModel = Session[LoadFilterSessionName] as PlanningViewModel;
			if (previousViewModel != null)
			{
				viewModel.Paging = previousViewModel.Paging;
				viewModel.Paging.Page = 1;
			}

			if (viewModel.TypesSelectList != null)
			{
				for (int i = 0; i < previousViewModel.TypesSelectList.Count(); i++)
				{
					previousViewModel.TypesSelectList[i].Selected = viewModel.TypesSelectList[i].Selected;
				}
			}
			viewModel.TypesSelectList = previousViewModel.TypesSelectList;


			int loadSelectCount = viewModel.LoadSelect == null ? 0 : viewModel.LoadSelect.Count();

			if (!string.IsNullOrEmpty(viewModel.SubmitButtonAssignLoads))
			{
				if (loadSelectCount > 0)
				{
					bool allPickupDatesPresent = db.Load.Where(x => viewModel.LoadSelect.Contains(x.LoadID)).All(x => x.PickupDate.HasValue);
					if (allPickupDatesPresent)
					{
						Session[LoadFilterSessionName] = viewModel;
						return RedirectToAction("DispatchIndex");
					}
					else
					{
						ModelState.AddModelError(string.Empty, "Selected loads must have Pickup Dates.");
					}
				}
				else
				{
					ModelState.AddModelError(string.Empty, "No loads are selected.");
				}
			}
			else if (!string.IsNullOrEmpty(viewModel.SubmitButtonCreateCarrierDispatch))
			{
				if (loadSelectCount > 0)
				{
					Session[LoadFilterSessionName] = viewModel;
					return RedirectToAction("Create", "DailyDispatch", new { id = 0, catchall = string.Join(",", viewModel.LoadSelect) });
				}
				else
				{
					ModelState.AddModelError(string.Empty, "No loads are selected.");
				}
			}

			viewModel = GenerateViewModel_Loads(viewModel);

			Session[LoadFilterSessionName] = viewModel;

			return View(viewModel);
		}

		private PlanningViewModel GenerateViewModel_Loads(PlanningViewModel viewModel)
		{
			// Apply filters.

			var list = BaseQuery.UnassignedLoads()
				.Include(x => x.PickupCompany)
				.OrderBy(x => x.PickupDate)
				.AsNoTracking();

			if (viewModel.FromDate.HasValue)
			{
				list = list.Where(x => x.ReadyDate >= viewModel.FromDate);
			}

			if (viewModel.ThruDate.HasValue)
			{
				list = list.Where(x => x.ReadyDate <= viewModel.ThruDate);
			}

			List<string> loads = viewModel.TypesSelectList.Where(x => x.Selected == true).Select(x => x.Value).ToList();
			if (loads.Count > 0)
			{
				list = list.Where(x => loads.Contains(x.LoadType));
			}
			else
			{
				list = list.Where(x => LoadTypes.Contains(x.LoadType));
			}

			// Special SearchField values

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string searchField = viewModel.SearchField.Trim();
				Int64 intValue = 0;
				decimal decValue = 0m;
				bool isNumber = Decimal.TryParse(searchField, out decValue);
				if (isNumber)
				{
					intValue = Decimal.ToInt64(decValue);
				}

				if (isNumber && intValue > 0)
				{
					list = list.Where(x =>
						(x.LoadID == intValue) ||
						(x.PickupCompany != null && x.PickupCompany.Name.Contains(searchField)) ||
						(x.PickupCompany != null && x.PickupCompany.City.Contains(searchField)) ||
						(x.PickupCompany != null && x.PickupCompany.StateCode.Contains(searchField))
						);
				}
				else
				{
					list = list.Where(x =>
						(x.PickupCompany != null && x.PickupCompany.Name.Contains(searchField)) ||
						(x.PickupCompany != null && x.PickupCompany.City.Contains(searchField)) ||
						(x.PickupCompany != null && x.PickupCompany.StateCode.Contains(searchField))
						);
				}
			}

			list = list
				.Include(x => x.LoadCompany)
				.Include(x => x.DailyDispatch)
				.Include(x => x.PickupCompany)
				.Include(x => x.Store);

			LoadSortColumn sortColumn;
			if (!Enum.TryParse(viewModel.SortColumn, out sortColumn))
			{
				sortColumn = LoadSortColumn.ReadyDate;
			}
			list = list.Sort(sortColumn, viewModel.SortDirection);

			// Get the total number of records for the paging functions.
			viewModel.Paging.TotalRecords = list.Count();
			// Perform skip/take
			list = list.Skip((viewModel.Paging.Page - 1) * viewModel.Paging.PageSize)
				.Take(viewModel.Paging.PageSize);

			viewModel.Loads = list
				.ToList()
				.Select(x => new LoadDragDropViewModel(x));

			return viewModel;
		}

		#endregion

		#region Dispatch List

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult DispatchIndex(int? id)
		{
			DailyDispatchIndexViewModel viewModel = Session[DispatchFilterSessionName] as DailyDispatchIndexViewModel;
			if (viewModel == null)
			{
				viewModel = new DailyDispatchIndexViewModel();
				viewModel.SelectDate = DateTime.Today;
				viewModel.SelectedDates = new List<DateTime>();
				viewModel.SelectDate = DateTime.Today;
				viewModel.FromDate = DateTime.Today;
				viewModel.ThruDate = DateTime.Today;
				viewModel.Paging = new PagingViewModel
				{
					Page = 1,
					PageSize = 50,
					LinksBeforeCurrentPage = 4,
					LinksAfterCurrentPage = 4,
					Action = "DispatchIndex/{0}"
				};
			}
			else if (id.HasValue)
			{
				if (viewModel.Paging.Page != id.Value)
				{
					ViewBag.OverrideSavedPosition = "0_0";
				}
				viewModel.Paging.Page = id.Value;
			}
			else
			{
				// If all selected loads are assigned to a dispatch, return to the Load list.
				PlanningViewModel selectedLoadsViewModel = Session[LoadFilterSessionName] as PlanningViewModel;
				if (selectedLoadsViewModel != null && selectedLoadsViewModel.LoadSelect != null)
				{
					if (db.Load.Where(x => selectedLoadsViewModel.LoadSelect.Contains(x.LoadID)).All(x => x.DailyDispatchID.HasValue))
					{
						return RedirectToAction("Index");
					}
				}
			}

			// Generate the new view model.
			viewModel = GenerateViewModel_Dispatches(viewModel);

			// Save the view model
			Session[DispatchFilterSessionName] = viewModel;

			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult DispatchIndex(DailyDispatchIndexViewModel viewModel)
		{
			DailyDispatchIndexViewModel previousViewModel = Session[DispatchFilterSessionName] as DailyDispatchIndexViewModel;
			if (previousViewModel != null)
			{
				viewModel.Paging = previousViewModel.Paging;
				viewModel.Paging.Page = 1;
			}

			viewModel.DispatchWeeks = previousViewModel.DispatchWeeks;
			viewModel.SelectedDates = previousViewModel.SelectedDates;

			viewModel = GenerateViewModel_Dispatches(viewModel);
			Session[DispatchFilterSessionName] = viewModel;

			return View(viewModel);
		}


		private DailyDispatchIndexViewModel GenerateViewModel_Dispatches(DailyDispatchIndexViewModel viewModel)
		{
			// ViewBag stuff.

			var CarrierList = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .OrderBy(x => x.Name)
				.ToList()
				.Select(x => new
				{
					Value = x.CarrierID,
					Text = x.Name
				});

			viewModel.CarrierList = new SelectList(CarrierList, "Value", "Text", viewModel.CarrierID);

			// Apply filtering.

			PlanningViewModel selectedLoadsViewModel = Session[LoadFilterSessionName] as PlanningViewModel;

			var selectedLoads = BaseQuery
				.Where(x => selectedLoadsViewModel.LoadSelect.Contains(x.LoadID))
				.Include(x => x.PickupCompany)
				.Include(x => x.Store)
				.OrderBy(x => x.LoadID)
				.AsNoTracking();

			ViewBag.SelectedLoads = selectedLoads
				.ToList()
				.Select(x => new LoadDragDropViewModel(x));

			IQueryable<DailyDispatch> list;

			if (viewModel.SelectDate.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "Select a date.");
			}

			if (!ModelState.IsValid)
			{
				return viewModel;
			}

			list = db.OpenDispatches()
				.Where(x =>
					viewModel.SelectDate.Value == x.InboundDate
					||
					x.Loads.Where(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType))
						.Any(y => y.EtaDateOnly == viewModel.SelectDate.Value)
					||
					x.Loads.Where(y => y.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || y.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
						.Any(y => y.EtaDateOnly ==  viewModel.SelectDate.Value)
				);

			list = list.AsNoTracking()
				.Include(x => x.Driver1)
				.Include(x => x.Driver2)
				.Include(x => x.Carrier)
				.Include(x => x.Loads)
				.Include(x => x.Loads.Select(a => a.Store))
				.Include(x => x.Loads.Select(a => a.PickupCompany));

			if (viewModel.CarrierID.HasValue)
			{
				list = list.Where(x => x.Carrier != null && x.Carrier.CarrierID == viewModel.CarrierID);
			}
			else
			{
				if (viewModel.CompanySelect == true || viewModel.NoCarrierOrCompanySelect == true)
				{
					list = list.Where(x =>
						(viewModel.CompanySelect == true && (x.Driver1 != null || x.Driver2 != null))
						|| (viewModel.NoCarrierOrCompanySelect == true && (x.Carrier == null && x.Driver1 == null && x.Driver2 == null))
						);
				}
			}

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim();
				int intValue = 0;
				bool isNumber = Int32.TryParse(textValue, out intValue);

				if (isNumber && intValue > 0)
				{
					list = list.Where(x =>
						x.DailyDispatchID == intValue
						|| x.Carrier.Name.Contains(textValue)
						|| (x.Driver1.FirstName.Contains(textValue) || x.Driver1.LastName.Contains(textValue))
						|| (x.Driver2.FirstName.Contains(textValue) || x.Driver2.LastName.Contains(textValue))
						|| x.Comment.Contains(textValue)
						|| x.Trailer.Contains(textValue)
						|| x.TrailerIn.Contains(textValue)
						|| x.TractorNumber == textValue
						|| x.Loads.Any(y => y.Store.StoreNumber == intValue)
						);
				}
				else
				{
					list = list.Where(x =>
						(x.Carrier != null && x.Carrier.Name.Contains(textValue))
						|| (x.Driver1.FirstName.Contains(textValue) || x.Driver1.LastName.Contains(textValue))
						|| (x.Driver2.FirstName.Contains(textValue) || x.Driver2.LastName.Contains(textValue))
						|| x.Comment.Contains(textValue)
						|| x.Trailer.Contains(textValue)
						|| x.TrailerIn.Contains(textValue)
						);
				}
			}

			DispatchSortColumn sortColumn;
			if (!Enum.TryParse(viewModel.SortColumn, out sortColumn))
			{
				sortColumn = DispatchSortColumn.OutboundStore;
			}
			list = list.Sort(sortColumn, viewModel.SortDirection);
			
			viewModel.Dispatches = list
				.ToList()
				.Select(x => new DispatchViewModel(x))
				.ToList();

			return viewModel;
		}

		#endregion

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}