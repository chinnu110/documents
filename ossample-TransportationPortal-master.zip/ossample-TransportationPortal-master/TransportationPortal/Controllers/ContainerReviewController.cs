﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.ViewModels;
using TransportationPortal.Repositories;
using Avatar;
using ContainerSystem.Service;
using ContainerSystem.Models;
using HobbyLobby.HLUtil.Logging;


namespace TransportationPortal.Controllers
{ 
	[HandleApplicationError]
	public class ContainerReviewController : Controller
	{
		private DispatchContext db = new DispatchContext();

		ContainerService containerService = null;

		private string FilterSessionName
		{
			get { return this.GetType().Name + ".Filter"; }
		}

		private const string ColumnClearCode = " ";

		public enum ContainerGroup
		{
			Released,
			DallasOOCL,
			DallasOther,
			ArrivedOKC,
			Empty,
			EmptyHM,
			LoadingStore
		}

		#region Index views

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index()
		{
			ContainerReviewViewModel newViewModel;

			ContainerReviewViewModel viewModel = Session[FilterSessionName] as ContainerReviewViewModel;
			if (viewModel == null)
			{
				viewModel = new ContainerReviewViewModel();
				newViewModel = GenerateViewModel(viewModel);
			}
			else
			{
				newViewModel = viewModel;
			}

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ActionResult Index(ContainerReviewViewModel viewModel)
		{
			ContainerReviewViewModel previousViewModel = Session[FilterSessionName] as ContainerReviewViewModel;
			if (previousViewModel != null)
			{
				// Copy any items needed that were not returned.
			}

			if (viewModel.DailyDispatchID.HasValue)
			{
				// If a DailyDispatchID has been clicked, go to that Dispatch.
				int dispatchID = viewModel.DailyDispatchID.Value;
				viewModel.DailyDispatchID = null;
				Session[FilterSessionName] = viewModel;
				return RedirectToAction("Edit", "DailyDispatch", new { id = dispatchID });
			}

			// Generate the new view model.
			ContainerReviewViewModel newViewModel = GenerateViewModel(viewModel);

			// Save the view model
			Session[FilterSessionName] = newViewModel;

			return View(newViewModel);
		}

		private ContainerReviewViewModel GenerateViewModel(ContainerReviewViewModel viewModel)
		{
			// Place holder for loading and using view-wide settings

			return viewModel;
		}

		#endregion

		#region Ajax methods for displaying container groups

		[HttpGet]
		public PartialViewResult GetContainerList(ContainerGroup containerGroup)
		{
			string viewName = string.Empty;

			ContainerGroupViewModel viewModel = new ContainerGroupViewModel();

			try
			{
				containerService = containerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

				IEnumerable<ContainerInfo> containerInfoList;

				switch (containerGroup)
				{
					case ContainerGroup.Released:
						viewName = "_ContainerList_Releases";
						containerInfoList = containerService.GetContainerList(new string[] { StatusCodeValues.EW_NOTIFICATION })
							.OrderBy(x => x.LastFreeDate).ThenBy(x => x.ContainerNumber);
						break;
					case ContainerGroup.DallasOther:
						viewName = "_ContainerList_Dallas";
						containerInfoList = containerService.GetContainerList(new string[] { StatusCodeValues.ARRIVED_DALLAS_YARD, StatusCodeValues.COMMITTED_TO_ARRIVE_OKC, StatusCodeValues.SOUTHWEST_FREIGHT_YARD })
							.Where(x => x.Carrier.Contains("OOCL") == false)
							.OrderBy(x => x.PerDiemDate).ThenBy(x => x.ContainerNumber);
						break;
					case ContainerGroup.DallasOOCL:
						viewName = "_ContainerList_Dallas";
						containerInfoList = containerService.GetContainerList(new string[] { StatusCodeValues.ARRIVED_DALLAS_YARD, StatusCodeValues.COMMITTED_TO_ARRIVE_OKC, StatusCodeValues.SOUTHWEST_FREIGHT_YARD })
							.Where(x => x.Carrier.Contains("OOCL") == true)
							.OrderBy(x => x.PerDiemDate).ThenBy(x => x.ContainerNumber);
						break;
					case ContainerGroup.ArrivedOKC:
						viewName = "_ContainerList_Arrived";
						containerInfoList = containerService.GetContainerList(new string[] { StatusCodeValues.ARRIVED_OKC_YARD })
							.OrderBy(x => x.ContainerNumber);
						break;
					case ContainerGroup.Empty:
						viewName = "_ContainerList_Empty";
						containerInfoList = containerService.GetContainerList(new string[] { StatusCodeValues.EMPTY_CONTAINER, StatusCodeValues.COMMITTED_RETURN })
							.OrderBy(x => x.PerDiemDate).ThenBy(x => x.ContainerNumber);
						break;
					case ContainerGroup.EmptyHM:
						viewName = "_ContainerList_EmptyHM";
						containerInfoList = containerService.GetContainerList(new string[] { StatusCodeValues.EMPTY_CONTAINER_HEMISPHERES, StatusCodeValues.COMMITTED_RETURN })
							.OrderBy(x => x.PerDiemDate).ThenBy(x => x.ContainerNumber);
						break;
					case ContainerGroup.LoadingStore:
						viewName = "_ContainerList_Empty";
						containerInfoList = containerService.GetContainerList(new string[] { StatusCodeValues.LOADING_HOBBYLOBBY_STORE })
							.OrderBy(x => x.PerDiemDate).ThenBy(x => x.ContainerNumber);
						break;
					default:
						viewName = "_ContainerList_Releases";
						containerInfoList = Enumerable.Empty<ContainerInfo>();
						break;
				}

				List<ContainerViewModel> containerList = new List<ContainerViewModel>();

				foreach (ContainerInfo containerInfo in containerInfoList)
				{
					var containerActions = 
						db.Container
						.AsNoTracking()
						.Include(x => x.DailyDispatch)
						.Include(x => x.DailyDispatch.Carrier)
						.Include(x => x.DailyDispatch.Driver1)
						.Include(x => x.DailyDispatch.Driver2)
						.Where(x => x.ContainerNumber == containerInfo.ContainerNumber);

					ContainerViewModel containerViewModel = new ContainerViewModel(containerInfo, containerActions);

					containerList.Add(containerViewModel);
				}

				viewModel.Containers = containerList;
				viewModel.Count = containerList.Count;
			}
			catch (Exception ex)
			{
				HLLogging.Error("Error in GetContainerList Ajax method", ex);
			}

			return PartialView(viewName, viewModel);
		}

		#endregion

		#region Ajax methods for container updates

		[HttpGet]
		public PartialViewResult UpdateContainers(int count, string containerNumber)
		{
			ContainerUpdateViewModel viewModel = new ContainerUpdateViewModel
			{
				ContainerNumber = containerNumber,
				Count = count
			};

			if (count == 1)
			{
				containerService = containerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

				ContainerInfo containerInfo = containerService.GetContainer(containerNumber);

				viewModel.PullDriverName = containerInfo.PullDriverName;
				viewModel.CommitDriverName = containerInfo.CommitDriverName;
				viewModel.ReturnDriverName = containerInfo.ReturnDriverName;
				viewModel.LotLocation = containerInfo.LotLocation;
				viewModel.LotNotes = containerInfo.LotNotes;
				viewModel.Note = containerInfo.Note;
				viewModel.PickupLocation = containerInfo.PickupLocation;
				viewModel.PullDate = containerInfo.PullDate;
				viewModel.ReturnNotes = containerInfo.ReturnNotes;
				viewModel.ShagNotes = containerInfo.ShagNotes;
			}
						
			return PartialView("UpdateContainerData", viewModel);
		}

		[HttpPost]
		public PartialViewResult UpdateContainers(ContainerUpdateViewModel viewModel)
		{
			if (viewModel == null)
			{
				viewModel = new ContainerUpdateViewModel();
			}

			Dictionary<UpdateColumn, object> updateColumns = new Dictionary<UpdateColumn, object>();

			if (viewModel.Count == 1)	// Single container update
			{
				// Driver names
				updateColumns.Add(UpdateColumn.PullDriverName, string.IsNullOrWhiteSpace(viewModel.PullDriverName) ? " " : viewModel.PullDriverName);
				updateColumns.Add(UpdateColumn.CommitDriverName, string.IsNullOrWhiteSpace(viewModel.CommitDriverName) ? " " : viewModel.CommitDriverName);
				updateColumns.Add(UpdateColumn.ReturnDriverName, string.IsNullOrWhiteSpace(viewModel.ReturnDriverName) ? " " : viewModel.ReturnDriverName);
				// Notes
				updateColumns.Add(UpdateColumn.PickupLocation, string.IsNullOrWhiteSpace(viewModel.PickupLocation) ? " " : viewModel.PickupLocation);
				updateColumns.Add(UpdateColumn.ShagNotes, string.IsNullOrWhiteSpace(viewModel.ShagNotes) ? " " : viewModel.ShagNotes);
				updateColumns.Add(UpdateColumn.ReturnNotes, string.IsNullOrWhiteSpace(viewModel.ReturnNotes) ? " " : viewModel.ReturnNotes);
				updateColumns.Add(UpdateColumn.LotLocation, string.IsNullOrWhiteSpace(viewModel.LotLocation) ? " " : viewModel.LotLocation);
				updateColumns.Add(UpdateColumn.LotNotes, string.IsNullOrWhiteSpace(viewModel.LotNotes) ? " " : viewModel.LotNotes);
				updateColumns.Add(UpdateColumn.Notes, string.IsNullOrWhiteSpace(viewModel.Note) ? " " : viewModel.Note);
			}
			else
			{
				// Multiple container update
				if (!string.IsNullOrWhiteSpace(viewModel.PickupLocation) && viewModel.PickupLocationClear)
				{
					ModelState.AddModelError("", "Pickup Location change is not valid.");
				}
				else if (!string.IsNullOrWhiteSpace(viewModel.PickupLocation))
				{
					updateColumns.Add(UpdateColumn.PickupLocation, viewModel.PickupLocation);
				}
				else if (viewModel.PickupLocationClear)
				{
					updateColumns.Add(UpdateColumn.PickupLocation, ColumnClearCode);
				}

				if (!string.IsNullOrWhiteSpace(viewModel.ShagNotes) && viewModel.ShagNotesClear)
				{
					ModelState.AddModelError("", "Shag Note change is not valid.");
				}
				else if (!string.IsNullOrWhiteSpace(viewModel.ShagNotes))
				{
					updateColumns.Add(UpdateColumn.ShagNotes, viewModel.ShagNotes);
				}
				else if (viewModel.ShagNotesClear)
				{
					updateColumns.Add(UpdateColumn.ShagNotes, ColumnClearCode);
				}

				if (!string.IsNullOrWhiteSpace(viewModel.ReturnNotes) && viewModel.ReturnNotesClear)
				{
					ModelState.AddModelError("", "Return Note change is not valid.");
				}
				else if (!string.IsNullOrWhiteSpace(viewModel.ReturnNotes))
				{
					updateColumns.Add(UpdateColumn.ReturnNotes, viewModel.ReturnNotes);
				}
				else if (viewModel.ReturnNotesClear)
				{
					updateColumns.Add(UpdateColumn.ReturnNotes, ColumnClearCode);
				}

				if (!string.IsNullOrWhiteSpace(viewModel.LotLocation) && viewModel.LotLocationClear)
				{
					ModelState.AddModelError("", "Lot Location change is not valid.");
				}
				else if (!string.IsNullOrWhiteSpace(viewModel.LotLocation))
				{
					updateColumns.Add(UpdateColumn.LotLocation, viewModel.LotLocation);
				}
				else if (viewModel.LotLocationClear)
				{
					updateColumns.Add(UpdateColumn.LotLocation, ColumnClearCode);
				}

				if (!string.IsNullOrWhiteSpace(viewModel.LotNotes) && viewModel.LotNotesClear)
				{
					ModelState.AddModelError("", "Lot Note change is not valid.");
				}
				else if (!string.IsNullOrWhiteSpace(viewModel.LotNotes))
				{
					updateColumns.Add(UpdateColumn.LotNotes, viewModel.LotNotes);
				}
				else if (viewModel.LotNotesClear)
				{
					updateColumns.Add(UpdateColumn.LotNotes, ColumnClearCode);
				}

				if (!string.IsNullOrWhiteSpace(viewModel.Note) && viewModel.NoteClear)
				{
					ModelState.AddModelError("", "Container Note change is not valid.");
				}
				else if (!string.IsNullOrWhiteSpace(viewModel.Note))
				{
					updateColumns.Add(UpdateColumn.Notes, viewModel.Note);
				}
				else if (viewModel.NoteClear)
				{
					updateColumns.Add(UpdateColumn.Notes, ColumnClearCode);
				}
			}

			if (updateColumns.Count == 0)
			{
				ModelState.AddModelError("", "Nothing to be changed.");
			}

			if (!ModelState.IsValid)
			{
				return PartialView("UpdateContainerData", viewModel);
			}

			try
			{
				containerService = containerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

				List<string> containerList = new List<string>();

				if (viewModel.Count == 1)
				{
					containerList.Add(viewModel.ContainerNumber);
				}
				else
				{
					foreach (var update in viewModel.ContainerList)
					{
						containerList.Add(update.ContainerNumber);
					}
				}

				containerService.UpdateContainers(containerList, updateColumns);

				return PartialView("UpdateContainerComplete", "Containers updated!");
			}
			catch (Exception ex)
			{
				HLLogging.Error(ex.Message, ex);
				ModelState.AddModelError("", ex.Message);
				return PartialView("UpdateContainerData", viewModel);
			}
		}

		#endregion

		#region Ajax methods for setting pull date

		[HttpGet]
		public PartialViewResult SetPullDate(int count, string containerNumber)
		{
			ContainerUpdateViewModel viewModel = new ContainerUpdateViewModel
			{
				ContainerNumber = containerNumber,
				Count = count
			};

			return PartialView("SetPullDate", viewModel);
		}

		[HttpPost]
		public PartialViewResult SetPullDate(ContainerUpdateViewModel viewModel)
		{
			if (viewModel == null)
			{
				viewModel = new ContainerUpdateViewModel();
			}

			if (viewModel.PullDate.HasValue == false)
			{
				ModelState.AddModelError("", "Pull Date missing or invalid.");
			}
			
			if (!ModelState.IsValid)
			{
				return PartialView("SetPullDate", viewModel);
			}

			try
			{
				containerService = containerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

				List<string> containerNumbers = new List<string>();

				if (!string.IsNullOrEmpty(viewModel.ContainerNumber))
				{
					containerNumbers.Add(viewModel.ContainerNumber);
				}
				else
				{
					foreach (var update in viewModel.ContainerList)
					{
						containerNumbers.Add(update.ContainerNumber);
					}
				}

				var resultSet = containerService.ContainerAction(ActionCodeValues.SET_PULL_DATE, containerNumbers);

				if (resultSet.Count() > 0) // Only errors are returned.
				{
					throw new Exception("Errors on Containers: " + string.Join(",", resultSet.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
				}

				return PartialView("UpdateContainerComplete", "Containers updated!");
			}
			catch (Exception ex)
			{
				HLLogging.Error(ex.Message, ex);
				ModelState.AddModelError("", ex.Message);
				return PartialView("SetPullDate", viewModel);
			}
		}

		#endregion

		#region Ajax methods for displaying Drivers

		[HttpGet]
		public PartialViewResult DriverAssignment(DateTime? SelectedDate)
		{
			ContainerDriverViewModel viewModel = new ContainerDriverViewModel
			{
				SelectedDate = DateTime.Today
			};

			viewModel = GetConsolidatedDriverDispatches(viewModel);

			return PartialView("DriverAssignment", viewModel);
		}

		[HttpPost]
		public PartialViewResult DriverAssignment(ContainerDriverViewModel viewModel)
		{
			try 
			{
				viewModel = GetConsolidatedDriverDispatches(viewModel);
			}
			catch (Exception ex)
			{
				HLLogging.Error(ex.Message, ex);
				ModelState.AddModelError("", ex.Message);
			}
			
			return PartialView("DriverAssignment", viewModel);
		}
		
		private ContainerDriverViewModel GetConsolidatedDriverDispatches(ContainerDriverViewModel viewModel)
		{
			var driverList = db.Driver.ActiveFilter().Where(x => x.DispatchGroup == DatabaseLists.DISPATCH_GROUP_DALLAS);

			if (viewModel.DriverShiftDay != viewModel.DriverShiftNight)
			{
				if (viewModel.DriverShiftDay)
				{
					driverList = driverList.Where(x => x.DriverShift == DriverShift.Day);
				}
				if (viewModel.DriverShiftNight)
				{
					driverList = driverList.Where(x => x.DriverShift == DriverShift.Night);
				}
			}

			if (viewModel.DriverShiftStartDallas != viewModel.DriverShiftStartOKC)
			{
				if (viewModel.DriverShiftStartDallas)
				{
					driverList = driverList.Where(x => x.DriverShiftStart == DriverShiftStart.Dallas);
				}
				if (viewModel.DriverShiftStartOKC)
				{
					driverList = driverList.Where(x => x.DriverShiftStart == DriverShiftStart.OKC);
				}
			}

			if (viewModel.DriverFullTime != viewModel.DriverPartTime)
			{
				if (viewModel.DriverFullTime)
				{
					driverList = driverList.Where(x => x.PartTime == false);
				}
				if (viewModel.DriverPartTime)
				{
					driverList = driverList.Where(x => x.PartTime == true);
				}
			}

			viewModel.DriverList = driverList
				.OrderBy(x => x.FirstName)
				.ThenBy(x => x.LastName)
				.ToList()
				.Select(x => new ContainerDriverDispatchViewModel(x))
				.ToList();

			List<int> driverIDs = viewModel.DriverList.Select(x => x.DriverID).ToList();

			List<DailyDispatch> dispatchList = db.DailyDispatch
				.Include(x => x.Loads)
				.Include(x => x.Loads.Select(y => y.Store))
				.Include(x => x.Containers)
				.Where(x => x.InboundDate == viewModel.SelectedDate)
				//.Where(x => x.DispatchGroup == DatabaseLists.DISPATCH_GROUP_DALLAS)
				.Where(x => driverIDs.Contains(x.Driver1ID.Value))
				.ToList();


			containerService = containerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);
			
			// Get the ContainerInfo records in one action.
			List<string> containerNumbers = dispatchList.SelectMany(x => x.Containers.Select(y => y.ContainerNumber)).ToList();
			Dictionary<string, ContainerInfo> containerList = containerService.GetContainerListByNumber(containerNumbers).ToDictionary(x => x.ContainerNumber);
						
			foreach (ContainerDriverDispatchViewModel driver in viewModel.DriverList)
			{
				DailyDispatch dispatch = dispatchList.FirstOrDefault(x => x.Driver1ID == driver.DriverID);
				if (dispatch != null)
				{
					driver.DailyDispatchID = dispatch.DailyDispatchID;
					driver.LoadCount = dispatch.Loads.Count();
					Load noseLoad = dispatch.Loads.Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(x => x.DispatchLoadOrder).FirstOrDefault();
					if (noseLoad != null)
					{
						driver.NoseLoadStore = noseLoad.Store.StoreAndCompany;
					}
					
					List<ContainerViewModel> driverContainers = new List<ContainerViewModel>();
					foreach (Container container in dispatch.Containers)
					{
						ContainerInfo containerInfo = null;
						if (containerList.TryGetValue(container.ContainerNumber, out containerInfo))
						{
							driverContainers.Add(new ContainerViewModel(container, containerInfo));
						}
						else
						{
							driverContainers.Add(new ContainerViewModel(container));
						}
					}
					
					driver.Containers = driverContainers;
				}
			}

			return viewModel;
		}

		#endregion

		#region Container assignment methods

		[HttpGet]
		public JsonResult CheckContainerAssignment(DriverAssignmentRequest request)
		{
			DriverAssignmentResult result = new DriverAssignmentResult();

			try
			{
				containerService = containerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

				ContainerInfo containerInfo = containerService.GetContainer(request.ContainerNumber);

				if (containerInfo == null)
				{
					result.Allow = false;
					result.Message = string.Format("Container {0} not found in Container Source.", request.ContainerNumber);
					throw new Exception(result.Message);
				}

				DateTime oldestOpenDispatchDate = db.OpenDispatchDates().OldestDispatchDate();

				var containerQuery = db.Container
					.Include(x => x.DailyDispatch)
					.Where(x => x.ContainerNumber == request.ContainerNumber)
					.Where(x => x.DailyDispatch.DispatchDate >= oldestOpenDispatchDate);

				switch (containerInfo.StatusCode)
				{
					case StatusCodeValues.EW_NOTIFICATION:
						containerQuery = containerQuery.Where(x => x.ContainerAction == ContainerAction.Pull || x.ContainerAction == ContainerAction.CommitToOKC);
						break;
					case StatusCodeValues.ARRIVED_DALLAS_YARD:
					case StatusCodeValues.COMMITTED_TO_ARRIVE_OKC:
						containerQuery = containerQuery.Where(x => x.ContainerAction == ContainerAction.CommitToOKC);
						break;
					case StatusCodeValues.EMPTY_CONTAINER:
					case StatusCodeValues.EMPTY_CONTAINER_HEMISPHERES:
					case StatusCodeValues.LOADING_HOBBYLOBBY_STORE:
					case StatusCodeValues.COMMITTED_RETURN:
						containerQuery = containerQuery.Where(x => x.ContainerAction == ContainerAction.EmptyReturn);
						break;
					case StatusCodeValues.ARRIVED_OKC_YARD:
					default:
						result.Allow = false;
						result.Message = string.Format("Container {0} status {1} not actionable.", containerInfo.ContainerNumber, containerInfo.StatusCode);
						throw new Exception(result.Message);
				}

				Container container = containerQuery.FirstOrDefault();
				if (container == null)
				{
					result.Allow = true;
					result.Ask = false;
				}
				else
				{
					result.Allow = true;
					result.Ask = true;

					string delivery;
					if (container.DailyDispatch.CarrierID.HasValue)
					{
						Carrier carrier = db.Carrier.Find(container.DailyDispatch.CarrierID);
						delivery = carrier.Name;
					}
					else if (container.DailyDispatch.Driver1ID.HasValue && container.DailyDispatch.Driver2ID.HasValue)
					{
						Driver driver1 = db.Driver.Find(container.DailyDispatch.Driver1ID);
						Driver driver2 = db.Driver.Find(container.DailyDispatch.Driver2ID);
						delivery = string.Format("{0}/{1}", driver1.FullName, driver1.FullName);
					}
					else if (container.DailyDispatch.Driver1ID.HasValue)
					{
						Driver driver = db.Driver.Find(container.DailyDispatch.Driver1ID);
						delivery = driver.FullName;
					}
					else if (container.DailyDispatch.Driver2ID.HasValue)
					{
						Driver driver = db.Driver.Find(container.DailyDispatch.Driver2ID);
						delivery = driver.FullName;
					}
					else
					{
						delivery = "Dispatch";
					}

					DateTime delvDate = container.DailyDispatch.InboundDate.HasValue ? container.DailyDispatch.InboundDate.Value : container.DailyDispatch.DispatchDate;

					result.Message = string.Format("Container {3} already assigned to {0} for {1} on {2}.\nReassign this container?", 
						delivery, container.ContainerAction, delvDate.ToString("M/d"), request.ContainerNumber);
				}
			}
			catch (Exception ex)
			{
				HLLogging.Error(ex.Message, ex);
				result.Allow = false;
				result.Message = ex.Message;
			}

			return Json(result, JsonRequestBehavior.AllowGet);
		}

		[HttpGet]
		public JsonResult AssignContainerToDriver(DriverAssignmentRequest request)
		{
			DriverAssignmentResult result = new DriverAssignmentResult();

			try
			{
				// Remove container from other dispatch, if it is assigned.
				if (request.FromDailyDispatchID != 0 && !string.IsNullOrEmpty(request.ContainerNumber))
				{
					Container existingContainer = db.Container
						.SingleOrDefault(x => x.ContainerNumber == request.ContainerNumber && x.DailyDispatchID == request.FromDailyDispatchID);
					if (existingContainer != null)
					{
						db.Container.Remove(existingContainer);
					}
				}
				else
				{
					DateTime oldestOpenDispatchDate = db.OpenDispatchDates().OldestDispatchDate();
					var containerQuery = db.Container
						.Include(x => x.DailyDispatch)
						.Where(x => x.ContainerNumber == request.ContainerNumber && x.ContainerAction == request.ContainerAction)
						.Where(x => x.DailyDispatch.DispatchDate >= oldestOpenDispatchDate);
					Container existingContainer = containerQuery.FirstOrDefault();
					if (existingContainer != null)
					{
						db.Container.Remove(existingContainer);
					}
				}

				Container container = new Container
				{
					ContainerAction = request.ContainerAction,
					ContainerNumber = request.ContainerNumber,
					StatusCode = "ZZ"
				};

				DailyDispatch dailyDispatch;

				if (request.DailyDispatchID == 0)
				{
					dailyDispatch = new DailyDispatch
					{
						DispatchDate = request.Date,
						DispatchGroup = DatabaseLists.DISPATCH_GROUP_DALLAS,
						Driver1ID = request.DriverID,
						InboundDate = request.Date
					};

					Driver driver = db.Driver.Single(x => x.DriverID == request.DriverID);
					dailyDispatch.TractorNumber = driver.TractorNumber;

					ChangeLogger.LogChange(this, db.Entry(dailyDispatch));
					db.DailyDispatch.Add(dailyDispatch);
				}
				else
				{
					dailyDispatch = db.DailyDispatch
						.Include(x => x.Containers)
						.Single(x => x.DailyDispatchID == request.DailyDispatchID);
				}

				if (dailyDispatch.Containers == null)
				{
					dailyDispatch.Containers = new List<Container>();
				}

				ChangeLogger.LogChange(this, db.Entry(container));
				dailyDispatch.Containers.Add(container);

				//dailyDispatch.TrailerIn = null;
				//dailyDispatch.Trailer = null;
				
				foreach (Container cont in dailyDispatch.Containers)
				{
					if (cont.ContainerAction == ContainerAction.CommitToOKC)
					{
						dailyDispatch.TrailerIn = cont.ContainerNumber;
					}
					else if (cont.ContainerAction == ContainerAction.EmptyReturn)
					{
						dailyDispatch.Trailer = cont.ContainerNumber;
					}
				}

				db.SaveChanges();

				/*
				 * Begin Container System updates.
				 */

				result.DailyDispatchID = dailyDispatch.DailyDispatchID;

				string deliveryBy = string.Empty;

				if (dailyDispatch.CarrierID.HasValue)
				{
					Carrier carrier = db.Carrier.Find(dailyDispatch.CarrierID.Value);
					deliveryBy = carrier.Name;
				}
				else if (dailyDispatch.Driver1ID.HasValue)
				{
					Driver driver = db.Driver.Find(dailyDispatch.Driver1ID.Value);
					deliveryBy = string.Format("{0} {1}", driver.FirstName, driver.LastName.Substring(0, 1));
				}
				else if (dailyDispatch.Driver2ID.HasValue)
				{
					Driver driver = db.Driver.Find(dailyDispatch.Driver2ID.Value);
					deliveryBy = string.Format("{0} {1}", driver.FirstName, driver.LastName.Substring(0, 1));
				}

				containerService = containerService ?? new ContainerService(LibConfigProperties.Settings.ContainerRepositoryType, LibConfigProperties.Settings.ContainerSourceConnection);

				try
				{
					ContainerInfo containerInfo = containerService.GetContainer(container.ContainerNumber);
					if (container.ContainerAction == ContainerAction.Pull)
					{
						if (containerInfo.StatusCode == StatusCodeValues.EW_NOTIFICATION)
						{
							Dictionary<UpdateColumn, object> updateColumns = new Dictionary<UpdateColumn, object>();
							updateColumns.Add(UpdateColumn.PullDriverName, deliveryBy);
							int rowCount = containerService.UpdateContainer(container.ContainerNumber, updateColumns);
							if (rowCount == 0)
							{
								throw new Exception("One or more container records not updated on Container System. Row Count = 0.");
							}
						}
					}
					else if (container.ContainerAction == ContainerAction.CommitToOKC)
					{
						if (containerInfo.StatusCode == StatusCodeValues.EW_NOTIFICATION)
						{
							Dictionary<UpdateColumn, object> updateColumns = new Dictionary<UpdateColumn, object>();
							updateColumns.Add(UpdateColumn.PullDriverName, deliveryBy);
							int rowCount = containerService.UpdateContainer(container.ContainerNumber, updateColumns);
							if (rowCount == 0)
							{
								throw new Exception("One or more container records not updated on Container System. Row Count = 0.");
							}
						}
						else if (containerInfo.StatusCode == StatusCodeValues.ARRIVED_DALLAS_YARD || containerInfo.StatusCode == StatusCodeValues.COMMITTED_TO_ARRIVE_OKC)
						{
							var results = containerService.ContainerAction(ActionCodeValues.ASSIGN_COMMIT_TO_OKC_DRIVER, new string[] { container.ContainerNumber }, driverName: deliveryBy);
							if (results.Count() > 0) // Only errors are returned.
							{
								throw new Exception("Errors on Containers: " + string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
							}
						}
					}
					else if (container.ContainerAction == ContainerAction.EmptyReturn)
					{
						if (containerInfo.StatusCode == StatusCodeValues.EMPTY_CONTAINER || containerInfo.StatusCode == StatusCodeValues.LOADING_HOBBYLOBBY_STORE || containerInfo.StatusCode == StatusCodeValues.COMMITTED_RETURN)
						{
							var results = containerService.ContainerAction(ActionCodeValues.ASSIGN_EMPTY_RETURN_DRIVER, new string[] { container.ContainerNumber }, driverName: deliveryBy);
							if (results.Count() > 0) // Only errors are returned.
							{
								throw new Exception("Errors on Containers: " + string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
							}
						}
						else if (containerInfo.StatusCode == StatusCodeValues.EMPTY_CONTAINER_HEMISPHERES)
						{
							var results = containerService.ContainerAction(ActionCodeValues.ASSIGN_HEMISPHERES_RETURN_DRIVER, new string[] { container.ContainerNumber }, driverName: deliveryBy);
							if (results.Count() > 0) // Only errors are returned.
							{
								throw new Exception("Errors on Containers: " + string.Join(",", results.Select(x => string.Format("{0}={1}", x.ContainerNumber, x.Error))));
							}
						}
					}
				}
				catch (Exception ex)
				{
					HLLogging.WarnFormat(string.Format("Dispatch {0}: Error trying to update remote Container Source. {1}", dailyDispatch.DailyDispatchID, ex.Message));
					throw ex;
				}

				/*
				 * End Container System updates.
				 */
			}
			catch (Exception ex)
			{
				HLLogging.Error(ex.Message, ex);
				result.Allow = false;
				result.Message = ex.Message;
			}

			return Json(result, JsonRequestBehavior.AllowGet);
		}

		[HttpGet]
		public JsonResult RemoveContainerFromDispatch(DriverAssignmentRequest request)
		{
			DriverAssignmentResult result = new DriverAssignmentResult();

			try
			{
				// Remove container from dispatch, if it is assigned.
				Container container = db.Container
					.SingleOrDefault(x => x.ContainerNumber == request.ContainerNumber && x.DailyDispatchID == request.DailyDispatchID);
				if (container != null)
				{
					db.Container.Remove(container);

					DailyDispatch dailyDispatch = db.DailyDispatch
						.Include(x => x.Containers)
						.Single(x => x.DailyDispatchID == request.DailyDispatchID);

					if (container.ContainerAction == ContainerAction.CommitToOKC)
					{
						dailyDispatch.TrailerIn = null;
					}
					else if (container.ContainerAction == ContainerAction.EmptyReturn)
					{
						dailyDispatch.Trailer = null;
					}
				}

				db.SaveChanges();
				result.Allow = true;
			}
			catch (Exception ex)
			{
				HLLogging.Error(ex.Message, ex);
				result.Allow = false;
				result.Message = "Exception occurred.";
			}

			return Json(result, JsonRequestBehavior.AllowGet);
		}

		#endregion

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}