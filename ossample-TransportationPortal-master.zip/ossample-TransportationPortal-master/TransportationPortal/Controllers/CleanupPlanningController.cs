﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Objects.SqlClient;
using System.Linq;
using System.Web.Mvc;
using Avatar;
using HobbyLobby.HLUtil.Logging;
using TransportationPortal.Models;
using TransportationPortal.Repositories;
using TransportationPortal.ViewModels;


namespace TransportationPortal.Controllers
{
	[HandleApplicationError]
	public class CleanupPlanningController : Controller
	{
		private DispatchContext db = new DispatchContext();

		private string LoadFilterSessionName
		{
			get { return this.GetType().Name + ".LoadFilter"; }
		}

		private string DispatchFilterSessionName
		{
			get { return this.GetType().Name + ".DispatchFilter"; }
		}

		#region Load List

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ViewResult Index(int? id)
		{
			PlanningViewModel viewModel = Session[LoadFilterSessionName] as PlanningViewModel;
			if (viewModel == null)
			{
				DateTime fromDate = DateTime.Today;

				viewModel = new PlanningViewModel
				{
					FromDate = fromDate,
				};

				// Find the next Friday
				switch (viewModel.FromDate.Value.DayOfWeek)
				{
					case DayOfWeek.Saturday: viewModel.ThruDate = viewModel.FromDate.Value.AddDays(6); break;
					case DayOfWeek.Sunday: viewModel.ThruDate = viewModel.FromDate.Value.AddDays(5); break;
					case DayOfWeek.Monday: viewModel.ThruDate = viewModel.FromDate.Value.AddDays(4); break;
					case DayOfWeek.Tuesday: viewModel.ThruDate = viewModel.FromDate.Value.AddDays(3); break;
					case DayOfWeek.Wednesday: viewModel.ThruDate = viewModel.FromDate.Value.AddDays(2); break;
					case DayOfWeek.Thursday: viewModel.ThruDate = viewModel.FromDate.Value.AddDays(1); break;
					case DayOfWeek.Friday: viewModel.ThruDate = viewModel.FromDate.Value; break;
				}

				viewModel.Paging = new PagingViewModel
				{
					Page = 1,
					PageSize = 50,
					LinksBeforeCurrentPage = 4,
					LinksAfterCurrentPage = 4,
				};
			}
			else if (id.HasValue)
			{
				viewModel.Paging.Page = id.Value;
				ViewBag.OverrideSavedPosition = "0_0";
			}

			// Generate the new view model.
			viewModel = GenerateViewModel_Loads(viewModel);

			// Save the view model
			Session[LoadFilterSessionName] = viewModel;

			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
		public ActionResult Index(PlanningViewModel viewModel)
		{
			PlanningViewModel previousViewModel = Session[LoadFilterSessionName] as PlanningViewModel;
			if (previousViewModel != null)
			{
				viewModel.Paging = previousViewModel.Paging;
				viewModel.Paging.Page = 1;
			}

			if (viewModel.TypesSelectList != null)
			{
				for (int i = 0; i < previousViewModel.TypesSelectList.Count(); i++)
				{
					previousViewModel.TypesSelectList[i].Selected = viewModel.TypesSelectList[i].Selected;
				}
			}
			viewModel.TypesSelectList = previousViewModel.TypesSelectList;


			int loadSelectCount = viewModel.LoadSelect == null ? 0 : viewModel.LoadSelect.Count();

			if (!string.IsNullOrEmpty(viewModel.SubmitButtonAssignLoads))
			{
				if (loadSelectCount > 0)
				{
					Session[LoadFilterSessionName] = viewModel;
					return RedirectToAction("DispatchIndex");
				}
				else
				{
					ModelState.AddModelError(string.Empty, "No loads are selected.");
				}
			}
			else if (!string.IsNullOrEmpty(viewModel.SubmitButtonCreateCarrierDispatch))
			{
				if (loadSelectCount > 0)
				{
					Session[LoadFilterSessionName] = viewModel;
					return RedirectToAction("Create", "DailyDispatch", new { id = 0, catchall = string.Join(",", viewModel.LoadSelect) });
				}
				else
				{
					ModelState.AddModelError(string.Empty, "No loads are selected.");
				}
			}

			viewModel = GenerateViewModel_Loads(viewModel);

			Session[LoadFilterSessionName] = viewModel;

			return View(viewModel);
		}

		private PlanningViewModel GenerateViewModel_Loads(PlanningViewModel viewModel)
		{
			// ViewBag 

			var stateList = CountryStates.USStates
				.AsEnumerable()
				.Select(x => new
				{
					Text = x.Value,
					Value = x.Key
				});

			if (string.IsNullOrEmpty(viewModel.StateCode))
			{
				viewModel.StateCodeList = new SelectList(stateList, "Value", "Text");
			}
			else
			{
				viewModel.StateCodeList = new SelectList(stateList, "Value", "Text", viewModel.StateCode);
			}

			if (AppAuthorization.ViewPermission(this, typeof(CleanupLoadController)).AtLeast(Avatar.PermissionLevel.Modify))
			{
				viewModel.CanUseCleanupUpdateMode = true;
			}
			else
			{
				viewModel.CanUseCleanupUpdateMode = false;
			}

			// Apply filters.

			DateTime oldestOpenDispatchDate = db.OpenDispatchDates().OldestDispatchDate();

			var list = db.Load
				.Where(x => x.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
				.Where(x => x.PickupDate >= oldestOpenDispatchDate)
				.Include(x => x.Store)
				.Include(x => x.DailyDispatch)
				.Include(x => x.DailyDispatch.Loads)
				.Include(x => x.DailyDispatch.Loads.Select(y => y.Store));
				//.AsNoTracking();

			if (viewModel.FromDate.HasValue)
			{
				list = list.Where(x => x.PickupDate >= viewModel.FromDate);
			}

			if (viewModel.ThruDate.HasValue)
			{
				list = list.Where(x => x.PickupDate <= viewModel.ThruDate);
			}

			if (!string.IsNullOrEmpty(viewModel.StateCode))
			{
				list = list.Where(x => x.Store.StateCode == viewModel.StateCode);
			}

			if (viewModel.UnassignedLoadsOnly)
			{
				list = list.Where(x => x.DailyDispatchID.HasValue == false);
			}


			// Special SearchField values

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string searchField = viewModel.SearchField.Trim();
				Int64 intValue = 0;
				decimal decValue = 0m;
				bool isNumber = Decimal.TryParse(searchField, out decValue);
				if (isNumber)
				{
					intValue = Decimal.ToInt64(decValue);
				}

				if (isNumber && intValue > 0)
				{
					list = list.Where(x =>
						(x.LoadID == intValue) ||
						(x.Store != null && x.Store.City.Contains(searchField)) ||
						(x.Store != null && x.Store.StateCode.Contains(searchField))
						);
				}
				else
				{
					list = list.Where(x =>
						(x.Store != null && x.Store.City.Contains(searchField)) ||
						(x.Store != null && x.Store.StateCode.Contains(searchField))
						);
				}
			}

			LoadSortColumn sortColumn;
			if (!Enum.TryParse(viewModel.SortColumn, out sortColumn))
			{
				sortColumn = LoadSortColumn.Store;
			}

			switch (sortColumn)
			{
				case LoadSortColumn.NoseLoadStore:
					list = (viewModel.SortDirection >= 0)
						? list
						.OrderBy(x => x.DailyDispatch.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
						.ThenBy(x => x.DailyDispatch.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber)
						: list
						.OrderByDescending(x => x.DailyDispatch.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
						.ThenByDescending(x => x.DailyDispatch.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber);
					break;
				case LoadSortColumn.StoreLocation:
					list = (viewModel.SortDirection >= 0)
						? list.OrderBy(x => x.Store.StateCode).ThenBy(x => x.Store.City).ThenBy(x => x.PickupDate)
						: list.OrderByDescending(x => x.Store.StateCode).ThenByDescending(x => x.Store.City).ThenBy(x => x.PickupDate);
					break;
				case LoadSortColumn.Store:
					list = (viewModel.SortDirection >= 0)
						? list.OrderBy(x => x.Store.CompanyID).ThenBy(x => x.Store.StoreNumber).ThenBy(x => x.PickupDate)
						: list.OrderByDescending(x => x.Store.CompanyID).ThenByDescending(x => x.Store.StoreNumber).ThenBy(x => x.PickupDate);
					break;
				case LoadSortColumn.PickupDate:
				default:
					list = (viewModel.SortDirection >= 0)
						? list.OrderBy(x => x.PickupDate) 
						: list.OrderByDescending(x => x.PickupDate);
					break;
			}

			// Get the total number of records for the paging functions.
			viewModel.Paging.TotalRecords = list.Count();
			// Perform skip/take
			list = list.Skip((viewModel.Paging.Page - 1) * viewModel.Paging.PageSize)
				.Take(viewModel.Paging.PageSize);

			viewModel.Loads = list
				.ToList()
				.Select(x => new LoadDragDropViewModel(x, loadDispatches: true));

			return viewModel;
		}

		#endregion

		#region Dispatch List

		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult DispatchIndex(int? id)
		{
			DailyDispatchIndexViewModel viewModel = Session[DispatchFilterSessionName] as DailyDispatchIndexViewModel;
			if (viewModel == null)
			{
				viewModel = new DailyDispatchIndexViewModel();
				viewModel.CarrierSelect = true;
				viewModel.CompanySelect = true;
				viewModel.SelectDate = DateTime.Today;
				viewModel.SelectedDates = new List<DateTime>();
				viewModel.SelectDate = DateTime.Today;
				viewModel.FromDate = DateTime.Today;
				viewModel.ThruDate = DateTime.Today;
				viewModel.Paging = new PagingViewModel
				{
					Page = 1,
					PageSize = 50,
					LinksBeforeCurrentPage = 4,
					LinksAfterCurrentPage = 4,
					Action = "DispatchIndex/{0}"
				};
			}
			else if (id.HasValue)
			{
				if (viewModel.Paging.Page != id.Value)
				{
					ViewBag.OverrideSavedPosition = "0_0";
				}
				viewModel.Paging.Page = id.Value;
			}
			else
			{
				// If a dispatch was updated, return to the Load Index
				string lastDailyDispatchID = (string)TempData[DailyDispatchController.TEMPDATA_LASTDAILYDISPATCHID];
				if (!string.IsNullOrWhiteSpace(lastDailyDispatchID))
				{
					return RedirectToAction("Index");
				}
			}

			// Generate the new view model.
			viewModel = GenerateViewModel_Dispatches(viewModel);

			// Save the view model
			Session[DispatchFilterSessionName] = viewModel;

			return View(viewModel);
		}

		[HttpPost]
		[AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Modify)]
		public ActionResult DispatchIndex(DailyDispatchIndexViewModel viewModel)
		{
			DailyDispatchIndexViewModel previousViewModel = Session[DispatchFilterSessionName] as DailyDispatchIndexViewModel;
			if (previousViewModel != null)
			{
				viewModel.Paging = previousViewModel.Paging;
				viewModel.Paging.Page = 1;
			}

			viewModel.DispatchWeeks = previousViewModel.DispatchWeeks;
			viewModel.SelectedDates = previousViewModel.SelectedDates;

			viewModel = GenerateViewModel_Dispatches(viewModel);
			Session[DispatchFilterSessionName] = viewModel;

			return View(viewModel);
		}


		private DailyDispatchIndexViewModel GenerateViewModel_Dispatches(DailyDispatchIndexViewModel viewModel)
		{
			// ViewBag stuff.

			var CarrierList = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .OrderBy(x => x.Name)
				.ToList()
				.Select(x => new
				{
					Value = x.CarrierID,
					Text = x.Name
				});

			viewModel.CarrierList = new SelectList(CarrierList, "Value", "Text", viewModel.CarrierID);

			// Apply filtering.

			PlanningViewModel selectedLoadsViewModel = Session[LoadFilterSessionName] as PlanningViewModel;

			var selectedLoads = db.Load
				.Where(x => selectedLoadsViewModel.LoadSelect.Contains(x.LoadID))
				.Include(x => x.PickupCompany)
				.Include(x => x.Store)
				.OrderBy(x => x.LoadID)
				.AsNoTracking();

			ViewBag.SelectedLoads = selectedLoads
				.ToList()
				.Select(x => new LoadDragDropViewModel(x));

			if (viewModel.SelectDate.HasValue == false)
			{
				ModelState.AddModelError(string.Empty, "Select a date.");
			}

			if (!ModelState.IsValid)
			{
				return viewModel;
			}

			var list = db.OpenDispatches()
				.Where(x =>
					viewModel.SelectDate.Value == x.InboundDate
					||
					viewModel.SelectDate.Value == x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
						.OrderBy(y => y.DispatchLoadOrder)
						.FirstOrDefault().EtaDateOnly
					);
						
			list = list.AsNoTracking()
				.Include(x => x.Driver1)
				.Include(x => x.Driver2)
				.Include(x => x.Carrier)
				.Include(x => x.Loads)
				.Include(x => x.Loads.Select(a => a.Store))
				.Include(x => x.Loads.Select(a => a.PickupCompany));

			list = list.Where(x => x.Loads.Any() == true);

			if (viewModel.CompanySelect == true && viewModel.CarrierSelect == true)
			{
				list = list.Where(x => x.Driver1ID.HasValue == true || x.Driver2ID.HasValue == true || x.CarrierID.HasValue == true);
			}
			else if (viewModel.CompanySelect == true)
			{
				list = list.Where(x => x.Driver1ID.HasValue == true || x.Driver2ID.HasValue == true);
			}
			else if (viewModel.CarrierSelect == true)
			{
				list = list.Where(x => x.CarrierID.HasValue == true);
			}
			else
			{
				list = list.Where(x => x.DailyDispatchID < 0);	// Don't show anything.
			}

			if (!string.IsNullOrWhiteSpace(viewModel.SearchField))
			{
				string textValue = viewModel.SearchField.Trim();
				int intValue = 0;
				bool isNumber = Int32.TryParse(textValue, out intValue);

				if (isNumber && intValue > 0)
				{
					list = list.Where(x =>
						x.DailyDispatchID == intValue
						|| x.Carrier.Name.Contains(textValue)
						|| (x.Driver1.FirstName.Contains(textValue) || x.Driver1.LastName.Contains(textValue))
						|| (x.Driver2.FirstName.Contains(textValue) || x.Driver2.LastName.Contains(textValue))
						|| x.Comment.Contains(textValue)
						|| x.Trailer.Contains(textValue)
						|| x.TrailerIn.Contains(textValue)
						|| x.TractorNumber == textValue
						|| x.Loads.Any(y => y.Store.StoreNumber == intValue)
						);
				}
				else
				{
					list = list.Where(x =>
						(x.Carrier != null && x.Carrier.Name.Contains(textValue))
						|| (x.Driver1.FirstName.Contains(textValue) || x.Driver1.LastName.Contains(textValue))
						|| (x.Driver2.FirstName.Contains(textValue) || x.Driver2.LastName.Contains(textValue))
						|| x.Comment.Contains(textValue)
						|| x.Trailer.Contains(textValue)
						|| x.TrailerIn.Contains(textValue)
						);
				}
			}

			DispatchSortColumn sortColumn;
			if (!Enum.TryParse(viewModel.SortColumn, out sortColumn))
			{
				sortColumn = DispatchSortColumn.OutboundStore;
			}
			list = list.Sort(sortColumn, viewModel.SortDirection);
			
			viewModel.Dispatches = list
				.ToList()
				.Select(x => new DispatchViewModel(x))
				.ToList();

			return viewModel;
		}

		#endregion

		#region Ajax Methods for updating individual elements from the DailyDispatch Index screen to the database.

		/// <summary>
		/// This method is called for each individual field to be updated when one or more columns in the Index view are in update mode.
		/// The call is triggered by the Changed event in the html.
		/// Supports updating these fields:
		/// Load: LinearFeet
		/// </summary>
		/// <param name="update">Field update object instantiated from JSON input, with record ID, field ID and new field value.</param>
		/// <returns>Count of successful updates (0 or 1).</returns>
		[HttpPost]
		public JsonResult UpdateField(FieldUpdate update)
		{
			FieldUpdateResponse response = new FieldUpdateResponse
			{
				changecount = 0
			};

			int dailyDispatchID = 0;

			try
			{
				if (update != null)
				{
					db = db ?? new DispatchContext();

					string updateValue = string.IsNullOrWhiteSpace(update.fieldvalue) ? null : update.fieldvalue.Trim();

					response.fieldvalue = updateValue;

					if (update.fieldid == FieldName.LoadFeet)
					{
						Load load = db.Load.Find(update.recordid);
						if (load != null)
						{
							if (updateValue == null)
							{
								load.LinearFeet = null;
								response.changecount++;
							}
							else
							{
								try
								{
									load.LinearFeet = Int32.Parse(updateValue);
									response.fieldvalue = load.LinearFeet.ToString();
									response.changecount++;
								}
								catch (Exception) { }
							}
							dailyDispatchID = load.DailyDispatchID ?? 0;
						}
					}

					foreach (var entry in db.ChangeTracker.Entries())
					{
						if (entry.State == EntityState.Modified)
						{
							ChangeLogger.LogChange(this, entry);
						}
					}

					// Persist changes
					db.SaveChanges();
				}
			}
			catch (Exception ex)
			{
				response.changecount = 0;
				HLLogging.Error("Error in UpdateField Ajax method", ex);
			}

			return Json(response);
		}

		#endregion

		protected override void Dispose(bool disposing)
		{
			db.Dispose();
			base.Dispose(disposing);
		}
	}
}