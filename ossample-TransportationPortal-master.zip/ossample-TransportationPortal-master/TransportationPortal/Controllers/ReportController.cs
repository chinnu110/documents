﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Objects.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web.Mvc;
using Avatar;
using ExcelUtil;
using HobbyLobby.HLUtil.Logging;
using TransportationPortal.Models;
using TransportationPortal.Repositories;
using TransportationPortal.ViewModels;

namespace TransportationPortal.Controllers
{
    [HandleApplicationError]
    [AppAuthorizationFilter(MinimumPermissionRequired = PermissionLevel.Read)]
    public class ReportController : Controller
    {
        public const string REPORT_ELEMENTS_TEMPDATA_NAME = "ReportElementsList";

        public class CarrierAdvisementSpreadsheet
        {
            public readonly uint DelveryDate = 1;
            public readonly uint Trailer = 2;
            public readonly uint Store = 3;
            public readonly uint StoresAdded = 4;
            public readonly uint RefNumber = 5;
            public readonly uint Merchandise = 6;
            public readonly uint Carrier = 7;
            public readonly uint Miles = 8;
        }

        public class StoreAdvisementSpreadsheet
        {
            public readonly uint Store = 1;
            public readonly uint Name = 2;
            public readonly uint Time = 3;
            public readonly uint Carrier = 4;
            public readonly uint Bflag = 5;
            public readonly uint Sflag = 6;
            public readonly uint Fflag = 7;
            public readonly uint DeliveryDate = 8;
            public readonly uint DeliveryTime = 9;
            public readonly uint Change = 10;
        }

        public class CarrierChargeSpreadsheet
        {
            public readonly uint Date = 1;
            public readonly uint RefNumber = 2;
            public readonly uint Store1 = 3;
            public readonly uint Store2 = 4;
            public readonly uint Store3 = 5;
            public readonly uint Store4 = 6;
            public readonly uint TotalCharge = 7;
            public readonly uint Carrier = 8;
            public readonly uint Trailer = 9;
            public readonly uint Merchandise = 10;
            public readonly uint Pallets = 11;
            public readonly uint Miles = 12;
            public readonly uint RoundTrip = 13;
            public readonly uint ID = 14;
        }

        public class BackhaulReportSpreadsheet
        {
            public readonly uint Date = 1;
            public readonly uint RefNumber = 2;
            public readonly uint Carrier = 3;
            public readonly uint Rate = 4;
            public readonly uint Vendor = 5;
            public readonly uint City = 6;
            public readonly uint State = 7;
            public readonly uint Zip = 8;
            public readonly uint PO1 = 9;
            public readonly uint PO2 = 10;
            public readonly uint Pallets = 11;
            public readonly uint Cartons = 12;
            public readonly uint Weight = 13;
            public readonly uint InvNum = 14;
            public readonly uint InvAmt = 15;
            public readonly uint DateCompleted = 16;
            public readonly uint Difference = 17;
            public readonly uint Notes = 18;
        }

        public class BackhaulTrackingSpreadsheet
        {
            public readonly uint PickupDate = 1;
            public readonly uint Trailer = 2;
            public readonly uint Vendor = 3;
            public readonly uint Pallets = 4;
            public readonly uint Zone = 5;
            public readonly uint PO1 = 6;
            public readonly uint PO2 = 7;
            public readonly uint EtaDate = 8;
            public readonly uint DateWorked = 9;
        }
        
        public class BrokerLoadListSpreadsheet
        {
            public readonly uint LoadID = 1;
            public readonly uint BrokerLoadNumber = 2;
            public readonly uint PickupDate = 3;
            public readonly uint DeliveryDate = 4;
            public readonly uint InvoiceDate = 5;
            public readonly uint InvoiceNumber = 6;
            public readonly uint BrokerName = 7;
            public readonly uint PickupCo = 8;
            public readonly uint DeliveryCo = 9;
            public readonly uint InvoiceAmount = 10;
        }

        public class CleanupHistorySpreadsheet
        {
            public readonly uint LoadID = 1;
            public readonly uint Store = 2;
            public readonly uint PickupDate = 3;
            public readonly uint DelvStore = 4;
            public readonly uint Pallets = 5;
            public readonly uint Totes = 6;
            public readonly uint LoadLocks = 7;
            public readonly uint Cartons = 8;
            public readonly uint LinearFeet = 9;
            public readonly uint CleanupStatus = 10;
        }

        private DispatchContext db = new DispatchContext();

        public ViewResult Index()
        {
            return View();
        }

        public ViewResult Inbound()
        {
            return View();
        }

        public ViewResult Outbound()
        {
            return View();
        }

        private byte[] GenerateReport(
            string reportName, 
            IDictionary<string, string> reportParameters, 
            HobbyLobby.Reporting.ReportFormat reportFormat = HobbyLobby.Reporting.ReportFormat.PDF)
        {
            return HobbyLobby.Reporting.Report.Render(
                reportName,
                reportServerUrl: LibConfigProperties.Settings.ReportServerUrl,
                reportFolder: LibConfigProperties.Settings.ReportFolder,
                username: LibConfigProperties.Settings.ReportServerUsername,
                password: LibConfigProperties.Settings.ReportServerPassword,
                domain: LibConfigProperties.Settings.ReportServerDomain,
                parameters: reportParameters,
                timout: LibConfigProperties.Settings.ReportTimeout,
                reportFormat: reportFormat);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        #region Direct Delivery Report

        public ActionResult DirectDelivery()
        {
            ReportViewModel viewModel = new ReportViewModel();

            viewModel.FromDate = DateTime.Today;
            viewModel.ThruDate = DateTime.Today;
            
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult DirectDelivery(ReportViewModel viewModel)
        {
            string fromDate = viewModel.FromDate.HasValue ? viewModel.FromDate.Value.ToString("yyyy-MM-dd") : string.Empty;

            string thruDate = viewModel.ThruDate.HasValue ? viewModel.ThruDate.Value.ToString("yyyy-MM-dd") : string.Empty;

            IDictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("ParamDeliveryType", DatabaseLists.LOAD_DELIVERY_TYPE_DIRECT);
            parameters.Add("ParamDateFrom", fromDate);
            parameters.Add("ParamDateThru", thruDate);

            byte[] report = GenerateReport("Current Backhauls", parameters);
            
            return File(report, "application/pdf", "Direct Delivery Backhauls.pdf");
        }

        #endregion

        #region Dallas Dispatch Delivery Report

        public ActionResult DallasDispatch()
        {
            ReportViewModel viewModel = new ReportViewModel();

            viewModel.FromDate = DateTime.Today;
            viewModel.ThruDate = DateTime.Today;

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult DallasDispatch(ReportViewModel viewModel)
        {
            if (!viewModel.FromDate.HasValue)
            {
                ModelState.AddModelError(string.Empty, "From Date must be entered.");
            }

            if (!viewModel.ThruDate.HasValue)
            {
                ModelState.AddModelError(string.Empty, "Thru Date must be entered.");
            }

            if (!ModelState.IsValid)
            {
                return View(viewModel);
            }

            IDictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("ParamDateFrom", viewModel.FromDate.Value.ToString("yyyy-MM-dd"));
            parameters.Add("ParamDateThru", viewModel.ThruDate.Value.ToString("yyyy-MM-dd"));

            if (viewModel.ReportName == ReportViewModel.ReportName_BackhaulPickups)
            {
                parameters.Add("ParamDispatchGroup", DatabaseLists.DISPATCH_GROUP_DALLAS);
                byte[] report = GenerateReport("Current Pickups", parameters);
                return File(report, "application/pdf", "Dallas Backhaul Pickups.pdf");
            }
            else if (viewModel.ReportName == ReportViewModel.ReportName_BackhaulDeliveries)
            {
                parameters.Add("ParamDeliveryType", DatabaseLists.LOAD_DELIVERY_TYPE_DALLAS_DISPATCH);
                byte[] report = GenerateReport("Current Backhauls", parameters);
                return File(report, "application/pdf", "Dallas Backhaul Deliveries.pdf");
            }
            else 
            {
                ModelState.AddModelError(string.Empty, "Select the Pickups or Deliveries report.");
                return View(viewModel);
            }
        }

        #endregion

        #region OKC Dispatch Delivery Report

        public ActionResult OkcDispatch()
        {
            ReportViewModel viewModel = new ReportViewModel();

            viewModel.FromDate = DateTime.Today;
            viewModel.ThruDate = DateTime.Today;

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult OkcDispatch(ReportViewModel viewModel)
        {
            string fromDate = viewModel.FromDate.HasValue ? viewModel.FromDate.Value.ToString("yyyy-MM-dd") : string.Empty;

            string thruDate = viewModel.ThruDate.HasValue ? viewModel.ThruDate.Value.ToString("yyyy-MM-dd") : string.Empty;

            IDictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("ParamDateFrom", fromDate);
            parameters.Add("ParamDateThru", thruDate);

            if (viewModel.ReportName == ReportViewModel.ReportName_BackhaulPickups)
            {
                parameters.Add("ParamDispatchGroup", DatabaseLists.DISPATCH_GROUP_OKC);
                byte[] report = GenerateReport("Current Pickups", parameters);
                return File(report, "application/pdf", "Oklahoma City Backhaul Pickups.pdf");
            }
            else if (viewModel.ReportName == ReportViewModel.ReportName_BackhaulDeliveries)
            {
                parameters.Add("ParamDeliveryType", DatabaseLists.LOAD_DELIVERY_TYPE_OKC_DISPATCH);
                byte[] report = GenerateReport("Current Backhauls", parameters);
                return File(report, "application/pdf", "Oklahoma City Backhaul Deliveries.pdf");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Select the Pickups or Deliveries report.");
                return View(viewModel);
            }
        }

        #endregion

        #region Carrier Advisement Spreadsheet

        public ActionResult CarrierAdvisement()
        {
            ReportViewModel viewModel = new ReportViewModel();

            CarrierAdvisementViewBag(viewModel);

            return View("CarrierAdvisement", viewModel);
        }

        private void CarrierAdvisementViewBag(ReportViewModel viewModel)
        {
            var dispatchDates = db.OpenDispatchDates()
                .OrderBy(x => x.DispatchDate)
                .ToList()
                .Select(x => new
                {
                    Value = x.DispatchDate.ToString("d"),
                    Text = x.DispatchDate.ToString("ddd M/d")
                });

            var carriers = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .OrderBy(x => x.Name)
                .Select(x => new
                {
                    Text = x.Name,
                    Value = x.CarrierID
                });

            if (viewModel == null)
            {
                ViewBag.SelectedDate = new SelectList(dispatchDates, "Value", "Text");
                ViewBag.CarrierID = new SelectList(carriers, "Value", "Text");
            }
            else
            {
                ViewBag.SelectedDate = new SelectList(dispatchDates, "Value", "Text", viewModel.SelectedDate);
                ViewBag.CarrierID = new SelectList(carriers, "Value", "Text", viewModel.CarrierID);
            }
        }

        [HttpPost]
        public ActionResult CarrierAdvisement(ReportViewModel viewModel)
        {
            if (viewModel.SelectedDate.HasValue)
            {
                if (viewModel.FromDate.HasValue || viewModel.ThruDate.HasValue)
                {
                    this.ModelState.AddModelError(string.Empty, "Dispatch Date and  Delivery From-Date/Thru-Date cannot both be specified.");
                }
            }
            else
            {
                if (!viewModel.FromDate.HasValue)
                {
                    this.ModelState.AddModelError(string.Empty, "Either Dispatch Date or Delivery From-Date must be specified.");
                }

                if (viewModel.FromDate.HasValue && viewModel.ThruDate.HasValue &&
                    viewModel.ThruDate.Value < viewModel.FromDate.Value)
                {
                    this.ModelState.AddModelError(string.Empty, "Delivery Thru-Date must be on or after the From-Date");
                }
            }

            if (!ModelState.IsValid)
            {
                CarrierAdvisementViewBag(viewModel);
                return View(viewModel);
            }

            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream spreadsheetTemplate = assembly.GetManifestResourceStream("TransportationPortal.Templates.Carrier Advisement Template 1.xlsx");

            using (MemoryStream mem = new MemoryStream())
            {
                spreadsheetTemplate.CopyTo(mem);
                spreadsheetTemplate.Close();

                XSpreadsheet spreadsheet = new XSpreadsheet
                {
                    Stream = mem,
                    SheetNumber = 1,
                    RunObject = viewModel
                };

                if (!spreadsheet.Update(CreateCarrierAdvisementSpreadsheet))
                {
                    this.ModelState.AddModelError(string.Empty, "Spreadsheet generation ended prematurely.");
                    CarrierAdvisementViewBag(viewModel);
                    return View(viewModel);
                }

                return File(mem.ToArray(), "application/xlsx", Path.ChangeExtension(LibConfigProperties.Settings.CarrierAdvisementSpreadsheetName, "xlsx"));
            }
        }

        private bool CreateCarrierAdvisementSpreadsheet(XSpreadsheet spreadsheet)
        {
            CarrierAdvisementSpreadsheet col = new CarrierAdvisementSpreadsheet();

            XRow templateXRow = spreadsheet[2];
            XRow templateXRow_NoLoad = spreadsheet[3];
            XRow templateXRow_AddedLoad = spreadsheet[4];

            var fields = col.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
            foreach (FieldInfo field in fields)
            {
                uint columnNumber = (uint)field.GetValue(col);
                try
                {
                    templateXRow[columnNumber].SetValue(null);
                    templateXRow_NoLoad[columnNumber].SetValue(null);
                    templateXRow_AddedLoad[columnNumber].SetValue(null);
                }
                catch (Exception)
                {
                    throw new Exception(string.Format("Template cell {0} is not present. A template row must have all the column cells filled.", columnNumber));
                }
            }

            uint row = 2;
            List<XRow> extraRows = spreadsheet.XRows.Where(x => x.RowNumber >= row).ToList();
            foreach (XRow xrow in extraRows)
            {
                spreadsheet.RemoveXRow(xrow);
            }

            ReportViewModel runValues = spreadsheet.RunObject as ReportViewModel;

            var querystart = db.DailyDispatch
                .AsNoTracking()
                .Where(x => x.DispatchGroup == DatabaseLists.DISPATCH_GROUP_OTR)
                .Include(x => x.Carrier);

            if (runValues.CarrierID.HasValue)
            {
                querystart = querystart.Where(x => x.CarrierID == runValues.CarrierID.Value);
            }
            else
            {
                querystart = querystart.Where(x => x.CarrierID.HasValue);
            }
            
            var query = querystart
                .Include(x => x.Loads)
                .Include(x => x.Loads.Select(a => a.Store))
                .Include(x => x.LoadHistory)
                .Include(x => x.LoadHistory.Select(a => a.Store))
                .Include(x => x.LoadHistory.Select(a => a.Load).Select(a => a.Store));

            var query1 = querystart;

            var query2 = querystart;

            if (runValues.SelectedDate.HasValue)
            {
                query = query.Where(x => x.DispatchDate == runValues.SelectedDate.Value);
                query1 = query1.Where(x => x.DispatchDate == runValues.SelectedDate.Value);
                query2 = query2.Where(x => x.DispatchDate == runValues.SelectedDate.Value);
            }
            else
            {
                DateTime thruDate = runValues.ThruDate.Value.AddDays(1);
                query = query.Where(x =>
                    x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Any(y => y.EtaDate >= runValues.FromDate.Value && y.EtaDate < thruDate)
                    ||
                    x.LoadHistory.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Any(y => y.EtaDate >= runValues.FromDate.Value && y.EtaDate < thruDate));
                query1 = query1.Where(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Any(y => y.EtaDate >= runValues.FromDate.Value && y.EtaDate < thruDate));
                query2 = query2.Where(x => x.LoadHistory.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Any(y => y.EtaDate >= runValues.FromDate.Value && y.EtaDate < thruDate));
            }

            var query1list = query1.ToList();
            var query2list = query2.ToList();

            List<int> dispatchIDlist = new List<int>();
            dispatchIDlist.AddRange(query1list.Select(x => x.DailyDispatchID));
            dispatchIDlist.AddRange(query2list.Select(x => x.DailyDispatchID));
            query = query.Where(x => dispatchIDlist.Contains(x.DailyDispatchID));

             // Sort by original store.
             query = query
                 .OrderBy(x => x.Carrier.Name)
                 .ThenByDescending(x => x.Generated)
                 .ThenBy(x => x.LoadHistory.FirstOrDefault().Store.CompanyID)
                 .ThenBy(x => x.LoadHistory.FirstOrDefault().Store.StoreNumber);

            foreach (var dispatch in query)
            {
                var loads = dispatch.Loads
                    .Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                    .OrderBy(x => x.DispatchLoadOrder);

                int loadCount = loads
                    .Count();

                int? origStoreID;
                int? noseStoreID = null;
                int? tailStoreID = null;

                DispatchLoadLinkHistory loadHistFirst = db.DispatchLoadLinkHistory
                    .AsNoTracking()
                    .Where(x => x.DailyDispatchID == dispatch.DailyDispatchID)
                    .Include(x => x.Store)
                    .Include(x => x.Load)
                    .Include(x => x.Load.Store)
                    .FirstOrDefault(x => x.DailyDispatchID == dispatch.DailyDispatchID);

                origStoreID = loadHistFirst != null ? loadHistFirst.StoreID : null;
                
                if (loadCount > 0)
                {
                    noseStoreID = loads.First().StoreID;
                    tailStoreID = loads.Last().StoreID;
                }
                
                if (dispatch.Generated)
                {
                    XRow templateToUse = loadCount > 0 ? templateXRow : templateXRow_NoLoad;

                    XRow newrow = spreadsheet.AddXRow(templateToUse, row++);

                    newrow[col.Trailer].SetValue(dispatch.Trailer);
                    newrow[col.Merchandise].SetValue("ORDER");
                    newrow[col.Carrier].SetValue(dispatch.Carrier.Name);
                    newrow[col.Miles].SetValue(dispatch.CarrierMiles);

                    if (loadHistFirst != null && loadHistFirst.Load != null && loadHistFirst.Load.EtaDate.HasValue)
                    {
                        newrow[col.DelveryDate].SetValue(loadHistFirst.Load.EtaDate.Value);
                    }

                    if (loadHistFirst != null)
                    {
                        if (loadHistFirst.Store != null && loadHistFirst.Load != null)
                        {
                            bool originalLoadIsACurrentLoad = dispatch.Loads.Any(x => x.Store != null && x.Store.StoreNumber == loadHistFirst.Store.StoreNumber && x.Store.CompanyID == loadHistFirst.Store.CompanyID);
                            
                            // Put the original nose load name in the Store column if there is a Load for it or there are no loads at all (i.e. cancelled)
                            if (originalLoadIsACurrentLoad || loadCount == 0)
                            {
                                string origStore = string.Format("{0}{1}", loadHistFirst.Store.StoreAndCompany, loadHistFirst.Load.StoreLoadType == "A" ? string.Empty : "-" + loadHistFirst.Load.StoreLoadType);
                                newrow[col.Store].SetValue(origStore);
                            }
                        }
                    }

                    if (loadCount == 0)
                    {
                        newrow[col.StoresAdded].SetValue("NO LOAD");
                        newrow[col.RefNumber].SetValue(null);
                    }
                    else
                    {
                        newrow[col.RefNumber].SetValue(dispatch.DailyDispatchID);
                        StringBuilder storesAdded = new StringBuilder();
                        foreach (var load in loads)
                        {
                            if (load.StoreID == origStoreID)
                            {
                                continue;
                            }

                            if (storesAdded.Length > 0)
                            {
                                storesAdded.Append(",");
                            }

                            string loadPosition = string.Empty;
                            if (load.StoreID == noseStoreID)
                            {
                                loadPosition = "(N)";
                            }
                            else if (load.StoreID == tailStoreID)
                            {
                                loadPosition = "(R)";
                            }

                            storesAdded.AppendFormat("{0}{2}{1}", load.Store.StoreAndCompany, loadPosition, load.StoreLoadType == "A" ? string.Empty : "-" + load.StoreLoadType);

                            if (load.EtaDate.HasValue && loadHistFirst != null && loadHistFirst.Load != null && loadHistFirst.Load.EtaDate.HasValue)
                            {
                                if (load.EtaDate.Value.Date != loadHistFirst.Load.EtaDate.Value.Date)
                                {
                                    storesAdded.AppendFormat(" Delv {0}", load.EtaDate.Value.ToString("d-MMM"));
                                }
                            }
                        }

                        newrow[col.StoresAdded].SetValue(storesAdded.ToString());
                    }
                }
                else if (runValues.IncludeCreatedDispatches)
                {
                    XRow newrow = spreadsheet.AddXRow(templateXRow_AddedLoad, row++);

                    newrow[col.Trailer].SetValue(dispatch.Trailer);
                    newrow[col.RefNumber].SetValue(dispatch.DailyDispatchID);
                    newrow[col.Merchandise].SetValue("ORDER");
                    newrow[col.Carrier].SetValue(dispatch.Carrier.Name);
                    newrow[col.Miles].SetValue(dispatch.CarrierMiles);

                    StringBuilder storesAdded = new StringBuilder();
                    DateTime? noseLoadEtaDate = null;
                    foreach (var load in loads)
                    {
                        if (storesAdded.Length > 0)
                        {
                            storesAdded.Append(",");
                        }

                        string loadPosition = string.Empty;
                        if (load.StoreID == noseStoreID)
                        {
                            newrow[col.Store].SetValue(string.Format("{0}{1}", load.Store.StoreAndCompany, load.StoreLoadType == "A" ? string.Empty : "-" + load.StoreLoadType));
                            if (load.EtaDate.HasValue)
                            {
                                newrow[col.DelveryDate].SetValue(load.EtaDate.Value);
                                noseLoadEtaDate = load.EtaDate.Value;
                            }

                            continue;
                        }
                        else if (load.StoreID == tailStoreID)
                        {
                            loadPosition = "(R)";
                        }

                        storesAdded.AppendFormat("{0}{2}{1}", load.Store.StoreAndCompany, loadPosition, load.StoreLoadType == "A" ? string.Empty : "-" + load.StoreLoadType);

                        if (load.EtaDate.HasValue && noseLoadEtaDate.HasValue && (load.EtaDate.Value.Date != noseLoadEtaDate.Value.Date))
                        {
                            storesAdded.AppendFormat(" Delv {0}", load.EtaDate.Value.ToString("d-MMM"));
                        }
                    }

                    newrow[col.StoresAdded].SetValue(storesAdded.ToString());
                }
            }

            return true;
        }

        #endregion
        
        #region Store Delivery Advisement Spreadsheet

        public ActionResult StoreAdvisement()
        {
            ReportViewModel viewModel = new ReportViewModel();

            StoreDeliveryAdvisementViewBag(viewModel);

            return View("StoreAdvisement", viewModel);
        }

        private void StoreDeliveryAdvisementViewBag(ReportViewModel viewModel)
        {
        }

        [HttpPost]
        public ActionResult StoreAdvisement(ReportViewModel viewModel)
        {
            if (!viewModel.SelectedDate.HasValue)
            {
                this.ModelState.AddModelError(string.Empty, "A Delivery Date must be specified.");
            }

            if (!ModelState.IsValid)
            {
                StoreDeliveryAdvisementViewBag(viewModel);
                return View(viewModel);
            }

            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream spreadsheetTemplate = assembly.GetManifestResourceStream("TransportationPortal.Templates.Store Advisement Template 1.xlsx");
            if (spreadsheetTemplate == null)
            {
                throw new Exception("Template not found");
            }

            using (MemoryStream mem = new MemoryStream())
            {
                spreadsheetTemplate.CopyTo(mem);
                spreadsheetTemplate.Close();

                XSpreadsheet spreadsheet = new XSpreadsheet
                {
                    Stream = mem,
                    SheetNumber = 1,
                    RunObject = viewModel
                };

                if (!spreadsheet.Update(CreateStoreAdvisementSpreadsheet))
                {
                    this.ModelState.AddModelError(string.Empty, "Spreadsheet generation ended prematurely.");
                    CarrierAdvisementViewBag(viewModel);
                    return View(viewModel);
                }

                return File(mem.ToArray(), "application/xlsx", string.Format("Store Advisement {0}.xlsx", viewModel.SelectedDate.Value.ToString("yyyy-MM-dd")));
            }
        }

        private bool CreateStoreAdvisementSpreadsheet(XSpreadsheet spreadsheet)
        {
            StoreAdvisementSpreadsheet col = new StoreAdvisementSpreadsheet();

            /*
             * Prepare spreadsheet.
             */

            XRow templateXRow = spreadsheet[2];
            XRow templateXRowFutureDelivery = spreadsheet[3];
            XRow templateXRowPastDelivery = spreadsheet[4];

            var fields = col.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
            foreach (FieldInfo field in fields)
            {
                uint columnNumber = (uint)field.GetValue(col);
                try
                {
                    templateXRow[columnNumber].SetValue(null);
                    templateXRowFutureDelivery[columnNumber].SetValue(null);
                    templateXRowPastDelivery[columnNumber].SetValue(null);
                }
                catch (Exception)
                {
                    throw new Exception(string.Format("Template cell {0} is not present. A template row must have all the column cells filled.", columnNumber));
                }
            }

            uint row = 2;
            List<XRow> extraRows = spreadsheet.XRows.Where(x => x.RowNumber >= row).ToList();
            foreach (XRow xrow in extraRows)
            {
                spreadsheet.RemoveXRow(xrow);
            }

            /*
             * Get data.
             */

            ReportViewModel runValues = spreadsheet.RunObject as ReportViewModel;

            DateTime deliveryDate = runValues.SelectedDate.Value;

            DateTime minDeliveryDate = db.DispatchDateControl.Where(y => !y.Closed).Select(y => y.DispatchDate).Min();

            var query = db.OpenDispatchesOrAnyOpenDeliveries(minDeliveryDate)
                .AsNoTracking()
                .Include(x => x.Carrier)
                .Include(x => x.Loads)
                .Include(x => x.Loads.Select(a => a.Store))
                .Include(x => x.LoadHistory.Select(a => a.Store))
                .Include(x => x.LoadHistory.Select(a => a.Load).Select(a => a.Store));

            query = query.Where(x =>
                x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Any(y => y.EtaDateOnly == deliveryDate)
                ||
                x.LoadHistory.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Any(y => y.Load.EtaDateOnly == deliveryDate));

            if (runValues.OnlyChangedDispatches)
            {
                query = query.Where(x =>
                    x.LoadHistory.Any(y => (y.EtaDate.HasValue && y.Load.EtaDate.HasValue) && (y.EtaDate != y.Load.EtaDate)) // store loads that have changed delivery dates
                    ||
                    x.Loads.Any(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD && !y.Generated) // store loads that have been created
                    ||
                    x.Loads.Any(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD && y.StoreLoadType != "A") // any "B" loads (generated or created)
                    ||
                    (x.Loads.Count(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD) > x.LoadHistory.Count())); // current store load count > original store load count
            }

            if (runValues.StoreAdvisementSort == ReportViewModel.StoreAdvisementSortEnum.Delivery_Date)
            {
                query = query.Sort(DispatchSortColumn.OutboundArrival, 1);
            }
            else if (runValues.StoreAdvisementSort == ReportViewModel.StoreAdvisementSortEnum.Store)
            {
                query = query.Sort(DispatchSortColumn.OutboundStore, 1);
            }

            /*
             * Build spreadsheet rows.
             */

            foreach (var dispatch in query)
            {
                var loads = dispatch.Loads
                    .Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                    .OrderBy(x => x.DispatchLoadOrder);

                DispatchLoadLinkHistory loadHist = dispatch.LoadHistory
                    .FirstOrDefault(x => x.DailyDispatchID == dispatch.DailyDispatchID);

                string carrierName = dispatch.CarrierID.HasValue ? dispatch.Carrier.Name : "HL";

                // Added EtaDateOnly == selected date because the dispatch should only be reported is one of the delivery dates is the selected date. 
                if (loads.Any() && loads.Any(x => x.EtaDateOnly == deliveryDate)) 
                {
                    foreach (var load in loads)
                    {
                        XRow templateToUse;
                        if (load.EtaDate.Value.Date > deliveryDate)
                        {
                            templateToUse = templateXRowFutureDelivery;
                        }
                        else if (load.EtaDate.Value.Date < deliveryDate)
                        {
                            templateToUse = templateXRowPastDelivery;
                        }
                        else
                        {
                            templateToUse = templateXRow;
                        }

                        XRow newrow = spreadsheet.AddXRow(templateToUse, row++);

                        string storeLoad = string.Format("{0}{1}", load.Store.StoreAndCompany, load.StoreLoadType == "A" ? string.Empty : "-" + load.StoreLoadType);

                        newrow[col.Store].SetValue(storeLoad);
                        newrow[col.Name].SetValue(null);
                        newrow[col.Time].SetValue(null);

                        newrow[col.Carrier].SetValue(carrierName);
                        carrierName = "\"";

                        newrow[col.Bflag].SetValue(null);
                        newrow[col.Sflag].SetValue(null);
                        newrow[col.Fflag].SetValue(null);

                        newrow[col.DeliveryDate].SetValue(load.EtaDate);
                        newrow[col.DeliveryTime].SetValue(load.EtaDate);

                        string delta = null;

                        if (!load.Generated)
                        {
                            delta = "Added";
                        }
                        else if (!dispatch.LoadHistory.Select(x => x.LoadID).Contains(load.LoadID))
                        {
                            delta = "Added";
                        }
                        else
                        {
                            DispatchLoadLinkHistory history = dispatch.LoadHistory.FirstOrDefault(x => x.LoadID == load.LoadID);
                            if (history != null)
                            {
                                if (load.EtaDate != history.EtaDate)
                                {
                                    delta = string.Format("Previous Delv: {0:g}", history.EtaDate);
                                }
                            }
                        }

                        newrow[col.Change].SetValue(delta);
                    }

                    // Add blank line.
                    spreadsheet.AddXRow(templateXRow, row++);
                }
            }

            return true;
        }

        #endregion
        
        #region Carrier Charges Spreadsheet

        public ActionResult CarrierCharges()
        {
            ReportViewModel viewModel = new ReportViewModel();

            CarrierChargesViewBag(viewModel);

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult CarrierCharges(ReportViewModel viewModel)
        {
            if (viewModel.DailyDispatchIDSelection != null && viewModel.DailyDispatchIDSelection.Where(x => x.HasValue && x > 0).Any())
            {
                if (viewModel.FromDate.HasValue || viewModel.ThruDate.HasValue)
                {
                    this.ModelState.AddModelError(string.Empty, "Dates and Reference Numbers cannot be used together.");
                }
            }
            else
            {
                if (!viewModel.FromDate.HasValue)
                {
                    this.ModelState.AddModelError(string.Empty, "From-Date must be specified");
                }

                if (viewModel.FromDate.HasValue && viewModel.ThruDate.HasValue &&
                    viewModel.ThruDate.Value < viewModel.FromDate.Value)
                {
                    this.ModelState.AddModelError(string.Empty, "Through-Date must be on or after the From-Date");
                }
            }
            
            if (!ModelState.IsValid)
            {
                CarrierChargesViewBag(viewModel);
                return View(viewModel);
            }

            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream spreadsheetTemplate = assembly.GetManifestResourceStream("TransportationPortal.Templates.Carrier Charges Template 1.xlsx");

            using (MemoryStream mem = new MemoryStream())
            {
                spreadsheetTemplate.CopyTo(mem);
                spreadsheetTemplate.Close();
            
                XSpreadsheet spreadsheet = new XSpreadsheet
                {
                    Stream = mem,
                    SheetNumber = 1,
                    RunObject = viewModel
                };

                if (!spreadsheet.Update(CreateCarrierChargesSpreadsheet))
                {
                    this.ModelState.AddModelError(string.Empty, "Spreadsheet generation ended prematurely.");
                    CarrierChargesViewBag(viewModel);
                    return View(viewModel);
                }

                return File(mem.ToArray(), "application/xlsx", "Carrier Charges.xlsx");
            }
        }

        private bool CreateCarrierChargesSpreadsheet(XSpreadsheet spreadsheet)
        {
            CarrierChargeSpreadsheet col = new CarrierChargeSpreadsheet();

            List<XRow> extraRows = spreadsheet.XRows.Where(x => x.RowNumber > 2).ToList();
            foreach (XRow xrow in extraRows)
            {
                spreadsheet.RemoveXRow(xrow);
            }

            XRow templateXRow = spreadsheet[2];
            if (templateXRow != null)
            {
                spreadsheet.RemoveXRow(templateXRow);
            }
            else
            {
                throw new Exception(string.Format("Template XRow not found."));
            }

            var fields = col.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
            foreach (FieldInfo field in fields)
            {
                uint columnNumber = (uint)field.GetValue(col);
                try
                {
                    templateXRow[columnNumber].SetValue(null);
                }
                catch (Exception)
                {
                    throw new Exception(string.Format("Template cell {0} is not present. A template row must have all the column cells filled.", columnNumber));
                }
            }

            ReportViewModel runValues = spreadsheet.RunObject as ReportViewModel;

            var query = db.DailyDispatch
                .AsNoTracking()
                .Include(x => x.Carrier)
                .Include(x => x.Loads)
                .Include(x => x.Loads.Select(y => y.Store))
                .Where(x => x.Loads.Any(y => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(y.LoadType)));

            if (runValues.CarrierID.HasValue)
            {
                query = query.Where(x => x.CarrierID == runValues.CarrierID.Value);
            }
            else
            {
                query = query.Where(x => x.CarrierID.HasValue);
            }
            
            switch (runValues.CarrierChargesDataType)
            {
                case ReportViewModel.CarrierChargesDataTypeEnum.Sendout:
                    query = query.Where(x => !x.Generated);
                    break;
                default:
                case ReportViewModel.CarrierChargesDataTypeEnum.Orders:
                    query = query.Where(x => x.Generated);
                    break;
            }

            // Select Dispatches with Nose Loads matching the from-date
            if (runValues.DailyDispatchIDSelection != null && runValues.DailyDispatchIDSelection.Where(x => x.HasValue && x > 0).Any())
            {
                query = query
                    .Where(x => runValues.DailyDispatchIDSelection.Where(a => a.HasValue && a > 0).Contains(x.DailyDispatchID));
            }
            else
            {
                query = query.Where(x =>
                    x.Loads
                    .Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                    .OrderBy(y => y.DispatchLoadOrder)
                    .FirstOrDefault().EtaDateOnly >= runValues.FromDate.Value);

                if (runValues.ThruDate.HasValue)
                {
                    query = query.Where(x =>
                        x.Loads
                        .Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                        .OrderBy(y => y.DispatchLoadOrder)
                        .FirstOrDefault().EtaDateOnly <= runValues.ThruDate.Value);
                }

                query = query.Sort(DispatchSortColumn.OutboundArrival, 1);
            }
            
            uint row = 2;
            
            foreach (var record in query)
            {
                XRow newrow = spreadsheet.AddXRow(templateXRow, row++);

                var loads = record.Loads
                    .Where(x => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(x.LoadType))
                    .OrderByDescending(x => x.DispatchLoadOrder);

                newrow[col.RefNumber].SetValue(record.DailyDispatchID);

                int storeCount = loads.Count();
                if (storeCount >= 1)
                {
                    newrow[col.Date].SetValue(loads.ElementAt(0).EtaDate);
                    newrow[col.Store1].SetValue(loads.ElementAt(0).Store.StoreAndCompany);
                }

                if (storeCount >= 2)
                {
                    newrow[col.Store2].SetValue(loads.ElementAt(1).Store.StoreAndCompany);
                }

                if (storeCount >= 3)
                {
                    newrow[col.Store3].SetValue(loads.ElementAt(2).Store.StoreAndCompany);
                }

                if (storeCount == 4)
                {
                    newrow[col.Store4].SetValue(loads.ElementAt(3).Store.StoreAndCompany);
                }

                newrow[col.TotalCharge].SetValue(record.CarrierTotalCharge);
                newrow[col.Carrier].SetValue(record.Carrier.Name);

                newrow[col.Trailer].SetValue(record.Trailer);

                newrow[col.Miles].SetValue(record.CarrierMiles);

                int? dispatchPalletTotal = record.Loads
                    .Where(x => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(x.LoadType))
                    .Sum(x => x.Pallets);
                if (dispatchPalletTotal.HasValue && dispatchPalletTotal > 0)
                {
                    newrow[col.Pallets].SetValue(dispatchPalletTotal);
                }

                var dispatchLoadTypes = record.Loads
                    .Select(x => x.LoadType);
                if (dispatchLoadTypes.Any(x => DatabaseLists.INBOUND_LOAD_TYPES.Contains(x)) &&
                    dispatchLoadTypes.Any(x => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(x)))
                {
                    newrow[col.RoundTrip].SetValue("Y");
                }
                else
                {
                    newrow[col.RoundTrip].SetValue("N");
                }

                switch (runValues.CarrierChargesDataType)
                {
                    case ReportViewModel.CarrierChargesDataTypeEnum.Sendout:
                        newrow[col.ID].SetValue("T");
                        break;
                    default:
                    case ReportViewModel.CarrierChargesDataTypeEnum.Orders:
                        newrow[col.ID].SetValue("TB");
                        break;
                }
            }

            return true;
        }

        private void CarrierChargesViewBag(ReportViewModel viewModel)
        {
            var carriers = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .OrderBy(x => x.Name)
                .Select(x => new
                {
                    Text = x.Name,
                    Value = x.CarrierID
                });

            if (viewModel == null)
            {
                ViewBag.CarrierID = new SelectList(carriers, "Value", "Text");
            }
            else
            {
                ViewBag.CarrierID = new SelectList(carriers, "Value", "Text", viewModel.CarrierID);
            }

            ViewBag.CarrierChargesDataType = Extensions.BuildSelectList<ReportViewModel.CarrierChargesDataTypeEnum>();
        }

        #endregion

        #region Backhaul Report (ABF) (BH_export.xlsx)

        public ActionResult BackhaulReport()
        {
            ReportViewModel viewModel = new ReportViewModel();

            BackhaulReportViewBag(viewModel);

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult BackhaulReport(ReportViewModel viewModel)
        {
            if (!viewModel.FromDate.HasValue && string.IsNullOrWhiteSpace(viewModel.LookupString))
            {
                this.ModelState.AddModelError(string.Empty, "From-Date must be specified or Search values entered.");
            }

            if (viewModel.FromDate.HasValue && viewModel.ThruDate.HasValue &&
                viewModel.ThruDate.Value < viewModel.FromDate.Value)
            {
                this.ModelState.AddModelError(string.Empty, "Dispatch Through-Date must be on or after the From-Date.");
            }

            if (viewModel.HobbyLobbyOnly)
            {
                if (viewModel.CarrierIDs != null && viewModel.CarrierIDs.Any())
                {
                    this.ModelState.AddModelError(string.Empty, "Cannot choose 'Hobby Lobby Only' and select any Carriers.");
                }
            }
            else
            {
                if (viewModel.CarrierIDs == null || !viewModel.CarrierIDs.Any())
                {
                    this.ModelState.AddModelError(string.Empty, "One or more Carriers must be specified");
                }
            }

            if (!ModelState.IsValid)
            {
                BackhaulReportViewBag(viewModel);
                return View(viewModel);
            }

            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream spreadsheetTemplate = assembly.GetManifestResourceStream("TransportationPortal.Templates.Backhaul Report Template 1.xlsx");

            using (MemoryStream mem = new MemoryStream())
            {
                spreadsheetTemplate.CopyTo(mem);
                spreadsheetTemplate.Close();

                XSpreadsheet spreadsheet = new XSpreadsheet
                {
                    Stream = mem,
                    SheetNumber = 1,
                    RunObject = viewModel
                };

                if (!spreadsheet.Update(CreateBackhaulReportSpreadsheet))
                {
                    this.ModelState.AddModelError(string.Empty, "Spreadsheet generation ended prematurely.");
                    BackhaulReportViewBag(viewModel);
                    return View(viewModel);
                }

                return File(mem.ToArray(), "application/xlsx", "BH_export.xlsx");
            }
        }

        private bool CreateBackhaulReportSpreadsheet(XSpreadsheet spreadsheet)
        {
            BackhaulReportSpreadsheet col = new BackhaulReportSpreadsheet();

            ReportViewModel runValues = spreadsheet.RunObject as ReportViewModel;

            List<XRow> extraRows = spreadsheet.XRows.Where(x => x.RowNumber > 3).ToList();
            foreach (XRow xrow in extraRows)
            {
                spreadsheet.RemoveXRow(xrow);
            }

            XRow templateXRowPlain = spreadsheet[2];
            if (templateXRowPlain != null)
            {
                spreadsheet.RemoveXRow(templateXRowPlain);
            }
            else
            {
                throw new Exception(string.Format("Template XRow for Plain not found."));
            }

            XRow templateXRowShaded = spreadsheet[3];
            if (templateXRowShaded != null)
            {
                spreadsheet.RemoveXRow(templateXRowShaded);
            }
            else
            {
                throw new Exception(string.Format("Template XRow for Shaded not found."));
            }

            var fields = col.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
            foreach (FieldInfo field in fields)
            {
                uint columnNumber = (uint)field.GetValue(col);
                try
                {
                    templateXRowPlain[columnNumber].SetValue(null);
                    templateXRowShaded[columnNumber].SetValue(null);
                }
                catch (Exception)
                {
                    throw new Exception(string.Format("Template cell {0} is not present. A template row must have all the column cells filled.", columnNumber));
                }
            }

            IQueryable<DailyDispatch> dispatches;

            if (runValues.HobbyLobbyOnly)
            {
                dispatches = db.DailyDispatch
                    .AsNoTracking()
                    .Include(x => x.Loads)
                    .Include(x => x.Loads.Select(y => y.PickupCompany))
                    .Where(x => x.DispatchGroup == DatabaseLists.DISPATCH_GROUP_OTR);
            }
            else
            {
                dispatches = db.DailyDispatch
                    .AsNoTracking()
                    .Include(x => x.Carrier)
                    .Include(x => x.Loads)
                    .Include(x => x.Loads.Select(y => y.PickupCompany))
                    .Where(x => x.DispatchGroup == DatabaseLists.DISPATCH_GROUP_OTR);
            }

            if (runValues.FromDate.HasValue && runValues.ThruDate.HasValue)
            {
                DateTime thruDate = runValues.ThruDate.Value.Date.AddDays(1);
            
                switch (runValues.BackhaulReportDateRangeSource)
                {
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Ready_Date:
                        dispatches = dispatches.Where(x => x.Loads.Any(y => y.ReadyDate >= runValues.FromDate.Value && y.ReadyDate < thruDate));
                        break;
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Pickup_Date:
                        dispatches = dispatches.Where(x => x.Loads.Any(y => y.PickupDate >= runValues.FromDate.Value && y.PickupDate < thruDate));
                        break;
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Carrier_Charge_Change_Date:
                        dispatches = dispatches.Where(x => x.CarrierTotalChargeChanged >= runValues.FromDate.Value && x.CarrierTotalChargeChanged < thruDate);
                        break;
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Dispatch_Date:
                    default:
                        dispatches = dispatches.Where(x => x.DispatchDate >= runValues.FromDate.Value && x.DispatchDate < thruDate);
                        break;
                }
            }
            else if (runValues.FromDate.HasValue)
            {
                switch (runValues.BackhaulReportDateRangeSource)
                {
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Ready_Date:
                        dispatches = dispatches.Where(x => x.Loads.Any(y => y.ReadyDate >= runValues.FromDate.Value));
                        break;
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Pickup_Date:
                        dispatches = dispatches.Where(x => x.Loads.Any(y => y.PickupDate >= runValues.FromDate.Value));
                        break;
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Carrier_Charge_Change_Date:
                        dispatches = dispatches.Where(x => x.CarrierTotalChargeChanged >= runValues.FromDate.Value);
                        break;
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Dispatch_Date:
                    default:
                        dispatches = dispatches.Where(x => x.DispatchDate >= runValues.FromDate.Value);
                        break;
                }
            }
            else if (runValues.ThruDate.HasValue)
            {
                DateTime thruDate = runValues.ThruDate.Value.Date.AddDays(1);
                switch (runValues.BackhaulReportDateRangeSource)
                {
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Ready_Date:
                        dispatches = dispatches.Where(x => x.Loads.Any(y => y.ReadyDate < thruDate));
                        break;
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Pickup_Date:
                        dispatches = dispatches.Where(x => x.Loads.Any(y => y.PickupDate < thruDate));
                        break;
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Carrier_Charge_Change_Date:
                        dispatches = dispatches.Where(x => x.CarrierTotalChargeChanged < thruDate);
                        break;
                    case ReportViewModel.BackhaulReportDateRangeSourceEnum.Dispatch_Date:
                    default:
                        dispatches = dispatches.Where(x => x.DispatchDate < thruDate);
                        break;
                }
            }

            if (runValues.HobbyLobbyOnly)
            {
                dispatches = dispatches.Where(x => !x.CarrierID.HasValue);
            }
            else if (runValues.CarrierIDs != null && runValues.CarrierIDs.Any())
            {
                dispatches = dispatches.Where(x => x.CarrierID.HasValue && runValues.CarrierIDs.Contains(x.CarrierID.Value));
            }
            else
            {
                throw new ArgumentException("Hobby Lobby Only = false but no Carriers selected.");
            }

            if (!string.IsNullOrWhiteSpace(runValues.LookupString))
            {
                string[] lookupStringValues = runValues.LookupString.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

                List<int> lookupIntegerValues = new List<int>();

                foreach (string s in lookupStringValues)
                {
                    int i = 0;
                    if (int.TryParse(s, out i))
                    {
                        if (i > 0)
                        {
                            lookupIntegerValues.Add(i);
                        }
                    }
                }

                switch (runValues.BackhaulReportSearchSource)
                {
                    case ReportViewModel.BackhaulReportSearchSourceEnum.Dispatch_Numbers:
                        dispatches = dispatches.Where(x => lookupIntegerValues.Contains(x.DailyDispatchID));
                        break;
                    case ReportViewModel.BackhaulReportSearchSourceEnum.Load_Numbers:
                        dispatches = dispatches.Where(x => x.Loads.Any(y => lookupIntegerValues.Contains(y.LoadID)));
                        break;
                    case ReportViewModel.BackhaulReportSearchSourceEnum.PO_Numbers:
                        List<IQueryable<DailyDispatch>> unions = new List<IQueryable<DailyDispatch>>();
                        foreach (string s in lookupStringValues)
                        {
                            string pattern = "%" + s.Trim() + "%";
                            unions.Add(dispatches.Where(x => x.Loads.Any(y => SqlFunctions.PatIndex(pattern, y.PO1) > 0 || SqlFunctions.PatIndex(pattern, y.PO2) > 0)));
                        }

                        dispatches = unions[0];
                        if (unions.Count > 1)
                        {
                            for (int u = 1; u < unions.Count; u++)
                            {
                                dispatches = dispatches.Concat(unions[u]);
                            }
                        }

                        break;
                }
            }

            dispatches = dispatches.OrderBy(x => x.DispatchDate);

            uint row = 2;

            XRow templateRow = templateXRowPlain;

            foreach (var dispatch in dispatches)
            {
                var backhauls = dispatch.Loads.Where(x => x.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL);

                if (!backhauls.Any())
                {
                    continue;
                }

                bool first = true;

                templateRow = templateRow == templateXRowPlain ? templateXRowShaded : templateXRowPlain;

                foreach (var load in backhauls)
                {
                    XRow newrow = spreadsheet.AddXRow(templateRow, row++);

                    switch (runValues.BackhaulReportDateRangeSource)
                    {
                        case ReportViewModel.BackhaulReportDateRangeSourceEnum.Ready_Date:
                            newrow[col.Date].SetValue(load.ReadyDate);
                            break;
                        case ReportViewModel.BackhaulReportDateRangeSourceEnum.Pickup_Date:
                            newrow[col.Date].SetValue(load.PickupDate);
                            break;
                        case ReportViewModel.BackhaulReportDateRangeSourceEnum.Carrier_Charge_Change_Date:
                            newrow[col.Date].SetValue(dispatch.CarrierTotalChargeChanged);
                            break;
                        case ReportViewModel.BackhaulReportDateRangeSourceEnum.Dispatch_Date:
                        default:
                            newrow[col.Date].SetValue(dispatch.DispatchDate);
                            break;
                    }

                    newrow[col.RefNumber].SetValue(dispatch.DailyDispatchID);

                    if (runValues.HobbyLobbyOnly)
                    {
                        newrow[col.Carrier].SetValue("Hobby Lobby");
                    }
                    else
                    {
                        newrow[col.Carrier].SetValue(dispatch.Carrier.Name);
                    }

                    if (first)
                    {
                        newrow[col.Rate].SetValue(dispatch.CarrierTotalCharge);
                    }

                    newrow[col.Vendor].SetValue(load.PickupCompany.Name);
                    newrow[col.City].SetValue(load.PickupCompany.City);
                    newrow[col.State].SetValue(load.PickupCompany.StateCode);
                    newrow[col.Zip].SetValue(load.PickupCompany.Zip);
                    newrow[col.PO1].SetValue(load.PO1);
                    newrow[col.PO2].SetValue(load.PO2);
                    newrow[col.Pallets].SetValue(load.Pallets);
                    newrow[col.Cartons].SetValue(load.Cartons);
                    newrow[col.Weight].SetValue(load.Weight);

                    newrow[col.InvNum].SetValue(null);
                    newrow[col.InvAmt].SetValue(null);
                    newrow[col.DateCompleted].SetValue(null);
                    newrow[col.Difference].SetValue(null);
                    newrow[col.Notes].SetValue(null);

                    first = false;
                }
            }

            return true;
        }

        private void BackhaulReportViewBag(ReportViewModel viewModel)
        {
            var carrierList = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .OrderBy(x => x.Name)
                .ToList()
                .Select(x => new
                {
                    Value = x.CarrierID,
                    Text = x.Name
                });

            if (viewModel == null)
            {
                viewModel.CarrierSelectList = new MultiSelectList(carrierList, "Value", "Text");
            }
            else
            {
                viewModel.CarrierSelectList = new MultiSelectList(carrierList, "Value", "Text", viewModel.CarrierIDs);
            }
        }

        #endregion

        #region Backhaul Tracking (BHTrackM-D-Y.xlsx)

        public ActionResult BackhaulTracking()
        {
            ReportViewModel viewModel = new ReportViewModel();

            BackhaulTrackingViewBag(viewModel);

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult BackhaulTracking(ReportViewModel viewModel)
        {
            if (viewModel.FromDate.HasValue && viewModel.ThruDate.HasValue &&
                viewModel.ThruDate.Value < viewModel.FromDate.Value)
            {
                this.ModelState.AddModelError(string.Empty, "Dispatch Through-Date must be on or after the From-Date");
            }

            if (!ModelState.IsValid)
            {
                BackhaulReportViewBag(viewModel);
                return View(viewModel);
            }

            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream spreadsheetTemplate = assembly.GetManifestResourceStream("TransportationPortal.Templates.Backhaul Tracking Template 1.xlsx");

            using (MemoryStream mem = new MemoryStream())
            {
                spreadsheetTemplate.CopyTo(mem);
                spreadsheetTemplate.Close();

                XSpreadsheet spreadsheet = new XSpreadsheet
                {
                    Stream = mem,
                    SheetNumber = 1,
                    RunObject = viewModel
                };

                if (!spreadsheet.Update(CreateBackhaulTrackingSpreadsheet))
                {
                    this.ModelState.AddModelError(string.Empty, "Spreadsheet generation ended prematurely.");
                    BackhaulTrackingViewBag(viewModel);
                    return View(viewModel);
                }

                return File(mem.ToArray(), "application/xlsx", string.Format("BHTrack{0}.xlsx", DateTime.Today.ToString("MM-dd-yyyy")));
            }
        }

        private bool CreateBackhaulTrackingSpreadsheet(XSpreadsheet spreadsheet)
        {
            BackhaulTrackingSpreadsheet col = new BackhaulTrackingSpreadsheet();

            ReportViewModel runValues = spreadsheet.RunObject as ReportViewModel;

            // Get the first data row to use as a template for Hobby Lobby dispatches.
            XRow templateXRow = spreadsheet[2];
            if (templateXRow != null)
            {
                spreadsheet.RemoveXRow(templateXRow);
            }
            else
            {
                throw new Exception(string.Format("Template XRow not found."));
            }

            var fields = col.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
            foreach (FieldInfo field in fields)
            {
                uint columnNumber = (uint)field.GetValue(col);
                try
                {
                    templateXRow[columnNumber].SetValue(null);
                }
                catch (Exception)
                {
                    throw new Exception(string.Format("Template cell {0} is not present. A template row must have all the column cells filled.", columnNumber));
                }
            }

            // Get the second header row. To be inserted when listing carrier dispatches.
            XRow secondHeaderXRow = spreadsheet[3];
            if (secondHeaderXRow != null)
            {
                spreadsheet.RemoveXRow(secondHeaderXRow);
            }
            else
            {
                throw new Exception(string.Format("Second Header XRow not found."));
            }

            // Remove all rows past the header.
            List<XRow> extraRows = spreadsheet.XRows.Where(x => x.RowNumber > 2).ToList();
            foreach (XRow xrow in extraRows)
            {
                spreadsheet.RemoveXRow(xrow);
            }

            // Begin processing
            uint row = 2;

            var hobbyLoads = db.Load
                .AsNoTracking()
                .Include(x => x.PickupCompany)
                .Include(x => x.DailyDispatch)
                .Include(x => x.DailyDispatch.Carrier)
                .Where(x => x.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                .Where(x => !x.SourceLoadID.HasValue)
                .Where(x => x.DailyDispatchID.HasValue)
                .Where(x => !x.DailyDispatch.CarrierID.HasValue);

            if (runValues.FromDate.HasValue)
            {
                hobbyLoads = hobbyLoads.Where(x => x.PickupDate >= runValues.FromDate.Value);
            }

            if (runValues.ThruDate.HasValue)
            {
                DateTime nextDay = runValues.ThruDate.Value.AddDays(1);
                hobbyLoads = hobbyLoads.Where(x => x.PickupDate < nextDay);
            }

            if (!runValues.IncludeWorkedLoads)
            {
                hobbyLoads = hobbyLoads.Where(x => !x.WorkDate.HasValue);
            }

            hobbyLoads = hobbyLoads
                .OrderBy(x => x.PickupDate)
                .ThenBy(x => x.DailyDispatchID);

            foreach (var load in hobbyLoads)
            {
                XRow newrow = spreadsheet.AddXRow(templateXRow, row++);

                newrow[col.PickupDate].SetValue(load.PickupDate);
                newrow[col.Trailer].SetValue(load.DailyDispatch.TrailerIn);
                newrow[col.Vendor].SetValue(load.PickupCompany.Name);
                newrow[col.Pallets].SetValue(load.Pallets);
                newrow[col.Zone].SetValue(load.Zone);
                newrow[col.PO1].SetValue(load.PO1);
                newrow[col.PO2].SetValue(load.PO2);
                newrow[col.EtaDate].SetValue(load.EtaDate);
                newrow[col.DateWorked].SetValue(load.WorkDate);
            }

            // Add the second header
            spreadsheet.AddXRow(secondHeaderXRow, row++);

            var carrierLoads = db.Load
                .AsNoTracking()
                .Include(x => x.PickupCompany)
                .Include(x => x.DailyDispatch)
                .Include(x => x.DailyDispatch.Carrier)
                .Where(x => x.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                .Where(x => x.DailyDispatchID.HasValue)
                .Where(x => x.DailyDispatch.CarrierID.HasValue);
            
            if (runValues.FromDate.HasValue)
            {
                carrierLoads = carrierLoads.Where(x => x.PickupDate >= runValues.FromDate.Value);
            }

            if (runValues.ThruDate.HasValue)
            {
                DateTime nextDay = runValues.ThruDate.Value.AddDays(1);
                carrierLoads = carrierLoads.Where(x => x.PickupDate < nextDay);
            }

            if (!runValues.IncludeWorkedLoads)
            {
                carrierLoads = carrierLoads.Where(x => !x.WorkDate.HasValue);
            }

            carrierLoads = carrierLoads
                .OrderBy(x => x.PickupDate)
                .ThenBy(x => x.DailyDispatchID);

            foreach (var load in carrierLoads)
            {
                XRow newrow = spreadsheet.AddXRow(templateXRow, row++);

                newrow[col.PickupDate].SetValue(load.PickupDate);
                newrow[col.Trailer].SetValue(load.DailyDispatch.Carrier.Name);
                newrow[col.Vendor].SetValue(load.PickupCompany.Name);
                newrow[col.Pallets].SetValue(load.Pallets);
                newrow[col.Zone].SetValue(load.Zone);
                newrow[col.PO1].SetValue(load.PO1);
                newrow[col.PO2].SetValue(load.PO2);
                newrow[col.EtaDate].SetValue(load.EtaDate);
                newrow[col.DateWorked].SetValue(load.WorkDate);
            }

            return true;
        }

        private void BackhaulTrackingViewBag(ReportViewModel viewModel)
        {
            var carrierList = db.Carrier
                .ActiveFilter(includeDeleted: this.AdministrativeSettings().AdminEditMode)
                .OrderBy(x => x.Name)
                .ToList()
                .Select(x => new
                {
                    Value = x.CarrierID,
                    Text = x.Name
                });

            if (viewModel == null)
            {
                viewModel.CarrierSelectList = new MultiSelectList(carrierList, "Value", "Text");
            }
            else
            {
                viewModel.CarrierSelectList = new MultiSelectList(carrierList, "Value", "Text", viewModel.CarrierIDs);
            }
        }

        #endregion

        #region Broker Load List (Broker Loads.xlsx)

        public ActionResult BrokerLoads()
        {
            ReportViewModel viewModel = new ReportViewModel();

            BrokerLoadListReportViewBag(viewModel);

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult BrokerLoads(ReportViewModel viewModel)
        {
            if (!viewModel.FromDate.HasValue)
            {
                this.ModelState.AddModelError(string.Empty, "From-Date must be specified.");
            }

            if (viewModel.FromDate.HasValue && viewModel.ThruDate.HasValue &&
                viewModel.ThruDate.Value < viewModel.FromDate.Value)
            {
                this.ModelState.AddModelError(string.Empty, "Through-Date must be on or after the From-Date");
            }

            if (!ModelState.IsValid)
            {
                BrokerLoadListReportViewBag(viewModel);
                return View(viewModel);
            }

            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream spreadsheetTemplate = assembly.GetManifestResourceStream("TransportationPortal.Templates.Broker Load List Template 1.xlsx");

            using (MemoryStream mem = new MemoryStream())
            {
                spreadsheetTemplate.CopyTo(mem);
                spreadsheetTemplate.Close();

                XSpreadsheet spreadsheet = new XSpreadsheet
                {
                    Stream = mem,
                    SheetNumber = 1,
                    RunObject = viewModel
                };

                if (!spreadsheet.Update(CreateBrokerLoadSpreadsheet))
                {
                    this.ModelState.AddModelError(string.Empty, "Spreadsheet generation ended prematurely.");
                    BackhaulReportViewBag(viewModel);
                    return View(viewModel);
                }

                return File(mem.ToArray(), "application/xlsx", "Broker Loads.xlsx");
            }
        }

        private bool CreateBrokerLoadSpreadsheet(XSpreadsheet spreadsheet)
        {
            BrokerLoadListSpreadsheet col = new BrokerLoadListSpreadsheet();

            int templateRowCount = 2;

            ReportViewModel runValues = spreadsheet.RunObject as ReportViewModel;

            List<XRow> extraRows = spreadsheet.XRows.Where(x => x.RowNumber > templateRowCount).ToList();
            foreach (XRow xrow in extraRows)
            {
                spreadsheet.RemoveXRow(xrow);
            }

            XRow templateXRowPlain = spreadsheet[2];
            if (templateXRowPlain != null)
            {
                spreadsheet.RemoveXRow(templateXRowPlain);
            }
            else
            {
                throw new Exception(string.Format("Template XRow for Plain not found."));
            }

            XRow templateXRowShaded = templateXRowPlain;

            var fields = col.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
            foreach (FieldInfo field in fields)
            {
                uint columnNumber = (uint)field.GetValue(col);
                try
                {
                    templateXRowPlain[columnNumber].SetValue(null);
                }
                catch (Exception)
                {
                    throw new Exception(string.Format("Template cell {0} is not present. A template row must have all the column cells filled.", columnNumber));
                }
            }

            var query = db.Load
                .AsNoTracking()
                .Include(x => x.LoadCompany)
                .Include(x => x.PickupCompany)
                .Include(x => x.DeliveryCompany)
                .Where(x => x.LoadType == DatabaseLists.INBOUND_BROKER_LOAD)
                .Where(x => !x.SourceLoadID.HasValue);

            if (runValues.FromDate.HasValue)
            {
                switch (runValues.BrokerLoadDateRangeSource)
                {
                    case ReportViewModel.BrokerLoadDateRangeSourceEnum.Delivery_Date:
                        query = query.Where(x => x.EtaDate >= runValues.FromDate.Value);
                        break;
                    case ReportViewModel.BrokerLoadDateRangeSourceEnum.Invoice_Date:
                        query = query.Where(x => x.InvoiceDate >= runValues.FromDate.Value);
                        break;
                    case ReportViewModel.BrokerLoadDateRangeSourceEnum.Pickup_Date:
                    default:
                        query = query.Where(x => x.PickupDate >= runValues.FromDate.Value);
                        break;
                }
            }

            if (runValues.ThruDate.HasValue)
            {
                DateTime thruDate = runValues.ThruDate.Value.Date.AddDays(1);
                switch (runValues.BrokerLoadDateRangeSource)
                {
                    case ReportViewModel.BrokerLoadDateRangeSourceEnum.Delivery_Date:
                        query = query.Where(x => x.EtaDate < thruDate);
                        break;
                    case ReportViewModel.BrokerLoadDateRangeSourceEnum.Invoice_Date:
                        query = query.Where(x => x.InvoiceDate < thruDate);
                        break;
                    case ReportViewModel.BrokerLoadDateRangeSourceEnum.Pickup_Date:
                    default:
                        query = query.Where(x => x.PickupDate < thruDate);
                        break;
                }
            }

            if (runValues.BrokerID.HasValue)
            {
                query = query.Where(x => x.LoadCompanyID == runValues.BrokerID.Value);
            }

            switch (runValues.InvoiceStatus)
            {
                case ReportViewModel.InvoiceStatusEnum.Invoiced:
                    query = query.Where(x => x.InvoiceDate.HasValue);
                    break;
                case ReportViewModel.InvoiceStatusEnum.Not_Invoiced:
                    query = query.Where(x => !x.InvoiceDate.HasValue);
                    break;
            }

            switch (runValues.BrokerLoadSort)
            {
                case ReportViewModel.BrokerLoadSortEnum.Broker_Name:
                    query = query.OrderBy(x => x.LoadCompany.Name);
                    break;
                case ReportViewModel.BrokerLoadSortEnum.Delivery_Date:
                    query = query.OrderBy(x => x.EtaDate);
                    break;
                case ReportViewModel.BrokerLoadSortEnum.Invoice_Date:
                    query = query.OrderBy(x => x.InvoiceDate);
                    break;
                case ReportViewModel.BrokerLoadSortEnum.Load_ID:
                    query = query.OrderBy(x => x.LoadID);
                    break;
                case ReportViewModel.BrokerLoadSortEnum.Pickup_Date:
                    query = query.OrderBy(x => x.PickupDate);
                    break;
            }

            uint row = 2;

            XRow templateRow = templateXRowPlain;

            decimal loadTotal = 0m;

            foreach (var record in query)
            {
                templateRow = templateRow == templateXRowPlain ? templateXRowShaded : templateXRowPlain;

                XRow newrow = spreadsheet.AddXRow(templateRow, row++);

                newrow[col.LoadID].SetValue(record.LoadID);
                newrow[col.BrokerLoadNumber].SetValue(record.BrokerLoadNumber);
                newrow[col.PickupDate].SetValue(record.PickupDate);
                newrow[col.DeliveryDate].SetValue(record.EtaDate);
                newrow[col.InvoiceDate].SetValue(record.InvoiceDate);
                newrow[col.InvoiceNumber].SetValue(record.InvoiceNumber);
                newrow[col.BrokerName].SetValue(record.LoadCompany != null ? record.LoadCompany.Name : null);

                if (record.PickupCompany != null)
                {
                    string addr = string.Format(
                        "{0}\n{1} {2}\n{3},{4} {5}",
                        record.PickupCompany.Name,
                        record.PickupCompany.Address1,
                        record.PickupCompany.Address2,
                        record.PickupCompany.City,
                        record.PickupCompany.StateCode,
                        record.PickupCompany.Zip);
                    newrow[col.PickupCo].SetValue(addr);
                }

                if (record.DeliveryCompany != null)
                {
                    string addr = string.Format(
                        "{0}\n{1} {2}\n{3},{4} {5}",
                        record.DeliveryCompany.Name,
                        record.DeliveryCompany.Address1,
                        record.DeliveryCompany.Address2,
                        record.DeliveryCompany.City,
                        record.DeliveryCompany.StateCode,
                        record.DeliveryCompany.Zip);
                    newrow[col.DeliveryCo].SetValue(addr);
                }

                newrow[col.InvoiceAmount].SetValue(record.InvoiceAmount);
                loadTotal += record.InvoiceAmount ?? 0;
            }

            if (row >= 3)
            {
                XCell topAmountCell = spreadsheet[2].XCells.FirstOrDefault(x => x.ColumnNumber == col.InvoiceAmount);
                XCell bottomAmountCell = spreadsheet[row - 1].XCells.FirstOrDefault(x => x.ColumnNumber == col.InvoiceAmount);
                XRow totalXRow = spreadsheet.AddXRow(templateRow, row++);
                totalXRow[col.DeliveryCo].SetValue("TOTAL");
                totalXRow[col.InvoiceAmount].Formula = string.Format("SUM({0}:{1})", topAmountCell.CellAddress, bottomAmountCell.CellAddress);
                /*
                 * Putting the total in the cell along with the formula allows the total to display even though the formula isn't executed when the 
                 * spreadsheet is first opened or when in blocked status.
                 */
                totalXRow[col.InvoiceAmount].SetValue(loadTotal);
            }

            return true;
        }

        private void BrokerLoadListReportViewBag(ReportViewModel viewModel)
        {
            var brokers = db.LoadCompanies(isBroker: true)
                .OrderBy(x => x.Name)
                .ToList()
                .Select(x => new
                {
                    Value = x.LoadCompanyID,
                    Text = x.Name
                });

            if (viewModel == null)
            {
                ViewBag.BrokerID = new SelectList(brokers, "Value", "Text");
            }
            else
            {
                ViewBag.BrokerID = new SelectList(brokers, "Value", "Text", viewModel.BrokerID);
            }
        }

        #endregion

        #region Cleanup History (Cleanup History.xlsx)

        public ActionResult CleanupHistory()
        {
            ReportViewModel viewModel = new ReportViewModel();

            CleanupHistoryViewBag(viewModel);

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult CleanupHistory(ReportViewModel viewModel)
        {
            if (!viewModel.FromDate.HasValue)
            {
                this.ModelState.AddModelError(string.Empty, "From-Date must be specified.");
            }

            if (!viewModel.ThruDate.HasValue)
            {
                this.ModelState.AddModelError(string.Empty, "Through-Date must be specified.");
            }

            if (viewModel.FromDate.HasValue && viewModel.ThruDate.HasValue &&
                viewModel.ThruDate.Value < viewModel.FromDate.Value)
            {
                this.ModelState.AddModelError(string.Empty, "Through-Date must be on or after the From-Date");
            }

            if (!ModelState.IsValid)
            {
                CleanupHistoryViewBag(viewModel);
                return View(viewModel);
            }

            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream spreadsheetTemplate = assembly.GetManifestResourceStream("TransportationPortal.Templates.Cleanup History Template 1.xlsx");

            using (MemoryStream mem = new MemoryStream())
            {
                spreadsheetTemplate.CopyTo(mem);
                spreadsheetTemplate.Close();

                XSpreadsheet spreadsheet = new XSpreadsheet
                {
                    Stream = mem,
                    SheetNumber = 1,
                    RunObject = viewModel
                };

                if (!spreadsheet.Update(CreateCleanupHistorySpreadsheet))
                {
                    this.ModelState.AddModelError(string.Empty, "Spreadsheet generation ended prematurely.");
                    CleanupHistoryViewBag(viewModel);
                    return View(viewModel);
                }

                return File(mem.ToArray(), "application/xlsx", "Cleanup History.xlsx");
            }
        }

        private bool CreateCleanupHistorySpreadsheet(XSpreadsheet spreadsheet)
        {
            CleanupHistorySpreadsheet col = new CleanupHistorySpreadsheet(); 

            int templateRowCount = 2;

            ReportViewModel runValues = spreadsheet.RunObject as ReportViewModel;

            List<XRow> extraRows = spreadsheet.XRows.Where(x => x.RowNumber > templateRowCount).ToList();
            foreach (XRow xrow in extraRows)
            {
                spreadsheet.RemoveXRow(xrow);
            }

            XRow templateXRow = spreadsheet[2];
            if (templateXRow != null)
            {
                spreadsheet.RemoveXRow(templateXRow);
            }
            else
            {
                throw new Exception(string.Format("Template XRow not found."));
            }

            var fields = col.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
            foreach (FieldInfo field in fields)
            {
                uint columnNumber = (uint)field.GetValue(col);
                try
                {
                    templateXRow[columnNumber].SetValue(null);
                }
                catch (Exception)
                {
                    throw new Exception(string.Format("Template cell {0} is not present. A template row must have all the column cells filled.", columnNumber));
                }
            }

            DateTime fromDate = runValues.FromDate.Value.Date;
            DateTime thruDate = runValues.ThruDate.Value.Date.AddDays(1);

            var query = db.Load
                .Include(x => x.Store)
                .Include(x => x.DailyDispatch)
                .Include(x => x.DailyDispatch.Loads)
                .Include(x => x.DailyDispatch.Loads.Select(y => y.Store))
                .Where(x => x.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                .Where(x => x.DailyDispatchID.HasValue)
                .Where(x => x.DailyDispatch.Loads.Any(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD && y.EtaDate >= fromDate && y.EtaDate < thruDate));

            query = query.Sort(LoadSortColumn.Store, 1);

            uint row = 2;

            foreach (var record in query)
            {
                Load noseload = record.DailyDispatch.Loads
                    .Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                    .OrderBy(x => x.DispatchLoadOrder)
                    .FirstOrDefault();

                XRow newrow = spreadsheet.AddXRow(templateXRow, row++);

                newrow[col.LoadID].SetValue(record.LoadName);
                newrow[col.Store].SetValue(record.Store.StoreAndCompanyLong);

                if (noseload != null)
                {
                    newrow[col.PickupDate].SetValue(noseload.EtaDate);
                    newrow[col.DelvStore].SetValue(noseload.Store.StoreAndCompanyLong);
                }
                
                newrow[col.Pallets].SetValue(record.Pallets);
                newrow[col.Totes].SetValue(record.Totes);
                newrow[col.LoadLocks].SetValue(record.LoadLocks);
                newrow[col.Cartons].SetValue(record.Cartons);
                newrow[col.LinearFeet].SetValue(record.LinearFeet);

                newrow[col.CleanupStatus].SetValue(record.PerformedCleanupStatus.ToString().Replace('_', ' '));
            }

            return true;
        }

        private void CleanupHistoryViewBag(ReportViewModel viewModel)
        {
            /*
            var brokers = db.LoadCompanies(isBroker: true)
                .OrderBy(x => x.Name)
                .ToList()
                .Select(x => new
                {
                    Value = x.LoadCompanyID,
                    Text = x.Name
                });

            if (viewModel == null)
            {
                ViewBag.BrokerID = new SelectList(brokers, "Value", "Text");
            }
            else
            {
                ViewBag.BrokerID = new SelectList(brokers, "Value", "Text", viewModel.BrokerID);
            }
             */
        }

        #endregion

        #region Driver Paysheets

        public FileContentResult PrintBlankPaysheet(string paysheetType = null)
        {
            IDictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("ParamDispatchID", "0");
            parameters.Add("ParamExcludeEmptyDriver", "false");

            string reportName;
            if (string.IsNullOrWhiteSpace(paysheetType) || paysheetType == DatabaseLists.DISPATCH_GROUP_OTR)
            {
                reportName = LibConfigProperties.Settings.DriverPaysheetOTRReportName;
            }
            else if (paysheetType == DatabaseLists.DISPATCH_GROUP_DALLAS)
            {
                reportName = LibConfigProperties.Settings.DriverPaysheetCTNReportName;
            }
            else
            {
                reportName = LibConfigProperties.Settings.DriverPaysheetOTRReportName;
            }

            byte[] report = GenerateReport(LibConfigProperties.Settings.DriverPaysheetOTRReportName, parameters);
            return File(report, "application/pdf", "Driver Paysheet.pdf");
        }
        
        public ActionResult PrintSingleDispatch(int id, string catchall = null)
        {
            HobbyLobby.Reporting.ReportFormat reportFormat = HobbyLobby.Reporting.ReportFormat.PDF;
            if (!string.IsNullOrWhiteSpace(catchall))
            {
                if (catchall.ToUpper().Contains("WORD"))
                {
                    reportFormat = HobbyLobby.Reporting.ReportFormat.Word;
                }
            }

            DailyDispatch model = db.DailyDispatch
                .Include(x => x.Carrier)
                .Include(x => x.Driver1)
                .Include(x => x.Driver2)
                .Include(x => x.Loads)
                .Include(x => x.Containers)
                .Single(x => x.DailyDispatchID == id);

            byte[] report;
            string paysheetName;

            if (model.CarrierID.HasValue)
            {
                if (model.Containers.Any())
                {
                    paysheetName = string.Format("{0} Carrier Dispatch", model.Carrier.Name);
                    IDictionary<string, string> parameters = new Dictionary<string, string>();
                    parameters.Add("ParamDispatchID", id.ToString());
                    report = GenerateReport(LibConfigProperties.Settings.DriverPaysheetCTNReportName, parameters, reportFormat: reportFormat);
                }
                else if (model.Loads.All(x => DatabaseLists.INBOUND_LOAD_TYPES.Contains(x.LoadType)))
                {
                    paysheetName = string.Format("{0} Carrier Dispatch", model.Carrier.Name);
                    IDictionary<string, string> parameters = new Dictionary<string, string>();
                    parameters.Add("ParamDispatchID", id.ToString());
                    report = GenerateReport(LibConfigProperties.Settings.CarrierDispatchReportName, parameters, reportFormat: reportFormat);
                }
                else if (model.Loads.Any(x => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(x.LoadType)))
                {
                    paysheetName = string.Format("Paysheet for {0}", model.Carrier.Name ?? "Carrier");
                    IDictionary<string, string> parameters = new Dictionary<string, string>();
                    parameters.Add("ParamDispatchID", id.ToString());
                    parameters.Add("ParamExcludeEmptyDriver", "false");
                    report = GenerateReport(LibConfigProperties.Settings.DriverPaysheetOTRReportName, parameters, reportFormat: reportFormat);
                }
                else
                {
                    throw new Exception("Cannot determine whether to print a Driver Paysheet or Inbound Backhaul Dispatch.");
                }
            }
            else
            {
                string reportName;
                if (model.DispatchGroup == DatabaseLists.DISPATCH_GROUP_OTR)
                {
                    reportName = LibConfigProperties.Settings.DriverPaysheetOTRReportName;
                }
                else
                {
                    reportName = LibConfigProperties.Settings.DriverPaysheetCTNReportName;
                }

                string name1 = model.Driver1 == null || string.IsNullOrWhiteSpace(model.Driver1.LastName) ? null : model.Driver1.LastName;
                string name2 = model.Driver2 == null || string.IsNullOrWhiteSpace(model.Driver2.LastName) ? null : model.Driver2.LastName;
                paysheetName = string.Format("Paysheet for {0}{1}{2}", name1, !string.IsNullOrWhiteSpace(name1) && !string.IsNullOrWhiteSpace(name2) ? "," : string.Empty, name2);
                IDictionary<string, string> parameters = new Dictionary<string, string>();
                parameters.Add("ParamDispatchID", id.ToString());
                parameters.Add("ParamExcludeEmptyDriver", "true");
                report = GenerateReport(reportName, parameters, reportFormat: reportFormat);
            }

            switch (reportFormat)
            {
                case HobbyLobby.Reporting.ReportFormat.Word:
                    return File(report, "application/doc", string.Format("{0}.doc", paysheetName));
                case HobbyLobby.Reporting.ReportFormat.PDF:
                default:
                    return File(report, "application/pdf");
            }
        }

        public ActionResult PrintListedPaysheets(string paysheetType = null)
        {
            string reportName;
            if (string.IsNullOrWhiteSpace(paysheetType) || paysheetType == DatabaseLists.DISPATCH_GROUP_OTR)
            {
                reportName = LibConfigProperties.Settings.DriverPaysheetOTRReportName;
            }
            else if (paysheetType == DatabaseLists.DISPATCH_GROUP_DALLAS)
            {
                reportName = LibConfigProperties.Settings.DriverPaysheetCTNReportName;
            }
            else
            {
                reportName = LibConfigProperties.Settings.DriverPaysheetOTRReportName;
            }

            string list = TempData[REPORT_ELEMENTS_TEMPDATA_NAME] as string;
            if (list != null)
            {
                IDictionary<string, string> parameters = new Dictionary<string, string>();
                parameters.Add("ParamDispatchID", list);
                parameters.Add("ParamExcludeEmptyDriver", "true");
                byte[] report = GenerateReport(reportName, parameters);
                return File(report, "application/pdf");
            }
            else
            {
                return new EmptyResult();
            }
        }

        public ActionResult PrintSelectedPaysheets(string dispatchIDs)
        {
            int[] dispatchIDlist = null;

            try
            {
                dispatchIDlist = dispatchIDs.Split(',').Select(x => int.Parse(x)).ToArray();
            }
            catch (Exception ex)
            {
                HLLogging.Error("Error in PrintSelectedPaysheets method", ex);
                throw new Exception("Error in PrintSelectedPaysheets method.");
            }

            if (dispatchIDlist == null || !dispatchIDlist.Any())
            {
                return new EmptyResult();
            }

            var selectedDispatches = db.DailyDispatch
                .AsNoTracking()
                .Include(x => x.Loads)
                .Where(x => dispatchIDlist.Contains(x.DailyDispatchID));

            int countDriverPaysheets = 0;
            int countCarrierDispatch = 0;
            int countOTRDispatch = 0;
            int countNonOTRDispatch = 0;

            foreach (DailyDispatch dispatch in selectedDispatches)
            {
                if (dispatch.CarrierID.HasValue)
                {
                    if (dispatch.Loads.All(x => DatabaseLists.INBOUND_LOAD_TYPES.Contains(x.LoadType)))
                    {
                        countCarrierDispatch++;
                    }
                    else if (dispatch.Loads.Any(x => DatabaseLists.OUTBOUND_LOAD_TYPES.Contains(x.LoadType)))
                    {
                        countDriverPaysheets++;
                    }
                }
                else
                {
                    countDriverPaysheets++;
                }

                if (dispatch.DispatchGroup == DatabaseLists.DISPATCH_GROUP_OTR)
                {
                    countOTRDispatch++;
                }
                else
                {
                    countNonOTRDispatch++;
                }
            }

            if (countDriverPaysheets > 0 && countCarrierDispatch > 0)
            {
                throw new Exception("You cannot mix Driver Paysheet and Carrier Inbound Request printing.");
            }

            if (countOTRDispatch > 0 && countNonOTRDispatch > 0)
            {
                throw new Exception("You cannot mix OTR and Dallas/OKC paysheet printing.");
            }

            if (countDriverPaysheets > 0)
            {
                if (countOTRDispatch > 0)
                {
                    IDictionary<string, string> parameters = new Dictionary<string, string>();
                    parameters.Add("ParamDispatchID", dispatchIDs);
                    parameters.Add("ParamExcludeEmptyDriver", "true");
                    byte[] report = GenerateReport(LibConfigProperties.Settings.DriverPaysheetOTRReportName, parameters);
                    return File(report, "application/pdf");
                }
                else
                {
                    IDictionary<string, string> parameters = new Dictionary<string, string>();
                    parameters.Add("ParamDispatchID", dispatchIDs);
                    parameters.Add("ParamExcludeEmptyDriver", "true");
                    byte[] report = GenerateReport(LibConfigProperties.Settings.DriverPaysheetCTNReportName, parameters);
                    return File(report, "application/pdf");
                }
            }
            else if (countCarrierDispatch > 0)
            {
                IDictionary<string, string> parameters = new Dictionary<string, string>();
                parameters.Add("ParamDispatchID", dispatchIDs);
                byte[] report = GenerateReport(LibConfigProperties.Settings.CarrierDispatchReportName, parameters);
                return File(report, "application/pdf");
            }
            else
            {
                return new EmptyResult();
            }
        }

        #endregion

        #region Daily Dispatch Summary

        public ActionResult DailyDispatchSummary()
        {
            ReportViewModel viewModel = new ReportViewModel();

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult DailyDispatchSummary(ReportViewModel viewModel)
        {
            if (!viewModel.SelectedDate.HasValue)
            {
                this.ModelState.AddModelError(string.Empty, "Dispatch Date must be entered.");
            }

            if (!ModelState.IsValid)
            {
                return View(viewModel);
            }

            string selectedDate = viewModel.SelectedDate.Value.ToString("yyyy-MM-dd");

            IDictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("ParamDispatchDate", selectedDate);
            parameters.Add("DispatchSort", viewModel.DispatchSort);
            parameters.Add("DateType", viewModel.DateType);

            byte[] report = GenerateReport("Daily Dispatch Summary", parameters);

            return File(report, "application/pdf", string.Format("Daily Dispatch Summary {0}.pdf", selectedDate));
        }

        #endregion

        #region Broker Invoice

        public FileContentResult PrintBrokerLoadInvoice(int id)
        {
            Load model = db.Load
                .Include(x => x.LoadCompany)
                .Single(x => x.LoadID == id);

            string reportFileName = string.Format("Freight Invoice for {0} ({1})", model.LoadCompany.Name, model.LoadName);

            IDictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("ParamLoadID", id.ToString());

            string reportName = LibConfigProperties.Settings.FreightInvoiceReportName;

            byte[] report = GenerateReport(reportName, parameters);

            return File(report, "application/pdf", string.Format("{0}.pdf", reportFileName));
        }

        #endregion
    }
}