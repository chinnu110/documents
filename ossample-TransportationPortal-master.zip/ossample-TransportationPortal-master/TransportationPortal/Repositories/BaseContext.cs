﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace TransportationPortal.Repositories
{
	public class BaseContext<TContext> : DbContext 
		where TContext : DbContext 
	{
		static BaseContext()
		{
			Database.SetInitializer<TContext>(null);
		}

		protected BaseContext()
			: base(LibConfigProperties.Settings.DispatchContext)
		{
			this.Configuration.LazyLoadingEnabled = false;
			Database.SetInitializer<TContext>(null);
		}

		protected BaseContext(string nameOrConnectionString)
			: base(nameOrConnectionString)
		{
			this.Configuration.LazyLoadingEnabled = false;
		}

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
			modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
			modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();
		}
	}
}