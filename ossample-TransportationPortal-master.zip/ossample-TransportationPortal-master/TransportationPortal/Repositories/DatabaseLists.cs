﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Web;

using TransportationPortal.Models;

namespace TransportationPortal.Repositories
{
    public enum DispatchSortColumn
    {
        CarrierThenStore,
        DispatchID,
        DispatchDepart,
        DispatchCreated,
        DispatchChanged,
        InboundLocation,
        OutboundArrival,
        OutboundLocation,
        OutboundStore,
        TractorNumber,
        Driver1,
        CreatedThenGenerated
    }

    public enum LoadSortColumn
    {
        ReadyDate = 0,
        PickupDate,
        LoadID,
        Pallets,
        Cartons,
        Weight,
        Cube,
        LinearFeet,
        DeliveryType,
        PickupLocation,
        DeliveryLocation,
        CreateDate,
        EtaDate,
        DispatchDate,
        StoreLocation,
        ConsolidatedPickupLocation,
        ConsolidatedDeliveryLocation,
        NoseLoadDeliveryDate,
        NoseLoadStore,
        PickupZip,
        Store
    }

    public enum StoreSortColumn
    {
        StoreAndCompany = 0,
        Location
    }

    /// <summary>
    /// These extension methods provides base lists of objects fitting business criteria.
    /// </summary>
    public static class DatabaseLists
    {
        public const string DISPATCH_GROUP_OTR = "OTR";
        public const string DISPATCH_GROUP_DALLAS = "DAL";
        public const string DISPATCH_GROUP_OKC = "OKC";

        public const string INBOUND_BROKER_LOAD = "B";
        public const string INBOUND_VENDOR_BACKHAUL = "N";
        public const string INBOUND_STORE_CLEANUP = "C";

        public static readonly string[] INBOUND_LOAD_TYPES = 
        { 
            INBOUND_BROKER_LOAD,
            INBOUND_VENDOR_BACKHAUL, 
            INBOUND_STORE_CLEANUP
        };

        public const string OUTBOUND_STORE_LOAD = "S";

        public static readonly string[] OUTBOUND_LOAD_TYPES = 
        { 
            OUTBOUND_STORE_LOAD
        };

        public const string LOAD_DELIVERY_TYPE_WAREHOUSE = "WHS";
        public const string LOAD_DELIVERY_TYPE_DIRECT = "DD";
        public const string LOAD_DELIVERY_TYPE_OKC_DISPATCH = "OKC";
        public const string LOAD_DELIVERY_TYPE_DALLAS_DISPATCH = "DAL";

        /// <summary>
        /// Returns a list of DispatchDateControl objects that are open.
        /// </summary>
        /// <param name="db">Current DispatchContext object</param>
        /// <returns></returns>
        public static IQueryable<DispatchDateControl> OpenDispatchDates(this DispatchContext db)
        {
            return db.DispatchDateControl.Where(x => x.Closed == false);
        }

        public static IQueryable<DispatchDateControl> OpenDispatchDates(this DispatchSlimContext db)
        {
            return db.DispatchDateControl.Where(x => x.Closed == false);
        }

        /// <summary>
        /// Returns a list of DispatchDateControl objects that are open and active (DispatchDate >= Today)
        /// </summary>
        /// <param name="db">Current DispatchContext object</param>
        /// <returns></returns>
        public static IQueryable<DispatchDateControl> ActiveDispatchDates(this DispatchContext db)
        {
            return db.DispatchDateControl
                .Where(x => x.Closed == false)
                .Where(x => x.DispatchDate >= DateTime.Today);
        }

        /// <summary>
        /// Returns the oldest Dispatch Date from the query.
        /// </summary>
        /// <param name="db"></param>
        /// <returns></returns>
        public static DateTime OldestDispatchDate(this IQueryable<DispatchDateControl> query)
        {
            return query.Select(x => x.DispatchDate).Min();
        }

        /// <summary>
        /// Returns a list of DailyDispatch objects that are open and modifyable.
        /// These include Active and Past Dispatch Dates.
        /// </summary>
        /// <param name="db">Current DispatchContext object</param>
        /// <returns></returns>
        public static IQueryable<DailyDispatch> OpenDispatches(this DispatchContext db)
        {
            return db.DailyDispatch
                .Where(x => x.DispatchDate >= db.DispatchDateControl.Where(y => y.Closed == false).Select(y => y.DispatchDate).Min());
        }

        public static IQueryable<DailyDispatchSlim> OpenDispatches(this DispatchSlimContext db)
        {
            return db.DailyDispatch
                .Where(x => x.DispatchDate >= db.DispatchDateControl.Where(y => y.Closed == false).Select(y => y.DispatchDate).Min());
        }

        public static IQueryable<DailyDispatch> OpenDispatchesOrAnyOpenDeliveries(this DispatchContext db, DateTime minDate)
        {
            return db.DailyDispatch
                .Where(x =>
                    x.DispatchDate >= minDate
                    ||
                    x.Loads.Any(y => y.EtaDate >= minDate)
                );
        }


        public static IQueryable<Store> ActiveFilter(this DbSet<Store> dbSet, bool includeDeleted = false)
        {
            return (includeDeleted) ? dbSet : dbSet.Where(x => x.DeleteDate.HasValue == false);
        }

        public static IQueryable<Driver> ActiveFilter(this DbSet<Driver> dbSet, bool includeDeleted = false)
        {
            return (includeDeleted) ? dbSet : dbSet.Where(x => x.DeleteDate.HasValue == false);
        }

        public static IQueryable<Carrier> ActiveFilter(this DbSet<Carrier> dbSet, bool includeDeleted = false)
        {
            return (includeDeleted) ? dbSet : dbSet.Where(x => x.DeleteDate.HasValue == false);
        }

        /// <summary>
        /// Returns a list of LoadCompany objects fitting the type criteria.
        /// </summary>
        /// <param name="db"></param>
        /// <param name="isBroker">If specified, will include LoadCompany objects with matching IsBroker.</param>
        /// <param name="isVendor">If specified, will include LoadCompany objects with matching IsVendor.</param>
        /// <param name="isPickupAddress">If specified, will include LoadCompany objects with matching IsPickupAddress.</param>
        /// <param name="isDeliveryAddress">If specified, will include LoadCompany objects with matching IsDeliveryAddress.</param>
        /// <returns></returns>
        public static IQueryable<LoadCompany> LoadCompanies(this DispatchContext db,
            bool? isBroker = null,
            bool? isVendor = null,
            bool? isPickupAddress = null,
            bool? isDeliveryAddress = null,
            bool? isHLCompany = null)
        {
            return db.LoadCompany
                .Where(x =>
                    (isBroker.HasValue == false || x.IsBroker == isBroker.Value)
                    && (isVendor.HasValue == false || x.IsVendor == isVendor.Value)
                    && (isPickupAddress.HasValue == false || x.IsPickupAddress == isPickupAddress.Value)
                    && (isDeliveryAddress.HasValue == false || x.IsDeliveryAddress == isDeliveryAddress.Value)
                    && (isHLCompany.HasValue == false || x.IsCompanyAddress == isHLCompany.Value)
                    )
                ;
        }

        /// <summary>
        /// Returns a list of all inbound Load objects, regardless of status.
        /// </summary>
        /// <param name="query">Load IQueryable</param>
        /// <returns>IQueryable</returns>
        public static IQueryable<Load> InboundOnly(this IQueryable<Load> query)
        {
            return query.Where(x => INBOUND_LOAD_TYPES.Contains(x.LoadType));
        }

        /// <summary>
        /// Returns a list of all inbound Load objects, regardless of status.
        /// </summary>
        /// <param name="query">Load IEnumerable</param>
        /// <returns>IQueryable</returns>
        public static IEnumerable<Load> InboundOnly(this IEnumerable<Load> query)
        {
            return query.Where(x => INBOUND_LOAD_TYPES.Contains(x.LoadType));
        }

        /// <summary>
        /// Returns a list of all outbound loads, regardless of status.
        /// </summary>
        /// <param name="query">Load IQueryable</param>
        /// <returns></returns>
        public static IQueryable<Load> OutboundOnly(this IQueryable<Load> query)
        {
            return query.Where(x => OUTBOUND_LOAD_TYPES.Contains(x.LoadType));
        }

        /// <summary>
        /// Returns a list of all outbound loads, regardless of status.
        /// </summary>
        /// <param name="query">Load IEnumerable</param>
        /// <returns></returns>
        public static IEnumerable<Load> OutboundOnly(this IEnumerable<Load> query)
        {
            return query.Where(x => OUTBOUND_LOAD_TYPES.Contains(x.LoadType));
        }

        /// <summary>
        /// Returns a list of Load objects matching the supplied Types.
        /// </summary>
        /// <param name="query">Load IQueryable</param>
        /// <param name="loadTypes">string[] of LoadType values</param>
        /// <param name="passQuery">Pass base query if params is empty? (default: false)</param>
        /// <returns></returns>
        public static IQueryable<Load> LoadSelectedTypes(this IQueryable<Load> query, IEnumerable<string> loadTypes, bool passQuery = false)
        {
            if (loadTypes == null || loadTypes.Count() == 0)
            {
                if (passQuery == true)
                {
                    return query;
                }
                else
                {
                    return query.Where(x => loadTypes.Contains(x.LoadType));
                }
            }
            else
            {
                return query.Where(x => loadTypes.Contains(x.LoadType));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="loadTypes">string[] of LoadType values</param>
        /// <param name="passQuery">Pass base query if params is empty? (default: false)</param>
        /// <returns></returns>
        public static IEnumerable<Load> LoadSelectedTypes(this IEnumerable<Load> query, IEnumerable<string> loadTypes, bool passQuery = false)
        {
            if (loadTypes == null || loadTypes.Count() == 0)
            {
                if (passQuery == true)
                {
                    return query;
                }
                else
                {
                    return query.Where(x => loadTypes.Contains(x.LoadType));
                }
            }
            else
            {
                return query.Where(x => loadTypes.Contains(x.LoadType));
            }
        }

        /// <summary>
        /// Return a list of Load objects that are not assigned to any DailyDispatch.
        /// </summary>
        /// <param name="query">Load IQueryable</param>
        /// <returns></returns>
        public static IQueryable<Load> UnassignedLoads(this IQueryable<Load> query)
        {
            return query.Where(x => x.DailyDispatchID.HasValue == false);
        }

        /// <summary>
        /// Return a list of store cleanup loads attached to dispatches. 
        /// The list is derived by looking for cleanup loads for the requested store attached to dispatches whose nose load delivery date is on or after the selected date.
        /// </summary>
        /// <param name="query">Load IQueryable</param>
        /// <param name="storeID">Store table record ID</param>
        /// <param name="fromDate">Earliest date for returned store cleanups</param>
        /// <returns>Load IQueryable to retrieve specific cleanups for the selected store. Unsorted. Sort by Dispatch nose load delivery date.</returns>
        public static IQueryable<Load> FutureScheduledCleanupLoads(this IQueryable<Load> query, int storeID, DateTime fromDate)
        {
            return query.Where(x => x.StoreID == storeID
                && x.LoadType == INBOUND_STORE_CLEANUP && x.PickupDateOnly != null).Where(x => x.PickupDateOnly >= fromDate).OrderBy(x => x.PickupDateOnly);
        }

        /// <summary>
        /// Overloaded Version that accepts of list of store ID's and returns all Loads for the passed stores.
        /// </summary>
        /// <param name="query">Load IQueryable</param>
        /// <param name="StoreID">Store table record ID</param>
        /// <param name="fromDate">Starting date</param>
        /// <returns></returns>
        public static IQueryable<Load> FutureScheduledCleanupLoads(this IQueryable<Load> query, List<int> StoreIDs, DateTime fromDate)
        {
            return query.Where(x => StoreIDs.Contains(x.StoreID.Value) && x.LoadType == INBOUND_STORE_CLEANUP && x.PickupDateOnly != null).Where(x => x.PickupDateOnly >= fromDate).OrderBy(x => x.PickupDateOnly);
            
        }

        /// <summary>
        /// Returns a list of store cleanups prior to the executing date.
        /// </summary>
        /// <param name="query">Load IQueryable</param>
        /// <param name="StoreID">Store table record ID</param>
        /// <returns>IQueryable of Load. 0 Index is last previous</returns>
        public static IQueryable<Load> PreviousScheduledCleanupLoad(this IQueryable<Load> query, int StoreID, DateTime date)
        {
            return query.Where(x => x.StoreID == StoreID
                && x.LoadType == INBOUND_STORE_CLEANUP                
                && x.DailyDispatch.Loads.Where(y => y.LoadType == OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().EtaDate < date);
        }

        /// <summary>
        /// Find the FuelSurcharge record for the requested date.
        /// </summary>
        /// <param name="query">Fuel Surcharge IQueryable</param>
        /// <param name="date">Date of FuelSurcharge</param>
        /// <returns>FuelSurcharge record or null</returns>
        public static FuelSurcharge GetFuelSurchargeForDate(this IQueryable<FuelSurcharge> query, DateTime date)
        {
            return query
                .ToList()
                .SingleOrDefault(x => date >= x.ActiveDate && (x.ActiveEndDate.HasValue == false || date < x.ActiveEndDate.Value.AddDays(1)));
        }

        /// <summary>
        /// Sort the DailyDispatch IQueryable on the selected column and direction. The default sort is Dispatch Date.
        /// </summary>
        /// <param name="query">DailyDispatch IQueryable</param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public static IOrderedQueryable<DailyDispatch> Sort(this IQueryable<DailyDispatch> query, DispatchSortColumn sortColumn, int sortDirection)
        {
            switch (sortColumn)
            {
                case DispatchSortColumn.Driver1:
                    return sortDirection >= 0
                        ? query
                        .OrderBy(x => x.Driver1.FirstName).ThenBy(x => x.Driver1.LastName)
                        : query
                        .OrderByDescending(x => x.Driver1.FirstName).ThenByDescending(x => x.Driver1.LastName);
                case DispatchSortColumn.DispatchID:
                    return sortDirection >= 0 ? query.OrderBy(x => x.DailyDispatchID) : query.OrderByDescending(x => x.DailyDispatchID);
                case DispatchSortColumn.TractorNumber:
                    return sortDirection >= 0 ? query.OrderBy(x => x.TractorNumber) : query.OrderByDescending(x => x.TractorNumber);
                case DispatchSortColumn.CarrierThenStore:
                    return sortDirection >= 0
                        ? query
                        .OrderBy(x => x.Carrier.Name)
                        .ThenBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
                        .ThenBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber)
                        : query
                        .OrderByDescending(x => x.Carrier.Name)
                        .ThenByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
                        .ThenByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber);
                case DispatchSortColumn.OutboundStore:
                    return sortDirection >= 0
                        ? query
                        .OrderBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
                        .ThenBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber)
                        : query
                        .OrderByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
                        .ThenByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber);
                case DispatchSortColumn.OutboundArrival:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Select(y => y.EtaDate).Min())
                        : query.OrderByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Select(y => y.EtaDate).Min());
                case DispatchSortColumn.DispatchCreated:
                    return sortDirection >= 0 ? query.OrderBy(x => x.CreateDate) : query.OrderByDescending(x => x.CreateDate);
                case DispatchSortColumn.DispatchChanged:
                    return sortDirection >= 0 ? query.OrderBy(x => x.ChangeDate) : query.OrderByDescending(x => x.ChangeDate);
                case DispatchSortColumn.OutboundLocation:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                            .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.Store.StateCode + y.Store.City })
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location)
                        : query.OrderByDescending(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                            .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.Store.StateCode + y.Store.City })
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location);
                case DispatchSortColumn.InboundLocation:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || y.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                            .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.PickupCompany.StateCode + y.PickupCompany.City })
                            .Concat(x.Loads
                                .Where(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                                .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.Store.StateCode + y.Store.City })
                            )
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location)
                        : query.OrderByDescending(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || y.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                            .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.PickupCompany.StateCode + y.PickupCompany.City })
                            .Concat(x.Loads
                                .Where(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                                .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.Store.StateCode + y.Store.City })
                            )
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location);
                case DispatchSortColumn.DispatchDepart:
                default:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.DispatchDate).ThenBy(x => x.DepartureTime)
                        : query.OrderByDescending(x => x.DispatchDate).ThenByDescending(x => x.DepartureTime);
            }
        }

        public static IOrderedQueryable<DailyDispatchSlim> Sort(this IQueryable<DailyDispatchSlim> query, DispatchSortColumn sortColumn, int sortDirection)
        {
            switch (sortColumn)
            {
                case DispatchSortColumn.DispatchID:
                    return sortDirection >= 0 ? query.OrderBy(x => x.DailyDispatchID) : query.OrderByDescending(x => x.DailyDispatchID);
                case DispatchSortColumn.TractorNumber:
                    return sortDirection >= 0 ? query.OrderBy(x => x.TractorNumber) : query.OrderByDescending(x => x.TractorNumber);
                case DispatchSortColumn.CarrierThenStore:
                    return sortDirection >= 0
                        ? query
                        .OrderBy(x => x.Carrier.Name)
                        .ThenBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
                        .ThenBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber)
                        : query
                        .OrderByDescending(x => x.Carrier.Name)
                        .ThenByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
                        .ThenByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber);
                case DispatchSortColumn.OutboundStore:
                    return sortDirection >= 0
                        ? query
                        .OrderBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
                        .ThenBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber)
                        : query
                        .OrderByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.CompanyID)
                        .ThenByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().Store.StoreNumber);
                case DispatchSortColumn.OutboundArrival:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Select(y => y.EtaDate).Min())
                        : query.OrderByDescending(x => x.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).Select(y => y.EtaDate).Min());
                //case DispatchSortColumn.DispatchCreated:
                //	return sortDirection >= 0 ? query.OrderBy(x => x.CreateDate) : query.OrderByDescending(x => x.CreateDate);
                //case DispatchSortColumn.DispatchChanged:
                //	return sortDirection >= 0 ? query.OrderBy(x => x.ChangeDate) : query.OrderByDescending(x => x.ChangeDate);
                case DispatchSortColumn.OutboundLocation:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                            .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.Store.StateCode + y.Store.City })
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location)
                        : query.OrderByDescending(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                            .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.Store.StateCode + y.Store.City })
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location);
                case DispatchSortColumn.InboundLocation:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || y.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                            .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.PickupCompany.StateCode + y.PickupCompany.City })
                            .Concat(x.Loads
                                .Where(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                                .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.Store.StateCode + y.Store.City })
                            )
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location)
                        : query.OrderByDescending(x => x.Loads
                            .Where(y => y.LoadType == DatabaseLists.INBOUND_BROKER_LOAD || y.LoadType == DatabaseLists.INBOUND_VENDOR_BACKHAUL)
                            .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.PickupCompany.StateCode + y.PickupCompany.City })
                            .Concat(x.Loads
                                .Where(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
                                .Select(y => new { LoadOrder = y.DispatchLoadOrder, Location = y.Store.StateCode + y.Store.City })
                            )
                            .OrderBy(y => y.LoadOrder)
                            .FirstOrDefault()
                            .Location);
                case DispatchSortColumn.DispatchDepart:
                default:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.DispatchDate).ThenBy(x => x.DepartureTime)
                        : query.OrderByDescending(x => x.DispatchDate).ThenByDescending(x => x.DepartureTime);
            }
        }

        /// <summary>
        /// Sort the Load IQueryable on the selected column and direction.
        /// </summary>
        /// <param name="query">Load IQueryable</param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public static IQueryable<Load> Sort(this IQueryable<Load> query, LoadSortColumn sortColumn, int sortDirection)
        {
            switch (sortColumn)
            {
                case LoadSortColumn.LoadID:
                    return sortDirection >= 0 ? query.OrderBy(x => x.LoadID) : query.OrderByDescending(x => x.LoadID);
                case LoadSortColumn.Pallets:
                    return sortDirection >= 0 ? query.OrderBy(x => x.Pallets) : query.OrderByDescending(x => x.Pallets);
                case LoadSortColumn.Cartons:
                    return sortDirection >= 0 ? query.OrderBy(x => x.Cartons) : query.OrderByDescending(x => x.Cartons);
                case LoadSortColumn.Weight:
                    return sortDirection >= 0 ? query.OrderBy(x => x.Weight) : query.OrderByDescending(x => x.Weight);
                case LoadSortColumn.Cube:
                    return sortDirection >= 0 ? query.OrderBy(x => x.Cube) : query.OrderByDescending(x => x.Cube);
                case LoadSortColumn.LinearFeet:
                    return sortDirection >= 0 ? query.OrderBy(x => x.LinearFeet) : query.OrderByDescending(x => x.LinearFeet);
                case LoadSortColumn.DeliveryType:
                    return sortDirection >= 0 ? query.OrderBy(x => x.DeliveryType) : query.OrderByDescending(x => x.DeliveryType);
                case LoadSortColumn.StoreLocation:
                    return (sortDirection >= 0)
                        ? query.OrderBy(x => x.Store.StateCode).ThenBy(x => x.Store.City)
                        : query.OrderByDescending(x => x.Store.StateCode).ThenByDescending(x => x.Store.City);
                case LoadSortColumn.Store:
                    return (sortDirection >= 0)
                        ? query.OrderBy(x => x.Store.CompanyID).ThenBy(x => x.Store.StoreNumber)
                        : query.OrderByDescending(x => x.Store.CompanyID).ThenByDescending(x => x.Store.StoreNumber);
                case LoadSortColumn.PickupLocation:
                    return (sortDirection >= 0)
                        ? query.OrderBy(x => x.PickupCompany.StateCode).ThenBy(x => x.PickupCompany.City)
                        : query.OrderByDescending(x => x.PickupCompany.StateCode).ThenByDescending(x => x.PickupCompany.City);
                case LoadSortColumn.PickupZip:
                    return (sortDirection >= 0)
                        ? query.OrderBy(x => x.PickupCompany.Zip)
                        : query.OrderByDescending(x => x.PickupCompany.Zip);
                case LoadSortColumn.DeliveryLocation:
                    return (sortDirection >= 0)
                        ? query.OrderBy(x => x.DeliveryCompany.StateCode).ThenBy(x => x.DeliveryCompany.City)
                        : query.OrderByDescending(x => x.DeliveryCompany.StateCode).ThenByDescending(x => x.DeliveryCompany.City);
                case LoadSortColumn.ConsolidatedDeliveryLocation:
                    return (sortDirection >= 0)
                        ? query.OrderBy(x => x.Store.StateCode).ThenBy(x => x.Store.City)
                        : query.OrderByDescending(x => x.Store.StateCode).ThenByDescending(x => x.Store.City);
                case LoadSortColumn.ConsolidatedPickupLocation:
                    return (sortDirection >= 0)
                        ? query.OrderBy(x => x.Store.StateCode ?? x.PickupCompany.StateCode).ThenBy(x => x.Store.City ?? x.PickupCompany.City)
                        : query.OrderByDescending(x => x.Store.StateCode ?? x.PickupCompany.StateCode).ThenByDescending(x => x.Store.City ?? x.PickupCompany.City);
                case LoadSortColumn.CreateDate:
                    return sortDirection >= 0 ? query.OrderBy(x => x.CreateDate) : query.OrderByDescending(x => x.CreateDate);
                case LoadSortColumn.DispatchDate:
                    return sortDirection >= 0 ? query.OrderBy(x => x.DailyDispatch.DispatchDate) : query.OrderByDescending(x => x.DailyDispatch.DispatchDate);
                case LoadSortColumn.EtaDate:
                    return sortDirection >= 0 ? query.OrderBy(x => x.EtaDate) : query.OrderByDescending(x => x.EtaDate);
                case LoadSortColumn.PickupDate:
                    return sortDirection >= 0 ? query.OrderBy(x => x.PickupDate) : query.OrderByDescending(x => x.PickupDate);
                case LoadSortColumn.NoseLoadDeliveryDate:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.DailyDispatch.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().EtaDate)
                        : query.OrderByDescending(x => x.DailyDispatch.Loads.Where(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD).OrderBy(y => y.DispatchLoadOrder).FirstOrDefault().EtaDate);
                case LoadSortColumn.ReadyDate:
                default:
                    return sortDirection >= 0 ? query.OrderBy(x => x.ReadyDate) : query.OrderByDescending(x => x.ReadyDate);
            }
        }

        /// <summary>
        /// Sort the Load IQueryable on the selected column and direction.
        /// </summary>
        /// <param name="query">Load IQueryable</param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public static IQueryable<Store> Sort(this IQueryable<Store> query, StoreSortColumn sortColumn, int sortDirection)
        {
            switch (sortColumn)
            {
                case StoreSortColumn.Location:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.StateCode).ThenBy(x => x.City)
                        : query.OrderByDescending(x => x.StateCode).ThenByDescending(x => x.City);
                case StoreSortColumn.StoreAndCompany:
                default:
                    return sortDirection >= 0
                        ? query.OrderBy(x => x.CompanyID).ThenBy(x => x.StoreNumber)
                        : query.OrderByDescending(x => x.CompanyID).ThenByDescending(x => x.StoreNumber);
            }
        }
    }
}