﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using TransportationPortal.Models;

namespace TransportationPortal.Repositories
{
	public class DispatchContext : BaseContext<DispatchContext> 
	{
		public DbSet<Carrier> Carrier { get; set; }
		
		public DbSet<Driver> Driver {get;set;}

		public DbSet<OutboundRoute> OutboundRoute { get; set; }

		public DbSet<WeekDay> WeekDay { get; set; }

		public DbSet<Dispatcher> Dispatcher { get; set; }

		public DbSet<Store> Store { get; set; }

		public DbSet<ZStore> ZStore { get; set; }

		public DbSet<StoreCarrierInfo> StoreCarrierInfo { get; set; }

		public DbSet<Company> Company { get; set; }

		public DbSet<DailyDispatch> DailyDispatch { get; set; }

		public DbSet<DispatchDateControl> DispatchDateControl { get; set; }

		public DbSet<LoadCompany> LoadCompany { get; set; }

		public DbSet<Load> Load { get; set; }

		public DbSet<FuelSurcharge> FuelSurcharge { get; set; }

		public DbSet<DispatchLoadLinkHistory> DispatchLoadLinkHistory { get; set; }

        public DbSet<Container> Container { get; set; }

		public DispatchContext()
			: base()
		{
			((IObjectContextAdapter)this).ObjectContext.CommandTimeout = 180;
		}
	}
}