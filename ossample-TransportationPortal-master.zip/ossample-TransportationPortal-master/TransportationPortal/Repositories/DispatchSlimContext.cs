﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using TransportationPortal.Models;

namespace TransportationPortal.Repositories
{
	public class DispatchSlimContext : BaseContext<DispatchSlimContext> 
	{
		public DbSet<Carrier> Carrier { get; set; }
		
		public DbSet<Dispatcher> Dispatcher { get; set; }

		public DbSet<DailyDispatchSlim> DailyDispatch { get; set; }

		public DbSet<DispatchDateControl> DispatchDateControl { get; set; }

		public DbSet<LoadSlim> Load { get; set; }

		/// <summary>
		/// Instantiate a context with the fully representative context as the LibConfig lookup value.
		/// </summary>
		public DispatchSlimContext()
			: base()
		{
			((IObjectContextAdapter)this).ObjectContext.CommandTimeout = 180;
		}
	}
}