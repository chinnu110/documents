﻿function BindableListHelper(){}

//-------------------------------------------------
var RegisteredLists = {};

BindableListHelper.GetJSONString = function (jsonObject) {
    return JSON.stringify(jsonObject);
}

BindableListHelper.GetJSONObject = function (jsonString) {
    return JSON.parse(jsonString);
}

BindableListHelper.RegisteredList = function (listId) {
    this.ListId = listId;
    this.List = $('#' + this.ListId);
    this.ListItems = $('#' + this.ListId).children('.BindableItemContainer');
    this.ListItemValues = new Array();

    for (var i = 0; i < this.ListItems.length; i++) {
        this.ListItemValues.push(BindableListHelper.GetJSONObject($(this.ListItems[i]).children('.BindableItemValue').first().val()));
    }

    this.SelectionMode = $('#' + this.ListId).children('#' + this.ListId + '_SelectionMode').val();

    this.CurrentItemContainer = $('#' + this.ListId).children('#' + this.ListId + '_CurrentItemAsString').first();
    this.CurrentItem = null;
    this.CurrentItemValue = null;
    this.CurrentItemIndex = null;

    this.SelectedItemsContainer = $('#' + this.ListId).children('#' + this.ListId + '_SelectedItemsAsString').first();
    this.SelectedItemsValues = {};

    this.UpdateSelectionValues = function () {
        switch (this.SelectionMode) {
            case "Multiple":
                this.CurrentItemContainer.val($(this.CurrentItem).children('.BindableItemValue').first().val());

                var sItems = new Array();
                for (var i in this.SelectedItemsValues) {
                    this.SelectedItemsValues[i] = BindableListHelper.GetJSONString(this.ListItemValues[i]);
                    sItems.push(this.SelectedItemsValues[i]);
                }

                this.SelectedItemsContainer.val(BindableListHelper.GetJSONString(sItems));
                break;
            case "Single":
                this.SelectedItemsValues = BindableListHelper.GetJSONString(this.ListItemValues[this.CurrentItemIndex]);
                this.CurrentItemContainer.val($(this.CurrentItem).children('.BindableItemValue').first().val());
                this.SelectedItemsContainer.val(this.SelectedItemsValues);
                break;
            case "None":
                break;
            default:
                this.SelectedItemsValues = BindableListHelper.GetJSONString(this.ListItemValues[this.CurrentItemIndex]);
                this.CurrentItemContainer.val($(this.CurrentItem).children('.BindableItemValue').first().val());
                this.SelectedItemsContainer.val(this.SelectedItemsValues);
                break;
        }
    }

    this.UpdateSelections = function () {
        switch (this.SelectionMode) {
            case "Multiple":
                this.CurrentItemContainer.val($(this.CurrentItem).children('.BindableItemValue').first().val());


                var sItems = new Array();
                for (var i in this.SelectedItemsValues) {
                    sItems.push(this.SelectedItemsValues[i]);
                }

                this.SelectedItemsContainer.val(BindableListHelper.GetJSONString(sItems));
                break;
            case "Single":
                this.CurrentItemContainer.val($(this.CurrentItem).children('.BindableItemValue').first().val());
                this.SelectedItemsContainer.val(this.CurrentItemContainer.val());
                break;
            case "None":
                break;
            default:
                this.SelectedItemsValues = BindableListHelper.GetJSONString(this.ListItemValues[this.CurrentItemIndex]);
                this.CurrentItemContainer.val($(this.CurrentItem).children('.BindableItemValue').first().val());
                this.SelectedItemsContainer.val(this.SelectedItemsValues);
                break;
        }
    }
}

BindableListHelper.RegisterList = function (listId, clickFunction, selectionChangedFunction) {
    var list = new BindableListHelper.RegisteredList(listId);

    list.ListItems.each(function (i, element) {
        $(element).click({ listId: list.ListId, itemIndex: i }, BindableListHelper.ItemClick);
        $(element).change({ listId: list.ListId, itemIndex: i }, BindableListHelper.SelectionChanged);
    });

    RegisteredLists[list.ListId] = list;

    if (clickFunction != null && clickFunction != undefined) {
        BindableListHelper.BindToListItemClick(listId, clickFunction);
    }
    if (selectionChangedFunction != null && selectionChangedFunction != undefined) {
        BindableListHelper.BindToSelectionChanged(listId, selectionChangedFunction);
    }

    BindableListHelper.PrepareList(list);
}

BindableListHelper.PrepareList = function (registeredList) {
    registeredList.ListItems.each(function (i, element) {
        $(element).change();
    });
}

BindableListHelper.BindToListItemClick = function (listId, functionToBind) {
    $('#' + listId).bind('itemClicked', functionToBind);
}

BindableListHelper.BindToSelectionChanged = function (listId, functionToBind) {
    $('#' + listId).bind('selectionChanged', functionToBind);
}

BindableListHelper.SelectionChanged = function (event) {
    var list = RegisteredLists[event.data.listId];
    var isSelected = $(this).children('.BindableItemSelected').first().val();
    var itemValue = $(this).children('.BindableItemValue').first().val();
    var itemIndex = $(this).children('.BindableItemIndex').first().val();

    if (isSelected == 'true') {
        isSelected = true;
    }
    else {
        isSelected = false;
    }

    switch (list.SelectionMode) {
        case "Multiple":
            if (isSelected == true) {
                list.SelectedItemsValues[itemIndex] = itemValue;
                $(this).css('background-color', $('#' + list.ListId).attr('selectedColor'));
            }
            else if (isSelected == false) {
                delete list.SelectedItemsValues[itemIndex];
                $(this).css('background-color', $('#' + list.ListId).attr('deSelectedColor'));
            }

            list.CurrentItem = this;
            list.CurrentItemValue = BindableListHelper.GetJSONObject(itemValue);
            list.CurrentItemIndex = itemIndex;

            list.UpdateSelections();
            break;
        case "Single":
            if (list.CurrentItemIndex != itemIndex) {
                $(list.CurrentItem).children('.BindableItemSelected').first().val(false);
                $(list.CurrentItem).change();
            }

            if (isSelected == true && list.CurrentItemIndex != itemIndex) {
                list.SelectedItemsValues = itemValue;
                $(this).css('background-color', $('#' + list.ListId).attr('selectedColor'));

                list.CurrentItem = this;
                list.CurrentItemValue = BindableListHelper.GetJSONObject(itemValue);
                list.CurrentItemIndex = itemIndex;

                list.UpdateSelections();
            }
            else if (isSelected == false) {
                list.SelectedItemValues = null;
                $(this).css('background-color', $('#' + list.ListId).attr('deSelectedColor'));
            }
            break;
        case "None":
            list.CurrentItem = this;
            list.CurrentItemValue = BindableListHelper.GetJSONObject(itemValue);
            list.CurrentItemIndex = itemIndex;
            break;
        default:
            if (list.CurrentItemIndex != itemIndex) {
                $(list.CurrentItem).children('.BindableItemSelected').first().val(false);
                $(list.CurrentItem).change();
            }

            if (isSelected == true && list.CurrentItemIndex != itemIndex) {
                list.SelectedItemValues = itemValue;
                $(this).css('background-color', $('#' + list.ListId).attr('selectedColor'));

                list.CurrentItem = this;
                list.CurrentItemValue = BindableListHelper.GetJSONObject(itemValue);
                list.CurrentItemIndex = itemIndex;

                list.UpdateSelections();
            }
            else if (isSelected == false) {
                list.SelectedItemValues = null;
                $(this).css('background-color', $('#' + list.ListId).attr('deSelectedColor'));
            }
            break;
    }

    $('#' + event.data.listId).trigger('selectionChanged', [event.data.listId, event.data.itemIndex, isSelected]);
}

BindableListHelper.ItemClick = function (event) {
    var list = RegisteredLists[event.data.listId];

    switch (list.SelectionMode) {
        case "Multiple":
            var isSelected = $(this).children('.BindableItemSelected').first().val();

            if (isSelected == 'true') {
                $(this).children('.BindableItemSelected').first().val(false);
            }
            else {
                $(this).children('.BindableItemSelected').first().val(true);
            }

            $(this).change();
            break;
        case "Single":
            var isSelected = $(this).children('.BindableItemSelected').first().val();

            if (isSelected == 'true') {

            }
            else {
                $(this).children('.BindableItemSelected').first().val(true);
                $(this).change();
            }
            break;
        case "None":

            break;
        default:
            var isSelected = $(this).children('.BindableItemSelected').first().val();

            if (isSelected == 'true') {

            }
            else {
                $(this).children('.BindableItemSelected').first().val(true);
                $(this).change();
            }
            break;
    }

    $('#' + list.ListId).trigger('itemClicked', [event.data.listId, event.data.itemIndex, event.target.id, event.target.type]);
}

BindableListHelper.GetListItem = function (listId, itemIndex) {
    return RegisteredLists[listId].ListItems[itemIndex];
}

BindableListHelper.GetControl = function (listId, itemIndex, controlId) {
    return $('#' + listId + '_Item' + itemIndex + '_' + controlId);
}

BindableListHelper.GetMyListId = function (controlId) {
    return $('#' + controlId).parents('.bindableList').first().attr('id');
}

BindableListHelper.GetMyIndex = function (controlId) {
    return Number($('#' + controlId).parents('.itemWrapper').first().children('.BindableItemIndex').first().val());
}

BindableListHelper.GetMyId = function (controlId) {
    return controlId.substring(controlId.lastIndexOf('_') + 1);
}

BindableListHelper.GetFQId = function (listId, itemIndex, id) {
    return listId + '_Item' + itemIndex + '_' + id;
}

BindableListHelper.GetValue = function (listId, index) {
    return RegisteredLists[listId].ListItemValues[index];
}

//BindableListHelper.GetValues = function (listId) {
//    return RegisteredLists[listId].ListItemValues;
//}

BindableListHelper.SetValue = function (listId, index, value) {
    RegisteredLists[listId].ListItemValues[index] = value;
    $(RegisteredLists[listId].ListItems[index]).children('.BindableItemValue').val(BindableListHelper.GetJSONString(value));

    RegisteredLists[listId].UpdateSelectionValues();
}