﻿using System.Web.Optimization;

namespace TransportationPortal
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new StyleBundle("~/bundles/styles").Include(
                "~/Content/styles.css"));
        }
    }
}