﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
	public class PlanningViewModel
	{
		public string SubmitButtonAssignLoads { get; set; }

		public string SubmitButtonCreateCarrierDispatch { get; set; }

		public string SubmitButtonFilter { get; set; }

		public bool CanUseCleanupUpdateMode { get; set; }

		public bool CleanupUpdateMode { get; set; }

		[Display(Name = "Ready Date")]
		public DateTime? ReadyDate { get; set; }

		[Display(Name = "Pickup Date")]
		public DateTime? PickupDate { get; set; }

		[Display(Name = "Company")]
		public Int32? LoadCompanyID { get; set; }

		[Display(Name = "Company")]
		public Int32? PickupCompanyID { get; set; }

		[Display(Name = "Search")]
		public string SearchField { get; set; }

		[Display(Name = "Unassigned only")]
		public bool UnassignedLoadsOnly { get; set; }

		public List<int> LoadSelect { get; set; }

		public List<SelectListItem> TypesSelectList { get; set; }

		public DateTime? FromDate { get; set; }

		public DateTime? ThruDate { get; set; }

		public string StateCode { get; set; }

		public SelectList StateCodeList { get; set; }
		
		public string SortColumn { get; set; }

		public int SortDirection { get; set; }

		public PagingViewModel Paging { get; set; }

		public IEnumerable<LoadDragDropViewModel> Loads { get; set; }
	}
}