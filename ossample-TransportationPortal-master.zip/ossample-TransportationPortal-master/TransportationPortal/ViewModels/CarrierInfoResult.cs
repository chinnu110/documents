﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
    public class CarrierInfoResult
    {
        public int? ChosenCarrierID { get; set; }

        [Display(Name = "Carrier Rate")]
        [DataType(DataType.Currency)]
        public decimal? CarrierRate { get; set; }

        public bool CarrierRateChanged { get; set; }

        [Display(Name = "Carrier Flat Rate")]
        [DataType(DataType.Currency)]
        public decimal? CarrierFlatRate { get; set; }

        public bool CarrierFlatRateChanged { get; set; }

        public int MileageCalcType { get; set; }

        [Display(Name = "Miles")]
        public int? CarrierMiles { get; set; }

        public bool CarrierMilesChanged { get; set; }

        [Display(Name = "Carrier Stop Charge 1")]
        [DataType(DataType.Currency)]
        public decimal? CarrierStopCharge1 { get; set; }

        public bool CarrierStopCharge1Changed { get; set; }

        [Display(Name = "Carrier Stop Charge 2")]
        [DataType(DataType.Currency)]
        public decimal? CarrierStopCharge2 { get; set; }

        public bool CarrierStopCharge2Changed { get; set; }

        [Display(Name = "Carrier Extra Charge")]
        [DataType(DataType.Currency)]
        public decimal? CarrierExtraCharge { get; set; }

        [Display(Name = "Carrier Total Charge")]
        [DataType(DataType.Currency)]
        public decimal? CarrierTotalCharge { get; set; }

        public bool LockCarrierTotalCharge { get; set; }

        [Display(Name = "Fuel Surcharge")]
        [DataType(DataType.Currency)]
        public decimal? FuelSurcharge { get; set; }

        public List<CarrierInfoElement> Carriers { get; set; }

        public class CarrierInfoElement
        {
            public string Name { get; set; }

            public int CarrierID { get; set; }

            public int? Miles { get; set; }

            [DataType(DataType.Currency)]
            public decimal? RatePerMile { get; set; }

            [DataType(DataType.Currency)]
            public decimal? FlatRate { get; set; }

            public int MileageCalcType { get; set; }

            [DataType(DataType.Currency)]
            public decimal? StopCharge1 { get; set; }

            [DataType(DataType.Currency)]
            public decimal? StopCharge2 { get; set; }

            [DataType(DataType.Currency)]
            public decimal? TotalCharge { get; set; }

            public bool IsLowestTotalCharge { get; set; }

            public bool IsSelectedCarrier { get; set; }

            public bool IsStopCharge1Used { get; set; }

            public bool IsStopCharge2Used { get; set; }
        }
    }
}