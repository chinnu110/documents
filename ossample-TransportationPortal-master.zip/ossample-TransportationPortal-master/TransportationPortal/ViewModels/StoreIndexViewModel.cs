﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
    public class StoreIndexViewModel
    {
        public string CompanyID { get; set; }

        public SelectList CompanyList { get; set; }

        public string StateCode { get; set; }

        public SelectList StateCodeList { get; set; }

        public int? PickDayID { get; set; }

        public SelectList PickDayList { get; set; }

        public int? ArrivalDayID { get; set; }

        public SelectList ArrivalDayList { get; set; }

        public int? LastDigitID { get; set; }

        public SelectList LastDigitList { get; set; }

        [Display(Name = "Search")]
        public string SearchField { get; set; }

        public string SortColumn { get; set; }

        public int SortDirection { get; set; }

        public PagingViewModel Paging { get; set; }
        
        // Output only.
        public IEnumerable<Store> Stores { get; set; }

        public class Store
        {
            [Key]
            public Int32 StoreID { get; set; }

            [Display(Name = "Store")]
            public Int32 StoreNumber { get; set; }

            [Display(Name = "Suffix")]
            public string DuplicateCode { get; set; }

            [Display(Name = "Co")]
            public string CompanyID { get; set; }

            [Display(Name = "City")]
            public string City { get; set; }

            [Display(Name = "State")]
            public string StateCode { get; set; }

            [Display(Name = "Miles")]
            public Int32? Miles { get; set; }

            [Display(Name = "A-Load Pick Day")]
            public int? ALoadPickDayID { get; set; }

            [Display(Name = "A-Load Arrive Day")]
            public int? ALoadArrivalDayID { get; set; }

            [Display(Name = "A-Load Arrive Time")]
            public DateTime? ALoadArrivalTime { get; set; }

            [Display(Name = "B-Load Arrive Day")]
            public int? BLoadArrivalDayID { get; set; }

            [Display(Name = "B-Load Arrive Time")]
            public DateTime? BLoadArrivalTime { get; set; }

            [Display(Name = "Week 1")]
            public bool Week1 { get; set; }

            [Display(Name = "Week 2")]
            public bool Week2 { get; set; }

            [Display(Name = "Local?")]
            public bool Local { get; set; }

            public DateTime? DeleteDate { get; set; }
        }
    }
}