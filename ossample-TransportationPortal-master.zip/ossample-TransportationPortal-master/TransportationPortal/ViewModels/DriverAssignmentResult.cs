﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public class DriverAssignmentResult
	{
		public int DailyDispatchID { get; set; }

		public bool Allow { get; set; }

		public bool Ask { get; set; }

		public string Message { get; set; }
	}
}