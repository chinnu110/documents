﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public class OutboundRoutePreviewViewModel
	{
		public DateTime Week1SundayDate { get; set; }

		public bool Week1Sunday { get; set; }
		public bool Week1Monday { get; set; }
		public bool Week1Tuesday { get; set; }
		public bool Week1Wednesday { get; set; }
		public bool Week1Thursday { get; set; }
		public bool Week1Friday { get; set; }
		public bool Week1Saturday { get; set; }

		public bool Week2Sunday { get; set; }
		public bool Week2Monday { get; set; }
		public bool Week2Tuesday { get; set; }
		public bool Week2Wednesday { get; set; }
		public bool Week2Thursday { get; set; }
		public bool Week2Friday { get; set; }
		public bool Week2Saturday { get; set; }

		// Output only.
		public IEnumerable<DispatchViewModel> Dispatches { get; set; }
	}
}