﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class CarrierRateHistoryResponse
	{
		public string Message { get; set; }

		public IEnumerable<string> StoreList { get; set; }

		public IEnumerable<DispatchViewModel> Dispatches { get; set; }
	}
}