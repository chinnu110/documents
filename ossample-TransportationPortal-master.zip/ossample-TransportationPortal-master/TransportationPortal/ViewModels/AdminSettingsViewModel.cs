﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class AdminSettingsViewModel
	{
		/// <summary>
		/// If set true, allows data normally read-only by condition to be changed.
		/// This would be used to allow changes to correct data values in error.
		/// </summary>
		[DisplayName("Allow administrative data editing")]
		public bool AdminEditMode { get; set; }
	}
}