﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;
using TransportationPortal.Models;
using TransportationPortal.Repositories;

namespace TransportationPortal.ViewModels
{
    public class DispatchViewModel
    {
        public Int32 DailyDispatchID { get; set; }

        public Byte[] Timestamp { get; set; }

        public DateTime DispatchDate { get; set; }

        public bool Generated { get; set; }

        public bool Closed { get; set; }

        public int? CarrierID { get; set; }

        public string CarrierName { get; set; }

        public decimal? CarrierRate { get; set; }

        public int? CarrierMiles { get; set; }

        public decimal? FuelSurcharge { get; set; }

        public decimal? CarrierTotalCharge { get; set; }

        public bool LockCarrierTotalCharge { get; set; }

        public int? Miles { get; set; }

        public int? Driver1ID { get; set; }

        public string Driver1Name { get; set; }

        public string Driver1FirstName { get; set; }

        public string Driver1LastName { get; set; }

        public int? Driver1DispatcherID { get; set; }

        public int? Driver2ID { get; set; }

        public string Driver2Name { get; set; }

        public string Driver2FirstName { get; set; }

        public string Driver2LastName { get; set; }

        public int? Driver2DispatcherID { get; set; }
        
        public string TractorNumber { get; set; }

        public string Trailer { get; set; }

        public string TrailerIn { get; set; }

        public string Comment { get; set; }

        public string Warnings { get; set; }

        public bool InTransitOnRegularDeliveryDay { get; set; }

        public DateTime? DepartureTime { get; set; }

        public string PrintFileName { get; set; }

        public IEnumerable<LoadDragDropViewModel> Loads { get; set; }

        public IEnumerable<DispatchLoadLinkViewModel> LoadHistory { get; set; }

        public IEnumerable<ContainerViewModel> Containers { get; set; }

        public DispatchViewModel() { }

        public DispatchViewModel(DailyDispatch x)
        {
            DailyDispatchID = x.DailyDispatchID;
            Timestamp = x.Timestamp;
            DispatchDate = x.DispatchDate;
            Generated = x.Generated;
            CarrierID = x.Carrier != null ? x.Carrier.CarrierID : default(int?);
            CarrierName = x.Carrier != null ? x.Carrier.Name : null;
            CarrierRate = x.CarrierRate;
            CarrierMiles = x.CarrierMiles;
            FuelSurcharge = x.FuelSurcharge;
            CarrierTotalCharge = x.CarrierTotalCharge;
            LockCarrierTotalCharge = x.LockCarrierTotalCharge;
            Miles = x.Miles;
            Driver1ID = x.Driver1 != null ? x.Driver1.DriverID : default(int?);
            Driver1Name = x.Driver1 != null ? x.Driver1.FullName : null;
            Driver2ID = x.Driver2 != null ? x.Driver2.DriverID : default(int?);
            Driver2Name = x.Driver2 != null ? x.Driver2.FullName : null;
            TractorNumber = x.TractorNumber != null ? x.TractorNumber : null;
            Trailer = x.Trailer;
            TrailerIn = x.TrailerIn;
            Comment = x.Comment;
            DepartureTime = x.DepartureTime;
            Loads = x.Loads != null ? x.Loads.OrderBy(y => y.DispatchLoadOrder).Select(y => new LoadDragDropViewModel(y)) : null;
            LoadHistory = x.LoadHistory != null ? x.LoadHistory.Select(y => new DispatchLoadLinkViewModel(y)) : null;
            Containers = x.Containers != null ? x.Containers.Select(y => new ContainerViewModel(y)) : null;

            if (x.CarrierID.HasValue)
            {
                if (x.CarrierTotalCharge.HasValue == false)
                {
                    if (x.CarrierRate.HasValue == false || x.CarrierRate == 0m)
                    {
                        Warnings = (Warnings == null ? string.Empty : "\n") + "Carrier Dispatch has no Rate.";
                    }
                    if (x.CarrierMiles.HasValue == false || x.CarrierMiles == 0)
                    {
                        Warnings = (Warnings == null ? string.Empty : "\n") + "Carrier Dispatch has no Miles.";
                    }
                    if (x.FuelSurcharge.HasValue == false)
                    {
                        Warnings = (Warnings == null ? string.Empty : "\n") + "Carrier Dispatch has no Fuel Surcharge.";
                    }
                }
            }

            if (x.Loads != null && x.Loads.Any(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP && y.LinearFeet.HasValue == false))
            {
                Warnings = (Warnings == null ? string.Empty : "\n") + "Cleanup has no footage.";
            }
        }

        public DispatchViewModel(DailyDispatchSlim x)
        {
            DailyDispatchID = x.DailyDispatchID;
            DispatchDate = x.DispatchDate;
            Generated = x.Generated;
            CarrierID = x.Carrier != null ? x.Carrier.CarrierID : default(int?);
            CarrierName = x.Carrier != null ? x.Carrier.Name : null;
            Driver1ID = x.Driver1 != null ? x.Driver1.DriverID : default(int?);
            Driver1Name = x.Driver1 != null ? x.Driver1.FullName : null;
            Driver2ID = x.Driver2 != null ? x.Driver2.DriverID : default(int?);
            Driver2Name = x.Driver2 != null ? x.Driver2.FullName : null;
            TractorNumber = x.TractorNumber != null ? x.TractorNumber : null;
            Trailer = x.Trailer;
            TrailerIn = x.TrailerIn;
            Comment = x.Comment;
            DepartureTime = x.DepartureTime;
            Loads = x.Loads.OrderBy(y => y.DispatchLoadOrder).Select(y => new LoadDragDropViewModel(y));
            LoadHistory = x.LoadHistory != null ? x.LoadHistory.Select(y => new DispatchLoadLinkViewModel(y)) : null;

            if (x.CarrierID.HasValue)
            {
                if (Loads.Any(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD))
                {
                    PrintFileName = CarrierName + " Driver Paysheet.pdf";
                }
                else
                {
                    PrintFileName = CarrierName + " Carrier Dispatch.pdf";
                }

                if (x.CarrierTotalCharge.HasValue == false)
                {
                    if (x.CarrierRate.HasValue == false || x.CarrierRate == 0m)
                    {
                        Warnings = (Warnings == null ? string.Empty : "\n") + "Carrier Dispatch has no Rate.";
                    }
                    if (x.CarrierMiles.HasValue == false || x.CarrierMiles == 0)
                    {
                        Warnings = (Warnings == null ? string.Empty : "\n") + "Carrier Dispatch has no Miles.";
                    }
                    if (x.FuelSurcharge.HasValue == false)
                    {
                        Warnings = (Warnings == null ? string.Empty : "\n") + "Carrier Dispatch has no Fuel Surcharge.";
                    }
                }
            }
            else if (x.Driver1ID.HasValue && x.Driver2ID.HasValue)
            {
                PrintFileName = "Paysheet for " + x.Driver1.LastName + "," + x.Driver2.LastName + ".pdf";
            }
            else if (x.Driver1ID.HasValue)
            {
                PrintFileName = "Paysheet for " + x.Driver1.LastName + ".pdf";
            }
            else if (x.Driver2ID.HasValue)
            {
                PrintFileName = "Paysheet for " + x.Driver2.LastName + ".pdf";
            }
            else
            {
                PrintFileName = "Paysheet.pdf";
            }

            if (x.Loads != null && x.Loads.Any(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP && y.LinearFeet.HasValue == false))
            {
                Warnings = (Warnings == null ? string.Empty : "\n") + "Cleanup has no footage.";
            }
        }

        public void SetFinalInstantiationValues()
        {
            if (CarrierID.HasValue)
            {
                if (Loads.Any(y => y.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD))
                {
                    PrintFileName = CarrierName + " Driver Paysheet.pdf";
                }
                else
                {
                    PrintFileName = CarrierName + " Carrier Dispatch.pdf";
                }

                if (CarrierTotalCharge.HasValue == false)
                {
                    if (CarrierRate.HasValue == false || CarrierRate == 0m)
                    {
                        Warnings = (Warnings == null ? string.Empty : "\n") + "Carrier Dispatch has no Rate.";
                    }
                    if (CarrierMiles.HasValue == false || CarrierMiles == 0)
                    {
                        Warnings = (Warnings == null ? string.Empty : "\n") + "Carrier Dispatch has no Miles.";
                    }
                    if (FuelSurcharge.HasValue == false)
                    {
                        Warnings = (Warnings == null ? string.Empty : "\n") + "Carrier Dispatch has no Fuel Surcharge.";
                    }
                }
            }
            else if (Driver1ID.HasValue && Driver2ID.HasValue)
            {
                PrintFileName = "Paysheet for " + Driver1LastName + "," + Driver2LastName + ".pdf";
            }
            else if (Driver1ID.HasValue)
            {
                PrintFileName = "Paysheet for " + Driver1LastName + ".pdf";
            }
            else if (Driver2ID.HasValue)
            {
                PrintFileName = "Paysheet for " + Driver2LastName + ".pdf";
            }
            else
            {
                PrintFileName = "Paysheet.pdf";
            }

            if (Loads != null && Loads.Any(y => y.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP && y.LinearFeet.HasValue == false))
            {
                Warnings = (Warnings == null ? string.Empty : "\n") + "Cleanup has no footage.";
            }
        }
    }
}