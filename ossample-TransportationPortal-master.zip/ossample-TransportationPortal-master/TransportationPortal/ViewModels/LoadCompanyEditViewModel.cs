﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using TransportationPortal.Models;
using TransportationPortal.Repositories;

namespace TransportationPortal.ViewModels
{
	public class LoadCompanyEditViewModel
	{
		public LoadCompany LoadCompany { get; set; }

		public LoadCompanyViewModel DeliveryCompany { get; set;}

		public LoadCompanyViewModel DeliveryCompanyHL { get; set;}


		public LoadCompanyEditViewModel()
		{
		}

		public LoadCompanyEditViewModel(LoadCompany x)
		{
			if (x != null)
			{
				LoadCompany = x;

				if (LoadCompany.IsVendor)
				{
					switch (LoadCompany.DeliveryType)
					{
						case DatabaseLists.LOAD_DELIVERY_TYPE_WAREHOUSE:
							DeliveryCompanyHL = new LoadCompanyViewModel(LoadCompany.DeliveryCompany);
							break;
						case DatabaseLists.LOAD_DELIVERY_TYPE_DALLAS_DISPATCH:
						case DatabaseLists.LOAD_DELIVERY_TYPE_DIRECT:
						case DatabaseLists.LOAD_DELIVERY_TYPE_OKC_DISPATCH:
							DeliveryCompany = new LoadCompanyViewModel(LoadCompany.DeliveryCompany);
							break;
					}
				}
			}
		}
	}
}