﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class ContainerReviewViewModel
	{
		public string SubmitButtonAssign { get; set; }

		public string SubmitButtonCreate { get; set; }

		public string SubmitButtonUpdate { get; set; }

		public bool SelectNotified { get; set; }

		public bool SelectDallas { get; set; }

		public bool SelectOKC { get; set; }

		public bool SelectEmpty { get; set; }

		public bool SelectEmptyHemispheres { get; set; }

		public bool SelectLoadingHobbyLobby { get; set; }

		public int? DailyDispatchID { get; set; }

		public string[] ContainerSelect { get; set; }

		public DateTime? PullDate { get; set; }

		public string Note { get; set; }

		public IEnumerable<ContainerViewModel> SelectedContainers { get; set; }
	}
}