﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public enum FieldName
	{
		None,
		DispatchTrailer,
		DispatchTrailerIn,
		DispatchComment,
		LoadFeet
	}

	public class FieldUpdate
	{
		public int recordid { get; set; }

		public FieldName fieldid { get; set; }

		public string fieldvalue { get; set; }
	}
}