﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
	public class DispatcherViewModel
	{
		// Output only.
		public IEnumerable<Dispatcher> Dispatchers { get; set; }

		public class Dispatcher
		{
			public Int32 DispatcherID { get; set; }
			public string FirstName { get; set; }
			public string LastName { get; set; }
			public string Drivers { get; set; }
		}
	}
}