﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class OutboundRouteViewModel
	{
		public string CreateSubmitButton { get; set; }

		public string SearchSubmitButton { get; set; }

		public bool Week1Sunday { get; set; }
		public bool Week1Monday { get; set; }
		public bool Week1Tuesday { get; set; }
		public bool Week1Wednesday { get; set; }
		public bool Week1Thursday { get; set; }
		public bool Week1Friday { get; set; }
		public bool Week1Saturday { get; set; }

		public bool Week2Sunday { get; set; }
		public bool Week2Monday { get; set; }
		public bool Week2Tuesday { get; set; }
		public bool Week2Wednesday { get; set; }
		public bool Week2Thursday { get; set; }
		public bool Week2Friday { get; set; }
		public bool Week2Saturday { get; set; }

		[DisplayName("Search:")]
		public string SearchField { get; set; }
		
		// Output only.
		public IEnumerable<Route> OutboundRoutes { get; set; }

		public class Route
		{
			public Int32 OutboundRouteID { get; set; }
			public string DispatchGroup { get; set; }
			public string TractorNumber { get; set; }
			public string CarrierName { get; set; }
			public string Driver1Name { get; set; }
			public string Driver2Name { get; set; }
			public string City { get; set; }
			public string StateCode { get; set; }
			public Int32 WeekNumber { get; set; }
			public string DayName { get; set; }

			public string InboundWeekDay { get; set; }

			public DateTime? DepartureTime { get; set; }
			public string Comment { get; set; }

			public string Load1Store { get; set; }
			public string Load1Type { get; set; }
			public string Load1DeliveryDay { get; set; }
			public DateTime? Load1DeliveryTime { get; set; }

			public string Load2Store { get; set; }
			public string Load2Type { get; set; }
			public string Load2DeliveryDay { get; set; }
			public DateTime? Load2DeliveryTime { get; set; }

			public string Load3Store { get; set; }
			public string Load3Type { get; set; }
			public string Load3DeliveryDay { get; set; }
			public DateTime? Load3DeliveryTime { get; set; }

			public Route(OutboundRoute x)
			{
				OutboundRouteID = x.OutboundRouteID;
				DispatchGroup = x.DispatchGroup;
				InboundWeekDay = x.InboundWeekDay != null ? x.InboundWeekDay.ShortName : null;
				TractorNumber = x.TractorNumber;
				CarrierName = x.Carrier != null ? x.Carrier.Name : null;
				Driver1Name = x.Driver1 != null ? x.Driver1.FullName : null;
				Driver2Name = x.Driver2 != null ? x.Driver2.FullName : null;
				WeekNumber = x.WeekNumber;
				DayName = x.WeekDay.ShortName;
				DepartureTime = x.DepartureTime;
				Comment = x.Comment;
				Load1Store = x.Load1Store != null ? x.Load1Store.StoreAndCompany : null;
				Load1Type = x.Load1Type;
				Load1DeliveryDay = x.Load1DeliveryDay != null ? x.Load1DeliveryDay.ShortName : null;
				Load1DeliveryTime = x.Load1DeliveryTime;
				Load2Store = x.Load2Store != null ? x.Load2Store.StoreAndCompany : null;
				Load2Type = x.Load2Type;
				Load2DeliveryDay = x.Load2DeliveryDay != null ? x.Load2DeliveryDay.ShortName : null;
				Load2DeliveryTime = x.Load2DeliveryTime;
				Load3Store = x.Load3Store != null ? x.Load3Store.StoreAndCompany : null;
				Load3Type = x.Load3Type;
				Load3DeliveryDay = x.Load3DeliveryDay != null ? x.Load3DeliveryDay.ShortName : null;
				Load3DeliveryTime = x.Load3DeliveryTime;

				if (x.Load1Store != null)
				{
					City = x.Load1Store.City;
					StateCode = x.Load1Store.StateCode;
				}
				else if (x.Load2Store != null)
				{
					City = x.Load2Store.City;
					StateCode = x.Load2Store.StateCode;
				}
				else if (x.Load3Store != null)
				{
					City = x.Load3Store.City;
					StateCode = x.Load3Store.StateCode;
				}
				else
				{
					City = x.City;
					StateCode = x.StateCode;
				}
			}
		}
	}
}