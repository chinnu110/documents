﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class LoadCompanyViewModel
	{
		public Int32? LoadCompanyID { get; set; }

		public bool IsPickupAddress { get; set; }

		[MaxLength(50)]
		[Display(Name = "Company Name")]
		public string Name { get; set; }

		[MaxLength(10)]
		public string Type { get; set; }

		[MaxLength(100)]
		[Display(Name = "Address 1")]
		[DataType(DataType.MultilineText)]
		public string Address1 { get; set; }

		[MaxLength(100)]
		[Display(Name = "Address 2")]
		[DataType(DataType.MultilineText)]
		public string Address2 { get; set; }

		[MaxLength(50)]
		public string City { get; set; }

		[MaxLength(2)]
		[Display(Name = "State")]
		public string StateCode { get; set; }

		[MaxLength(10)]
		[Display(Name = "Zip Code")]
		public string Zip { get; set; }

		[MaxLength(3)]
		[Display(Name = "Country")]
		public string CountryCode { get; set; }

		[MaxLength(50)]
		[Display(Name = "Contact Name")]
		public string Contact { get; set; }

		[MaxLength(100)]
		public string Email { get; set; }

		[MaxLength(50)]
		public string Phone { get; set; }

		[MaxLength(50)]
		public string Reference { get; set; }

		[MaxLength(50)]
		public string Zone { get; set; }

		[Display(Name = "Available Times")]
		public string AvailableTimes { get; set; }

		public string PreselectDeliveryType { get; set; }

		public int? PreselectDeliveryCompanyID { get; set; }


		public LoadCompanyViewModel()
		{
		}

		public LoadCompanyViewModel(LoadCompany x)
		{
			if (x != null)
			{
				Address1 = x.Address1;
				Address2 = x.Address2;
				City = x.City;
				Contact = x.Contact;
				CountryCode = x.CountryCode;
				Email = x.Email;
				LoadCompanyID = x.LoadCompanyID;
				Name = x.Name;
				Phone = x.Phone;
				Reference = x.Reference;
				StateCode = x.StateCode;
				Type = x.Type;
				Zip = x.Zip;
				Zone = x.Zone;
				AvailableTimes = x.AvailableTimes;
				IsPickupAddress = x.IsPickupAddress;

				if (x.IsPickupAddress)
				{
					PreselectDeliveryType = x.DeliveryType;
					PreselectDeliveryCompanyID = x.DeliveryCompanyID;
				}
			}
		}
	}
}