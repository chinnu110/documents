﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using TransportationPortal.Models;
using TransportationPortal.Repositories;

namespace TransportationPortal.ViewModels
{
    public class LoadDragDropViewModel
    {
        public string ViewStatus { get; set; }

        public Int32 LoadID { get; set; }

        public Int32? DailyDispatchID { get; set; }

        public string LoadType { get; set; }

        public string LoadName { get; set; }

        public Int32 DispatchLoadOrder { get; set; }

        public string LoadDescription { get; set; }

        public string LoadPickupCity { get; set; }

        public string LoadPickupStateCode { get; set; }

        public string LoadPickupZip { get; set; }

        public string LoadDeliveryCity { get; set; }

        public string LoadDeliveryStateCode { get; set; }

        public DateTime? EtaDate { get; set; }

        public DateTime? EtaTime { get; set; }

        public string DeliveryType { get; set; }

        public DateTime ReadyDate { get; set; }

        public DateTime? PickupDate { get; set; }

        public DateTime? PickupTime { get; set; }

        public Int32? Pallets { get; set; }

        public bool Truckload { get; set; }

        public Int32? Totes { get; set; }

        public Int32? LoadLocks { get; set; }

        public Int32? Cartons { get; set; }

        public Int32? Weight { get; set; }

        public bool DoubleStack { get; set; }

        public string DoubleStackDisplay { get { return DoubleStack == true ? "Yes" : "No"; } }

        public bool DownStack { get; set; }

        public string DownStackDisplay { get { return DownStack == true ? "Yes" : "No"; } }

        public Int32? Cube { get; set; }

        public Int32? LinearFeet { get; set; }

        public string Comment { get; set; }

        public string StoreCompanyID { get; set; }

        public int? StoreNumber { get; set; }

        public string StoreAndCompany { get; set; }

        public bool StoreOpening { get; set; }

        public string StoreLoadType { get; set; }

        public string StoreCity { get; set; }

        public string StoreStateCode { get; set; }

        public bool DisableRemoveButton { get; set; }

        public string StoreDeliveries { get; set; }

        public LoadDragDropViewModel()
        { }

        public LoadDragDropViewModel(Load x, bool loadDispatches = false)
        {
            LoadID = x.LoadID;
            DailyDispatchID = x.DailyDispatchID;
            LoadName = x.LoadName;
            LoadType = x.LoadType;
            DispatchLoadOrder = x.DispatchLoadOrder;
            LoadDescription = x.LoadDescription;
            LoadPickupCity = x.LoadPickupCity;
            LoadPickupStateCode = x.LoadPickupStateCode;
            LoadPickupZip = x.LoadPickupZip;
            LoadDeliveryCity = x.LoadDeliveryCity;
            LoadDeliveryStateCode = x.LoadDeliveryStateCode;
            ReadyDate = x.ReadyDate;
            PickupDate = x.PickupDate;
            if (x.PickupDate.HasValue && x.PickupDate.Value.TimeOfDay != TimeSpan.Zero)
            {
                PickupTime = x.PickupDate.Value;
            }
            else
            {
                PickupTime = null;
            }
            DeliveryType = x.DeliveryType;
            Pallets = x.Pallets;
            Totes = x.Totes;
            LoadLocks = x.LoadLocks;
            Cartons = x.Cartons;
            Truckload = x.Truckload;
            Cube = x.Cube;
            DoubleStack = x.DoubleStack;
            DownStack = x.DownStack;
            Weight = x.Weight;
            LinearFeet = x.LinearFeet;
            StoreAndCompany = x.Store != null ? x.Store.StoreAndCompany : null;
            StoreLoadType = x.StoreLoadType;
            StoreOpening = x.StoreOpening;
            EtaDate = x.EtaDate;
            if (x.EtaDate.HasValue && x.EtaDate.Value.TimeOfDay != TimeSpan.Zero)
            {
                EtaTime = x.EtaDate.Value;
            }
            else
            {
                EtaTime = null;
            }
            Comment = x.Comment;

            if (loadDispatches)
            {
                LoadDispatches(x.DailyDispatch);
            }

            if (x.LoadType == DatabaseLists.INBOUND_STORE_CLEANUP)
            {
                if (x.PerformedCleanupStatus != PerformedCleanupStatus.None) //|| (x.ScheduledDate.HasValue && x.ScheduledDate < DateTime.Today))
                {
                    DisableRemoveButton = true;
                }
            }
        }

        public LoadDragDropViewModel(LoadSlim x)
        {
            LoadID = x.LoadID;
            DailyDispatchID = x.DailyDispatchID;
            LoadName = x.LoadName;
            LoadType = x.LoadType;
            DispatchLoadOrder = x.DispatchLoadOrder;
            LoadDescription = x.LoadDescription;
            LoadPickupCity = x.LoadPickupCity;
            LoadPickupStateCode = x.LoadPickupStateCode;
            LoadDeliveryCity = x.LoadDeliveryCity;
            LoadDeliveryStateCode = x.LoadDeliveryStateCode;
            ReadyDate = x.ReadyDate;
            PickupDate = x.PickupDate;
            if (x.PickupDate.HasValue && x.PickupDate.Value.TimeOfDay != TimeSpan.Zero)
            {
                PickupTime = x.PickupDate.Value;
            }
            else
            {
                PickupTime = null;
            }
            DeliveryType = x.DeliveryType;
            LinearFeet = x.LinearFeet;
            Pallets = x.Pallets;
            Totes = x.Totes;
            LoadLocks = x.LoadLocks;
            Cartons = x.Cartons;
            StoreAndCompany = x.Store != null ? x.Store.StoreAndCompany : null;
            StoreOpening = x.StoreOpening;
            EtaDate = x.EtaDate;
            if (x.EtaDate.HasValue && x.EtaDate.Value.TimeOfDay != TimeSpan.Zero)
            {
                EtaTime = x.EtaDate.Value;
            }
            else
            {
                EtaTime = null;
            }
        }

        public void LoadDispatches(DailyDispatch dispatch)
        {
            if (dispatch != null && dispatch.Loads != null)
            {
                List<Load> deliveries = dispatch.Loads
                    .Where(x => x.LoadType == DatabaseLists.OUTBOUND_STORE_LOAD)
                    .OrderBy(x => x.DispatchLoadOrder)
                    .ToList();

                if (deliveries.Count() > 0)
                {
                    StoreDeliveries = string.Join(",", deliveries.Select(x => x.Store.StoreAndCompany));
                }
                else
                {
                    StoreDeliveries = "None";
                }
            }
            else
            {
                StoreDeliveries = "None";
            }
        }
    }
}