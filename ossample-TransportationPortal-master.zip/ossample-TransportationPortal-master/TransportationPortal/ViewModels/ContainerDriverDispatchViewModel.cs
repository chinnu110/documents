﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class ContainerDriverDispatchViewModel
	{
		public Int32 DriverID { get; set; }
		
		public string FullName { get; set; }
		
		public string DriverShift { get; set; }

		public string DriverShiftStart { get; set; }

		public string PartTime { get; set; }

		public int DailyDispatchID { get; set; }

		public int LoadCount { get; set; }

		public string NoseLoadStore { get; set; }

		public IEnumerable<ContainerViewModel> Containers { get; set; }

		public ContainerDriverDispatchViewModel() { }

		public ContainerDriverDispatchViewModel(Driver x)
		{
			DriverID = x.DriverID;
			FullName = x.FullName;

			PartTime = x.PartTime ? "PT" : string.Empty;

			switch (x.DriverShift)
			{
				case Models.DriverShift.Day:
					DriverShift = "Day";
					break;
				case Models.DriverShift.Night:
					DriverShift = "Night";
					break;
				default:
					DriverShift = string.Empty;
					break;
			}

			switch (x.DriverShiftStart)
			{
				case Models.DriverShiftStart.Dallas:
					DriverShiftStart = "Dallas";
					break;
				case Models.DriverShiftStart.OKC:
					DriverShiftStart = "OKC";
					break;
				default:
					DriverShiftStart = string.Empty;
					break;
			}
		}
	}
}