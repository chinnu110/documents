﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public class CarrierRateHistoryRequest
	{
		public int? CarrierID { get; set; }

		public ICollection<int> OutboundLoadID { get; set; }
	}
}