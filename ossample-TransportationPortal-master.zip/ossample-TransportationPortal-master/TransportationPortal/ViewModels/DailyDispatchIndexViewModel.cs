﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
    public class DailyDispatchIndexViewModel
    {
        [DisplayName("History View")]
        public bool AdminViewMode { get; set; }

        public DateTime? FromDate { get; set; }

        public DateTime? ThruDate { get; set; }

        public int? DailyDispatchID { get; set; }

        public List<DateTime> SelectedDates { get; set; }

        public DateTime? SelectDate { get; set; }

        [DisplayName("Search:")]
        public string SearchField { get; set; }

        [DisplayName("Include Carrier Routes?")]
        public bool CarrierSelect { get; set; }

        [DisplayName("Include Company Routes?")]
        public bool CompanySelect { get; set; }

        [DisplayName("Include Unassigned Routes?")]
        public bool NoCarrierOrCompanySelect { get; set; }

        [DisplayName("Include Warnings?")]
        public bool DispatchesWithWarnings { get; set; }

        [DisplayName("Include Non-Loaded Routes?")]
        public LoadListFilterEnum LoadListFilterSelect { get; set; }

        public SelectList LoadListFilterSelectList { get; set; }

        public enum LoadListFilterEnum
        {
            All = 0,
            With_Any_Loads,
            With_Outbound_Loads,
            With_Outbound_Loads_and_Transit,
            With_Outbound_Loads_Only,
            With_Inbound_Loads,
            With_Inbound_Loads_Only,
            Without_Loads
        }

        [Display(Name = "Dispatcher")]
        public Int32? DispatcherID { get; set; }

        public SelectList DispatcherList { get; set; }

        public SelectList DriverList { get; set; }

        [Display(Name = "Carrier")]
        public Int32? CarrierID { get; set; }

        [Display(Name = "Driver")]
        public Int32? DriverID { get; set; }

        public string StoreNumber { get; set; }

        public string TractorNumber { get; set; }

        public string TrailerNumber { get; set; }

        public SelectList CarrierList { get; set; }

        public enum DateTypeSelectEnum
        {
            ArrivalDate = 0,
            DepartureDate = 1
        }

        public DateTypeSelectEnum DateTypeSelect { get; set; }

        [Display(Name = "Multiple Date Select")]
        public bool MultipleDateSelect { get; set; }

        public PagingViewModel Paging { get; set; }

        public List<DispatchWeek> DispatchWeeks { get; set; }

        public class DispatchWeek
        {
            public int WeekNumber { get; set; }
            public int WeekDayIDStart { get; set; }
            public int WeekDayIDEnd { get; set; }
            public DateTime?[] WeekDay { get; set; }
        }

        public bool CanUseTrailerUpdateMode { get; set; }

        public bool TrailerUpdateMode { get; set; }

        public bool CanUseNoteUpdateMode { get; set; }

        public bool NoteUpdateMode { get; set; }

        public bool CanUseCleanupUpdateMode { get; set; }

        public bool CleanupUpdateMode { get; set; }

        public string SortColumn { get; set; }

        public int SortDirection { get; set; }

        public string SortingID { get; set; }

        public SelectList SortingList { get; set; }

        // Output only.

        public List<DispatchViewModel> Dispatches { get; set; }

        public IEnumerable<SelectListItem> DispatcherListData { get; set; }

        public IEnumerable<SelectListItem> DriverListData { get; set; }

        public IEnumerable<SelectListItem> CarrierListData { get; set; }

        public DateTime? OldestOpenDispatchDate { get; set; }

        public DateTime? LatestSelectedDeliveryDate { get; set; }

        public bool DriverShiftDay { get; set; }

        public bool DriverShiftNight { get; set; }

        public bool DriverShiftStartOKC { get; set; }

        public bool DriverShiftStartDallas { get; set; }

        public bool DriverFullTime { get; set; }

        public bool DriverPartTime { get; set; }
        
        public DailyDispatchIndexViewModel() { }

        public DailyDispatchIndexViewModel(DailyDispatchIndexViewModel prev)
        {
            DispatchWeeks = prev.DispatchWeeks;
            SelectedDates = prev.SelectedDates;
            Paging = prev.Paging;
            Paging.Page = 1;

            DispatcherListData = prev.DispatcherListData;
            CarrierListData = prev.CarrierListData;
        }
    }
}