﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class StoreUpdateViewModel
	{
		public Store Store { get; set; }

		public List<CarrierInfo> Carriers { get; set; }

		public class CarrierInfo
		{
			public int CarrierID { get; set; }

			public string Name { get; set; }

			[DataType(DataType.Currency)]
			public decimal? RatePerMile { get; set; }

			[DataType(DataType.Currency)]
			public decimal? FlatRate { get; set; }

			public int MileageCalcType { get; set; }

			public int? Miles { get; set; }

			[DataType(DataType.Currency)]
			public decimal? Total 
			{
				get
				{
					if (MileageCalcType == (int)CarrierChargeCalculation.MileageCalcEnum.UseRatePerMile)
					{
						return Miles * RatePerMile;
					}
					else
					{
						return FlatRate;
					}
				}
			}
		}
	}
}