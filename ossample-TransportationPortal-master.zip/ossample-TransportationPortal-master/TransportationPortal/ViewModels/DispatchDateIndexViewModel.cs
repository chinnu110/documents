﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
	public class DispatchDateIndexViewModel
	{
		// Output only.
		public IEnumerable<DispatchDate> DispatchDates { get; set; }

		public class DispatchDate
		{
			public DateTime Date { get; set; }

			public Int32 WeekNumber { get; set; }

			public Int32 WeekDayID { get; set; }

			public string WeekDayName { get; set; }

			public Int32 TemplateWeekNumber { get; set; }

			public Int32 TemplateWeekDayID { get; set; }

			public string TemplateWeekDayName { get; set; }
		}
	}
}