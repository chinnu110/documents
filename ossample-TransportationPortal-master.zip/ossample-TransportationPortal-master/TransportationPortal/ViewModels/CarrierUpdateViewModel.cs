﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class CarrierUpdateViewModel
	{
		public Carrier Carrier { get; set; }

		public List<StoreInfo> Stores { get; set; }

		public class StoreInfo
		{
			public int StoreID { get; set; }

			public string StoreName { get; set; }

			public string StoreLocation { get; set; }

			[DataType(DataType.Currency)]
			public decimal? RatePerMile { get; set; }
		}
	}
}