﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class DispatchLoadLinkViewModel
	{
		public Int32 LoadID { get; set; }

		public Int32? DailyDispatchID { get; set; }

		public string LoadType { get; set; }

		public string LoadName { get; set; }

		public string LoadDescription { get; set; }

		public string LoadPickupCity { get; set; }

		public string LoadPickupStateCode { get; set; }

		public string LoadDeliveryCity { get; set; }

		public string LoadDeliveryStateCode { get; set; }

		public DateTime? DepartureTime { get; set; }

		public DateTime? ArrivalTime { get; set; }

		public string DeliveryType { get; set; }

		public DispatchLoadLinkViewModel()
		{ }

		public DispatchLoadLinkViewModel(DispatchLoadLinkHistory model)
		{
			LoadID = model.LoadID;
			DailyDispatchID = model.DailyDispatchID;
			LoadName = model.Load.LoadName;
			LoadType = model.Load.LoadType;
			LoadDescription = model.Load.LoadDescription;
			LoadPickupCity = model.Load.LoadPickupCity;
			LoadPickupStateCode = model.Load.LoadPickupStateCode;
			LoadDeliveryCity = model.Load.LoadDeliveryCity;
			LoadDeliveryStateCode = model.Load.LoadDeliveryStateCode;
			DeliveryType = model.Load.DeliveryType;
		}

		public DispatchLoadLinkViewModel(DispatchLoadLinkHistorySlim model)
		{
			LoadID = model.LoadID;
			DailyDispatchID = model.DailyDispatchID;
			LoadName = model.Load.LoadName;
			LoadType = model.Load.LoadType;
			LoadDescription = model.Load.LoadDescription;
			LoadPickupCity = model.Load.LoadPickupCity;
			LoadPickupStateCode = model.Load.LoadPickupStateCode;
			LoadDeliveryCity = model.Load.LoadDeliveryCity;
			LoadDeliveryStateCode = model.Load.LoadDeliveryStateCode;
			DeliveryType = model.Load.DeliveryType;
		}
	}
}