﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class ContainerUpdateViewModel
	{
		public string ContainerNumber { get; set; }

		public int Count { get; set; }

		[Display(Name = "Pull Driver")]
		public string PullDriverName { get; set; }

		[Display(Name = "Commit-OKC Driver")]
		public string CommitDriverName { get; set; }

		[Display(Name = "Return Driver")]
		public string ReturnDriverName { get; set; }

		[DisplayName("Pull Date")]
		public DateTime? PullDate { get; set; }

		[DisplayName("Pickup Location")]
		public string PickupLocation { get; set; }

		public bool PickupLocationClear { get; set; }

		[DisplayName("Shag Notes")]
		public string ShagNotes { get; set; }

		public bool ShagNotesClear { get; set; }

		[DisplayName("Return Notes")]
		public string ReturnNotes { get; set; }

		public bool ReturnNotesClear { get; set; }

		[DisplayName("Lot Location")]
		public string LotLocation { get; set; }

		public bool LotLocationClear { get; set; }

		[DisplayName("Lot Notes")]
		public string LotNotes { get; set; }

		public bool LotNotesClear { get; set; }

		[DisplayName("Location/Notes")]
		public string Note { get; set; }

		public bool NoteClear { get; set; }


		public List<ContainerDispatch> ContainerList { get; set; }

		public class ContainerDispatch
		{
			public string ContainerNumber { get; set; }

			public int[] DailyDispatchID { get; set; }
		}
	}
}