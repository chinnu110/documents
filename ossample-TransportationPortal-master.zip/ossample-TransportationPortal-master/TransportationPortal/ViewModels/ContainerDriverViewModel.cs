﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class ContainerDriverViewModel
	{
		[DisplayName("Selected Date")]
		public DateTime SelectedDate { get; set; }

		public bool DriverShiftDay { get; set; }

		public bool DriverShiftNight { get; set; }

		public bool DriverShiftStartOKC { get; set; }

		public bool DriverShiftStartDallas { get; set; }

		public bool DriverFullTime { get; set; }

		public bool DriverPartTime { get; set; }

		public string SortColumn { get; set; }

		public int SortDirection { get; set; }

		public List<ContainerDriverDispatchViewModel> DriverList { get; set; }

	}
}