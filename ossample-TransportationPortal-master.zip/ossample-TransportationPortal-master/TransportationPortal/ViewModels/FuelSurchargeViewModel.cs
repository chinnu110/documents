﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
    public class FuelSurchargeViewModel
    {
        public string SubmitButton { get; set; }

        public Int32 FuelSurchargeID { get; set; }

        [Required]
        public DateTime ActiveDate { get; set; }

        [Required]
        public DateTime? ActiveEndDate { get; set; }

        [Display(Name = "Fuel Surcharge")]
        [DataType(DataType.Currency)]
        public decimal? Amount { get; set; }

        public Dictionary<int, decimal?> FuelSurchargeApply { get; set; }

        [DataType(DataType.MultilineText)]
        public string Comment { get; set; }

        [Timestamp]
        public Byte[] Timestamp { get; set; }

        public string CreateUser { get; set; }

        public DateTime CreateDate { get; set; }

        public string ChangeUser { get; set; }

        public DateTime? ChangeDate { get; set; }

        public string SortColumn { get; set; }

        public int SortDirection { get; set; }

        public string SortingID { get; set; }

        public SelectList SortingList { get; set; }

        public List<DispatchViewModel> Dispatches { get; set; }
    }
}