﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace TransportationPortal.ViewModels
{
	/// <summary>
	/// ScreenMessages ViewModel and shared html provide a turn-around message capability.
	/// This feature provides enhanced message display which can also ask for user input or acknowledgement.
	/// 
	/// Message types: (ActionNeeded enum)
	///	  ShowOnly   - Message will display at least once, even if all edits passed. This is a one-time reminder message.
	///	  ErrorFixed - Message will display each time it is issued. It is not kept.
	///	  NeedAck    - Message will display with an [ ]OK check box. The user must check the box to continue.
	///	  NeedYesNo  - Message will display with ( )YES ( )NO radio buttons. The user must choose an answer to continue.
	/// </summary>
	
	public class ScreenMessagesViewModel
	{
		// ScreenMessageViewModel creation:
		// 
		//   [HttpGet]
		//   public ActionResult Edit(int id)
		//   {
		//     ScreenMessagesViewModel screenMessages = new ScreenMessagesViewModel();
		//      
		//   [HttpPost]
		//   public ActionResult Edit(Model model, ScreenMessagesViewModel screenMessages)
		//   {
		//   	screenMessages = new ScreenMessagesViewModel(screenMessages);
		// 
		// Message Creation:
		// 
		//   screenMessages.Add(new ScreenMessagesViewModel.Message
		//   {
		// 	Text = "I need you to acknowledge this before continuing. Check OK to continue.",
		// 	Key = "ConfirmThis",
		// 	ActionNeeded = ScreenMessagesViewModel.ActionNeeded.NeedAck
		//   });
		// 
		//   screenMessages.Add(new ScreenMessagesViewModel.Message
		//   {
		// 	Text = "I need to know whether or not to handle this before continuing. Check YES or NO to continue.",
		// 	Key = "DetermineThis",
		// 	ActionNeeded = ScreenMessagesViewModel.ActionNeeded.NeedYesNo
		//   });
		// 
		// Message validation:
		// 
		//   After all edits have been performed, call this method on the ScreenMessagesViewModel to confirm that
		//   there are no ErrorFixed messages that need user action and all other messages have a user response.
		//   
		//   if (screenMessages.AllMessagesFixedOrAcknowledged() == false)
		//   {
		//   	ViewBag.ScreenMessages = screenMessages;
		//   	return View(screen);
		//   }
		//   
		//   continue processing here.
		// 
		// Message action handling:
		// 
		//   When all messages are fixed or acknowledged, then the user responses can be obtained to tailor processing.
		// 
		//   var userMessageResponse = screenMessages.MessageList.FirstOrDefault(x => x.Key == "DetermineThis");
		//   if (userMessageResponse != null)  // If message was issued
		//   {
		//   	if (userMessageResponse.UserAnswer == 1)  // Check the user response
		//   	{
		// 

		public enum ActionNeeded
		{
			ShowOnly = 0,
			ErrorFixed,
			NeedAck,
			NeedYesNo
		}

		public ScreenMessagesViewModel()
		{
			MessageList = new List<Message>();
		}

		/// <summary>
		/// Build the new ScreenMessages from any previous one. This will keep all messages except ActionNeeded.ErrorFixed messages. 
		/// ActionNeeded.ErrorFixed messages can be reissued if needed.
		/// </summary>
		/// <param name="previous"></param>
		public ScreenMessagesViewModel(ScreenMessagesViewModel previous)
		{
			MessageList = new List<Message>();

			foreach (Message msg in previous.MessageList)
			{
				switch (msg.ActionNeeded)
				{
					case ActionNeeded.NeedAck:
						if (msg.UserAck == true)
						{
							MessageList.Add(msg);
						}
						break;
					case ActionNeeded.NeedYesNo:
						if (msg.UserAnswer.HasValue)
						{
							MessageList.Add(msg);
						}
						break;
					case ActionNeeded.ShowOnly:
						MessageList.Add(msg);
						break;
					default:
						break;
				}
			}
		}

		public List<Message> MessageList { get; private set; }

		public class Message
		{
			public string Key { get; set; }

			public string Text { get; set; }

			public ActionNeeded ActionNeeded { get; set; }

			public int? UserAnswer { get; set; }

			public bool UserAck { get; set; }
		}

		public void Add(Message message)
		{
			Message existingMessage = MessageList.SingleOrDefault(x => x.Key == message.Key);
			
			if (existingMessage != null)
			{
				existingMessage.Text = message.Text;
			}
			else
			{
				MessageList.Add(message);
			}
		}

		public bool AllMessagesFixedOrAcknowledged()
		{
			return MessageList.All(x => 
				(x.ActionNeeded == ActionNeeded.NeedAck && x.UserAck == true)
				|| (x.ActionNeeded == ActionNeeded.NeedYesNo && x.UserAnswer.HasValue && x.UserAnswer != 0)
				|| (x.ActionNeeded == ActionNeeded.ShowOnly && x.UserAck == true)
				); 
		}
	}
}