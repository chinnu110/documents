﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
    public class ReportViewModel
    {
        public DateTime? SelectedDate { get; set; }

        public int[] DailyDispatchIDs { get; set; }
        
        public List<int?> DailyDispatchIDSelection { get; set; }

        public string LookupString { get; set; }

        public int? CarrierID { get; set; }

        public List<int> CarrierIDs { get; set; }

        public bool HobbyLobbyOnly { get; set; }

        public MultiSelectList CarrierSelectList { get; set; }

        public CarrierChargesDataTypeEnum CarrierChargesDataType { get; set; }

        public enum CarrierChargesDataTypeEnum
        {
            Orders = 0,
            Sendout
        }

        public string ReportName { get; set; }

        public const string ReportName_BackhaulPickups = "BackhaulPickups";
        public const string ReportName_BackhaulDeliveries = "BackhaulDeliveries";

        public DateTime? FromDate { get; set; }

        public DateTime? ThruDate { get; set; }

        public int? BrokerID { get; set; }

        public InvoiceStatusEnum InvoiceStatus { get; set; }

        public enum InvoiceStatusEnum
        {
            Any = 0,
            Invoiced,
            Not_Invoiced
        }

        public BrokerLoadSortEnum BrokerLoadSort { get; set; }

        public enum BrokerLoadSortEnum
        {
            Load_ID = 0,
            Pickup_Date,
            Invoice_Date,
            Delivery_Date,
            Broker_Name
        }

        public BrokerLoadDateRangeSourceEnum BrokerLoadDateRangeSource { get; set; }

        public enum BrokerLoadDateRangeSourceEnum
        {
            Pickup_Date = 0,
            Delivery_Date,
            Invoice_Date
        }

        public BackhaulReportDateRangeSourceEnum BackhaulReportDateRangeSource { get; set; }

        public enum BackhaulReportDateRangeSourceEnum
        {
            Ready_Date = 0,
            Pickup_Date,
            Dispatch_Date,
            Carrier_Charge_Change_Date
        }

        public BackhaulReportSearchSourceEnum BackhaulReportSearchSource { get; set; }

        public enum BackhaulReportSearchSourceEnum
        {
            Load_Numbers = 0,
            PO_Numbers,
            Dispatch_Numbers,
        }

        public bool IncludeWorkedLoads { get; set; }

        public bool IncludeCreatedDispatches { get; set; }

        public StoreAdvisementSortEnum StoreAdvisementSort { get; set; }

        public enum StoreAdvisementSortEnum
        {
            Delivery_Date = 0,
            Store
        }
        
        public bool OnlyChangedDispatches { get; set; }

        public string DispatchSort { get; set; }
    
        public const string DispatchSort_Store = "STORE";
        public const string DispatchSort_Location = "LOCATION";

        public string DateType { get; set; }

        public const string DateType_Dispatch = "DISPATCH";
        public const string DateType_Delivery = "DELIVERY";
    }
}