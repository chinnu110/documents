﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class DailyDispatchSelectContainerViewModel
	{
		public string SubmitButtonFilter { get; set; }

        public string[] AlreadySelected { get; set; }

        public ContainerAction ContainerAction { get; set; }

        public IEnumerable<ContainerViewModel> Containers { get; set; }
	}
}