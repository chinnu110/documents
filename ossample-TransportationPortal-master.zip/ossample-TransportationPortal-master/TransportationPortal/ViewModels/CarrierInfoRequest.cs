﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public class CarrierInfoRequest
	{
		public int? CalculationType { get; set; }
		
		public int? DailyDispatchID { get; set; }

		public int? CarrierID { get; set; }

		public int? ChosenCarrierID { get; set; }

		public ICollection<int> OutboundLoadIDs { get; set; }

		public ICollection<int> InboundLoadIDs { get; set; }

		public decimal? CarrierRate { get; set; }

		public decimal? CarrierFlatRate { get; set; }

		public int MileageCalcType { get; set; }

		public int? CarrierMiles { get; set; }

		public decimal? CarrierStopCharge1 { get; set; }

		public decimal? CarrierStopCharge2 { get; set; }

		public decimal? CarrierExtraCharge { get; set; }

		public decimal? FuelSurcharge { get; set; }

		public decimal? CarrierTotalCharge { get; set; }
	}
}