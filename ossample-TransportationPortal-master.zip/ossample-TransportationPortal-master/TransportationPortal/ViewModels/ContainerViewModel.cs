﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;
using ContainerSystem.Models;

namespace TransportationPortal.ViewModels
{
	public class ContainerViewModel
	{
		[Display(Name = "DispatchID")]
		public Int32 DailyDispatchID { get; set; }

		[Display(Name = "Action")]
		public ContainerAction ContainerAction { get; set; }
		
		[Display(Name = "Action")]
		public string ContainerActionDisplay 
		{ 
			get
			{
				switch (ContainerAction)
				{
					case ContainerAction.Pull:
						return "Pull";
					case ContainerAction.CommitToOKC:
						return "Commit To OKC";
					case ContainerAction.EmptyReturn:
						return "Empty return";
					default:
						return "None";
				}
			}
		}

		public Int16 DispatchOrder { get; set; }

		[Display(Name = "Container")]
		public string ContainerNumber { get; set; }

		[Display(Name = "Status Code")]
		public string StatusCode { get; set; }

		[Display(Name = "Status Code")]
		public string StatusCodeText { get; set; }

		[Display(Name = "Status Code")]
		public string StatusCodeTextOnly { get; set; }

		[Display(Name = "Status Date")]
		public DateTime? StatusDate { get; set; }

		[Display(Name = "Shipping Line")]
		public string Carrier { get; set; }

		[Display(Name = "Pickup Number")]
		public string PickupNumber { get; set; }

		[Display(Name = "Pickup Location")]
		public string PickupLocation { get; set; }

		[Display(Name = "Hot")]
		public string Hot { get; set; }

		[Display(Name = "Pull Date")]
		public DateTime? PullDate { get; set; }

		[Display(Name = "Last Free Date")]
		[DisplayFormat(DataFormatString = "{0:MMM d}" )]
		public DateTime? LastFreeDate { get; set; }

		[Display(Name = "Per-Diem Date")]
		[DisplayFormat(DataFormatString = "{0:MMM d}")]
		public DateTime? PerDiemDate { get; set; }

		[Display(Name = "Delivery Zone")]
		public string DeliveryZone { get; set; }

		[Display(Name = "Delivery Zones")]
		public string DeliveryZones { get; set; }

		[Display(Name = "Seal Number")]
		public string SealNumber { get; set; }

		[Display(Name = "Pull Driver")]
		public string PullDriverName { get; set; }

		[Display(Name = "Commit-OKC Driver")]
		public string CommitDriverName { get; set; }

		[Display(Name = "Return Driver")]
		public string ReturnDriverName { get; set; }

		[Display(Name = "Size")]
		public string ContainerSize { get; set; }

		[Display(Name = "Location/Notes")]
		public string Note { get; set; }

		[Display(Name = "Shag Notes")]
		public string ShagNotes { get; set; }

		[Display(Name = "Lot Notes")]
		public string LotNotes { get; set; }

		[Display(Name = "Return Notes")]
		public string ReturnNotes { get; set; }

		[Display(Name = "Lot Location")]
		public string LotLocation { get; set; }

		public string ViewStatus { get; set; }

		public List<Action> Actions { get; set; }

		public ContainerViewModel()
		{ }

		public ContainerViewModel(Container x)
		{
			DailyDispatchID = x.DailyDispatchID;
			ContainerNumber = x.ContainerNumber;
			ContainerAction = x.ContainerAction;
			DispatchOrder = x.DispatchOrder;

			StatusCode = x.StatusCode;
			StatusCodeText = StatusCodeValues.GetText(x.StatusCode);
			StatusCodeTextOnly = StatusCodeValues.GetTextOnly(x.StatusCode);
		}

		public ContainerViewModel(ContainerInfo x)
		{
			ContainerNumber = x.ContainerNumber;

			StatusCode = x.StatusCode;
			StatusCodeText = StatusCodeValues.GetText(x.StatusCode);
			StatusCodeTextOnly = StatusCodeValues.GetTextOnly(x.StatusCode);

			StatusDate = x.StatusDate;
			PickupNumber = x.PickupNumber;
			PickupLocation = x.PickupLocation;
			Hot = x.Hot ? "HOT" : string.Empty;
			PullDate = x.PullDate;
			LastFreeDate = x.LastFreeDate;
			PerDiemDate = x.PerDiemDate;
			SealNumber = x.SealNumber;
			PullDriverName = x.PullDriverName;
			CommitDriverName = x.CommitDriverName;
			ReturnDriverName = x.ReturnDriverName;
			Note = x.Note;
			DeliveryZone = x.DeliveryZone;
			Carrier = x.Carrier;
			ContainerSize = x.ContainerSize;
			ShagNotes = x.ShagNotes;
			LotNotes = x.LotNotes;
			ReturnNotes = x.ReturnNotes;
			LotLocation = x.LotLocation;
		}

		public ContainerViewModel(Container x, ContainerInfo y)
		{
			DailyDispatchID = x.DailyDispatchID;
			ContainerNumber = x.ContainerNumber;
			ContainerAction = x.ContainerAction;
			DispatchOrder = x.DispatchOrder;

			StatusCode = y.StatusCode;
			StatusCodeText = StatusCodeValues.GetText(y.StatusCode);
			StatusCodeTextOnly = StatusCodeValues.GetTextOnly(y.StatusCode);

			StatusDate = y.StatusDate;
			PickupNumber = y.PickupNumber;
			PickupLocation = y.PickupLocation;
			Hot = y.Hot ? "HOT" : string.Empty;
			PullDate = y.PullDate;
			LastFreeDate = y.LastFreeDate;
			PerDiemDate = y.PerDiemDate;
			SealNumber = y.SealNumber;
			PullDriverName = y.PullDriverName;
			CommitDriverName = y.CommitDriverName;
			ReturnDriverName = y.ReturnDriverName;
			Note = y.Note;
			DeliveryZone = y.DeliveryZone;
			Carrier = y.Carrier;
			ContainerSize = y.ContainerSize;
			ShagNotes = y.ShagNotes;
			LotNotes = y.LotNotes;
			ReturnNotes = y.ReturnNotes;
			LotLocation = y.LotLocation;
		}

		public ContainerViewModel(ContainerInfo x, IEnumerable<Container> actions) :
			this(x)
		{
			Actions = new List<Action>();
			foreach (Container container in actions)
			{
				Actions.Add(new Action
				{
					ContainerAction = container.ContainerAction,
					DailyDispatchID = container.DailyDispatchID,
					DispatchDate = container.DailyDispatch.DispatchDate,
					CarrierName = container.DailyDispatch.CarrierID.HasValue ? container.DailyDispatch.Carrier.Name : string.Empty,
					Driver1Name = container.DailyDispatch.Driver1ID.HasValue ? container.DailyDispatch.Driver1.FullName : string.Empty,
					Driver2Name = container.DailyDispatch.Driver2ID.HasValue ? container.DailyDispatch.Driver2.FullName : string.Empty
				});
			}
		}

		public class Action
		{
			public ContainerAction ContainerAction { get; set; }

			public int DailyDispatchID { get; set; }

			public DateTime DispatchDate { get; set; }

			public string CarrierName { get; set; }

			public string Driver1Name { get; set; }

			public string Driver2Name { get; set; }

			public string GetDeliveryName
			{
				get 
				{
					string driverName = string.Empty;
					if (!string.IsNullOrEmpty(CarrierName))
					{
						driverName = CarrierName;
					}
					else if (!string.IsNullOrEmpty(Driver1Name))
					{
						driverName = Driver1Name;
					}
					else if (!string.IsNullOrEmpty(Driver2Name))
					{
						driverName = Driver2Name;
					}
					return driverName;
				}
			}
		}
	}
}