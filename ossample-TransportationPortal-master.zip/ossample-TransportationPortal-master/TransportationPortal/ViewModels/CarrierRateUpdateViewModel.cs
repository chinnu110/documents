﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using TransportationPortal.Models;
using System.Web.Mvc;
using System.Web;

namespace TransportationPortal.ViewModels
{
	public class CarrierRateUpdateViewModel
	{
		public int? CarrierID { get; set; }

		public Carrier CarrierSelected { get; set; }

		public int TotalRowCount { get; set; }

		public int ActionableRowCount { get; set; }

		public HttpPostedFileBase FileUpload { get; set; }

		public Dictionary<string, uint> ColumnMap { get; set; }

		public List<string> Messages { get; set; }
	}
}