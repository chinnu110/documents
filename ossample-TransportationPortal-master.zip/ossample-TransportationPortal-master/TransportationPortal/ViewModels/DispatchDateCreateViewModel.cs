﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class DispatchDateCreateViewModel
	{
		public DispatchDateControl DispatchDateControl { get; set; }

		public SelectList WeekNumberSelectList { get; set; }

		public SelectList WeekDayIDSelectList { get; set; }

		// These are only used for a Re-create.

		[Display(Name = "Delete manually created routes?")]
		public bool DeleteCreatedRoutes { get; set; }

		[Display(Name = "Delete generated but modified routes?")]
		public bool DeleteGeneratedButModifiedRoutes { get; set; }

		public long? Nonce { get; set; }

		public bool Complete { get; set; }

		public string Message { get; set; }
	}
}