﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public class LoadIndexViewModel
	{
		[Display(Name = "Company")]
		public Int32? LoadCompanyID { get; set; }

		[Display(Name = "Company")]
		public Int32? PickupCompanyID { get; set; }

		[Display(Name = "Store")]
		public Int32? StoreID { get; set; }

		[Display(Name = "Carrier")]
		public Int32? CarrierID { get; set; }

		[Display(Name = "Search")]
		public string SearchField { get; set; }

		public int DispatchStatus { get; set; }

		public int WorkStatus { get; set; }

		public int InvoiceStatus { get; set; }

		public int ChargeStatus { get; set; }

		public List<int> LoadSelect { get; set; }

		public string ActionSelection { get; set; }

		public string SelectedActionGoButton { get; set; }

		public int DateType { get; set; }

		public DateTime? FromDate { get; set; }

		public DateTime? ThruDate { get; set; }

		public string SortingID { get; set; }

		public PagingViewModel Paging { get; set; }

		
		// Output only.
		public IEnumerable<Load> Loads { get; set; }

		public class Load
		{
			public Int32 LoadID { get; set; }

			public string LoadName { get; set; }

			public string LoadType { get; set; }

			public string StoreLoadType { get; set; }

			public string DeliveryType { get; set; }

			public DateTime ReadyDate { get; set; }

			public DateTime? PickupDate { get; set; }
			
			public string LoadCompanyName { get; set; }
			
			public string LoadContact { get; set; }

			public string PickupCompanyName { get; set; }

			public string PickupContact { get; set; }

			public DateTime? DispatchDate { get; set; }

			public int? DailyDispatchID { get; set; }

			public string LoadStoreName { get; set; }

			public string LoadStoreCity { get; set; }

			public string LoadStoreStateCode { get; set; }

			public string StoreName { get; set; }

			public string City { get; set; }
			
			public string StateCode { get; set; }
			
			public string PO1 { get; set; }
			
			public string PO2 { get; set; }
		
			public string DeliveryCity { get; set; }

			public string DeliveryStateCode { get; set; }

		}
	}
}