﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
	public class DriverIndexViewModel
	{
		[DisplayName("Dispatcher")]
		public int? DispatcherID { get; set; }

		public SelectList DispatcherList { get; set; }

		// Output only.
		public IEnumerable<DriverViewModel> Drivers { get; set; }
	}
}