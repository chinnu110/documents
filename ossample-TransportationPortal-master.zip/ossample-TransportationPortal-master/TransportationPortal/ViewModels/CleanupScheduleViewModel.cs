﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public class CleanupScheduleViewModel
	{
		public bool Week1Sunday { get; set; }
		public bool Week1Monday { get; set; }
		public bool Week1Tuesday { get; set; }
		public bool Week1Wednesday { get; set; }
		public bool Week1Thursday { get; set; }
		public bool Week1Friday { get; set; }
		public bool Week1Saturday { get; set; }

		public bool Week2Sunday { get; set; }
		public bool Week2Monday { get; set; }
		public bool Week2Tuesday { get; set; }
		public bool Week2Wednesday { get; set; }
		public bool Week2Thursday { get; set; }
		public bool Week2Friday { get; set; }
		public bool Week2Saturday { get; set; }

		public Int32? SearchStoreID { get; set; }
		
		// Output only.
		public IEnumerable<OutboundRoute> OutboundRoutes { get; set; }

		public class OutboundRoute
		{
			public Int32 OutboundRouteID { get; set; }

			public string Route { get; set; }

			public string Store { get; set; }

			public Int32 WeekNumber { get; set; }
			public string DayName { get; set; }

			public string Cleanup1Store { get; set; }
			public string Cleanup2Store { get; set; }
			public string Cleanup3Store { get; set; }
		}
	}
}