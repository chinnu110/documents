﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
	public class PagingViewModel
	{
		private const string pagelinkFormat = "{0}";

		private int totalPages = 0;

		public int Page { get; set; }

		public int PageSize { get; set; }

		/// <summary>
		/// Set to .Count() of the list to be paged to get a button for the last page. 
		/// Set to zero to turn off last page button when the list is huge or requires too much time to count.
		/// </summary>
		public int TotalRecords { get; set; }

		public int LinksBeforeCurrentPage { get; set; }

		public int LinksAfterCurrentPage { get; set; }

		public int HighestVisitedPage { get; set; }

		private string _Action = "Index/{0}";

		public string Action
		{
			get { return _Action; }
			set { _Action = value; }
		}

		public List<PagingItemViewModel> PagingLinks 
		{
			get
			{
				List<PagingItemViewModel> _PagingLinks = new List<PagingItemViewModel>();

				int overflowRecords = 0;
				if (TotalRecords > 0)
				{
					totalPages = Math.DivRem(TotalRecords, PageSize, out overflowRecords);
					totalPages += overflowRecords > 0 ? 1 : 0;
				}

				// Insert the current page pagelink. All pagelinks will go before or after this entry.
				_PagingLinks.Add(new PagingItemViewModel { Text = string.Format(pagelinkFormat, Page), Value = Page.ToString(), Selected = true, Title = PageRange(Page) });
				if (Page > HighestVisitedPage)
				{
					HighestVisitedPage = Page;
				}

				// Insert all pagelinks going before the current page pagelink.
				for (int page = Page - 1, linkCount = LinksBeforeCurrentPage; page > 0 && linkCount > 0; page--, linkCount--)
				{
					_PagingLinks.Insert(0, new PagingItemViewModel { Text = string.Format(pagelinkFormat, page), Value = page.ToString(), Title = PageRange(page) });
				}

				if (Page > (LinksBeforeCurrentPage + 1))
				{
					_PagingLinks.Insert(0, new PagingItemViewModel { Text = "...", Value = null });
					_PagingLinks.Insert(0, new PagingItemViewModel { Text = string.Format(pagelinkFormat, 1), Value = "1", Title = PageRange(1) });
				}

				if (Page != 1)
				{
					_PagingLinks.Insert(0, new PagingItemViewModel { Text = "«", Value = (Page - 1).ToString() });
				}

				// Insert all pagelinks going after the current page pagelink.


				if (totalPages > 0)
				{
					int trailingPage = Page + 1;
					for (int linkCount = LinksAfterCurrentPage; trailingPage <= totalPages && linkCount > 0; trailingPage++, linkCount--)
					{
						_PagingLinks.Add(new PagingItemViewModel { Text = string.Format(pagelinkFormat, trailingPage), Value = trailingPage.ToString(), Title = PageRange(trailingPage) });
					}
					trailingPage--;

					if (trailingPage < totalPages)
					{
						_PagingLinks.Add(new PagingItemViewModel { Text = "...", Value = null });
						_PagingLinks.Add(new PagingItemViewModel { Text = string.Format(pagelinkFormat, totalPages), Value = totalPages.ToString(), Title = PageRange(totalPages) });
					}
				}
				else
				{
					int trailingPage = Page + 1;
					for (int linkCount = LinksAfterCurrentPage; trailingPage <= HighestVisitedPage && linkCount > 0; trailingPage++, linkCount--)
					{
						_PagingLinks.Add(new PagingItemViewModel { Text = string.Format(pagelinkFormat, trailingPage), Value = trailingPage.ToString(), Title = PageRange(trailingPage) });
					}
				}

				if (totalPages == 0 || Page < totalPages)
				{
					_PagingLinks.Add(new PagingItemViewModel { Text = "»", Value = (Page + 1).ToString(), Title = PageRange(Page + 1) });
				}

				return _PagingLinks;
			}
		}

		private string PageRange(int page)
		{
			int fromRecord = page == 1 ? 1 : (page-1)*PageSize + 1;
			int thruRecord = (TotalRecords > 0 && page == totalPages) ? TotalRecords : page*PageSize;
			return string.Format("{0}-{1}", fromRecord, thruRecord);
		}
	}
}