﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public class FuelSurchargeIndexViewModel
	{
		public DateTime? FromDate { get; set; }

		public DateTime? ThruDate { get; set; }

		public PagingViewModel Paging { get; set; }
		
		// Output only.
		public IEnumerable<FuelSurcharge> Items { get; set; }

		public class FuelSurcharge
		{
			public int FuelSurchargeID { get; set; }

			public DateTime ActiveDate { get; set; }

			public DateTime? ActiveEndDate { get; set; }

			[DataType(DataType.Currency)]
			public decimal Amount { get; set; }

			[DataType(DataType.MultilineText)]
			public string Comment { get; set; }
		}
	}
}