﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TransportationPortal.ViewModels
{
	public class LoadCompanyIndexViewModel
	{
		public bool? IsBroker { get; set; }

		public bool? IsVendor { get; set; }

		public bool? IsPickupAddress { get; set; }

		public bool? IsDeliveryAddress { get; set; }

		public bool? IsHLCompany { get; set; }

		[Display(Name = "Search")]
		public string SearchField { get; set; }

		public string SortColumn { get; set; }

		public int SortDirection { get; set; }

		public PagingViewModel Paging { get; set; }
		
		// Output only.
		public IEnumerable<LoadCompanyViewModel> Companies { get; set; }
	}
}