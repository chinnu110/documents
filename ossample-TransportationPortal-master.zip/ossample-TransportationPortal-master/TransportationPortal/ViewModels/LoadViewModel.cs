﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using TransportationPortal.Repositories;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class LoadViewModel
	{
		public bool AdminMode { get; set; }

		public bool IsInvoiced { get; set; }

		public Load Load { get; set; }

		public DateTime? PickupDate { get; set; }

		public DateTime? PickupTime { get; set; }

		public DateTime? EtaTime { get; set; }

		public LoadCompanyViewModel Broker { get; set; }

		public LoadCompanyViewModel Pickup { get; set; }

		public LoadCompanyViewModel Delivery { get; set; }

		[Display(Name = "Remember Delivery for this Vendor/Pickup?")]
		public bool RememberDelivery { get; set; }

		public LoadCompanyViewModel DeliveryHL { get; set; }

		[Display(Name = "Remember Delivery for this Vendor/Pickup?")]
		public bool RememberDeliveryHL { get; set; }

		public long? Nonce { get; set; }

		public LoadViewModel()
		{
		}

		public LoadViewModel(Load x)
		{
			if (x == null)
			{
				return;
			}

			Load = x;
			
			// Load fields
			PickupDate = x.PickupDate;

			if (PickupDate.HasValue)
			{
				TimeSpan time = PickupDate.Value.TimeOfDay;
				if (time != TimeSpan.Zero)
				{
					PickupTime = DateTime.MinValue + time;
				}
				else
				{
					PickupTime = null;
				}
			}
			else
			{
				PickupTime = null;
			}

			if (Load.EtaDate.HasValue)
			{
				TimeSpan time = Load.EtaDate.Value.TimeOfDay;
				if (time != TimeSpan.Zero)
				{
					EtaTime = DateTime.MinValue + time;
				}
				else
				{
					EtaTime = null;
				}
			}
			else
			{
				EtaTime = null;
			}

			Broker = new LoadCompanyViewModel(x.LoadCompany);

			Pickup = new LoadCompanyViewModel(x.PickupCompany);

			if (Load.DeliveryType == DatabaseLists.LOAD_DELIVERY_TYPE_WAREHOUSE)
			{
				DeliveryHL = new LoadCompanyViewModel(x.DeliveryCompany);
			}
			else
			{
				Delivery = new LoadCompanyViewModel(x.DeliveryCompany);
			}

			IsInvoiced = x.InvoiceDate.HasValue;
		}
	}
}