﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class DailyDispatchLoadViewModel
	{
		public string SubmitButtonCreate { get; set; }

		public string SubmitButtonFilter { get; set; }

		public string SearchField { get; set; }
		
		public DateTime? FromDate { get; set; }

		public DateTime? ThruDate { get; set; }

		public bool IncludeBrokerLoads { get; set; }

		public bool IncludeVendorBackhauls { get; set; }

		public bool? IncludeCleanupLoads { get; set; }

		public string SortColumn { get; set; }

		public int SortDirection { get; set; }

		public int? LoadID { get; set; }

		[DisplayName("Pickup Date")]
		public DateTime? PickupDate { get; set; }

		[DisplayName("Pickup Time")]
		public DateTime? PickupTime { get; set; }

		public string PickupCity { get; set; }

		public string PickupStateCode { get; set; }

		[DisplayName("Delivery Date")]
		public DateTime? EtaDate { get; set; }

		[DisplayName("Delivery Time")]
		public DateTime? EtaTime { get; set; }

		[DisplayName("Store")]
		public int? StoreID { get; set; }

		public int? StoreNumber { get; set; }

		[DisplayName("Store")]
		public string StoreName { get; set; }

		[DisplayName("Load Type")]
		public string LoadType { get; set; }

		[DisplayName("Load Name")]
		public string LoadName { get; set; }

		[DisplayName("Description")]
		public string LoadDescription { get; set; }

		[DisplayName("Store Load Type")]
		public string StoreLoadType { get; set; }

		[DisplayName("Store Opening")]
		public bool StoreOpening { get; set; }

		[DisplayName("Cleanup Feet")]
		public int? LinearFeet { get; set; }

		[DisplayName("Comment")]
		[DataType(DataType.MultilineText)]
		public string Comment { get; set; }

		public string DispatchGroup { get; set; }

		public IEnumerable<LoadDragDropViewModel> Loads { get; set; }
	}
}