﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public class LoadCompanyHLViewModel
	{
		public Int32? LoadCompanyID { get; set; }

		public IEnumerable<LoadCompanyViewModel> Companies { get; set; }
	}
}