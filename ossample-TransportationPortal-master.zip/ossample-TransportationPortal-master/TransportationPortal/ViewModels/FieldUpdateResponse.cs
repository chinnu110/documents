﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	public class FieldUpdateResponse
	{
		public int changecount { get; set; }

		public string fieldvalue { get; set; }
	}
}