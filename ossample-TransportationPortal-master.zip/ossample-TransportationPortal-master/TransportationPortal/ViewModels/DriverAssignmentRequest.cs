﻿using System;

namespace TransportationPortal.ViewModels
{
	public class DriverAssignmentRequest
	{
		public int DailyDispatchID { get; set; }

		public int FromDailyDispatchID { get; set; }
		
		public int DriverID { get; set; }

		public string ContainerNumber { get; set; }

		public DateTime Date { get; set; }

		public ContainerAction ContainerAction { get; set; }
	}
}