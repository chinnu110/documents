﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	public class DriverViewModel
	{
		public Int32 DriverID { get; set; }
		
		public string FirstName { get; set; }
		
		public string MiddleName { get; set; }
		
		public string LastName { get; set; }
		
		public string Suffix { get; set; }
		
		public string FullName { get; set; }
		
		public string DispatcherFullName { get; set; }
		
		public string TeamPartnerFullName { get; set; }
		
		public string Phone { get; set; }
		
		public bool Smoker { get; set; }

		public string DriveHours { get; set; }
		
		public string Notes { get; set; }

		public string TractorNumber { get; set; }

		public DateTime? DeleteDate { get; set; }

		public DriverViewModel() { }

		public DriverViewModel(Driver x)
		{
			DriverID = x.DriverID;
			FirstName = x.FirstName;
			MiddleName = x.MiddleName;
			LastName = x.LastName;
			Suffix = x.Suffix;
			FullName = x.FullName;
			Phone = x.Phone;
			Smoker = x.Smoker;
			DriveHours = x.DriveHours;
			TractorNumber = x.TractorNumber;
			Notes = x.Notes;
			DispatcherFullName = x.Dispatcher != null ? x.Dispatcher.FullName : null;
			TeamPartnerFullName = x.TeamPartner != null ? x.TeamPartner.FullName : null;
			DeleteDate = x.DeleteDate;
		}
	}
}