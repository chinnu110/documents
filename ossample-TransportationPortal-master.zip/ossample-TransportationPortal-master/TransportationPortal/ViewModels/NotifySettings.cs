﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.ViewModels
{
	/// <summary>
	/// Notify Settings for Driver Paysheets and Carrier Dispatch Requests.
	/// This class is created by the DailyDispatch and InboundPlanning controllers and given to the root Index page to act upon.
	/// Either a PDF report will be created or an email with the report PDF attached will be created.
	/// </summary>
	public class NotifySettings
	{
		/// <summary>
		/// print, email, or none.
		/// </summary>
		public string Type { get; set; }

		/// <summary>
		/// Email address for type=email.
		/// </summary>
		public string To { get; set; }

		/// <summary>
		/// Email subject line for type=email.
		/// </summary>
		public string Subject { get; set; }

		/// <summary>
		/// Email message for type=email.
		/// </summary>
		public string HTMLBody { get; set; }

		/// <summary>
		/// Fully Qualified URL of the document to attach.
		/// </summary>
		public string Attachment { get; set; }

		/// <summary>
		/// Relative Url of the document for type=print and type=email when no address is found..
		/// </summary>
		public string Url { get; set; }
	}
}