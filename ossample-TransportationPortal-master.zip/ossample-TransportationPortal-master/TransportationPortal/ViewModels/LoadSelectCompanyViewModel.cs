﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using TransportationPortal.Models;

namespace TransportationPortal.ViewModels
{
	/// <summary>
	/// ViewModel for selecting a Broker, Vendor, Pickup, or Delivery address.
	/// When adding additional properties here, they may need hidden fields in the SelectLoadCompany.cshtml to allow the 
	/// popup to be updated in-place and retain the values.
	/// </summary>
	public class LoadSelectCompanyViewModel
	{
		public string SubmitButtonFilter { get; set; }

		public bool IsBroker { get; set; }

		public bool IsVendor { get; set; }

		public bool IsPickupAddress { get; set; }

		public bool IsDeliveryAddress { get; set; }

		public string Search { get; set; }

		public string DialogID { get; set; }

		public string CloseDialogAction { get; set; }

		public string SelectionID { get; set; }

		public string BindPrefix { get; set; }

		public IEnumerable<LoadCompany> Companies { get; set; }
	}
}