﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.Models
{
	public class Dispatcher
	{
		[Key]
		public Int32 DispatcherID { get; set; }

		[Required(ErrorMessage="First name is required.")]
		[StringLength(50, MinimumLength = 2, ErrorMessage = "Name must be at least 2 characters and not exceed 50 characters.")]
		[Display(Name = "First Name")]
		public string FirstName { get; set; }

		[Required(ErrorMessage = "Last name is required.")]
		[StringLength(50, MinimumLength = 2, ErrorMessage = "Name must be at least 2 characters and not exceed 50 characters.")]
		[Display(Name = "Last Name")]
		public string LastName { get; set; }

		// Convenience Properties

		public string FullName
		{
			get { return string.Format("{0} {1}", FirstName, LastName).Replace("  ", " ").Trim(); }
		}

		// Navigation Properties

		[Display(Name = "Drivers")]
		public ICollection<Driver> Drivers { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }
	}
}