﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class OutboundRoute
	{
		[Key]
		public Int32 OutboundRouteID { get; set; }

		[Display(Name = "Tractor")]
		public string TractorNumber { get; set; }

		[Display(Name = "Carrier")]
		public Int32? CarrierID { get; set; }

		[Display(Name = "Dispatch Group")]
		public string DispatchGroup { get; set; }
		
		[Display(Name = "Inbound Delivery Day")]
		public int? InboundWeekDayID { get; set; }

		[Display(Name = "Driver1")]
		public Int32? Driver1ID { get; set; }

		[Display(Name = "Driver2")]
		public Int32? Driver2ID { get; set; }

		[Display(Name = "Load 1 Store")]
		public Int32? Load1StoreID { get; set; }

		[Display(Name = "Load 2 Store")]
		public Int32? Load2StoreID { get; set; }

		[Display(Name = "Load 3 Store")]
		public Int32? Load3StoreID { get; set; }

		[Display(Name = "Load 1 Delivery Day")]
		public int? Load1DeliveryDayID { get; set; }

		[Display(Name = "Load 2 Delivery Day")]
		public int? Load2DeliveryDayID { get; set; }

		[Display(Name = "Load 3 Delivery Day")]
		public int? Load3DeliveryDayID { get; set; }

		[Display(Name = "Load 1 Delivery Time")]
		public DateTime? Load1DeliveryTime { get; set; }

		[Display(Name = "Load 2 Delivery Time")]
		public DateTime? Load2DeliveryTime { get; set; }

		[Display(Name = "Load 3 Delivery Time")]
		public DateTime? Load3DeliveryTime { get; set; }
		
		[Display(Name = "Load 1 Type")]
		public string Load1Type { get; set; }

		[Display(Name = "Load 2 Type")]
		public string Load2Type { get; set; }

		[Display(Name = "Load 3 Type")]
		public string Load3Type { get; set; }

		[Display(Name = "Week")]
		[Required(ErrorMessage = "Week number is required")]
		[Range(1, 2, ErrorMessage = "Week number must be 1 or 2")]
		public Int32 WeekNumber { get; set; }

		[Display(Name = "Day")]
		[Required(ErrorMessage = "Day of Week is required")]
		[Range(1, 7)]
		public Int32 WeekDayID { get; set; }

		[Display(Name = "City")]
		public string City { get; set; }

		[Display(Name = "State")]
		public string StateCode { get; set; }

		[Display(Name = "Depart")]
		public DateTime? DepartureTime { get; set; }

		[Display(Name = "Arrive")]
		public DateTime? ScheduledArrivalTime { get; set; }

		[Display(Name = "Miles")]
		public Int32? Miles { get; set; }

		[Display(Name = "Hours")]
		public Int32? Hours { get; set; }

		[Display(Name = "Carrier Rate")]
		[DataType(DataType.Currency)]
		public decimal? CarrierRate { get; set; }

		[Display(Name = "Carrier Stop Charge 1")]
		[DataType(DataType.Currency)]
		public decimal? CarrierStopCharge1 { get; set; }

		[Display(Name = "Carrier Stop Charge 2")]
		[DataType(DataType.Currency)]
		public decimal? CarrierStopCharge2 { get; set; }

		[Display(Name = "Carrier Extra Charge")]
		[DataType(DataType.Currency)]
		public decimal? CarrierExtraCharge { get; set; }

		[Display(Name = "Carrier Total Override")]
		[DataType(DataType.Currency)]
		public decimal? CarrierTotalChargeOverride { get; set; }

		[Display(Name = "Cleanup Store 1")]
		public Int32? Cleanup1StoreID { get; set; }

		[Display(Name = "Cleanup Store 2")]
		public Int32? Cleanup2StoreID { get; set; }

		[Display(Name = "Cleanup Store 3")]
		public Int32? Cleanup3StoreID { get; set; }

		[Display(Name = "Comment")]
		public string Comment { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

		/*
		 * Navigation Properties
		 */

		[ForeignKey("InboundWeekDayID")]
		public WeekDay InboundWeekDay { get; set; }

		[ForeignKey("Driver1ID")]
		public Driver Driver1 { get; set; }
		
		[ForeignKey("Driver2ID")]
		public Driver Driver2 { get; set; }

		[ForeignKey("CarrierID")]
		public Carrier Carrier { get; set; }

		[ForeignKey("WeekDayID")]
		public WeekDay WeekDay { get; set; }

		[ForeignKey("Load1StoreID")]
		public Store Load1Store { get; set; }

		[ForeignKey("Load2StoreID")]
		public Store Load2Store { get; set; }

		[ForeignKey("Load3StoreID")]
		public Store Load3Store { get; set; }

		[ForeignKey("Load1DeliveryDayID")]
		public WeekDay Load1DeliveryDay { get; set; }

		[ForeignKey("Load2DeliveryDayID")]
		public WeekDay Load2DeliveryDay { get; set; }

		[ForeignKey("Load3DeliveryDayID")]
		public WeekDay Load3DeliveryDay { get; set; }

		[ForeignKey("Cleanup1StoreID")]
		public Store Cleanup1Store { get; set; }

		[ForeignKey("Cleanup2StoreID")]
		public Store Cleanup2Store { get; set; }

		[ForeignKey("Cleanup3StoreID")]
		public Store Cleanup3Store { get; set; }
	}
}