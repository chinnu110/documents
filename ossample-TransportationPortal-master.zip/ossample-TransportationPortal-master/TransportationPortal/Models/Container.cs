﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class Container
	{
		[Key]
		[Column(Order = 1)]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		[Display(Name = "Dispatch ID")]
		public Int32 DailyDispatchID { get; set; }

		[Key]
		[Column(Order = 2)]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		[Display(Name = "Container Number")]
		public string ContainerNumber { get; set; }

		[Display(Name = "Action")]
		public ContainerAction ContainerAction { get; set; }

		[Display(Name = "Dispatch Order")]
		public Int16 DispatchOrder { get; set; }

		[Display(Name = "Status Code")]
		public string StatusCode { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

		/*
		 * Navigation Properties
		 */

		[ForeignKey("DailyDispatchID")]
		public DailyDispatch DailyDispatch { get; set; }
	}
}