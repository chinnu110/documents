﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class LoadCompany
	{
		[Key]
		public Int32 LoadCompanyID { get; set; }

		[MaxLength(50)]
		[Display(Name = "Company Name")]
		public string Name { get; set; }

		[MaxLength(10)]
		public string Type { get; set; }

		[MaxLength(100)]
		[Display(Name = "Address 1")]
		[DataType(DataType.MultilineText)]
		public string Address1 { get; set; }

		[MaxLength(100)]
		[Display(Name = "Address 2")]
		[DataType(DataType.MultilineText)]
		public string Address2 { get; set; }

		[MaxLength(50)]
		public string City { get; set; }

		[MaxLength(2)]
		[Display(Name = "State")]
		public string StateCode { get; set; }

		[MaxLength(10)]
		[Display(Name = "Zip Code")]
		public string Zip { get; set; }

		[MaxLength(3)]
		[Display(Name = "Country")]
		public string CountryCode { get; set; }

		[MaxLength(50)]
		[Display(Name = "Contact Name")]
		public string Contact { get; set; }

		[MaxLength(100)]
		public string Email { get; set; }

		[MaxLength(50)]
		public string Phone { get; set; }

		[MaxLength(50)]
		public string Reference { get; set; }

		[MaxLength(50)]
		[Display(Name = "Available Times")]
		public string AvailableTimes { get; set; }
		
		public Int32? Miles { get; set; }

		[MaxLength(50)]
		public string CompanyRef { get; set; }

		[MaxLength(50)]
		public string Zone { get; set; }

		[MaxLength(50)]
		public string Class { get; set; }
		
		[MaxLength(10)]
		[Display(Name = "SAP ID")]
		public string SapEntity { get; set; }

		[MaxLength(50)]
		[Display(Name = "SAP Name")]
		public string SapEntityName { get; set; }

		[Display(Name = "Broker")]
		public bool IsBroker { get; set; }

		[Display(Name = "Vendor")]
		public bool IsVendor { get; set; }

		[Display(Name = "Pickup Address")]
		public bool IsPickupAddress { get; set; }

		[Display(Name = "Delivery Address")]
		public bool IsDeliveryAddress { get; set; }

		[Display(Name = "HL Company Address")]
		public bool IsCompanyAddress { get; set; }

		[Display(Name = "Delivery Type")]
		public string DeliveryType { get; set; }

		[Display(Name = "Delivery Company")]
		public int? DeliveryCompanyID { get; set; }

		[ForeignKey("DeliveryCompanyID")]
		public LoadCompany DeliveryCompany { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

		// Navigation properties

		[InverseProperty("LoadCompany")]
		public ICollection<Load> AssignedAsBroker { get; set; }

		[InverseProperty("PickupCompany")]
		public ICollection<Load> AssignedAsPickup { get; set; }

		[InverseProperty("DeliveryCompany")]
		public ICollection<Load> AssignedAsDelivery { get; set; }
	}
}