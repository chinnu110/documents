﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class Store
	{
		[Key]
		public Int32 StoreID { get; set; }

		[Display(Name = "Store")]
		public Int32 StoreNumber { get; set; }

		[Display(Name = "Co")]
		public string CompanyID { get; set; }

		[Display(Name = "Dup Code Suffix")]
		[MaxLength(1, ErrorMessage = "Duplicate Code Suffix must be one Character")]
		public string DuplicateCode { get; set; }

		[Display(Name = "City")]
		public string City { get; set; }

		[Display(Name = "State")]
		public string StateCode { get; set; }

		[Display(Name = "A-Load Arrive Day")]
		public int? ALoadArrivalDayID { get; set; }

		[Display(Name = "A-Load Arrive Time")]
		public DateTime? ALoadArrivalTime { get; set; }

		[Display(Name = "B-Load Arrive Day")]
		public int? BLoadArrivalDayID { get; set; }

		[Display(Name = "B-Load Arrive Time")]
		public DateTime? BLoadArrivalTime { get; set; }

		[Display(Name = "Miles")]
		public Int32? Miles { get; set; }

		[Display(Name = "Week 1")]
		public bool Week1 { get; set; }

		[Display(Name = "Week 2")]
		public bool Week2 { get; set; }

		[Display(Name = "Local?")]
		public bool Local { get; set; }

		[Display(Name = "Cleanup Time")]
		public string CleanupTime { get; set; }
		
		[Display(Name = "A-Load Pick Day")]
		public int? ALoadPickDayID { get; set; }

		[Display(Name = "Seq#")]
		public int? SequenceNumber { get; set; }

		// Convenience properties

		[Display(Name = "Store")]
		[NotMapped]
		public string StoreAndCompany
		{
			get { return (CompanyID == "HL" ? string.Format("{0}", StoreNumberPlusDupCode) : string.Format("{0} {1}", StoreNumber, CompanyID)); }
		}

		[Display(Name = "Store")]
		[NotMapped]
		public string StoreAndCompanyLong
		{
			get { return string.Format("{0}{1} {2},{3}", StoreNumberPlusDupCode, CompanyID == "HL" ? string.Empty : " " + CompanyID, City, StateCode); }
		}

		[NotMapped]
		public string StoreNumberPlusDupCode
		{
			get { return string.Format("{0}{1}", StoreNumber, DuplicateCode ?? string.Empty); }
		}

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

		[MaxLength(50)]
		public string DeleteUser { get; set; }

		public DateTime? DeleteDate { get; set; }

		// Navigation properties.

		[ForeignKey("CompanyID")]
		public Company Company { get; set; }

		[ForeignKey("ALoadArrivalDayID")]
		public WeekDay ALoadArrivalDay { get; set; }

		[ForeignKey("ALoadPickDayID")]
		public WeekDay ALoadPickDay { get; set; }

		[ForeignKey("StoreID")]
		public ICollection<StoreCarrierInfo> StoreCarrierInfo { get; set; }

		[InverseProperty("Load1Store")]
		public ICollection<OutboundRoute> AssignedAsLoad1 { get; set; }

		[InverseProperty("Load2Store")]
		public ICollection<OutboundRoute> AssignedAsLoad2 { get; set; }

		[InverseProperty("Load3Store")]
		public ICollection<OutboundRoute> AssignedAsLoad3 { get; set; }

		[InverseProperty("Cleanup1Store")]
		public ICollection<OutboundRoute> AssignedAsCleanup1 { get; set; }

		[InverseProperty("Cleanup2Store")]
		public ICollection<OutboundRoute> AssignedAsCleanup2 { get; set; }

		[InverseProperty("Cleanup3Store")]
		public ICollection<OutboundRoute> AssignedAsCleanup3 { get; set; }

		[ForeignKey("StoreID")]
		public ICollection<Load> Loads { get; set; }
	}
}