﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class StoreCarrierInfo
	{
		[Key]
		[Column(Order = 1)]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		public Int32 StoreID { get; set; }

		[Key]
		[Column(Order = 2)]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		public Int32 CarrierID { get; set; }

		[Display(Name = "Rate Per Mile")]
		[DataType(DataType.Currency)]
		public decimal? RatePerMile { get; set; }

		[Display(Name = "Flat Rate")]
		[DataType(DataType.Currency)]
		public decimal? FlatRate { get; set; }

		[Display(Name = "Mileage Calculation")]
		public int MileageCalcType { get; set; }

		[Display(Name = "Miles")]
		public int? Miles { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

		/*
		 * Navigation properties
		 */

		[ForeignKey("StoreID")]
		public Store Store { get; set; }

		[ForeignKey("CarrierID")]
		public Carrier Carrier { get; set; }
	}
}