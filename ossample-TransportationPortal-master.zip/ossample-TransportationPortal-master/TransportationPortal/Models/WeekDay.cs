﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	/// <summary>
	/// WeekDay for the Dispatch Dates. Sunday (1) thru Saturday (7).
	/// </summary>
	public class WeekDay
	{
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		[Display(Name = "Day#")]
		public Int32 WeekDayID { get; set; }

		[Display(Name = "Day")]
		public string ShortName { get; set; }

		[Display(Name = "Day")]
		public string LongName { get; set; }
	}
}