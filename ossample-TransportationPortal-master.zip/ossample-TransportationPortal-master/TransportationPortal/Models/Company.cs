﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.Models
{
	public class Company
	{
		[Display(Name = "Company Code")]
		[Required]
		public string CompanyID { get; set; }

		[Display(Name = "Company Name")]
		[Required]
		public string CompanyName { get; set; }

		[Display(Name = "Chain ID")]
		public Int16 Chain { get; set; }

		// Navigation properties

		public ICollection<Store> Stores { get; set; }
	}
}