﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	[Table("vw_StoreSlim")]
	public class StoreSlim
	{
		[Key]
		public Int32 StoreID { get; set; }

		[Display(Name = "Store")]
		public Int32 StoreNumber { get; set; }

		[Display(Name = "Co")]
		public string CompanyID { get; set; }

		[Display(Name = "Dup Code Suffix")]
		[MaxLength(1, ErrorMessage = "Duplicate Code Suffix must be one Character")]
		public string DuplicateCode { get; set; }

		[Display(Name = "City")]
		public string City { get; set; }

		[Display(Name = "State")]
		public string StateCode { get; set; }

		// Convenience properties

		[Display(Name = "Store")]
		[NotMapped]
		public string StoreAndCompany
		{
			get { return (CompanyID == "HL" ? string.Format("{0}", StoreNumberPlusDupCode) : string.Format("{0} {1}", StoreNumber, CompanyID)); }
		}

		[Display(Name = "Store")]
		[NotMapped]
		public string StoreAndCompanyLong
		{
			get { return string.Format("{0}{1} {2},{3}", StoreNumberPlusDupCode, CompanyID == "HL" ? string.Empty : " " + CompanyID, City, StateCode); }
		}

		[NotMapped]
		public string StoreNumberPlusDupCode
		{
			get { return string.Format("{0}{1}", StoreNumber, DuplicateCode ?? string.Empty); }
		}

		[ForeignKey("CompanyID")]
		public Company Company { get; set; }
	}
}