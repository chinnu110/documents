﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class DispatchLoadLinkHistory
	{
		[Key]
		[Column(Order = 1)]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		public Int32 DailyDispatchID { get; set; }

		[Key]
		[Column(Order = 2)]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		public Int32 LoadID { get; set; }

		/// <summary>
		/// 0 = Original. Only value defined at this time.
		/// </summary>
		public int Status { get; set; }

		/// <summary>
		/// Original value from Load.
		/// </summary>
		public string LoadType { get; set; }

		/// <summary>
		/// Original value from Load.
		/// </summary>
		public int? StoreID { get; set; }

		/// <summary>
		/// Original value from Load.
		/// </summary>
		public DateTime? EtaDate { get; set; }

		/*
		 * Navigation properties
		 */

		[ForeignKey("DailyDispatchID")]
		public DailyDispatch DailyDispatch { get; set; }

		[ForeignKey("LoadID")]
		public Load Load { get; set; }

		[ForeignKey("StoreID")]
		public Store Store { get; set; }
	}
}