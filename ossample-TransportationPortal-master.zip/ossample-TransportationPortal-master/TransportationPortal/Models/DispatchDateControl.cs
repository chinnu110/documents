﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class DispatchDateControl
	{
		[Key]
		[DisplayName("Dispatch Date")]
		public DateTime DispatchDate { get; set; }

		[DisplayName("Week Number")]
		public Int32 WeekNumber { get; set; }

		[DisplayName("Day of Week")]
		public Int32 WeekDayID { get; set; }

		[DisplayName("Week Number")]
		public Int32 TemplateWeekNumber { get; set; }

		[DisplayName("Day of Week")]
		public Int32 TemplateWeekDayID { get; set; }

		[DisplayName("Date is closed")]
		public bool Closed { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

		//
		// Navigation properties.
		//

		[ForeignKey("WeekDayID")]
		public WeekDay WeekDay { get; set; }

		[ForeignKey("TemplateWeekDayID")]
		public WeekDay TemplateWeekDay { get; set; }
	}
}