﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class DailyDispatch
	{
		[Key]
		[Display(Name = "Dispatch ID")]
		public Int32 DailyDispatchID { get; set; }

		[Display(Name = "Generated")]
		public bool Generated { get; set; }

		[Display(Name = "Dispatch Date")]
		public DateTime DispatchDate { get; set; }

		[Display(Name = "Inbound Date")]
		public DateTime? InboundDate { get; set; }

		[Display(Name = "Week")]
		public Int32 Weeknumber { get; set; }

		[Display(Name = "Day")]
		public Int32 WeekDayID { get; set; }

		[Display(Name = "Dispatch Group")]
		public string DispatchGroup { get; set; }

		[Display(Name = "Outbound Route ID")]
		public Int32? OutboundRouteID { get; set; }
				
		[Display(Name = "Carrier")]
		public Int32? CarrierID { get; set; }

		[Display(Name = "Driver1")]
		public Int32? Driver1ID { get; set; }

		[Display(Name = "Driver2")]
		public Int32? Driver2ID { get; set; }

		[Display(Name = "Tractor")]
		public string TractorNumber { get; set; }

		[Display(Name = "Trailer")]
		public string Trailer { get; set; }

		[Display(Name = "Inbound Trailer")]
		public string TrailerIn { get; set; }
		
		[Display(Name = "Miles")]
		public int? Miles { get; set; }

		[Display(Name = "Depart")]
		public DateTime? DepartureTime { get; set; }

		[Display(Name = "Comment")]
		[DataType(DataType.MultilineText)]
		public string Comment { get; set; }

		[Display(Name = "Carrier Rate")]
		[DataType(DataType.Currency)]
		public decimal? CarrierRate { get; set; }

		[Display(Name = "Carrier FlatRate")]
		[DataType(DataType.Currency)]
		public decimal? CarrierFlatRate { get; set; }

		[Display(Name = "Mileage Calc Type")]
		public int MileageCalcType { get; set; }

		[Display(Name = "Carrier Miles")]
		public int? CarrierMiles { get; set; }

		[Display(Name = "Carrier Stop Charge 1")]
		[DataType(DataType.Currency)]
		public decimal? CarrierStopCharge1 { get; set; }

		[Display(Name = "Carrier Stop Charge 2")]
		[DataType(DataType.Currency)]
		public decimal? CarrierStopCharge2 { get; set; }

		[Display(Name = "Carrier Extra Charge")]
		[DataType(DataType.Currency)]
		public decimal? CarrierExtraCharge { get; set; }

		[Display(Name = "Carrier Total Charge")]
		[DataType(DataType.Currency)]
		public decimal? CarrierTotalCharge { get; set; }

		public DateTime? CarrierTotalChargeChanged { get; set; }

		[Display(Name = "Carrier Total Override")]
		[DataType(DataType.Currency)]
		public decimal? CarrierTotalChargeOverride { get; set; }

		[Display(Name = "Fuel Surcharge")]
		[DataType(DataType.Currency)]
		public decimal? FuelSurcharge { get; set; }

		[Display(Name = "Carrier Comment")]
		[DataType(DataType.MultilineText)]
		public string CarrierComment { get; set; }

		[Display(Name = "FSC auto update")]
		public bool LockCarrierTotalCharge { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

		//
		// Navigation properties.
		//

		[ForeignKey("CarrierID")]
		public Carrier Carrier { get; set; }

		[ForeignKey("Driver1ID")]
		public Driver Driver1 { get; set; }

		[ForeignKey("Driver2ID")]
		public Driver Driver2 { get; set; }

		public ICollection<Load> Loads { get; set; }

		public ICollection<DispatchLoadLinkHistory> LoadHistory { get; set; }

        public ICollection<Container> Containers { get; set; }
	}
}