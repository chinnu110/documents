﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public enum StoreCleanupStatus
	{
		None = 0,
		Entered
	}

	public enum DispatchCleanupStatus
	{
		None = 0,
		Confirmed,
		Problem,
		Cancelled
	}

	public enum PerformedCleanupStatus 
	{
		None = 0,
		Cleaned_All,
		Cleaned_Some,
		No_Cleanup_Performed
	}

	public class Load
	{
		[Key]
		public Int32 LoadID { get; set; }

		[Display(Name = "Type")]
		public string LoadType { get; set; }

		[NotMapped]
		public string LoadName
		{
			get
			{
				string loadName = string.Empty;
				if (LoadID > 0)
				{
					if (SourceLoadID.HasValue)
					{
						loadName = string.Format("{0}{1}(Copy of {0}{2})", LoadType, LoadID, SourceLoadID);
					}
					else
					{
						loadName = string.Format("{0}{1}", LoadType, LoadID);
					}
				}
				else
				{
					switch (LoadType)
					{
						case "B":
							loadName = "Broker Load";
							break;
						case "N":
							loadName = "Vendor Backhaul";
							break;
						case "C":
							loadName = "Cleanup";
							break;
						case "S":
							loadName = "Store Load";
							break;
					}
				}
				return loadName;
			}
		}

		[NotMapped]
		public string LoadDescription
		{
			get
			{
				switch (LoadType)
				{
					case "B":
					case "N":
						return PickupCompany != null ? PickupCompany.Name : string.Empty;
					case "C":
						return string.Format("Cleanup {0}", Store != null ? Store.StoreAndCompany : string.Empty);
					case "S":
						return string.Format("Store {0}{1}",
							Store != null ? Store.StoreAndCompany : string.Empty,
							StoreLoadType != "" && StoreLoadType != "A" ? string.Format(" ({0})", StoreLoadType) : string.Empty);
					default:
						return string.Empty;
				}
			}
		}

		[NotMapped]
		public string LoadPickupCity
		{
			get
			{
				switch (LoadType)
				{
					case "C":
						return Store != null ? Store.City : string.Empty;
					default:
						return PickupCompany != null ? PickupCompany.City : string.Empty;
				}
			}
		}

		[NotMapped]
		public string LoadPickupStateCode
		{
			get
			{
				switch (LoadType)
				{
					case "C":
						return Store != null ? Store.StateCode : string.Empty;
					default:
						return PickupCompany != null ? PickupCompany.StateCode : string.Empty;
				}
			}
		}

		[NotMapped]
		public string LoadPickupZip
		{
			get
			{
				return PickupCompany != null ? PickupCompany.Zip : string.Empty;
			}
		}

		[NotMapped]
		public string LoadDeliveryCity
		{
			get
			{
				switch (LoadType)
				{
					case "S":
						return Store != null ? Store.City : string.Empty;
					default:
						return DeliveryCompany != null ? DeliveryCompany.City : string.Empty;
				}
			}
		}

		[NotMapped]
		public string LoadDeliveryStateCode
		{
			get
			{
				switch (LoadType)
				{
					case "S":
						return Store != null ? Store.StateCode : string.Empty;
					default:
						return DeliveryCompany != null ? DeliveryCompany.StateCode : string.Empty;
				}
			}
		}
		
		[Display(Name = "Assigned To")]
		public Int32? DailyDispatchID { get; set; }

		[Display(Name = "Dispatch Load Order")]
		public Int32 DispatchLoadOrder { get; set; }

		[Display(Name = "Load Company")]
		public Int32? LoadCompanyID { get; set; }

		[Display(Name = "Load Contact")]
		public string LoadContact { get; set; }
		
		[Display(Name = "Pickup")]
		public Int32? PickupCompanyID { get; set; }

		[Display(Name = "Pickup Contact")]
		public string PickupContact { get; set; }

		[Display(Name = "Pickup Address")]
		[DataType(DataType.MultilineText)]
		public string PickupAddress { get; set; }

		[Display(Name = "Pickup Stop Count")]
		public Int32? PickupStops { get; set; }

		[Display(Name = "Delivery")]
		public Int32? DeliveryCompanyID { get; set; }

		[Display(Name = "Delivery Contact")]
		public string DeliveryContact { get; set; }

		[Display(Name = "Delivery Address")]
		[DataType(DataType.MultilineText)]
		public string DeliveryAddress { get; set; }

		[Display(Name = "Delivery Stop Count")]
		public Int32? DeliveryStops { get; set; }

		[Display(Name = "Transfer to")]
		public string DeliveryType { get; set; }

		[Display(Name = "PO #1")]
		[DataType(DataType.MultilineText)]
		public string PO1 { get; set; }

		[Display(Name = "PO #2")]
		[DataType(DataType.MultilineText)]
		public string PO2 { get; set; }

		[Display(Name = "Confirmation")]
		public string Confirmation { get; set; }

		[Display(Name = "Pallet Count")]
		public Int32? Pallets { get; set; }

		[Display(Name = "Carton Count")]
		public Int32? Cartons { get; set; }

		[Display(Name = "LoadLocks")]
		public Int32? LoadLocks { get; set; }

		[Display(Name = "Totes")]
		public Int32? Totes { get; set; }

		[Display(Name = "Store Status")]
		[Column("StoreStatus")]
		public StoreCleanupStatus StoreCleanupStatus { get; set; }

		[Display(Name = "Dispatch Status")]
		[Column("DispatchStatus")]
		public DispatchCleanupStatus DispatchCleanupStatus { get; set; }
		
		[Display(Name = "Cleanup Status")]
		[Column("CleanupStatus")]
		public PerformedCleanupStatus PerformedCleanupStatus { get; set; }
        
        public decimal? CleanupUpdatedBy { get; set; }

		[Display(Name = "Weight")]
		public Int32? Weight { get; set; }

		[MaxLength(50)]
		public string Class { get; set; }

		[Display(Name = "Truckload")]
		public bool Truckload { get; set; }

		[Display(Name = "Double Stack")]
		public bool DoubleStack { get; set; }

		[Display(Name = "Down Stack")]
		public bool DownStack { get; set; }

		[Display(Name = "Cube")]
		public Int32? Cube { get; set; }

		[Display(Name = "Store")]
		public Int32? StoreID { get; set; }

		[Display(Name = "Linear Feet")]
		public Int32? LinearFeet { get; set; }

		[Display(Name = "Store Load")]
		public string StoreLoadType { get; set; }

		[Display(Name = "Load Value")]
		[DataType(DataType.Currency)]
		public decimal? LoadValue { get; set; }

		[Display(Name = "Zone")]
		[MaxLength(50)]
		public string Zone { get; set; }

		[Display(Name = "Trailer")]
		[MaxLength(10)]
		public string Trailer { get; set; }

		[DataType(DataType.Currency)]
		public decimal? Rate { get; set; }

		[Display(Name = "Ready Date")]
		public DateTime ReadyDate { get; set; }

		[Display(Name = "Pickup Date")]
		public DateTime? PickupDate { get; set; }

		[Display(Name = "Pickup Date")]
		[DatabaseGenerated(DatabaseGeneratedOption.Computed)]
		public DateTime? PickupDateOnly { get; set; }

		[Display(Name = "ETA Date")]
		public DateTime? EtaDate { get; set; }

		[Display(Name = "ETA Date")]
		[DatabaseGenerated(DatabaseGeneratedOption.Computed)]
		public DateTime? EtaDateOnly { get; set; }

		[Display(Name = "Date Worked")]
		public DateTime? WorkDate { get; set; }

		[Display(Name = "Sched Date")]
		public DateTime? ScheduledDate { get; set; }

		[DataType(DataType.MultilineText)]
		public string Comment { get; set; }

		[Display(Name = "Broker LD#")]
		public string BrokerLoadNumber { get; set; }

		[Display(Name = "PRO Number")]
		[DataType(DataType.MultilineText)]
		public string ProNumber { get; set; }

		[Display(Name = "BL Number")]
		[DataType(DataType.MultilineText)]
		public string BLNumber { get; set; }

		[Display(Name = "Invoice Number")]
		public string InvoiceNumber { get; set; }

		[Display(Name = "SAP Send Count")]
		public Int32 InvoiceCount { get; set; }

		[Display(Name = "Invoice Date")]
		public DateTime? InvoiceDate { get; set; }

		[Display(Name = "Invoice Amount")]
		[DataType(DataType.Currency)]
		public decimal? InvoiceAmount { get; set; }

		[MaxLength(250)]
		[Display(Name = "Invoice Comment")]
		[DataType(DataType.MultilineText)]
		public string InvoiceComment { get; set; }

		[Display(Name = "Export Date")]
		public DateTime? DataExportDate { get; set; }

		[Display(Name = "Generated?")]
		public bool Generated { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

		[Display(Name = "Store Opening?")]
		public bool StoreOpening { get; set; }

		[Display(Name = "Cleanup Request Change Date")]
		public DateTime? CleanupRequestChangeDate { get; set; }

		[Display(Name = "Source Load")]
		public Int32? SourceLoadID { get; set; }

		/*
		 * Navigation Properties
		 */

		[ForeignKey("SourceLoadID")]
		public Load SourceLoad { get; set; }

		[InverseProperty("SourceLoad")]
		public ICollection<Load> LoadCopies { get; set; }

		[ForeignKey("StoreID")]
		public Store Store { get; set; }

		[ForeignKey("DailyDispatchID")]
		public DailyDispatch DailyDispatch { get; set; }

		[ForeignKey("LoadCompanyID")]
		public LoadCompany LoadCompany { get; set; }

		[ForeignKey("PickupCompanyID")]
		public LoadCompany PickupCompany { get; set; }

		[ForeignKey("DeliveryCompanyID")]
		public LoadCompany DeliveryCompany { get; set; }

		/// <summary>
		/// Makes a copy of the Load object. No EF specific fields are copied. No relationships are copied.
		/// </summary>
		/// <returns></returns>
		public Load MakeCopy()
		{
			Load loadCopy = new Load();

			loadCopy.LoadType = this.LoadType;
			loadCopy.DailyDispatchID = this.DailyDispatchID;
			loadCopy.DispatchLoadOrder = this.DispatchLoadOrder;
			loadCopy.LoadCompanyID = this.LoadCompanyID;
			loadCopy.LoadContact = this.LoadContact;
			loadCopy.PickupCompanyID = this.PickupCompanyID;
			loadCopy.PickupContact = this.PickupContact;
			loadCopy.PickupAddress = this.PickupAddress;
			loadCopy.PickupStops = this.PickupStops;
			loadCopy.DeliveryCompanyID = this.DeliveryCompanyID;
			loadCopy.DeliveryContact = this.DeliveryContact;
			loadCopy.DeliveryAddress = this.DeliveryAddress;
			loadCopy.DeliveryStops = this.DeliveryStops;
			loadCopy.DeliveryType = this.DeliveryType;
			loadCopy.PO1 = this.PO1;
			loadCopy.PO2 = this.PO2;
			loadCopy.Confirmation = this.Confirmation;
			loadCopy.Pallets = this.Pallets;
			loadCopy.Cartons = this.Cartons;
			loadCopy.LoadLocks = this.LoadLocks;
			loadCopy.Totes = this.Totes;
			loadCopy.StoreCleanupStatus = this.StoreCleanupStatus;
			loadCopy.DispatchCleanupStatus = this.DispatchCleanupStatus;
			loadCopy.PerformedCleanupStatus = this.PerformedCleanupStatus;
			loadCopy.Weight = this.Weight;
			loadCopy.Class = this.Class;
			loadCopy.Truckload = this.Truckload;
			loadCopy.DoubleStack = this.DoubleStack;
			loadCopy.DownStack = this.DownStack;
			loadCopy.Cube = this.Cube;
			loadCopy.StoreID = this.StoreID;
			loadCopy.LinearFeet = this.LinearFeet;
			loadCopy.StoreLoadType = this.StoreLoadType;
			loadCopy.LoadValue = this.LoadValue;
			loadCopy.Zone = this.Zone;
			loadCopy.Trailer = this.Trailer;
			loadCopy.Rate = this.Rate;
			loadCopy.ReadyDate = this.ReadyDate;
			loadCopy.PickupDate = this.PickupDate;
			loadCopy.PickupDateOnly = this.PickupDateOnly;
			loadCopy.EtaDate = this.EtaDate;
			loadCopy.EtaDateOnly = this.EtaDateOnly;
			loadCopy.WorkDate = this.WorkDate;
			loadCopy.ScheduledDate = this.ScheduledDate;
			loadCopy.Comment = this.Comment;
			loadCopy.BrokerLoadNumber = this.BrokerLoadNumber;
			loadCopy.ProNumber = this.ProNumber;
			loadCopy.BLNumber = this.BLNumber;
			loadCopy.InvoiceNumber = this.InvoiceNumber;
			loadCopy.InvoiceCount = this.InvoiceCount;
			loadCopy.InvoiceDate = this.InvoiceDate;
			loadCopy.InvoiceAmount = this.InvoiceAmount;
			loadCopy.InvoiceComment = this.InvoiceComment;
			loadCopy.DataExportDate = this.DataExportDate;
			loadCopy.Generated = this.Generated;
			loadCopy.StoreOpening = this.StoreOpening;
			loadCopy.CleanupRequestChangeDate = this.CleanupRequestChangeDate;
			loadCopy.SourceLoadID = this.SourceLoadID;

			return loadCopy;
		}
	}
}