﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	[Table("vw_DailyDispatchSlim")]
	public class DailyDispatchSlim
	{
		[Key]
		[Display(Name = "Dispatch ID")]
		public Int32 DailyDispatchID { get; set; }

		[Display(Name = "Generated")]
		public bool Generated { get; set; }

		[Display(Name = "Dispatch Date")]
		public DateTime DispatchDate { get; set; }

		[Display(Name = "Inbound Date")]
		public DateTime? InboundDate { get; set; }

		[Display(Name = "Week")]
		public Int32 Weeknumber { get; set; }

		[Display(Name = "Day")]
		public Int32 WeekDayID { get; set; }

		[Display(Name = "Dispatch Group")]
		public string DispatchGroup { get; set; }

		[Display(Name = "Carrier")]
		public Int32? CarrierID { get; set; }

		[Display(Name = "Driver1")]
		public Int32? Driver1ID { get; set; }

		[Display(Name = "Driver2")]
		public Int32? Driver2ID { get; set; }

		[Display(Name = "Tractor")]
		public string TractorNumber { get; set; }

		[Display(Name = "Trailer")]
		public string Trailer { get; set; }

		[Display(Name = "Inbound Trailer")]
		public string TrailerIn { get; set; }
		
		[Display(Name = "Depart")]
		public DateTime? DepartureTime { get; set; }

		[Display(Name = "Comment")]
		[DataType(DataType.MultilineText)]
		public string Comment { get; set; }

		[Display(Name = "Carrier Rate")]
		[DataType(DataType.Currency)]
		public decimal? CarrierRate { get; set; }

		[Display(Name = "Carrier Miles")]
		public int? CarrierMiles { get; set; }

		[Display(Name = "Carrier Total Charge")]
		[DataType(DataType.Currency)]
		public decimal? CarrierTotalCharge { get; set; }

		[Display(Name = "Fuel Surcharge")]
		[DataType(DataType.Currency)]
		public decimal? FuelSurcharge { get; set; }

		//
		// Navigation properties.
		//

		[ForeignKey("CarrierID")]
		public Carrier Carrier { get; set; }

		[ForeignKey("Driver1ID")]
		public Driver Driver1 { get; set; }

		[ForeignKey("Driver2ID")]
		public Driver Driver2 { get; set; }

		public ICollection<LoadSlim> Loads { get; set; }

		public ICollection<DispatchLoadLinkHistorySlim> LoadHistory { get; set; }
	}
}