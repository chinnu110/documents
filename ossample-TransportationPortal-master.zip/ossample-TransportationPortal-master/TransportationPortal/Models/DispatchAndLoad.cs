﻿using System;
using System.Collections.Generic;
using HobbyLobby.HLUtil.DataAccess;

namespace TransportationPortal.Models
{
    public class DispatchAndLoad
    {
        // DailyDispatch columns

        [DBColumn(Name = "DailyDispatchID")]
        public int DailyDispatchID { get; set; }

        [DBColumn(Name = "Generated")]
        public bool Generated { get; set; }

        [DBColumn(Name = "DispatchDate")]
        public DateTime DispatchDate { get; set; }

        [DBColumn(Name = "InboundDate")]
        public DateTime? InboundDate { get; set; }

        [DBColumn(Name = "Weeknumber")]
        public int Weeknumber { get; set; }

        [DBColumn(Name = "WeekDayID")]
        public int WeekDayID { get; set; }

        [DBColumn(Name = "DispatchGroup")]
        public string DispatchGroup { get; set; }

        [DBColumn(Name = "CarrierID")]
        public int? CarrierID { get; set; }

        [DBColumn(Name = "Driver1ID")]
        public int? Driver1ID { get; set; }

        [DBColumn(Name = "Driver2ID")]
        public int? Driver2ID { get; set; }

        [DBColumn(Name = "TractorNumber")]
        public string TractorNumber { get; set; }

        [DBColumn(Name = "Trailer")]
        public string Trailer { get; set; }

        [DBColumn(Name = "TrailerIn")]
        public string TrailerIn { get; set; }

        [DBColumn(Name = "DepartureTime")]
        public DateTime? DepartureTime { get; set; }

        [DBColumn(Name = "Comment")]
        public string Comment { get; set; }

        [DBColumn(Name = "CarrierRate")]
        public decimal? CarrierRate { get; set; }

        [DBColumn(Name = "CarrierMiles")]
        public int? CarrierMiles { get; set; }

        [DBColumn(Name = "CarrierTotalCharge")]
        public decimal? CarrierTotalCharge { get; set; }

        [DBColumn(Name = "LockCarrierTotalCharge")]
        public bool LockCarrierTotalCharge { get; set; }

        [DBColumn(Name = "FuelSurcharge")]
        public decimal? FuelSurcharge { get; set; }

        // Load History columns

        [DBColumn(Name = "HistoryLoadID")]
        public int? HistoryLoadID { get; set; }

        [DBColumn(Name = "HistoryLoadType")]
        public string HistoryLoadType { get; set; }

        [DBColumn(Name = "HistoryStoreID")]
        public int? HistoryStoreID { get; set; }

        [DBColumn(Name = "HistoryStatus")]
        public int? HistoryStatus { get; set; }

        [DBColumn(Name = "HistoryEtaDate")]
        public DateTime? HistoryEtaDate { get; set; }

        // Load columns

        [DBColumn(Name = "LoadID")]
        public int? LoadID { get; set; }

        [DBColumn(Name = "LoadType")]
        public string LoadType { get; set; }

        [DBColumn(Name = "LoadComment")]
        public string LoadComment { get; set; }

        [DBColumn(Name = "DispatchLoadOrder")]
        public int? DispatchLoadOrder { get; set; }

        [DBColumn(Name = "LoadCompanyID")]
        public int? LoadCompanyID { get; set; }

        [DBColumn(Name = "PickupCompanyID")]
        public int? PickupCompanyID { get; set; }

        [DBColumn(Name = "DeliveryCompanyID")]
        public int? DeliveryCompanyID { get; set; }

        [DBColumn(Name = "DeliveryType")]
        public string DeliveryType { get; set; }

        [DBColumn(Name = "StoreID")]
        public int? StoreID { get; set; }

        [DBColumn(Name = "LinearFeet")]
        public int? LinearFeet { get; set; }

        [DBColumn(Name = "StoreLoadType")]
        public string StoreLoadType { get; set; }

        [DBColumn(Name = "ReadyDate")]
        public DateTime? ReadyDate { get; set; }

        [DBColumn(Name = "PickupDate")]
        public DateTime? PickupDate { get; set; }

        [DBColumn(Name = "EtaDate")]
        public DateTime? EtaDate { get; set; }

        [DBColumn(Name = "Pallets")]
        public int? Pallets { get; set; }

        [DBColumn(Name = "Cartons")]
        public int? Cartons { get; set; }

        [DBColumn(Name = "LoadLocks")]
        public int? LoadLocks { get; set; }

        [DBColumn(Name = "Totes")]
        public int? Totes { get; set; }

        [DBColumn(Name = "StoreOpening")]
        public bool? StoreOpening { get; set; }

        // Carrier

        [DBColumn(Name = "CarrierName")]
        public string CarrierName { get; set; }

        // Drivers

        [DBColumn(Name = "Driver1FirstName")]
        public string Driver1FirstName { get; set; }

        [DBColumn(Name = "Driver1LastName")]
        public string Driver1LastName { get; set; }

        [DBColumn(Name = "Driver1Suffix")]
        public string Driver1Suffix { get; set; }

        [DBColumn(Name = "Driver1DispatcherID")]
        public int? Driver1DispatcherID { get; set; }

        [DBColumn(Name = "Driver2FirstName")]
        public string Driver2FirstName { get; set; }

        [DBColumn(Name = "Driver2LastName")]
        public string Driver2LastName { get; set; }

        [DBColumn(Name = "Driver2Suffix")]
        public string Driver2Suffix { get; set; }

        [DBColumn(Name = "Driver2DispatcherID")]
        public int? Driver2DispatcherID { get; set; }

        // Store

        [DBColumn(Name = "StoreCompanyID")]
        public string StoreCompanyID { get; set; }
        
        [DBColumn(Name = "StoreNumber")]
        public int? StoreNumber { get; set; }

        [DBColumn(Name = "StoreDuplicateCode")]
        public string StoreDuplicateCode { get; set; }

        [DBColumn(Name = "StoreCity")]
        public string StoreCity { get; set; }

        [DBColumn(Name = "StoreStateCode")]
        public string StoreStateCode { get; set; }

        // Broker

        [DBColumn(Name = "BrokerName")]
        public string BrokerName { get; set; }

        [DBColumn(Name = "BrokerCity")]
        public string BrokerCity { get; set; }

        [DBColumn(Name = "BrokerStateCode")]
        public string BrokerStateCode { get; set; }

        // Pickup

        [DBColumn(Name = "PickupName")]
        public string PickupName { get; set; }

        [DBColumn(Name = "PickupCity")]
        public string PickupCity { get; set; }

        [DBColumn(Name = "PickupStateCode")]
        public string PickupStateCode { get; set; }

        // Deliver

        [DBColumn(Name = "DeliveryName")]
        public string DeliveryName { get; set; }

        [DBColumn(Name = "DeliveryCity")]
        public string DeliveryCity { get; set; }

        [DBColumn(Name = "DeliveryStateCode")]
        public string DeliveryStateCode { get; set; }


        /*
         * Derived values.
         */

        public DateTime? PickupDateOnly 
        {
            get
            {
                return PickupDate != null ? PickupDate.Value.Date : (DateTime?)null;
            }
        }

        public DateTime? EtaDateOnly
        {
            get
            {
                return EtaDate != null ? EtaDate.Value.Date : (DateTime?)null;
            }
        }

        public string LoadName
        {
            get
            {
                if (LoadID > 0)
                {
                    return string.Format("{0}{1}", LoadType, LoadID);
                }
                else
                {
                    switch (LoadType)
                    {
                        case "B":
                            return "Broker Load";
                        case "N":
                            return "Vendor Backhaul";
                        case "C":
                            return "Cleanup";
                        case "S":
                            return "Store Load";
                        default:
                            return string.Empty;
                    }
                }
            }
        }

        public string LoadDescription
        {
            get
            {
                switch (LoadType)
                {
                	case "B":
                	case "N":
                		return PickupName;
                	case "C":
                		return string.Format("Cleanup {0}", StoreAndCompany);
                	case "S":
                		return string.Format("Store {0}{1}",
                			StoreAndCompany,
                			StoreLoadType != "" && StoreLoadType != "A" ? string.Format(" ({0})", StoreLoadType) : string.Empty);
                	default:
                		return string.Empty;
                }
            }
        }

        public string StoreAndCompany
        {
            get { return (StoreCompanyID == "HL" ? string.Format("{0}", StoreNumberPlusDupCode) : string.Format("{0} {1}", StoreNumber, StoreCompanyID)); }
        }

        public string StoreNumberPlusDupCode
        {
            get { return string.Format("{0}{1}", StoreNumber, StoreDuplicateCode ?? string.Empty); }
        }

        public string LoadPickupCity
        {
            get
            {
                switch (LoadType)
                {
                	case "C":
                		return StoreCity;
                	default:
                		return PickupCity;
                }
            }
        }

        public string LoadPickupStateCode
        {
            get
            {
                switch (LoadType)
                {
                	case "C":
                		return StoreStateCode;
                	default:
                		return PickupStateCode;
                }
            }
        }

        public string LoadDeliveryCity
        {
            get
            {
                switch (LoadType)
                {
                	case "S":
                		return StoreCity;
                	default:
                		return DeliveryCity;
                }
            }
        }

        public string LoadDeliveryStateCode
        {
            get
            {
                switch (LoadType)
                {
                	case "S":
                		return StoreStateCode;
                	default:
                		return DeliveryStateCode;
                }
            }
        }
    }
}