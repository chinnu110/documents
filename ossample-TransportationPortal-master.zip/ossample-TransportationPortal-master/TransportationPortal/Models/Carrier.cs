﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class Carrier
	{
		[Key]
		public Int32 CarrierID { get; set; }

		[Display(Name = "Carrier Name")]
		public string Name { get; set; }

		[Display(Name = "Contact Name")]
		public string ContactName { get; set; }

		[Display(Name = "Phone")]
		public string Phone { get; set; }

		[Display(Name = "Fax")]
		public string Fax { get; set; }

		[Display(Name = "Email Name")]
		public string DispatchEmailName { get; set; }

		[Display(Name = "Email Address")]
		[DataType(DataType.EmailAddress)]
		public string DispatchEmailAddress { get; set; }

		[Display(Name = "Notes")]
		[DataType(DataType.MultilineText)]
		public string Notes { get; set; }

		[Display(Name = "First Stop Charge")]
		[DataType(DataType.Currency)]
		public decimal? StopCharge1 { get; set; }

		[Display(Name = "Second Stop Charge")]
		[DataType(DataType.Currency)]
		public decimal? StopCharge2 { get; set; }

		/*
		 * Navigation properties
		 */

		public ICollection<DailyDispatch> Dispatches { get; set; }

		[ForeignKey("CarrierID")]
		public ICollection<StoreCarrierInfo> StoreCarrierInfo { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

        [Display(Name = "Deleted by")]
        [MaxLength(50)]
        public string DeleteUser { get; set; }

        [Display(Name = "Deleted on")]
        public DateTime? DeleteDate { get; set; }
    }
}