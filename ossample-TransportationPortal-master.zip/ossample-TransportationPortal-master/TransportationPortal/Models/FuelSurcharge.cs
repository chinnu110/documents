﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public class FuelSurcharge
	{
		[Key]
		public Int32 FuelSurchargeID { get; set; }

		public DateTime ActiveDate { get; set; }

        [Column("ActiveDateEnd")]
		public DateTime? ActiveEndDate { get; set; }

		[Display(Name = "Fuel Surcharge")]
		[DataType(DataType.Currency)]
		public decimal Amount { get; set; }

		[DataType(DataType.MultilineText)]
		public string Comment { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }
	}
}