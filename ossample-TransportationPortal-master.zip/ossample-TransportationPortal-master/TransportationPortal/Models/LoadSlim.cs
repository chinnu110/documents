﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	[Table("vw_LoadSlim")]
	public class LoadSlim
	{
		[Key]
		public Int32 LoadID { get; set; }

		[Display(Name = "Type")]
		public string LoadType { get; set; }

		[NotMapped]
		public string LoadName
		{
			get
			{
				if (LoadID > 0)
				{
					return string.Format("{0}{1}", LoadType, LoadID);
				}
				else
				{
					switch (LoadType)
					{
						case "B":
							return "Broker Load";
						case "N":
							return "Vendor Backhaul";
						case "C":
							return "Cleanup";
						case "S":
							return "Store Load";
						default:
							return string.Empty;
					}
				}
			}
		}

		[NotMapped]
		public string LoadDescription
		{
			get
			{
				switch (LoadType)
				{
					case "B":
					case "N":
						return PickupCompany != null ? PickupCompany.Name : string.Empty;
					case "C":
						return string.Format("Cleanup {0}", Store != null ? Store.StoreAndCompany : string.Empty);
					case "S":
						return string.Format("Store {0}{1}",
							Store != null ? Store.StoreAndCompany : string.Empty,
							StoreLoadType != "" && StoreLoadType != "A" ? string.Format(" ({0})", StoreLoadType) : string.Empty);
					default:
						return string.Empty;
				}
			}
		}

		[NotMapped]
		public string LoadPickupCity
		{
			get
			{
				switch (LoadType)
				{
					case "C":
						return Store != null ? Store.City : string.Empty;
					default:
						return PickupCompany != null ? PickupCompany.City : string.Empty;
				}
			}
		}

		[NotMapped]
		public string LoadPickupStateCode
		{
			get
			{
				switch (LoadType)
				{
					case "C":
						return Store != null ? Store.StateCode : string.Empty;
					default:
						return PickupCompany != null ? PickupCompany.StateCode : string.Empty;
				}
			}
		}

		[NotMapped]
		public string LoadDeliveryCity
		{
			get
			{
				switch (LoadType)
				{
					case "S":
						return Store != null ? Store.City : string.Empty;
					default:
						return DeliveryCompany != null ? DeliveryCompany.City : string.Empty;
				}
			}
		}

		[NotMapped]
		public string LoadDeliveryStateCode
		{
			get
			{
				switch (LoadType)
				{
					case "S":
						return Store != null ? Store.StateCode : string.Empty;
					default:
						return DeliveryCompany != null ? DeliveryCompany.StateCode : string.Empty;
				}
			}
		}
		
		[Display(Name = "Assigned To")]
		public Int32? DailyDispatchID { get; set; }

		[Display(Name = "Dispatch Load Order")]
		public Int32 DispatchLoadOrder { get; set; }

		[Display(Name = "Load Company")]
		public Int32? LoadCompanyID { get; set; }

		[Display(Name = "Pickup")]
		public Int32? PickupCompanyID { get; set; }

		[Display(Name = "Delivery")]
		public Int32? DeliveryCompanyID { get; set; }

		[Display(Name = "Transfer to")]
		public string DeliveryType { get; set; }

		[Display(Name = "Store")]
		public Int32? StoreID { get; set; }

		[Display(Name = "Linear Feet")]
		public Int32? LinearFeet { get; set; }

		[Display(Name = "Store Load")]
		public string StoreLoadType { get; set; }

		[Display(Name = "Ready Date")]
		public DateTime ReadyDate { get; set; }

		[Display(Name = "Pickup Date")]
		public DateTime? PickupDate { get; set; }

		[Display(Name = "Pickup Date")]
		[DatabaseGenerated(DatabaseGeneratedOption.Computed)]
		public DateTime? PickupDateOnly { get; set; }

		[Display(Name = "ETA Date")]
		public DateTime? EtaDate { get; set; }
		
		[Display(Name = "ETA Date")]
		[DatabaseGenerated(DatabaseGeneratedOption.Computed)]
		public DateTime? EtaDateOnly { get; set; }

		[Display(Name = "Pallet Count")]
		public Int32? Pallets { get; set; }

		[Display(Name = "Carton Count")]
		public Int32? Cartons { get; set; }

		[Display(Name = "LoadLocks")]
		public Int32? LoadLocks { get; set; }

		[Display(Name = "Totes")]
		public Int32? Totes { get; set; }

		[Display(Name = "Store Opening?")]
		public bool StoreOpening { get; set; }

		/*
		 * Navigation Properties
		 */

		[ForeignKey("StoreID")]
		public StoreSlim Store { get; set; }

		[ForeignKey("DailyDispatchID")]
		public DailyDispatchSlim DailyDispatch { get; set; }

		[ForeignKey("LoadCompanyID")]
		public LoadCompanySlim LoadCompany { get; set; }

		[ForeignKey("PickupCompanyID")]
		public LoadCompanySlim PickupCompany { get; set; }

		[ForeignKey("DeliveryCompanyID")]
		public LoadCompanySlim DeliveryCompany { get; set; }
	}
}