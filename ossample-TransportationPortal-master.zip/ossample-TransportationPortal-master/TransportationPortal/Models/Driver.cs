﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	public enum DriverShift
	{
		None = 0,
		Day = 1,
		Night = 2
	}

	public enum DriverShiftStart
	{
		None = 0,
		OKC = 1,
		Dallas = 2
	}

	public class Driver
	{
		[Key]
		public Int32 DriverID { get; set; }

		[Required(ErrorMessage="First name is required.")]
		[Display(Name = "First Name")]
		public string FirstName { get; set; }

		[Display(Name = "Middle Name")]
		public string MiddleName { get; set; }

		[Required(ErrorMessage = "Last name is required.")]
		[Display(Name = "Last Name")]
		public string LastName { get; set; }

		[Display(Name = "Suffix")]
		public string Suffix { get; set; }

		[Display(Name = "Dispatcher")]
		public Int32? DispatcherID { get; set; }

		[Display(Name = "Team Partner")]
		public Int32? TeamPartnerID { get; set; }

		[Display(Name = "Phone")]
		public string Phone { get; set; }

		[Display(Name = "Drive Hours")]
		public string DriveHours { get; set; }

		[Display(Name = "Smoker")]
		public bool Smoker { get; set; }

		[Display(Name = "Notes")]
		[DataType(DataType.MultilineText)]
		public string Notes { get; set; }

		[Display(Name = "Shift")]
		public DriverShift DriverShift { get; set; }

		[Display(Name = "Shift Start")]
		public DriverShiftStart DriverShiftStart { get; set; }

		[Display(Name = "Dispatch Group")]
		public string DispatchGroup { get; set; }

		[Display(Name = "Part Time")]
		public bool PartTime { get; set; }

		[Display(Name = "Tractor")]
		public string TractorNumber { get; set; }

		// Convenience Properties

		[NotMapped]
		public string FullName
		{
			get { return string.Format("{0} {1} {2} {3}", FirstName, MiddleName, LastName, Suffix).Replace("  ", " ").Trim(); }
		}

		[NotMapped]
		[Display(Name = "SAP Driver ID")]
		public string SapDriverID { get; set; }

		[NotMapped]
		[Display(Name = "SAP Driver Name")]
		public string SapDriverName { get; set; }

		[Timestamp]
		public Byte[] Timestamp { get; set; }

		[MaxLength(50)]
		public string CreateUser { get; set; }

		public DateTime CreateDate { get; set; }

		[MaxLength(50)]
		public string ChangeUser { get; set; }

		public DateTime? ChangeDate { get; set; }

		[MaxLength(50)]
		public string DeleteUser { get; set; }

		public DateTime? DeleteDate { get; set; }

		// Navigation Properties

		[ForeignKey("DispatcherID")]
		public Dispatcher Dispatcher { get; set; }

		[ForeignKey("TeamPartnerID")]
		public Driver TeamPartner { get; set; }

		[InverseProperty("Driver1")]
		public ICollection<OutboundRoute> AssignedAsDriver1 { get; set; }

		[InverseProperty("Driver2")]
		public ICollection<OutboundRoute> AssignedAsDriver2 { get; set; }
	}
}