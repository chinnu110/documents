﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TransportationPortal.Models
{
	[Table("vw_LoadCompanySlim")]
	public class LoadCompanySlim
	{
		[Key]
		public Int32 LoadCompanyID { get; set; }

		[MaxLength(50)]
		[Display(Name = "Company Name")]
		public string Name { get; set; }

		[MaxLength(50)]
		public string City { get; set; }

		[MaxLength(2)]
		[Display(Name = "State")]
		public string StateCode { get; set; }

		[MaxLength(10)]
		[Display(Name = "Zip Code")]
		public string Zip { get; set; }
	}
}