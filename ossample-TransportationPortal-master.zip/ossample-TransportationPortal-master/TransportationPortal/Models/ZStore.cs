﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TransportationPortal.Models
{
	public class ZStore
	{
		[Key]
		[Display(Name = "Store ID")]
		public Int32 Store_ID { get; set; }

		[Display(Name = "Chain")]
		public Int16 Chain { get; set; }

		[Display(Name = "Store Number")]
		public Int16 Store_Number { get; set; }

		[Display(Name = "Street Address")]
		public string Street_Address { get; set; }

		[Display(Name = "City")]
		public string City { get; set; }

		[Display(Name = "State")]
		public string State { get; set; }

		[Display(Name = "Zip")]
		public string Zip_Code { get; set; }

		[Display(Name = "Location")]
		public string Location { get; set; }

		[Display(Name = "Manager")]
		public short? Manager { get; set; }

		[Display(Name = "Phone")]
		public decimal? Phone_Number { get; set; }

		[Display(Name = "Fixture Date")]
		public DateTime? Fixture_Date { get; set; }

		[Display(Name = "Dry Run Date")]
		public DateTime? Dry_Run_Date { get; set; }

		[Display(Name = "Time Zone")]
		public string Time_Zone { get; set; }

		[Display(Name = "Email")]
		public string Email_Address { get; set; }

		[Display(Name = "Status")]
		public string Status { get; set; }
	}
}