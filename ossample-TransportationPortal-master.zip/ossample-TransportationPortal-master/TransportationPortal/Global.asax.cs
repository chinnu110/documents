﻿using System.Web.Mvc;
using System.Web.Routing;
using HobbyLobby.HLUtil.Configuration;
using HobbyLobby.HLUtil.Logging;
using System;
using System.Web;
using System.Diagnostics;
using System.Reflection;
using System.Web.Optimization;

namespace TransportationPortal
{
    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            Route theRoute;

            // Define route with catchall.
            theRoute = routes.MapRoute(
                "DefaultWithCatchall",
                "{controller}/{action}/{id}/{*catchall}",
                new { controller = "Home", action = "Index", id = UrlParameter.Optional },
                new string[] { "TransportationPortal.Controllers" });
            theRoute.DataTokens["UseNamespaceFallback"] = false;

            theRoute = routes.MapRoute(
                "Default",
                "{controller}/{action}/{id}",
                new { controller = "Home", action = "Index", id = UrlParameter.Optional },
                new string[] { "TransportationPortal.Controllers" });
            theRoute.DataTokens["UseNamespaceFallback"] = false;
        }

        protected void Application_Start()
        {
            HLConfig.Configure();            

            ViewEngines.Engines.Clear();
            ViewEngines.Engines.Add(new RazorViewEngine());    

            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            HLLogging.Info("Application_Start.");
        }

        protected void Application_End()
        {
            HttpRuntime runtime = (HttpRuntime)typeof(System.Web.HttpRuntime)
                .InvokeMember("_theRuntime", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.GetField, null, null, null);

            if (runtime == null)
            {
                HLLogging.Info("Application_End");
                return;
            }
            
            string shutDownMessage = (string)runtime.GetType()
                .InvokeMember("_shutDownMessage", BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.GetField, null, runtime, null);
            
            shutDownMessage = shutDownMessage.Replace('\r', ' ').Replace('\n', '.');
            
            HLLogging.Info(string.Format("Application_End _shutDownMessage={0}", shutDownMessage));
        }

        protected void Session_OnStart()
        {
            string user = null;
            string sessionID = null;
            try
            {
                user = this.Request.LogonUserIdentity.Name;
                sessionID = this.Session.SessionID;
            }
            catch (Exception)
            {
                user = "unknown";
                sessionID = "unknown";
            }
            HLLogging.Info(string.Format("Session_OnStart: User {0} SessionID {1}", user, sessionID));
        }

        protected void Session_OnEnd()
        {
            string sessionID = null;
            try
            {
                sessionID = this.Session.SessionID;
            }
            catch (Exception)
            {
                sessionID = "unknown";
            }
            HLLogging.Info(string.Format("Session_OnEnd: SessionID {0}", sessionID));
        }
    }
}
