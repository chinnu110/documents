﻿using Microsoft.Extensions.Configuration;

namespace CleanupTruckScheduler.Api.Common
{
    public interface ILibConfiguration
    {
        string ConnectionString { get; }
    }
}