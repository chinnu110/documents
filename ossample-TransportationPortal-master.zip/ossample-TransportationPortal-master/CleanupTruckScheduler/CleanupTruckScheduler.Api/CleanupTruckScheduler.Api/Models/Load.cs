﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class Load
    {
        public Load()
        {
            InverseSourceLoad = new HashSet<Load>();
        }

        public int LoadId { get; set; }
        public string LoadType { get; set; }
        public int? DailyDispatchId { get; set; }
        public int DispatchLoadOrder { get; set; }
        public int? LoadCompanyId { get; set; }
        public string LoadContact { get; set; }
        public int? PickupCompanyId { get; set; }
        public string PickupContact { get; set; }
        public string PickupAddress { get; set; }
        public int? PickupStops { get; set; }
        public int? DeliveryCompanyId { get; set; }
        public string DeliveryContact { get; set; }
        public string DeliveryAddress { get; set; }
        public int? DeliveryStops { get; set; }
        public string DeliveryType { get; set; }
        public string Po1 { get; set; }
        public string Po2 { get; set; }
        public string Confirmation { get; set; }
        public int? Pallets { get; set; }
        public int? Cartons { get; set; }
        public int? Weight { get; set; }
        public string Class { get; set; }
        public bool DoubleStack { get; set; }
        public bool DownStack { get; set; }
        public int? Cube { get; set; }
        public int? StoreId { get; set; }
        public int? LinearFeet { get; set; }
        public string Zone { get; set; }
        public string Trailer { get; set; }
        public decimal? Rate { get; set; }
        public DateTime ReadyDate { get; set; }
        public DateTime? PickupDate { get; set; }
        public DateTime? WorkDate { get; set; }
        public DateTime? ScheduledDate { get; set; }
        public string Comment { get; set; }
        public string InvoiceNumber { get; set; }
        public int InvoiceCount { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public decimal? InvoiceAmount { get; set; }
        public string InvoiceComment { get; set; }
        public DateTime? DataExportDate { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
        public DateTime? DepartureTime { get; set; }
        public string StoreLoadType { get; set; }
        public decimal? LoadValue { get; set; }
        public DateTime? EtaDate { get; set; }
        public string ProNumber { get; set; }
        public string Blnumber { get; set; }
        public string BrokerLoadNumber { get; set; }
        public bool Truckload { get; set; }
        public bool Generated { get; set; }
        public int? LoadLocks { get; set; }
        public int? Totes { get; set; }
        public int StoreStatus { get; set; }
        public int DispatchStatus { get; set; }
        public int CleanupStatus { get; set; }
        public DateTime? CleanupRequestChangeDate { get; set; }
        public bool StoreOpening { get; set; }
        public DateTime? EtaDateOnly { get; set; }
        public DateTime? PickupDateOnly { get; set; }
        public int? SourceLoadId { get; set; }
        public decimal? CleanupUpdatedBy { get; set; }

        public DailyDispatch DailyDispatch { get; set; }
        public LoadCompany DeliveryCompany { get; set; }
        public LoadCompany LoadCompany { get; set; }
        public LoadCompany PickupCompany { get; set; }
        public Load SourceLoad { get; set; }
        public Store Store { get; set; }
        public ICollection<Load> InverseSourceLoad { get; set; }
    }
}
