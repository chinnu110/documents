﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class Dispatcher
    {
        public Dispatcher()
        {
            Driver = new HashSet<Driver>();
        }

        public int DispatcherId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }

        public ICollection<Driver> Driver { get; set; }
    }
}
