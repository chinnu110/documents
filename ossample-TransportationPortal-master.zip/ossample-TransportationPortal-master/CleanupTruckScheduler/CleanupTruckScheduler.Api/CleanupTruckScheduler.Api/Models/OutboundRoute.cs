﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class OutboundRoute
    {
        public int OutboundRouteId { get; set; }
        public string TractorNumber { get; set; }
        public int? Driver1Id { get; set; }
        public int? Driver2Id { get; set; }
        public int? CarrierId { get; set; }
        public string City { get; set; }
        public string StateCode { get; set; }
        public int? Load1StoreId { get; set; }
        public int WeekNumber { get; set; }
        public int WeekDayId { get; set; }
        public DateTime? DepartureTime { get; set; }
        public DateTime? ScheduledArrivalTime { get; set; }
        public int? Miles { get; set; }
        public int? Hours { get; set; }
        public int? Cleanup1StoreId { get; set; }
        public int? Cleanup2StoreId { get; set; }
        public int? Cleanup3StoreId { get; set; }
        public string Comment { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
        public decimal? CarrierRate { get; set; }
        public decimal? CarrierStopCharge1 { get; set; }
        public decimal? CarrierStopCharge2 { get; set; }
        public decimal? CarrierExtraCharge { get; set; }
        public decimal? CarrierTotalChargeOverride { get; set; }
        public int? Load2StoreId { get; set; }
        public int? Load3StoreId { get; set; }
        public string Load1Type { get; set; }
        public string Load2Type { get; set; }
        public string Load3Type { get; set; }
        public int? Load1DeliveryDayId { get; set; }
        public int? Load2DeliveryDayId { get; set; }
        public int? Load3DeliveryDayId { get; set; }
        public DateTime? Load1DeliveryTime { get; set; }
        public DateTime? Load2DeliveryTime { get; set; }
        public DateTime? Load3DeliveryTime { get; set; }
        public string DispatchGroup { get; set; }
        public int? InboundWeekDayId { get; set; }

        public Carrier Carrier { get; set; }
        public Store Cleanup1Store { get; set; }
        public Store Cleanup2Store { get; set; }
        public Store Cleanup3Store { get; set; }
        public Driver Driver1 { get; set; }
        public Driver Driver2 { get; set; }
        public Store Load1Store { get; set; }
        public Store Load2Store { get; set; }
        public Store Load3Store { get; set; }
    }
}
