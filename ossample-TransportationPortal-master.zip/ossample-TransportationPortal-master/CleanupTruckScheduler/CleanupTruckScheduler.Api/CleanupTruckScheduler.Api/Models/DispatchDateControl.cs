﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class DispatchDateControl
    {
        public DateTime DispatchDate { get; set; }
        public int WeekNumber { get; set; }
        public int WeekDayId { get; set; }
        public int TemplateWeekNumber { get; set; }
        public int TemplateWeekDayId { get; set; }
        public bool Closed { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
    }
}
