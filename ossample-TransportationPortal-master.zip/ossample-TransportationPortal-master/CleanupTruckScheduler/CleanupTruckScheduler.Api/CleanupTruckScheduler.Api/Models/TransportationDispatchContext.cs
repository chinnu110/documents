using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using CleanupTruckScheduler.Api.Common;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class TransportationDispatchContext : DbContext
    {
        public TransportationDispatchContext(ILibConfiguration libConfiguration)
        {
            this.LibConfiguration = libConfiguration;
        }
        private ILibConfiguration LibConfiguration { get; set; }
        public virtual DbSet<Carrier> Carrier { get; set; }
        public virtual DbSet<Company> Company { get; set; }
        public virtual DbSet<Container> Container { get; set; }
        public virtual DbSet<DailyDispatch> DailyDispatch { get; set; }
        public virtual DbSet<DispatchDateControl> DispatchDateControl { get; set; }
        public virtual DbSet<Dispatcher> Dispatcher { get; set; }
        public virtual DbSet<DispatchLoadLinkHistory> DispatchLoadLinkHistory { get; set; }
        public virtual DbSet<Driver> Driver { get; set; }
        public virtual DbSet<FuelSurcharge> FuelSurcharge { get; set; }
        public virtual DbSet<Load> Load { get; set; }
        public virtual DbSet<LoadCompany> LoadCompany { get; set; }
        public virtual DbSet<OutboundRoute> OutboundRoute { get; set; }
        public virtual DbSet<Store> Store { get; set; }
        public virtual DbSet<StoreCarrierInfo> StoreCarrierInfo { get; set; }
        public virtual DbSet<WeekDay> WeekDay { get; set; }
        public virtual DbSet<ZStore> ZStore { get; set; }
        public virtual DbSet<ZStoreHx> ZStoreHx { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(LibConfiguration.ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Carrier>(entity =>
            {
                entity.Property(e => e.CarrierId).HasColumnName("CarrierID");

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContactName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeleteDate).HasColumnType("datetime");

                entity.Property(e => e.DeleteUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DispatchEmailAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DispatchEmailName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Fax)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Notes)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StopCharge1).HasColumnType("money");

                entity.Property(e => e.StopCharge2).HasColumnType("money");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<Company>(entity =>
            {
                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CompanyName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Container>(entity =>
            {
                entity.HasKey(e => new { e.DailyDispatchId, e.ContainerNumber });

                entity.Property(e => e.DailyDispatchId).HasColumnName("DailyDispatchID");

                entity.Property(e => e.ContainerNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContainerAction).HasDefaultValueSql("((0))");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StatusCode)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.DailyDispatch)
                    .WithMany(p => p.Container)
                    .HasForeignKey(d => d.DailyDispatchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Container_DailyDispatch");
            });

            modelBuilder.Entity<DailyDispatch>(entity =>
            {
                entity.HasIndex(e => e.DispatchDate);

                entity.HasIndex(e => e.InboundDate)
                    .HasName("IX_InboundDate");

                entity.Property(e => e.DailyDispatchId).HasColumnName("DailyDispatchID");

                entity.Property(e => e.CarrierComment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.CarrierExtraCharge).HasColumnType("money");

                entity.Property(e => e.CarrierFlatRate).HasColumnType("money");

                entity.Property(e => e.CarrierId).HasColumnName("CarrierID");

                entity.Property(e => e.CarrierRate).HasColumnType("money");

                entity.Property(e => e.CarrierStopCharge1).HasColumnType("money");

                entity.Property(e => e.CarrierStopCharge2).HasColumnType("money");

                entity.Property(e => e.CarrierTotalCharge).HasColumnType("money");

                entity.Property(e => e.CarrierTotalChargeChanged).HasColumnType("datetime");

                entity.Property(e => e.CarrierTotalChargeOverride).HasColumnType("money");

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Comment)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DepartureTime).HasColumnType("datetime");

                entity.Property(e => e.DispatchDate).HasColumnType("date");

                entity.Property(e => e.DispatchGroup)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Driver1Id).HasColumnName("Driver1ID");

                entity.Property(e => e.Driver2Id).HasColumnName("Driver2ID");

                entity.Property(e => e.FuelSurcharge).HasColumnType("money");

                entity.Property(e => e.InboundDate).HasColumnType("date");

                entity.Property(e => e.OutboundRouteId).HasColumnName("OutboundRouteID");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.TractorNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Trailer)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TrailerIn)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.WeekDayId).HasColumnName("WeekDayID");

                entity.HasOne(d => d.Carrier)
                    .WithMany(p => p.DailyDispatch)
                    .HasForeignKey(d => d.CarrierId)
                    .HasConstraintName("FK_DailyDispatch_Carrier");

                entity.HasOne(d => d.Driver1)
                    .WithMany(p => p.DailyDispatchDriver1)
                    .HasForeignKey(d => d.Driver1Id)
                    .HasConstraintName("FK_DailyDispatch_Driver_1");

                entity.HasOne(d => d.Driver2)
                    .WithMany(p => p.DailyDispatchDriver2)
                    .HasForeignKey(d => d.Driver2Id)
                    .HasConstraintName("FK_DailyDispatch_Driver_2");
            });

            modelBuilder.Entity<DispatchDateControl>(entity =>
            {
                entity.HasKey(e => e.DispatchDate);

                entity.Property(e => e.DispatchDate).HasColumnType("date");

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TemplateWeekDayId).HasColumnName("TemplateWeekDayID");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.WeekDayId).HasColumnName("WeekDayID");
            });

            modelBuilder.Entity<Dispatcher>(entity =>
            {
                entity.Property(e => e.DispatcherId).HasColumnName("DispatcherID");

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<DispatchLoadLinkHistory>(entity =>
            {
                entity.HasKey(e => new { e.DailyDispatchId, e.LoadId });

                entity.Property(e => e.DailyDispatchId).HasColumnName("DailyDispatchID");

                entity.Property(e => e.LoadId).HasColumnName("LoadID");

                entity.Property(e => e.EtaDate).HasColumnType("datetime");

                entity.Property(e => e.LoadType)
                    .IsRequired()
                    .HasColumnType("char(1)");

                entity.Property(e => e.StoreId).HasColumnName("StoreID");
            });

            modelBuilder.Entity<Driver>(entity =>
            {
                entity.Property(e => e.DriverId).HasColumnName("DriverID");

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeleteDate).HasColumnType("datetime");

                entity.Property(e => e.DeleteUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DispatchGroup)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.DispatcherId).HasColumnName("DispatcherID");

                entity.Property(e => e.DriveHours)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MiddleName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Notes)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Suffix)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TeamPartnerId).HasColumnName("TeamPartnerID");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.TractorNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.Dispatcher)
                    .WithMany(p => p.Driver)
                    .HasForeignKey(d => d.DispatcherId)
                    .HasConstraintName("FK_Driver_Dispatcher");

                entity.HasOne(d => d.TeamPartner)
                    .WithMany(p => p.InverseTeamPartner)
                    .HasForeignKey(d => d.TeamPartnerId)
                    .HasConstraintName("FK_Driver_Driver");
            });

            modelBuilder.Entity<FuelSurcharge>(entity =>
            {
                entity.Property(e => e.FuelSurchargeId).HasColumnName("FuelSurchargeID");

                entity.Property(e => e.ActiveDate).HasColumnType("date");

                entity.Property(e => e.ActiveDateEnd).HasColumnType("date");

                entity.Property(e => e.Amount).HasColumnType("money");

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Comment)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<Load>(entity =>
            {
                entity.HasIndex(e => e.EtaDate)
                    .HasName("IX_EtaDate");

                entity.HasIndex(e => e.EtaDateOnly)
                    .HasName("IX_EtaDateOnly");

                entity.HasIndex(e => e.PickupDate)
                    .HasName("IX_PickupDate");

                entity.HasIndex(e => e.PickupDateOnly)
                    .HasName("IX_PickDateOnly");

                entity.Property(e => e.LoadId).HasColumnName("LoadID");

                entity.Property(e => e.Blnumber)
                    .HasColumnName("BLNumber")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.BrokerLoadNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Class)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CleanupRequestChangeDate).HasColumnType("datetime");

                entity.Property(e => e.CleanupUpdatedBy).HasColumnType("numeric(6, 0)");

                entity.Property(e => e.Comment)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Confirmation)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DailyDispatchId).HasColumnName("DailyDispatchID");

                entity.Property(e => e.DataExportDate).HasColumnType("datetime");

                entity.Property(e => e.DeliveryAddress)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.DeliveryCompanyId).HasColumnName("DeliveryCompanyID");

                entity.Property(e => e.DeliveryContact)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeliveryType)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.DepartureTime).HasColumnType("datetime");

                entity.Property(e => e.EtaDate).HasColumnType("datetime");

                entity.Property(e => e.EtaDateOnly)
                    .HasColumnType("datetime")
                    .ValueGeneratedOnAddOrUpdate();

                entity.Property(e => e.InvoiceAmount).HasColumnType("money");

                entity.Property(e => e.InvoiceComment)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.InvoiceDate).HasColumnType("datetime");

                entity.Property(e => e.InvoiceNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoadCompanyId).HasColumnName("LoadCompanyID");

                entity.Property(e => e.LoadContact)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoadType)
                    .IsRequired()
                    .HasColumnType("char(1)");

                entity.Property(e => e.LoadValue).HasColumnType("money");

                entity.Property(e => e.PickupAddress)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.PickupCompanyId).HasColumnName("PickupCompanyID");

                entity.Property(e => e.PickupContact)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PickupDate).HasColumnType("datetime");

                entity.Property(e => e.PickupDateOnly)
                    .HasColumnType("datetime")
                    .ValueGeneratedOnAddOrUpdate();

                entity.Property(e => e.Po1)
                    .HasColumnName("PO1")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Po2)
                    .HasColumnName("PO2")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ProNumber)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Rate).HasColumnType("money");

                entity.Property(e => e.ReadyDate).HasColumnType("date");

                entity.Property(e => e.ScheduledDate).HasColumnType("date");

                entity.Property(e => e.SourceLoadId).HasColumnName("SourceLoadID");

                entity.Property(e => e.StoreId).HasColumnName("StoreID");

                entity.Property(e => e.StoreLoadType).HasColumnType("char(1)");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.Trailer)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.WorkDate).HasColumnType("date");

                entity.Property(e => e.Zone)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.DailyDispatch)
                    .WithMany(p => p.Load)
                    .HasForeignKey(d => d.DailyDispatchId)
                    .HasConstraintName("FK_InboundLoad_DailyDispatch");

                entity.HasOne(d => d.DeliveryCompany)
                    .WithMany(p => p.LoadDeliveryCompany)
                    .HasForeignKey(d => d.DeliveryCompanyId)
                    .HasConstraintName("FK_InboundLoad_DeliveryCompany");

                entity.HasOne(d => d.LoadCompany)
                    .WithMany(p => p.LoadLoadCompany)
                    .HasForeignKey(d => d.LoadCompanyId)
                    .HasConstraintName("FK_InboundLoad_LoadCompany");

                entity.HasOne(d => d.PickupCompany)
                    .WithMany(p => p.LoadPickupCompany)
                    .HasForeignKey(d => d.PickupCompanyId)
                    .HasConstraintName("FK_InboundLoad_PickupCompany");

                entity.HasOne(d => d.SourceLoad)
                    .WithMany(p => p.InverseSourceLoad)
                    .HasForeignKey(d => d.SourceLoadId)
                    .HasConstraintName("FK_Load_Load");

                entity.HasOne(d => d.Store)
                    .WithMany(p => p.Load)
                    .HasForeignKey(d => d.StoreId)
                    .HasConstraintName("FK_InboundLoad_Store");
            });

            modelBuilder.Entity<LoadCompany>(entity =>
            {
                entity.Property(e => e.LoadCompanyId).HasColumnName("LoadCompanyID");

                entity.Property(e => e.Address1)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Address2)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.AvailableTimes)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Class)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CompanyRef)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Contact)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CountryCode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeliveryCompanyId).HasColumnName("DeliveryCompanyID");

                entity.Property(e => e.DeliveryType)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Reference)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SapEntity)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SapEntityName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.Type)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Zip)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Zone)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.DeliveryCompany)
                    .WithMany(p => p.InverseDeliveryCompany)
                    .HasForeignKey(d => d.DeliveryCompanyId)
                    .HasConstraintName("FK_LoadCompany_DeliveryCompany");
            });

            modelBuilder.Entity<OutboundRoute>(entity =>
            {
                entity.Property(e => e.OutboundRouteId).HasColumnName("OutboundRouteID");

                entity.Property(e => e.CarrierExtraCharge).HasColumnType("money");

                entity.Property(e => e.CarrierId).HasColumnName("CarrierID");

                entity.Property(e => e.CarrierRate).HasColumnType("money");

                entity.Property(e => e.CarrierStopCharge1).HasColumnType("money");

                entity.Property(e => e.CarrierStopCharge2).HasColumnType("money");

                entity.Property(e => e.CarrierTotalChargeOverride).HasColumnType("money");

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Cleanup1StoreId).HasColumnName("Cleanup1StoreID");

                entity.Property(e => e.Cleanup2StoreId).HasColumnName("Cleanup2StoreID");

                entity.Property(e => e.Cleanup3StoreId).HasColumnName("Cleanup3StoreID");

                entity.Property(e => e.Comment)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DepartureTime).HasColumnType("datetime");

                entity.Property(e => e.DispatchGroup)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Driver1Id).HasColumnName("Driver1ID");

                entity.Property(e => e.Driver2Id).HasColumnName("Driver2ID");

                entity.Property(e => e.InboundWeekDayId).HasColumnName("InboundWeekDayID");

                entity.Property(e => e.Load1DeliveryDayId).HasColumnName("Load1DeliveryDayID");

                entity.Property(e => e.Load1DeliveryTime).HasColumnType("datetime");

                entity.Property(e => e.Load1StoreId).HasColumnName("Load1StoreID");

                entity.Property(e => e.Load1Type).HasColumnType("char(1)");

                entity.Property(e => e.Load2DeliveryDayId).HasColumnName("Load2DeliveryDayID");

                entity.Property(e => e.Load2DeliveryTime).HasColumnType("datetime");

                entity.Property(e => e.Load2StoreId).HasColumnName("Load2StoreID");

                entity.Property(e => e.Load2Type).HasColumnType("char(1)");

                entity.Property(e => e.Load3DeliveryDayId).HasColumnName("Load3DeliveryDayID");

                entity.Property(e => e.Load3DeliveryTime).HasColumnType("datetime");

                entity.Property(e => e.Load3StoreId).HasColumnName("Load3StoreID");

                entity.Property(e => e.Load3Type).HasColumnType("char(1)");

                entity.Property(e => e.ScheduledArrivalTime).HasColumnType("datetime");

                entity.Property(e => e.StateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.TractorNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.WeekDayId).HasColumnName("WeekDayID");

                entity.HasOne(d => d.Carrier)
                    .WithMany(p => p.OutboundRoute)
                    .HasForeignKey(d => d.CarrierId)
                    .HasConstraintName("FK_OutboundRoute_Carrier");

                entity.HasOne(d => d.Cleanup1Store)
                    .WithMany(p => p.OutboundRouteCleanup1Store)
                    .HasForeignKey(d => d.Cleanup1StoreId)
                    .HasConstraintName("FK_OutboundRoute_Cleanup1");

                entity.HasOne(d => d.Cleanup2Store)
                    .WithMany(p => p.OutboundRouteCleanup2Store)
                    .HasForeignKey(d => d.Cleanup2StoreId)
                    .HasConstraintName("FK_OutboundRoute_Cleanup2");

                entity.HasOne(d => d.Cleanup3Store)
                    .WithMany(p => p.OutboundRouteCleanup3Store)
                    .HasForeignKey(d => d.Cleanup3StoreId)
                    .HasConstraintName("FK_OutboundRoute_Cleanup3");

                entity.HasOne(d => d.Driver1)
                    .WithMany(p => p.OutboundRouteDriver1)
                    .HasForeignKey(d => d.Driver1Id)
                    .HasConstraintName("FK_OutboundRoute_Driver1");

                entity.HasOne(d => d.Driver2)
                    .WithMany(p => p.OutboundRouteDriver2)
                    .HasForeignKey(d => d.Driver2Id)
                    .HasConstraintName("FK_OutboundRoute_Driver2");

                entity.HasOne(d => d.Load1Store)
                    .WithMany(p => p.OutboundRouteLoad1Store)
                    .HasForeignKey(d => d.Load1StoreId)
                    .HasConstraintName("FK_OutboundRoute_Load1Store");

                entity.HasOne(d => d.Load2Store)
                    .WithMany(p => p.OutboundRouteLoad2Store)
                    .HasForeignKey(d => d.Load2StoreId)
                    .HasConstraintName("FK_OutboundRoute_Load2Store");

                entity.HasOne(d => d.Load3Store)
                    .WithMany(p => p.OutboundRouteLoad3Store)
                    .HasForeignKey(d => d.Load3StoreId)
                    .HasConstraintName("FK_OutboundRoute_Load3Store");
            });

            modelBuilder.Entity<Store>(entity =>
            {
                entity.Property(e => e.StoreId).HasColumnName("StoreID");

                entity.Property(e => e.AloadArrivalDayId).HasColumnName("ALoadArrivalDayID");

                entity.Property(e => e.AloadArrivalTime)
                    .HasColumnName("ALoadArrivalTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.AloadPickDayId).HasColumnName("ALoadPickDayID");

                entity.Property(e => e.BloadArrivalDayId).HasColumnName("BLoadArrivalDayID");

                entity.Property(e => e.BloadArrivalTime)
                    .HasColumnName("BLoadArrivalTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CleanupTime)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CompanyId)
                    .IsRequired()
                    .HasColumnName("CompanyID")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeleteDate).HasColumnType("datetime");

                entity.Property(e => e.DeleteUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DuplicateCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.StateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Store)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Store_Company");
            });

            modelBuilder.Entity<StoreCarrierInfo>(entity =>
            {
                entity.HasKey(e => new { e.StoreId, e.CarrierId });

                entity.Property(e => e.StoreId).HasColumnName("StoreID");

                entity.Property(e => e.CarrierId).HasColumnName("CarrierID");

                entity.Property(e => e.ChangeDate).HasColumnType("datetime");

                entity.Property(e => e.ChangeUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FlatRate).HasColumnType("money");

                entity.Property(e => e.RatePerMile).HasColumnType("money");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.Carrier)
                    .WithMany(p => p.StoreCarrierInfo)
                    .HasForeignKey(d => d.CarrierId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_StoreCarrierInfo_Carrier");

                entity.HasOne(d => d.Store)
                    .WithMany(p => p.StoreCarrierInfo)
                    .HasForeignKey(d => d.StoreId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_StoreCarrierInfo_Store");
            });

            modelBuilder.Entity<WeekDay>(entity =>
            {
                entity.Property(e => e.WeekDayId)
                    .HasColumnName("WeekDayID")
                    .ValueGeneratedNever();

                entity.Property(e => e.LongName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ShortName)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ZStore>(entity =>
            {
                entity.HasKey(e => e.StoreId);

                entity.ToTable("zSTORE");

                entity.Property(e => e.StoreId).HasColumnName("Store_ID");

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DryRunDate)
                    .HasColumnName("Dry_Run_Date")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.EmailAddress)
                    .HasColumnName("Email_Address")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FixtureDate)
                    .HasColumnName("Fixture_Date")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.Latitude).HasColumnType("decimal(11, 6)");

                entity.Property(e => e.Location)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Longitude).HasColumnType("decimal(11, 6)");

                entity.Property(e => e.PhoneNumber)
                    .HasColumnName("Phone_Number")
                    .HasColumnType("numeric(10, 0)");

                entity.Property(e => e.State)
                    .IsRequired()
                    .HasColumnType("char(2)");

                entity.Property(e => e.Status).HasColumnType("char(1)");

                entity.Property(e => e.StoreNumber).HasColumnName("Store_Number");

                entity.Property(e => e.StreetAddress)
                    .IsRequired()
                    .HasColumnName("Street_Address")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.TimeZone)
                    .IsRequired()
                    .HasColumnName("Time_Zone")
                    .HasColumnType("char(2)");

                entity.Property(e => e.ZipCode)
                    .HasColumnName("Zip_Code")
                    .HasColumnType("char(5)");
            });

            modelBuilder.Entity<ZStoreHx>(entity =>
            {
                entity.HasKey(e => e.StoreId);

                entity.ToTable("zSTORE_HX");

                entity.Property(e => e.StoreId)
                    .HasColumnName("Store_ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.ActiveFlag).HasColumnName("Active_Flag");

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CloseDate)
                    .HasColumnName("Close_Date")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.OpenDate)
                    .HasColumnName("Open_Date")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.State)
                    .IsRequired()
                    .HasColumnType("char(2)");

                entity.Property(e => e.StoreNumber).HasColumnName("Store_Number");

                entity.Property(e => e.StreetAddress)
                    .HasColumnName("Street_Address")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.ZipCode)
                    .HasColumnName("Zip_Code")
                    .HasColumnType("char(5)");
            });
        }
    }
}
