﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class ZStore
    {
        public int StoreId { get; set; }
        public short Chain { get; set; }
        public short StoreNumber { get; set; }
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public string Location { get; set; }
        public short? Manager { get; set; }
        public decimal? PhoneNumber { get; set; }
        public DateTime? FixtureDate { get; set; }
        public DateTime? DryRunDate { get; set; }
        public string TimeZone { get; set; }
        public string EmailAddress { get; set; }
        public string Status { get; set; }
    }
}
