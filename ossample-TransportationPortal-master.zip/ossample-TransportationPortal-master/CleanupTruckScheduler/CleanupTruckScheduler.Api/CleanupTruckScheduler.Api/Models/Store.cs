﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class Store
    {
        public Store()
        {
            Load = new HashSet<Load>();
            OutboundRouteCleanup1Store = new HashSet<OutboundRoute>();
            OutboundRouteCleanup2Store = new HashSet<OutboundRoute>();
            OutboundRouteCleanup3Store = new HashSet<OutboundRoute>();
            OutboundRouteLoad1Store = new HashSet<OutboundRoute>();
            OutboundRouteLoad2Store = new HashSet<OutboundRoute>();
            OutboundRouteLoad3Store = new HashSet<OutboundRoute>();
            StoreCarrierInfo = new HashSet<StoreCarrierInfo>();
        }

        public int StoreId { get; set; }
        public int StoreNumber { get; set; }
        public string CompanyId { get; set; }
        public string City { get; set; }
        public string StateCode { get; set; }
        public int? Miles { get; set; }
        public bool Week1 { get; set; }
        public bool Week2 { get; set; }
        public bool Local { get; set; }
        public string CleanupTime { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
        public DateTime? AloadArrivalTime { get; set; }
        public int? SequenceNumber { get; set; }
        public int? AloadArrivalDayId { get; set; }
        public int? AloadPickDayId { get; set; }
        public int? BloadArrivalDayId { get; set; }
        public DateTime? BloadArrivalTime { get; set; }
        public string DuplicateCode { get; set; }
        public string DeleteUser { get; set; }
        public DateTime? DeleteDate { get; set; }

        public Company Company { get; set; }
        public ICollection<Load> Load { get; set; }
        public ICollection<OutboundRoute> OutboundRouteCleanup1Store { get; set; }
        public ICollection<OutboundRoute> OutboundRouteCleanup2Store { get; set; }
        public ICollection<OutboundRoute> OutboundRouteCleanup3Store { get; set; }
        public ICollection<OutboundRoute> OutboundRouteLoad1Store { get; set; }
        public ICollection<OutboundRoute> OutboundRouteLoad2Store { get; set; }
        public ICollection<OutboundRoute> OutboundRouteLoad3Store { get; set; }
        public ICollection<StoreCarrierInfo> StoreCarrierInfo { get; set; }
    }
}
