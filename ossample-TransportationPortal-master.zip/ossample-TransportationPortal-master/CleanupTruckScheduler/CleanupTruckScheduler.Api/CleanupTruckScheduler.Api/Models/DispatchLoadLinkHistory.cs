﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class DispatchLoadLinkHistory
    {
        public int DailyDispatchId { get; set; }
        public int LoadId { get; set; }
        public string LoadType { get; set; }
        public int? StoreId { get; set; }
        public int Status { get; set; }
        public DateTime? EtaDate { get; set; }
    }
}
