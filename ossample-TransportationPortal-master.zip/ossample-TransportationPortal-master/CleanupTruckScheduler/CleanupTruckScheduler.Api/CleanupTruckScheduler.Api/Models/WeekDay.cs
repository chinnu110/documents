﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class WeekDay
    {
        public int WeekDayId { get; set; }
        public string ShortName { get; set; }
        public string LongName { get; set; }
    }
}
