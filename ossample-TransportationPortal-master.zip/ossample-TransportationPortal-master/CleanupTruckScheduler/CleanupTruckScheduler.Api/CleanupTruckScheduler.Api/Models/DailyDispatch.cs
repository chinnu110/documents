﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class DailyDispatch
    {
        public DailyDispatch()
        {
            Container = new HashSet<Container>();
            Load = new HashSet<Load>();
        }

        public int DailyDispatchId { get; set; }
        public DateTime DispatchDate { get; set; }
        public bool Generated { get; set; }
        public int WeekNumber { get; set; }
        public int WeekDayId { get; set; }
        public int? OutboundRouteId { get; set; }
        public int? CarrierId { get; set; }
        public int? Driver1Id { get; set; }
        public int? Driver2Id { get; set; }
        public string TractorNumber { get; set; }
        public string Trailer { get; set; }
        public string TrailerIn { get; set; }
        public int? Miles { get; set; }
        public DateTime? DepartureTime { get; set; }
        public decimal? CarrierRate { get; set; }
        public string Comment { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
        public decimal? CarrierStopCharge1 { get; set; }
        public decimal? CarrierStopCharge2 { get; set; }
        public decimal? CarrierExtraCharge { get; set; }
        public decimal? CarrierTotalCharge { get; set; }
        public decimal? FuelSurcharge { get; set; }
        public decimal? CarrierTotalChargeOverride { get; set; }
        public int? CarrierMiles { get; set; }
        public DateTime? CarrierTotalChargeChanged { get; set; }
        public decimal? CarrierFlatRate { get; set; }
        public int MileageCalcType { get; set; }
        public string CarrierComment { get; set; }
        public string DispatchGroup { get; set; }
        public DateTime? InboundDate { get; set; }
        public bool LockCarrierTotalCharge { get; set; }

        public Carrier Carrier { get; set; }
        public Driver Driver1 { get; set; }
        public Driver Driver2 { get; set; }
        public ICollection<Container> Container { get; set; }
        public ICollection<Load> Load { get; set; }
    }
}
