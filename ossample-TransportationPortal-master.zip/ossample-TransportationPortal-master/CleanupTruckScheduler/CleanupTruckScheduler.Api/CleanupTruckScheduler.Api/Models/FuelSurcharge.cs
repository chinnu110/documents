﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class FuelSurcharge
    {
        public int FuelSurchargeId { get; set; }
        public DateTime ActiveDate { get; set; }
        public DateTime? ActiveDateEnd { get; set; }
        public decimal Amount { get; set; }
        public string Comment { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
    }
}
