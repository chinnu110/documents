﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class Container
    {
        public int DailyDispatchId { get; set; }
        public string ContainerNumber { get; set; }
        public int ContainerAction { get; set; }
        public short DispatchOrder { get; set; }
        public string StatusCode { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }

        public DailyDispatch DailyDispatch { get; set; }
    }
}
