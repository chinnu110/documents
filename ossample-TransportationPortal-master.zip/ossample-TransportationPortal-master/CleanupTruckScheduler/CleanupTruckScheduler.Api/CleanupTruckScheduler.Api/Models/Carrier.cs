﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class Carrier
    {
        public Carrier()
        {
            DailyDispatch = new HashSet<DailyDispatch>();
            OutboundRoute = new HashSet<OutboundRoute>();
            StoreCarrierInfo = new HashSet<StoreCarrierInfo>();
        }

        public int CarrierId { get; set; }
        public string Name { get; set; }
        public string DispatchEmailName { get; set; }
        public string DispatchEmailAddress { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
        public string ContactName { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Notes { get; set; }
        public decimal? StopCharge1 { get; set; }
        public decimal? StopCharge2 { get; set; }
        public string DeleteUser { get; set; }
        public DateTime? DeleteDate { get; set; }

        public ICollection<DailyDispatch> DailyDispatch { get; set; }
        public ICollection<OutboundRoute> OutboundRoute { get; set; }
        public ICollection<StoreCarrierInfo> StoreCarrierInfo { get; set; }
    }
}
