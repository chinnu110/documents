﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class LoadCompany
    {
        public LoadCompany()
        {
            InverseDeliveryCompany = new HashSet<LoadCompany>();
            LoadDeliveryCompany = new HashSet<Load>();
            LoadLoadCompany = new HashSet<Load>();
            LoadPickupCompany = new HashSet<Load>();
        }

        public int LoadCompanyId { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string StateCode { get; set; }
        public string Zip { get; set; }
        public string CountryCode { get; set; }
        public string Email { get; set; }
        public string Contact { get; set; }
        public string Phone { get; set; }
        public string Reference { get; set; }
        public string AvailableTimes { get; set; }
        public int? Miles { get; set; }
        public string CompanyRef { get; set; }
        public string Zone { get; set; }
        public string Class { get; set; }
        public string SapEntity { get; set; }
        public string SapEntityName { get; set; }
        public bool? SapEntityMatched { get; set; }
        public bool IsBroker { get; set; }
        public bool IsVendor { get; set; }
        public bool IsPickupAddress { get; set; }
        public bool IsDeliveryAddress { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
        public bool IsCompanyAddress { get; set; }
        public string DeliveryType { get; set; }
        public int? DeliveryCompanyId { get; set; }

        public LoadCompany DeliveryCompany { get; set; }
        public ICollection<LoadCompany> InverseDeliveryCompany { get; set; }
        public ICollection<Load> LoadDeliveryCompany { get; set; }
        public ICollection<Load> LoadLoadCompany { get; set; }
        public ICollection<Load> LoadPickupCompany { get; set; }
    }
}
