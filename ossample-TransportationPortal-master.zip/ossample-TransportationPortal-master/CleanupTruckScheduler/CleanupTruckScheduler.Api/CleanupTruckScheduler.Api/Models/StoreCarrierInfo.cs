﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class StoreCarrierInfo
    {
        public int StoreId { get; set; }
        public int CarrierId { get; set; }
        public decimal? RatePerMile { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
        public int? Miles { get; set; }
        public decimal? FlatRate { get; set; }
        public int MileageCalcType { get; set; }

        public Carrier Carrier { get; set; }
        public Store Store { get; set; }
    }
}
