﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class Driver
    {
        public Driver()
        {
            DailyDispatchDriver1 = new HashSet<DailyDispatch>();
            DailyDispatchDriver2 = new HashSet<DailyDispatch>();
            InverseTeamPartner = new HashSet<Driver>();
            OutboundRouteDriver1 = new HashSet<OutboundRoute>();
            OutboundRouteDriver2 = new HashSet<OutboundRoute>();
        }

        public int DriverId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Suffix { get; set; }
        public int? DispatcherId { get; set; }
        public byte[] Timestamp { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeUser { get; set; }
        public DateTime? ChangeDate { get; set; }
        public int? TeamPartnerId { get; set; }
        public string Phone { get; set; }
        public bool Smoker { get; set; }
        public string Notes { get; set; }
        public string DriveHours { get; set; }
        public string DeleteUser { get; set; }
        public DateTime? DeleteDate { get; set; }
        public int DriverShift { get; set; }
        public int DriverShiftStart { get; set; }
        public string DispatchGroup { get; set; }
        public bool PartTime { get; set; }
        public string TractorNumber { get; set; }

        public Dispatcher Dispatcher { get; set; }
        public Driver TeamPartner { get; set; }
        public ICollection<DailyDispatch> DailyDispatchDriver1 { get; set; }
        public ICollection<DailyDispatch> DailyDispatchDriver2 { get; set; }
        public ICollection<Driver> InverseTeamPartner { get; set; }
        public ICollection<OutboundRoute> OutboundRouteDriver1 { get; set; }
        public ICollection<OutboundRoute> OutboundRouteDriver2 { get; set; }
    }
}
