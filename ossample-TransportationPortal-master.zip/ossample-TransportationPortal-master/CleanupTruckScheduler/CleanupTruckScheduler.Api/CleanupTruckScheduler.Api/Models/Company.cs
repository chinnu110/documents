﻿using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Models
{
    public partial class Company
    {
        public Company()
        {
            Store = new HashSet<Store>();
        }

        public string CompanyId { get; set; }
        public string CompanyName { get; set; }
        public short Chain { get; set; }

        public ICollection<Store> Store { get; set; }
    }
}
