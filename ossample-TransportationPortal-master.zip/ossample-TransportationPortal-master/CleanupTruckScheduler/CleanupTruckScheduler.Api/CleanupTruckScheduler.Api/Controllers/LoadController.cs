using CleanupTruckScheduler.Api.Models;
using CleanupTruckScheduler.Api.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using System;
using System.Collections.Generic;

namespace CleanupTruckScheduler.Api.Controllers
{
    [Route("api/[controller]")]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "readAccess")]
    public class LoadController : Controller
    {
        private ILoadRepository LoadRepository;

        public LoadController(ILoadRepository loadRepository)
        {
            this.LoadRepository = loadRepository;
        }
        [Microsoft.AspNetCore.Mvc.HttpGet("{id}")]
        public Load Get(int id)
        {
            Log.Debug($"Load {id} requested");
            var load = this.LoadRepository.GetLoad(id);
            return load;
        }

        [Microsoft.AspNetCore.Mvc.HttpGet("{storeNumber}/{chain}")]
        public List<Load> Get(int chain, int storeNumber)
        {
            Log.Debug($"Gettings Loads for Store: {storeNumber}, Chain: {chain}");
            var loads = this.LoadRepository.GetList(chain, storeNumber);
            loads.ForEach(x =>
            {
                x.Pallets = x.Pallets ?? 0;
                x.Totes = x.Totes ?? 0;
                x.Cartons = x.Cartons ?? 0;
                x.LoadLocks = x.LoadLocks ?? 0;
            });
            return loads;
        }

        [Microsoft.AspNetCore.Mvc.HttpPost("{previousForDate}/{chain}/{storeNumber}")]
        public Load GetPreviousForDate(DateTime previousForDate, int chain, int storeNumber)
        {
            Log.Debug($"Getting Previous Load for Store: {storeNumber}, Chain: {chain}, previousForDate: {previousForDate.ToShortDateString()}");
            var ret = this.LoadRepository.GetPreviousLoad(previousForDate, chain, storeNumber);
            return ret;
        }

        [Microsoft.AspNetCore.Mvc.HttpPost]
        public bool Post(int loadId, int cartons, int totes, int loadlocks, int pallets, decimal updatedByPernr)
        {
            try
            {
                Log.Debug($"Saving Load Data: LoadID: {loadId}, cartons: {cartons}, loadlocks: {loadlocks}, pallets: {pallets}, updatedbypernr: {updatedByPernr}");
                this.LoadRepository.UpdateLoad(loadId, cartons, totes, loadlocks, pallets, updatedByPernr);
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }
    }
}
