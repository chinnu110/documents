using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using CleanupTruckScheduler.Api.Models;
using System.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using CleanupTruckScheduler.Api.Repositories;

namespace CleanupTruckScheduler.Api.Controllers
{
    [Produces("application/json")]
    [Route("api/DistrictLoad")]
    public class DistrictLoadController : Controller
    {
        private IDistrictLoadRepository DistrictLoadRepository;

        public DistrictLoadController(IDistrictLoadRepository districtLoadRepository)
        {
            this.DistrictLoadRepository = districtLoadRepository;
        }

        [Microsoft.AspNetCore.Mvc.HttpGet("{district}/{chain}")]
        public JsonResult GetLoadsForDistrict(int district, int chain)
        {
            var ret = this.DistrictLoadRepository.GetList(district, chain);
            return Json(ret);
        }

        [Microsoft.AspNetCore.Mvc.HttpGet("{pernr}")]
        public int GetDistrictNumber(int pernr)
        {
            var ret = this.DistrictLoadRepository.GetDistrictNumberForPernr(pernr);
            return ret;
        }
    }
}
