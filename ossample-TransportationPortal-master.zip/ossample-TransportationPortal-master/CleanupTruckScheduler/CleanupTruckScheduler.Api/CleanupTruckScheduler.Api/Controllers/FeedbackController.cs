using Microsoft.AspNetCore.Mvc;
using CleanupTruckScheduler.Api.Repositories;
using Serilog;

namespace CleanupTruckScheduler.Api.Controllers
{
    [Produces("application/json")]
    [Route("api/Feedback")]
    public class FeedbackController : Controller
    {
        private ILoadRepository LoadRepository;

        public FeedbackController(ILoadRepository loadRepository)
        {
            this.LoadRepository = loadRepository;
        }

        [Microsoft.AspNetCore.Mvc.HttpPost("{loadId}/{cleanupStatus}")]
        public bool Post(int loadId, int cleanupStatus)
        {
            Log.Debug($"Saving status for cleanup: {loadId}");
            var ret = this.LoadRepository.UpdateFeedback(loadId, cleanupStatus);
            return ret;
        }
    }
}
