﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanupTruckScheduler.Api.Repositories
{
    public interface IDistrictLoadRepository
    {
        List<dynamic> GetList(int district, int chain);
        int GetDistrictNumberForPernr(int pernr);
    }
}
