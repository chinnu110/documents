﻿using CleanupTruckScheduler.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanupTruckScheduler.Api.Repositories
{
    public interface ILoadRepository
    {
        Load GetLoad(int id);
        List<Load> GetList(int chain, int storeNumber);
        Load GetPreviousLoad(DateTime previousForDate, int chain, int storeNumber);
        void UpdateLoad(int loadId, int cartons, int totes, int loadlocks, int pallets, decimal updatedByPernr);
        bool UpdateFeedback(int loadId, int cleanupStatus);
    }
}
