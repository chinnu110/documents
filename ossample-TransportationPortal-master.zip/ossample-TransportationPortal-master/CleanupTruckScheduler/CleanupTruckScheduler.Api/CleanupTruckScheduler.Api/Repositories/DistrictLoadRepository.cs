﻿using CleanupTruckScheduler.Api.Common;
using CleanupTruckScheduler.Api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace CleanupTruckScheduler.Api.Repositories
{
    public class DistrictLoadRepository : IDistrictLoadRepository
    {
        public DistrictLoadRepository(ILibConfiguration libConfiguration)
        {
            this.LibConfiguration = libConfiguration;
        }
        private ILibConfiguration LibConfiguration { get; set; }
        public List<dynamic> GetList(int district, int chain)
        {
            try
            {
                var ret = new List<dynamic>();
                using (TransportationDispatchContext context = new TransportationDispatchContext(LibConfiguration))
                using (var command = context.Database.GetDbConnection().CreateCommand())
                {
                    command.CommandText = "USP_Get_Loads_By_District";
                    command.Parameters.Add(new SqlParameter("@District", district));
                    command.CommandType = CommandType.StoredProcedure;
                    context.Database.OpenConnection();
                    using (var result = command.ExecuteReader())
                    {
                        while (result.Read())
                        {
                            ret.Add(new
                            {
                                store = result["store"],
                                loadId = result["loadId"],
                                totes = result["totes"].ToString() == "" ? 0 : result["totes"],
                                cartons = result["cartons"].ToString() == "" ? 0 : result["cartons"],
                                loadLocks = result["loadLocks"].ToString() == "" ? 0 : result["loadLocks"],
                                pallets = result["pallets"].ToString() == "" ? 0 : result["pallets"],
                                pickupDateOnly = result["pickupDateOnly"],
                                cleanupUpdatedBy = result["cleanupUpdatedBy"].ToString()
                            });
                        }
                    }
                }
                return ret;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

       public int GetDistrictNumberForPernr(int pernr)
        {
            try
            {
                using (TransportationDispatchContext context = new TransportationDispatchContext(LibConfiguration))
                using (var command = context.Database.GetDbConnection().CreateCommand())
                {
                    command.CommandText = "select District from Enterprise.dbo.DISTRICT where DM_AN8 = @Pernr";
                    command.Parameters.Add(new SqlParameter("@Pernr", pernr));
                    command.CommandType = CommandType.Text;
                    context.Database.OpenConnection();
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        return int.Parse(result.ToString());
                    }
                }
                return 1;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }
    }
}
