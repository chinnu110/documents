﻿using CleanupTruckScheduler.Api.Common;
using CleanupTruckScheduler.Api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanupTruckScheduler.Api.Repositories
{
    public class LoadRepository : ILoadRepository
    {
        public LoadRepository(ILibConfiguration libConfiguration)
        {
            this.LibConfiguration = libConfiguration;
        }
        private ILibConfiguration LibConfiguration { get; set; }

        public Load GetLoad(int id)
        {
            try
            {
                using (var ctx = new TransportationDispatchContext(LibConfiguration))
                {
                    var load = ctx.Load.Include(x => x.Store.Company).Where(x => x.LoadId == id).Single();
                    load.Cartons = load.Cartons ?? 0;
                    load.Pallets = load.Pallets ?? 0;
                    load.Totes = load.Totes ?? 0;
                    load.LoadLocks = load.LoadLocks ?? 0;
                    return load;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

        public List<Load> GetList(int chain, int storeNumber)
        {
            try
            {
                var fromDate = DateTime.Now.AddMonths(-6);
                using (var ctx = new TransportationDispatchContext(LibConfiguration))
                {
                    return ctx.Load
                        .Where(x => x.Store.Company.Chain == chain && x.PickupDateOnly >= fromDate && x.Store.StoreNumber == storeNumber && x.LoadType == "C" && x.DailyDispatchId != null).Include(x => x.Store.Company).ToList();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

        public Load GetPreviousLoad(DateTime previousForDate, int chain, int storeNumber)
        {
            // usp_Get_Previous_Cleanup_For_Date  @store, @chain, @previousPickupDate
            using (TransportationDispatchContext ctx = new TransportationDispatchContext(LibConfiguration))
            {
                return ctx.Load.FromSql("usp_Get_Previous_Cleanup_For_Date @p0, @p1, @p2", storeNumber, chain, previousForDate.ToShortDateString()).Single();
            }
        }

        public void UpdateLoad(int loadId, int cartons, int totes, int loadlocks, int pallets, decimal updatedByPernr)
        {
            try
            {
                using (var ctx = new TransportationDispatchContext(LibConfiguration))
                {
                    var load = ctx.Load.Single(x => x.LoadId == loadId);
                    load.Cartons = cartons;
                    load.Totes = totes;
                    load.LoadLocks = loadlocks;
                    load.Pallets = pallets;
                    load.CleanupUpdatedBy = updatedByPernr;
                    ctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

        public bool UpdateFeedback(int loadId, int cleanupStatus)
        {
            try
            {
                try
                {
                    using (var ctx = new TransportationDispatchContext(LibConfiguration))
                    {
                        var l = ctx.Load.Where(x => x.LoadId == loadId).Single();
                        l.CleanupStatus = cleanupStatus;
                        ctx.Attach<Load>(l);
                        ctx.SaveChanges();
                        return true;
                    }
                }
                catch (Exception)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }
    }
}