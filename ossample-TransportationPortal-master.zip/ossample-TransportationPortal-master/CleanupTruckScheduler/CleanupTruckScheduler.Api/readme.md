# Instructions to generate the angular API client. 
* Start server api and grab swagger URL. 
* Run the command below replacing

```java -jar swagger-codegen-cli-2.3.0.jar generate -i http://localhost:1164/swagger/v1/swagger.json -l typescript-angular -o C:\_git\TransportationPortal\CleanupTruckScheduler\CleanupTruckScheduler.App\src\app\services```