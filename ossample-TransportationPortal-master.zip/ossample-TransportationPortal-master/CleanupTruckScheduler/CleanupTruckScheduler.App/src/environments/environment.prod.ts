export const environment = {
  envFlag: 'prod',
  production: true,
  apiUrl: 'http://hlapp/cleanuptruckscheduler-api',
  authority: 'https://auth.hobbylobby.corp/identity/',
  redirect_uri: 'http://hlapp/cleanuptruckscheduler/auth.html',
  post_logout_redirect_uri: 'http://hlapp/cleanuptruckscheduler/',
  silent_redirect_uri: 'http://hlapp/cleanuptruckscheduler/silent-renew.html',
  auth_context: '/cleanup/',
  date: new Date()
};

