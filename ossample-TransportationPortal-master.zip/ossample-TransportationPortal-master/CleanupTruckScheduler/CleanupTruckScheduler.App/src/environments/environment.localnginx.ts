export const environment = {
    envFlag: 'localnginx',
    production: false,
    apiUrl: 'http://localhost:5000',
    authority: 'https://devauth.hobbylobby.corp/identity/',
    redirect_uri: 'http://localhost/cleanuptruckscheduler/auth.html',
    post_logout_redirect_uri: 'http://locahost/cleanuptruckscheduler/',
    silent_redirect_uri: 'http://localhost/cleanuptruckscheduler/silent-renew.html',
    auth_context: '/cleanup/'
  };
