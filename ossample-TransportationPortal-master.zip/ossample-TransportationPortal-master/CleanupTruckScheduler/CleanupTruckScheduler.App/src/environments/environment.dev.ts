export const environment = {
    envFlag: 'dev',
    production: false,
    apiUrl: 'http://devapp/cleanuptruckscheduler-api',
    authority: 'https://devauth.hobbylobby.corp/identity/',
    redirect_uri: 'http://devapp/cleanuptruckscheduler/auth.html',
    post_logout_redirect_uri: 'http://devapp/cleanuptruckscheduler/',
    silent_redirect_uri: 'http://devapp/cleanuptruckscheduler/silent-renew.html',
    auth_context: '/cleanup/',
    date: new Date('12/15/2017')
  };
