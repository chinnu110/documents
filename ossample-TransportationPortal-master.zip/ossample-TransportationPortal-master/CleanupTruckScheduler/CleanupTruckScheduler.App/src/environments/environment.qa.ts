export const environment = {
    envFlag: 'qa',
    production: false,
    apiUrl: 'http://qaapp/cleanuptruckscheduler-api',
    authority: 'https://auth.hobbylobby.corp/identity/',
    redirect_uri: 'http://qaapp/cleanuptruckscheduler/auth.html',
    post_logout_redirect_uri: 'http://qaapp/cleanuptruckscheduler/',
    silent_redirect_uri: 'http://qaapp/cleanuptruckscheduler/silent-renew.html',
    auth_context: '/cleanup/',
    date: new Date()
  };

