import { Component, OnInit } from '@angular/core';
import { AuthService } from '../core/security/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit() {
    // Direct trafic based on claims
    if(!this.authService.hasAdminClaim) {
    if (this.authService.hasDMClaim) {
      this.router.navigate(['/dm-calendar']);
    } else if (this.authService.hasCorpClaim) {
      this.router.navigate(['/corpedit']);
    } else if (this.authService.hasStoreClaim) {
      this.router.navigate(['/store-calendar']);
    }
  }
  }
}
