import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { CommonModule } from '@angular/common';  
import { BrowserModule } from '@angular/platform-browser';

import { SupportRoutingModule } from './support-routing.module';
import { OidcHelperComponent } from './oidc-helper.component';
import { SupportComponent } from './support.component';


@NgModule({
  imports: [
    SharedModule,
    SupportRoutingModule,
    CommonModule
  ],
  declarations: [OidcHelperComponent, SupportComponent]
})
export class SupportModule { }
