import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute, Route, ActivatedRouteSnapshot, UrlSegment, Params, Data } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { ApiService } from '../core/api/api.service';
import { AuthService } from '../core/security/auth.service';

import { MockApiService } from '../core/mock/mock-api.service';
import { MockActivatedRoute } from '../core/mock/mock-activated-route.service';
import { CacheMockService } from '../core/cache/cache-mock.service';
import { MockAuthService } from '../core/mock/mock-auth.service';
import { MockRouter } from '../core/mock/mock-router.service';

import { SharedModule } from '../shared/shared.module';
import { OidcHelperComponent } from './oidc-helper.component';

describe('OidcHelperComponent', () => {
  let component: OidcHelperComponent;
  let fixture: ComponentFixture<OidcHelperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OidcHelperComponent ],
      providers: [
            { provide: ApiService, useClass: MockApiService },
            { provide: ActivatedRoute, useClass: MockActivatedRoute },
            { provide: Router, useClass: MockRouter },
            { provide: AuthService, useClass: MockAuthService }
        ],
      imports: [
         SharedModule
          // ModalModule.forRoot()
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OidcHelperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
