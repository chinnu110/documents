import { Component, OnInit } from '@angular/core';
import { UserManager, Log, MetadataService, User } from 'oidc-client';
import { AuthService } from '../core/security/auth.service';

import { Observable } from 'rxjs/Rx';
//import { ApiService } from 'app/core/api/api.service';

@Component({
  selector: 'app-oidc-helper',
  templateUrl: './oidc-helper.component.html',
  styleUrls: ['./oidc-helper.component.css']
})
export class OidcHelperComponent implements OnInit {
  _user: User;
  loadedUserSub: any;

  expired = true;
  expires_in = 0;
  expires_at = null;
  session_state = null;

  constructor(private authService: AuthService) { }

  ngOnInit() {
    this.loadedUserSub = this.authService.userLoadededEvent
      .subscribe((user: User) => {
        if (user) {
          this._user = user;
          this.expired = user.expired;
          this.expires_at = user.expires_at;
          this.expires_in = user.expires_in;
          this.session_state = user.session_state;
        }
      });
  }

  userDataTest(): void {
    //const chain = this.authService.chain;
    //const store = this.authService.store;
    //const userid = this.authService.userid;
  }

  apiTest(): void {

  }

  expiresIn(): string {
    return this.expires_in.toString();
  }

  tokenExpTime(): string {
    let time = '';
    if (this._user) {
      time = this._user.expires_in.toString();
    }
    return time;
  }

  public convertMillisecondsToStr(t: number): string {
    let totalTime = '0:0';
    const time = t / 1000;
    const minutes = Math.floor(time / 60);
    const seconds = time - minutes * 60;
    const hours = Math.floor(time / 3600);
    totalTime = Math.round(minutes) + 'm' + ' ' + Math.round(seconds) + 's';
    // 00:00 format
    // totalTime = this.str_pad_left(minutes, '0', 2) + ':' + this.str_pad_left(seconds, '0', 2);
    return totalTime;
  }

  refresh(): Observable<User> {
    return null;
    // return Observable.fromPromise(this.authService.getUserPromise());
  }

  clearState() {
    this.authService.clearState();
  }

  getUser() {
    this.authService.getUser();
  }

  removeUser() {
    this.authService.removeUser();
  }
  startSigninMainWindow() {
    this.authService.startSigninMainWindow();
  }

  signinSilent(): void {
    this.authService.signinSilent();
  }

  startSignInPopup() {
    //this.authService.startSignInPopup();
  }

  endSigninMainWindow() {
    this.authService.endSigninMainWindow();
  }
  startSignoutMainWindow() {
    this.authService.startSignoutMainWindow();
  }
  endSignoutMainWindow() {
    this.authService.endSigninMainWindow();
  }

  ngOnDestroy() {
    if (this.loadedUserSub.unsubscribe()) {
      this.loadedUserSub.unsubscribe();
    }
  }
}
