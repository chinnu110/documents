import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SupportComponent } from 'app/support/support.component';
import { OidcHelperComponent } from 'app/support/oidc-helper.component';
import { AuthGuard } from 'app/core/security/auth.guard';

const routes: Routes = [
  {
    path: 'support',
    component: SupportComponent,
    children: [
      { path: 'oidc-helper', component: OidcHelperComponent}
    ],
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SupportRoutingModule { }
