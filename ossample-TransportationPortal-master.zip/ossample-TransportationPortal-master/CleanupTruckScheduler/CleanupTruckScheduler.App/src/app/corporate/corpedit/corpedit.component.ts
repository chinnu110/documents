import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HistoryComponent } from './history/history.component';
@Component({
  selector: 'app-corpedit',
  templateUrl: './corpedit.component.html',
  styleUrls: ['./corpedit.component.css']
})
export class CorpeditComponent {
  @ViewChild('history') private historyComponent: HistoryComponent;
  private chain: number;
  private storeNumber: number;

  constructor(private router: Router, private route: ActivatedRoute) { }

  viewHistory(): void {
    this.historyComponent.loadData(this.chain, this.storeNumber);
  }
}
