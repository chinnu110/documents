import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoadService, Load } from 'hl-cleanupscheduler-api';
import { Observable } from 'rxjs/Observable';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { DataSource } from '@angular/cdk/collections';
import { LoadDataSource } from '../../../shared/load-data-source';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { EditstoreComponent } from '../../../shared/editstore/editstore.component';
import { environment } from '../../../../environments/environment';


@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent {

  constructor(
    private route: ActivatedRoute,
    private loadService: LoadService,
    public dialog: MatDialog) { }

  private chain: number;
  private storeNumber: number;

  // Table Stuff
  private displayedColumns = ['date', 'status', 'pallets', 'cartons', 'loadLocks', 'totes'];
  private dataSource: MatTableDataSource<Load>;
  private doneLoading = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  // Loads the table with load table. 
  // Public because exposed out as ViewChild on parent
  public loadData(chain: number, store: number): void {
    this.doneLoading = false;
    this.chain = chain;
    this.storeNumber = store;

    this.loadService.apiLoadByStoreNumberByChainGet(chain, store).subscribe(data => {
      this.loadDataSource(data);
      this.doneLoading = true;
    });
  }

  // Loads the instance datasource with Load array
  loadDataSource(Loads: Load[]): void {
    this.dataSource = new MatTableDataSource(this.sortByPickupDate(this.setReadOnlyLoads(Loads)));
    this.dataSource.paginator = this.paginator;
  }

  // Iterates Loads and sets the readonly flag
  setReadOnlyLoads(Loads: any[]): any[] {
    return Loads.map(l => {
      l.readonly = new Date(l.pickupDateOnly) > environment.date;
      return l;
    });
  }

  // Sorts the Loads by pickupdate desc
  sortByPickupDate(Loads: Load[]): Load[] {
    return Loads.sort((a: Load, b: Load) => {
      return +new Date(a.pickupDateOnly) - +new Date(b.pickupDateOnly);
    }).reverse();
  }

  // Opens modal to edit the clicked cleanup
  editCleanup(cleanup: Load): void {
    // open dialog
    const dialogRef = this.dialog.open(EditstoreComponent, {
      width: '600px',
      data: { currentLoad: cleanup, prevLoad: null }
    });
  }
}
