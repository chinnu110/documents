import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorpeditComponent } from './corpedit.component';

describe('CorpeditComponent', () => {
  let component: CorpeditComponent;
  let fixture: ComponentFixture<CorpeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorpeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorpeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
