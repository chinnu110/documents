import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CorpeditComponent } from './corpedit/corpedit.component';
import { AppRoutingModule } from './app-routing.module';
import { HistoryComponent } from './corpedit/history/history.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  imports: [
    CommonModule,
    AppRoutingModule,
    SharedModule
  ],
  declarations: [CorpeditComponent, HistoryComponent],
})
export class CorporateModule { }
