import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CorpeditComponent } from './corpedit/corpedit.component';
import { HistoryComponent } from './corpedit/history/history.component';
import { AuthGuard } from '../core/security/auth.guard';

const routes: Routes = [
     {
       path: 'corpedit', component: CorpeditComponent, canActivate: [AuthGuard]
      }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
