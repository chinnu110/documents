import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router
} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from './auth.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    // const isLoggedIn = true;
    const isLoggedIn = this.authService.isLoggedInObs();
    isLoggedIn.subscribe(loggedin => {
      if (!loggedin) {
        // bypass router navigate and directly call authService logout
        this.authService.startSigninMainWindow();
      } else {
        // check claims to route
        let authorized = false;
        switch (state.url) {
          case '/corpedit': {
            authorized = this.authService.hasCorpClaim;
            break;
          }
          case '/store-calendar': {
            authorized = this.authService.hasStoreClaim;
            break;
          }
          case '/dm-calendar': {
            authorized = this.authService.hasDMClaim;
            break;
          }
          case '/home': {
            authorized = true;
            break;
          }
          default: {
            this.router.navigate(['unauthorized']);
            break;
          }
        }

        if (!authorized) {
          this.router.navigate(['unauthorized']);
        }
      }
    });
    return isLoggedIn;
  }
}
