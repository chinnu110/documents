import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DmCalendarComponent} from './dm-calendar/dm-calendar.component';
import { AuthGuard } from '../core/security/auth.guard';

const routes: Routes = [
    { path: 'dm-calendar', component: DmCalendarComponent, canActivate: [AuthGuard] }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
