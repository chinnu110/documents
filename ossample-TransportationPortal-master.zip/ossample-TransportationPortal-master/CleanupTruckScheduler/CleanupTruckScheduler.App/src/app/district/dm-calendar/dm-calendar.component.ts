import { Component, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { CalendarEvent, CalendarMonthViewDay } from 'angular-calendar';
import { colors } from '../../shared/colors';
import { Load, DistrictLoadService } from 'hl-cleanupscheduler-api';
import { Observable } from 'rxjs/Observable';

import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours
} from 'date-fns';
import { AuthService } from '../../core/security/auth.service';
import { LegendHelper } from '../../shared/legend-helper';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-dm-calendar',
  templateUrl: './dm-calendar.component.html',
  styleUrls: ['./dm-calendar.component.css']
})
export class DmCalendarComponent implements OnInit {
  view = 'week';
  viewDate: Date = environment.date;
  events: CalendarEvent[];
  activeDayIsOpen = false;

  legendLabel: string;

  constructor(private districtLoadService: DistrictLoadService, private authService: AuthService) { }

  ngOnInit(): void {
    this.fetchEvents();
  }

  // Pull cleanups from api
  fetchEvents(): void {
    // TODO: Remove hardcoded chain and district and get from authService
    this.districtLoadService.apiDistrictLoadByPernrGet(parseInt(this.authService.pernr, 10)).subscribe(district => {
     const helper = new LegendHelper();
     this.legendLabel = helper.getLegendTextDistrict(this.authService.chain.toString(), district);
      this.districtLoadService.apiDistrictLoadByDistrictByChainGet(district, this.authService.chain).map(
        results => {
          return results.map((load: Load) => {
            return {
              title: `Store: ${load.store},
                      Cartons: ${(load.cartons)},
                      Loadlocks: ${(load.loadLocks)},
                      Totes: ${(load.totes)},
                      Pallets: ${(load.pallets)}`,
              start: new Date(load.pickupDateOnly),
              color: load.cleanupUpdatedBy ? colors.blue : colors.red,
              meta: load
            };
          });
        }).subscribe(result => this.events = result);
    });
  }

  // Day event to allow viewing details of the cleanup without navigating to it
  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    if (isSameMonth(date, this.viewDate)) {
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
        this.viewDate = date;
      }
    }
  }
}
