import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DmCalendarComponent } from './dm-calendar/dm-calendar.component';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    AppRoutingModule,
    SharedModule
  ],
  providers: [],
  declarations: [DmCalendarComponent],
  exports: [DmCalendarComponent]
})
export class DistrictModule { }
