import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from '../shared/shared.module';

// Componenets
import { StorecalendarComponent } from './storecalendar/storecalendar.component';

@NgModule({
  imports: [
    SharedModule,
    CommonModule,
    AppRoutingModule
  ],
  providers: [],
  declarations: [
    StorecalendarComponent
  ]
})
export class StoreModule { }
