import { Component, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { CalendarEvent, CalendarMonthViewDay, CalendarEventAction } from 'angular-calendar';
import { colors } from '../../shared/colors';
import { Router } from '@angular/router';
import { LoadService, Load } from 'hl-cleanupscheduler-api';
import { OfflinemodalComponent } from '../../shared/offlinemodal/offlinemodal.component';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/timer';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/retryWhen';
import 'rxjs/add/operator/delay';
import 'rxjs/add/observable/of';

import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours
} from 'date-fns';
import { MatDialogModule, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { AuthService } from '../../core/security/auth.service';
import { EditstoreComponent } from '../../shared/editstore/editstore.component';
import { LegendHelper } from '../../shared/legend-helper';
import { environment } from '../../../environments/environment';
import { FeedbackComponent } from '../../shared/editstore/feedback/feedback.component';

@Component({
  selector: 'app-calendar',
  templateUrl: './storecalendar.component.html',
  styleUrls: ['storecalendar.component.css']
})
export class StorecalendarComponent implements OnInit {
  view = 'month';
  viewDate: Date = environment.date;
  events: CalendarEvent[] = [];
  activeDayIsOpen = false;
  doneLoading = false;
  legendLabel: string;

  chain: number;
  storeNumber: number;

  constructor(
    private router: Router,
    private loadService: LoadService,
    private dialog: MatDialog,
    private authService: AuthService
  ) {
    this.chain = this.authService.chain;
    this.storeNumber = this.authService.store;
  }

  ngOnInit(): void {
    this.fetchEvents();
  }

  // Pull cleanups from api
  fetchEvents(): void {
    const get = this.loadService
      .apiLoadByStoreNumberByChainGet(this.chain, this.storeNumber)
      .map(results => {
        return results.map((load: Load) => {
          return {
            title: `Cartons: ${load.cartons}, Loadlocks: ${
              load.loadLocks
            }, Totes: ${load.totes}, Pallets: ${load.pallets}`,
            start: new Date(load.pickupDateOnly),
            color:
              new Date(load.pickupDateOnly) > this.viewDate
                ? colors.red
                : colors.blue,
            meta: load
          };
        });
      })
      .finally(() => {
     const helper = new LegendHelper();
     this.legendLabel = helper.getLegendTextStore(this.chain.toString(), this.storeNumber);
        this.doneLoading = true;
      });

    get.retryWhen(x => {
        this.dialog.open(OfflinemodalComponent);
        return x.delay(2000);
      })
      .subscribe(result => (this.events = result));
  }

  handleEvent(event: CalendarEvent): void {
    this.doneLoading = false;

    // Get previous Load
    const currnetLoad = event.meta;
    let prevLoad: Load;

    // tslint:disable-next-line:max-line-length
    this.loadService.apiLoadByPreviousForDateByChainByStoreNumberPost(currnetLoad.pickupDateOnly, currnetLoad.store.company.chain, currnetLoad.store.storeNumber).subscribe(prev => {
      prevLoad = prev;
      if (prevLoad && prevLoad.cleanupStatus === 0 && new Date(prev.pickupDateOnly) <= new Date(this.viewDate)) {
        this.OpenSetFeedbackModal(prevLoad, currnetLoad);
      }
    else { 
      this.OpenSetCleanupModal(prevLoad, currnetLoad);
    }
    },
    () => {
      // Finally
    }, () => this.doneLoading = true);
  }

  private OpenSetFeedbackModal(prevLoad: Load, currnetLoad: Load): void {
    const dialogRef = this.dialog.open(FeedbackComponent, {
      width: '600px',
      data: {prevLoad: prevLoad, currentLoad: currnetLoad}
    });

    dialogRef.afterClosed().subscribe(result => {
      this.OpenSetCleanupModal(result.prevLoad, result.currentLoad);
    });

  }

  private OpenSetCleanupModal(prevLoad: Load, currnetLoad: Load): void {
    const dialogRef = this.dialog.open(EditstoreComponent, {
      width: '600px',
      data: {prevLoad: prevLoad, currentLoad: currnetLoad}
    });
  }
}
