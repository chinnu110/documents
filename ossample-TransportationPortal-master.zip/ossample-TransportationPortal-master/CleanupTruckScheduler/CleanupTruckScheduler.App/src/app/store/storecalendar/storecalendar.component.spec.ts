import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StorecalendarComponent } from './storecalendar.component';
import { SharedModule } from '../../shared/shared.module';
import { CorpeditComponent } from '../../corporate/corpedit/corpedit.component';
import { HistoryComponent } from '../../corporate/corpedit/history/history.component';
import { LoadService } from 'hl-cleanupscheduler-api';

describe('StorecalendarComponent', () => {
  let component: StorecalendarComponent;
  let fixture: ComponentFixture<StorecalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StorecalendarComponent, CorpeditComponent, HistoryComponent ],
      imports: [SharedModule],
      providers: [
        {provide: LoadService, useClass: mockLoadService},
        {provide: AuthService, useClass: MockAuthService}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StorecalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});


// import { Employee } from '../model/video-training-model';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import {
    Response,
    XHRBackend,
    Http,
    BaseRequestOptions,
    ResponseOptions,
    RequestOptions,
    URLSearchParams
} from '@angular/http';
import { AuthService } from '../../core/security/auth.service';

export class MockAuthService {
    employee: any = {
        personnelId: 222294,
        managerId: null,
        pernr: 999999,
        firstName: 'Mohammed',
        lastName: 'Ali',
        chain: 200,
        storeNumber: 69
    };

    userLoadededEvent = Observable.create((observer: Observer<any>) => {
        const user = {
            id_token: 'id_token',
            session_state: null,
            access_token: 'access_token',
            token_type: 'token_type',
            scope: 'scope',
            profile: 'profile',
            expires_at: 2322323,
            state: 'state',
            expires_in: 123,
            expired: false,
            scopes: []
        };
        observer.next(user);
        observer.complete();
    });

    public startSigninMainWindow(): void {

    }

     public startSignoutMainWindow(): void {

    }

    public isCorp(): boolean {
        return false;
    }

    public logIn(username: string, password: string): Observable<any> {
        return null;
    }
    public getUser(): any {
        return this.employee;
    }

    public authUser(): Observable<any> {
        return null;
    }

    AuthGet(url: string, options?: RequestOptions): Observable<Response> {
        return null;
    }
    /**
     * @param options if options are not supplied the default content type is application/json
     */
    AuthPut(url: string, body: any, options?: RequestOptions): Observable<Response> {
        return null;
    }
    /**
     * @param options if options are not supplied the default content type is application/json
     */
    AuthDelete(url: string, options?: RequestOptions): Observable<Response> {
        return null;
    }
    /**
     * @param options if options are not supplied the default content type is application/json
     */
    AuthPost(url: string, body: any, options?: RequestOptions): Observable<Response> {
        return null;
    }
}