export const colors: any = {
    red: {
      primary: '#ad2121',
      secondary: '#FAE3E3'
    },
    blue: {
      primary: '#0000ff',
      secondary: '#6b6bed'
    },
    yellow: {
      primary: '#e3bc08',
      secondary: '#FDF1BA'
    },
    grey: {
      primary: '#808080',
      secondary: '#d0d0d0'
    }
  };
