import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { LegendHelper } from '../legend-helper';

@Component({
  selector: 'mwl-calendar-header',
  templateUrl: './calendar-header.component.html',
  styleUrls: ['calendar-header.component.css']
})
export class CalendarHeaderComponent implements OnInit {
  @Input() view: string;

  @Input() viewDate: Date;

  @Input() locale = 'en';

  @Input() useStoreLegend: boolean;

  @Input() legendLabel: string;

  @Input() public activeDayIsOpen: boolean;

  @Output() viewChange: EventEmitter<string> = new EventEmitter();

  @Output() viewDateChange: EventEmitter<Date> = new EventEmitter();

  @Output() activeDayIsOpenChange: EventEmitter<boolean> = new EventEmitter();

  title: string;

  ngOnInit(): void {
  }

  changeActiveDay(): void {
    this.activeDayIsOpen = false;
    this.activeDayIsOpenChange.next(this.activeDayIsOpen);
  }
}
