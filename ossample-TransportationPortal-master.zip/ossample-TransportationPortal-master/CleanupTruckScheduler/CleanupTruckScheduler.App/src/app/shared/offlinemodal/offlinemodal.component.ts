import { Component, OnInit } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';

@Component({
  selector: 'app-offlinemodal',
  templateUrl: './offlinemodal.component.html',
  styleUrls: ['./offlinemodal.component.css']
})
export class OfflinemodalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
