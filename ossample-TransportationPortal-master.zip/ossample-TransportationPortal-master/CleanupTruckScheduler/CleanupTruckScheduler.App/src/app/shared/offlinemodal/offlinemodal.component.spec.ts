import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfflinemodalComponent } from './offlinemodal.component';

describe('OfflinemodalComponent', () => {
  let component: OfflinemodalComponent;
  let fixture: ComponentFixture<OfflinemodalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfflinemodalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfflinemodalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
