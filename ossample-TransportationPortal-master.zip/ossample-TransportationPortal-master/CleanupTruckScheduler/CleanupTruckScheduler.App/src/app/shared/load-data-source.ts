import { DataSource } from '@angular/cdk/table';
import { LoadService, Load } from 'hl-cleanupscheduler-api';
import { Observable } from 'rxjs/Observable';

export class LoadDataSource extends DataSource<any> {
    private chain: number;
    private storeNumber: number;
    constructor(private loadService: LoadService, _chain: number, _storeNumber: number){
      super();
      this.chain = _chain;
      this.storeNumber = _storeNumber;
    }
    connect(): Observable<Load[]> {
      return this.loadService.apiLoadByStoreNumberByChainGet(this.chain, this.storeNumber);
    }
    disconnect() {}
  }
