import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { Load, FeedbackService } from 'hl-cleanupscheduler-api';
import { Router } from '@angular/router';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  cleanupStatus: number;
  currentLoad: Load;
  prevLoad: Load;
  constructor(
    private feedbackService: FeedbackService,
    public dialogRef: MatDialogRef<FeedbackComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.prevLoad = this.data.prevLoad;
    this.currentLoad = this.data.currentLoad;

  }

  saveFeedback(): void {
    this.feedbackService.apiFeedbackByLoadIdByCleanupStatusPost(this.prevLoad.loadId, this.cleanupStatus)
    .subscribe(x => {
      this.dialogRef.close({prevLoad: this.prevLoad, currentLoad: this.currentLoad});
    });
  }
}
