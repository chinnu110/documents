import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { LoadService, Load } from 'hl-cleanupscheduler-api';
import { addDays, differenceInHours } from 'date-fns';
import { AuthService } from '../../core/security/auth.service';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs/Observable';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-editstore',
  templateUrl: './editstore.component.html',
  styleUrls: ['./editstore.component.css']
})
export class EditstoreComponent implements OnInit {
  constructor(
    private loadService: LoadService,
    public dialogRef: MatDialogRef<EditstoreComponent>,
    private snackBar: MatSnackBar,
    private authService: AuthService,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    }

    

   // Holds the previous load
  previousLoad: Load = { pickupDateOnly: addDays(environment.date, -2) };
  currentLoad: Load;

  loadFootage = {cartons: 0, loadLocks: 0, pallets: 0, totes: 0};

  differenceInHours: number;

  // Date to compare load and previous load to
  today = environment.date;

  // Flag to indicate validation errors
  validation = true;

  // Flag to indicate if the cleanup can be edited
  readOnly = false;

  // Flag to signal to browser if all data has finished loading
  doneLoading = false;

  toteControl = new FormControl();
  palletControl = new FormControl();
  loadLockControl = new FormControl();
  cartonControl = new FormControl();

  ngOnInit() {
    this.Load(this.data.prevLoad, this.data.currentLoad);
    this.toteControl = new FormControl('', [Validators.required, Validators.max(500)]);
    this.palletControl = new FormControl('', [Validators.required, Validators.max(26)]);
    this.cartonControl = new FormControl('', [Validators.required, Validators.max(1000)]);
    this.loadLockControl = new FormControl('', [Validators.required, Validators.max(25)]);
  }

  public Load(prevLoad: Load, currentLoad: Load): void {
      this.loadFootage.cartons = currentLoad.cartons;
      this.loadFootage.loadLocks = currentLoad.loadLocks;
      this.loadFootage.pallets = currentLoad.pallets;
      this.loadFootage.totes = currentLoad.totes;
      this.currentLoad = currentLoad;

      // get hours until currentload
     this.differenceInHours = differenceInHours(this.today, currentLoad.pickupDateOnly);
     this.readOnly = this.differenceInHours > -24;
     if (prevLoad) {
     this.previousLoad.pickupDateOnly = new Date(prevLoad.pickupDateOnly);
     }
     this.doneLoading = true;
  }

  save(): void {
    // Validate
    // tslint:disable-next-line:max-line-length
    if (this.isInvalid()) {
      return;
    }
    // Update Passed in model
    this.data.currentLoad.cartons = this.loadFootage.cartons;
    this.data.currentLoad.pallets = this.loadFootage.pallets;
    this.data.currentLoad.loadLocks = this.loadFootage.loadLocks;
    this.data.currentLoad.totes = this.loadFootage.totes;

    this.loadService.apiLoadPost(
      this.data.currentLoad.loadId,
      this.data.currentLoad.cartons,
      this.data.currentLoad.totes,
      this.data.currentLoad.loadLocks,
      this.data.currentLoad.pallets,
      parseInt(this.authService.pernr, 10)).subscribe(x => {
        const message = x === true ?
                        'Cleanup Saved Successfully' :
                        'There was an error saving. Please try again or contact the helpdesk.';

        this.snackBar.open(message, null, {
          duration: 2000,
        });

        this.dialogRef.close(x);
      });
  }

  isInvalid(): boolean {
    return this.toteControl.invalid || this.loadLockControl.invalid || this.cartonControl.invalid || this.palletControl.invalid;
  }

  canEdit(): boolean {
    return this.previousLoad.pickupDateOnly <= this.today;
  }
}
