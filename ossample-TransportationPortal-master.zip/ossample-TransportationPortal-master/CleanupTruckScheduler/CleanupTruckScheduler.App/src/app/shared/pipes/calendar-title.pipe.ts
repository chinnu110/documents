import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'calendarTitle' })
export class CalendarTitlePipe implements PipeTransform {
    private months = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'];

    transform(value: Date, view: string): string {
        if (view === 'month') {
            return `${this.months[value.getMonth()]} ${value.getFullYear()}`;
        }

        return `Week Of ${this.months[value.getMonth()]} ${this.getMonday(value).getDate()}`;
    }

    private getMonday(d): Date {
        const inputDate = new Date(d);
        const day = inputDate.getDay();
        const diff = inputDate.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
        return new Date(d.setDate(diff));
    }
}
