// Angular Modules
import { NgModule, } from '@angular/core';

import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
// Components
import { OfflinemodalComponent } from './offlinemodal/offlinemodal.component';
import { CalendarHeaderComponent } from './calendarheader/calendar-header.component';
import { CalendarModule } from 'angular-calendar';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditstoreComponent } from './editstore/editstore.component';
import {
  MatSelectModule,
  MatInputModule,
  MatCardModule,
  MatButtonModule,
  MatListModule,
  MatTableModule,
  MatPaginatorModule,
  MatSliderModule,
  MatDialogModule,
  MatSnackBarModule,
  MatMenuModule,
  MatProgressSpinnerModule} from '@angular/material';
import { FeedbackComponent } from './editstore/feedback/feedback.component';
import { CalendarTitlePipe } from './pipes/calendar-title.pipe';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CalendarModule.forRoot(),
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    MatListModule,
    MatTableModule,
    MatPaginatorModule,
    ReactiveFormsModule,
    MatCardModule,
    MatSliderModule,
    MatDialogModule,
    FormsModule,
    CommonModule,
    HttpModule,
    MatSnackBarModule,
    MatMenuModule,
    MatProgressSpinnerModule,
  ],
  providers: [
  ],
  declarations: [
    OfflinemodalComponent,
    CalendarHeaderComponent,
    EditstoreComponent,
    FeedbackComponent,
    CalendarTitlePipe
  ],
  exports: [
    OfflinemodalComponent,
    CalendarHeaderComponent,
    EditstoreComponent,
    FeedbackComponent,
    CommonModule,
    CalendarModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    MatListModule,
    MatTableModule,
    MatPaginatorModule,
    MatCardModule,
    MatSliderModule,
    MatDialogModule,
    FormsModule,
    CalendarTitlePipe,
    MatMenuModule,
    MatProgressSpinnerModule
  ],
  entryComponents: [OfflinemodalComponent, EditstoreComponent, FeedbackComponent]
})
export class SharedModule {}
