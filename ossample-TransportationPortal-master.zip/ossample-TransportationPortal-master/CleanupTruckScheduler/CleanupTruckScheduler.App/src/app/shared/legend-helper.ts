export class LegendHelper {
   public getLegendTextStore(chain: string, storeNumber: number): string {
        let title: string;
        if (chain === '200') { title = 'Hobby Lobby Store'; }
        else if (chain === '500') { title = 'Mardel Store'; }
        else if (chain === '800') { title = 'Hemisphere Store'; }

        return `${title} ${storeNumber}`;
    }

    public getLegendTextDistrict(chain: string, districtNumber: number): string {
        let title: string;
        if (chain === '200') { title = 'Hobby Lobby District'; }
        else if (chain === '500') { title = 'Mardel District'; }
        else if (chain === '800') { title = 'Hemisphere District'; }

        return `${title} ${districtNumber}`;
    }
}
