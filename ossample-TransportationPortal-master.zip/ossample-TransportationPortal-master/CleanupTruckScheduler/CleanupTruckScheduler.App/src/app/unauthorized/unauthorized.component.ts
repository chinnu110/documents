import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { AuthService } from '../core/security/auth.service';

@Component({
  selector: 'app-unauthorized',
  templateUrl: './unauthorized.component.html',
  styleUrls: ['./unauthorized.component.css']
})
export class UnauthorizedComponent implements OnInit {

  constructor(private authService: AuthService) { }

  ngOnInit() {
    //this.authService.startSigninMainWindow();
  }

  login() {
    //this.authService.startSigninMainWindow();
  }

  goback() {
    // this.location.back();
  }

}
