import { NgModule, ApplicationRef } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';

// Modules
import { CoreModule } from './core/core.module';
import { StoreModule } from './store/store.module';
import { CorporateModule } from './corporate/corporate.module';
import { DistrictModule } from './district/district.module';
import { SupportModule } from './support/support.module';
import 'hammerjs';
// Components
import { AppComponent } from './app.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';

// Environment
import { BASE_PATH, ApiModule, Configuration } from 'hl-cleanupscheduler-api';
import { environment } from '../environments/environment';
import { SharedModule } from './shared/shared.module';
import { HomeComponent } from './home/home.component';
import { AuthService } from './core/security/auth.service';

import { MomentModule } from 'angular2-moment'; // optional, provides moment-style pipes for date formatting
import { NgIdleModule } from '@ng-idle/core';

@NgModule({
  imports: [
    AppRoutingModule,
    SharedModule,
    StoreModule,
    CorporateModule,
    DistrictModule,
    ApiModule,
    HttpModule,
    MomentModule,
    NgIdleModule.forRoot(),
    CoreModule.forRoot(),
    SupportModule
  ],
  providers: [
    { provide: BASE_PATH, useValue: environment.apiUrl },
    { provide: Configuration,
      useFactory: (authService: AuthService) =>
      new Configuration({
        basePath: environment.apiUrl,
        accessToken: authService.getAccessToken.bind(authService),
        withCredentials: false }),
        deps: [AuthService], multi: false }
  ],
  declarations: [
    AppComponent,
    UnauthorizedComponent,
    HomeComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
