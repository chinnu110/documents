﻿var self = this;
var containerViewModel = null;
$("#spinner").hide();
$(".pagination").hide();
$("#containers1").hide();
/*
$(function () {
    $("#spinner").show();
    $(".table").hide();
    $(".pagination").hide();
    $.ajax({
        url: './Status/GetAll',
        cache: false,
        type: 'GET',
        contentType: 'application/json; charset=utf-8',
        data: {},
        dataType: 'json',
        success: function (data) {
            if (containerViewModel === null) {
                containerViewModel = ko.mapping.fromJS(data);
                ko.applyBindings(containerViewModel, document.getElementById('changer'));

            } else {
                ko.mapping.fromJS(data, containerViewModel);
            }
            $(".table").show();
            $("#spinner").hide();
            $(".pagination").show();
        }
    });
});
*/
self.load_containers = function (status_type, page_number) {
    $("#main-message").val("");
    $("#spinner").show();
    $("#spinner-message").html("");
    $(".table").hide();
    $(".pagination").hide();
    $("#pill_CommittedToHemi").removeClass("active");
    $("#pill_CommittedToOKC").removeClass("active");
    $("#pill_Releases").removeClass("active");
    $("#pill_Arrived").removeClass("active");
    $("#pill_Empty").removeClass("active");
    $("#main-message").hide();
    $("#myfilter").val("");

    $.ajax({
        url: './Status/GetAll/' + status_type + '/' + page_number,
        cache: false,
        type: 'GET',
        contentType: 'application/json; charset=utf-8',
        data: {},
        dataType: 'json',
        success: function (data) {
            if (containerViewModel === null) {
                containerViewModel = ko.mapping.fromJS(data);
                ko.applyBindings(containerViewModel, document.getElementById('changer'));

            } else {
                ko.mapping.fromJS(data, containerViewModel);
            }
            $(".pagination").hide();
            $("#changer").show();
            $(".table").show();
            $("#spinner").hide();
            
        },
        failure: function () {
            $(".table").show();
            $("#spinner").hide();
            $(".btn").attr("enabled", true);
        }
    });
    $("#pill_" + status_type).addClass("active");
};
self.load_with_filter = function (containerVal) {
    var container = 0;
    if (containerVal == 0) { container = $('#myfilter').val(); } else { container = containerVal; }
 
    $("#main-message").val("");
    $("#spinner").show();
    $("#spinner-message").html("");
    $(".table").hide();
    $(".pagination").hide();
    //$("#pill_CommittedToHemi").removeClass("active");
    //$("#pill_CommittedToOKC").removeClass("active");
    //$("#pill_Releases").removeClass("active");
    //$("#pill_Arrived").removeClass("active");
    //$("#pill_Empty").removeClass("active");
    $("#main-message").hide();
    $(".functions").css("width", "250px");
    $(".table").css("width", "450px");
     $.ajax({
         url: '../status/get_container/' + container,
        cache: false,
        type: 'GET',
        contentType: 'application/json; charset=utf-8',
        data: {},
        dataType: 'json',
        success: function (data) {
            if (containerViewModel === null) {
                containerViewModel = ko.mapping.fromJS(data);
                ko.applyBindings(containerViewModel, document.getElementById('changer'));

            } else {
                ko.mapping.fromJS(data, containerViewModel);
            }
            $("#changer").show();
            $(".pagination").hide();
            $(".table").show();
            $("#containers1").hide();
            $("#spinner").hide();

        },
        failure: function () {
            $(".table").show();
            $("#spinner").hide();
            $(".btn").attr("enabled", true);
        }
    });
//     $(".btn-arrived").removeClass("hidden");
  //   $(".btn-commit").removeClass("hidden");
     //$(".btn-empty").removeClass("hidden");
    // $(".btn-arrived").show();
     //$(".btn-commit").show();
     //$(".btn-empty").show();
     //$(".btn-change").addClass("hidden");
};


self.make_change = function (ContainerNumber, Action, StatusType, Page) {
    $(".btn").attr("disabled", true);
    $("#spinner-message").html("Setting container: " + ContainerNumber + " status to '" + Action + "'");
    $("#spinner").show();

    $.ajax({
        url: './Status/Make_Change/' + Action + '/' + ContainerNumber + '/' + StatusType + '/' + Page,
        cache: false,
        type: 'PUT',
        contentType: 'application/json; charset=utf-8',
        data: {},
        dataType: 'json',
        success: function (data) {
            if (containerViewModel === null) {
                containerViewModel = ko.mapping.fromJS(data);
                ko.applyBindings(containerViewModel, document.getElementById('changer'));
            } else {
                ko.mapping.fromJS(data, containerViewModel);
            }
            $("#message").html("Setting container: " + ContainerNumber + " status to '" + Action + "' is complete.");
            $("#main-message").addClass("success");
            $("#main-message").show();
            $("#spinner").hide();
            
        },
        failure: function () {
            $(".table").show();
            $("#spinner").hide();
            $(".btn").attr("enabled", true);
        }

    });
}




