﻿$(window).scroll(function () {
    if ($(this).scrollTop() > 40) {
        $('header > div.navbar').addClass("transition");
        $('header > div.navbar').addClass("navbar-fixed-top");
        $('header > div.navbar').css("margin-top", "0");
        $('#siteHead').css('margin-bottom', '70px');
        $('#logo-small').removeClass('hidden-lg');
        $('#logo').addClass("hidden-lg");
    }
    else {
        $('header > div.navbar').addClass("transition");
        if ($(this).width() < 766) {
            $('header > div.navbar').addClass("navbar-fixed-top");
        } else {
            $('header > div.navbar').removeClass("navbar-fixed-top");
        }
        $('#siteHead').css('margin-bottom', '10px');
        $('#logo-small').addClass('hidden-lg');
        $('#logo').removeClass("hidden-lg");
    }
});
$(document).ready(function () {
    var $window = $(window);
    function checkWidth() {
        var windowsize = $window.width();
        if (windowsize < 766) {
            $('header > div.navbar').addClass("navbar-fixed-top");
        } else {
            $('header > div.navbar').removeClass("navbar-fixed-top");
        }
    }
    // Execute on load
    checkWidth();
    // Bind event listener
    $(window).resize(checkWidth);
});