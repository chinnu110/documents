﻿
using HobbyLobby.Verde;
using System;

namespace HemispheresContainers.Web.EntitySession
{
    public class UserInfoSession : EntitySessionBase<UserInfo>
    {
        public void LoadVerdeUser(VUser verdeUser)
        {
            UserInfo user = new UserInfo();
            user.IsCorporateUser = verdeUser.StoreNumber == 2000 || verdeUser.StoreNumber == 3000 ? true : false;
            user.IsAdmin = Avatar.Authorization.IsAuthorizedToElement(System.Web.HttpContext.Current.Request.LogonUserIdentity.Name, "TransportationPortal", "Cleanup Truck Scheduler", "Admin").IsAuthorized;
            user.ManagerFlag = verdeUser.ManagerFlag;
            user.District = verdeUser.District;            
            if (!user.IsCorporateUser)
            {
                user.Chain = verdeUser.Chain;
                user.StoreNumber = verdeUser.StoreNumber;
            }

            Refresh(user);
        }
    }

    [Serializable]
    public class UserInfo
    {
        public int Chain
        {
            get;
            set;
        }

        public int StoreNumber
        {
            get;
            set;
        }

        public int District
        {
            get;
            set;
        }

        public bool IsCorporateUser
        {
            get;
            set;
        }      

        public int ManagerFlag
        {
            get;
            set;
        }

        public bool IsAdmin
        {
            get;
            set;
        }
    }
}