﻿using HobbyLobby.HLUtil.Extensions;
using System;
using System.Web;

namespace HemispheresContainers.Web.EntitySession
{
        public abstract class EntitySessionBase<T>
        {
            private string _sessionName;

            public virtual string SessionName
            {
                get
                {
                    if (_sessionName.IsEmptyOrNull())
                    {
                        _sessionName = GetType().Name;
                    }

                    return _sessionName;
                }
            }

            public virtual void Refresh()
            {
                throw new NotImplementedException();
            }

            public virtual void Refresh(T value)
            {
                // Overwrites the existing entry if it already exists
                HttpContext.Current.Session.Add(SessionName, value);
            }

            public virtual T GetSession()
            {
                if (HttpContext.Current.Session[SessionName] != null)
                {
                    return (T)HttpContext.Current.Session[SessionName];
                }

                return default(T);
            }

            public virtual void Remove()
            {
                // If item does not exist, nothing will happen
                HttpContext.Current.Session.Remove(SessionName);
            }
        }
    
}