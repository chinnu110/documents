﻿using System.Web.Mvc;

namespace HemispheresContainers.Web
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HemispheresContainers.Core.ActionFilters.HemispheresContainersCaptureErrorAttribute());
//            filters.Add(new HandleErrorAttribute());
        }
    }
}