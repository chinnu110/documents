﻿using System;
using System.Web.Mvc;
using HemispheresContainers.Web.ViewModels;
using HobbyLobby.HLUtil.Logging;
using ContainerSystem.Models;
using HemispheresContainers.Core.Models;
using System.Collections.Generic;
using HobbyLobby.Reporting;
using TransportationPortal;


namespace HemispheresContainers.Web.Controllers
{

    public class StatusController : Controller
    {
        public ActionResult Index()
        {
            var containersVM = new ContainerViewModel();
            //Create_Report();
            return View("Index", containersVM);
        }
        public void Create_Report(bool refresh = false)
        {
            try
            {
                IDictionary<string, string> rParameters = null;
                string path = Server.MapPath("~/Content/CurrentReport.html");
                var refreshTime = System.IO.File.GetCreationTime(path).AddMinutes(5);
                
                if(refresh != true){
                    if ((System.IO.File.Exists(path) && DateTime.Now < refreshTime) || !System.IO.File.Exists(path))
                    {
                        refresh = true;
                    }
                }

                if (refresh == true)
                {

                    System.IO.File.Delete(path);
                    byte[] result = Report.Render("Freight Tracking by Warehouse Destination",
                                        reportServerUrl: LibConfigProperties.Settings.ReportServerUrl,
                                        reportFolder: "Distribution/Warehouse Reports",
                                        parameters: rParameters,
                                        username: LibConfigProperties.Settings.ReportServerUsername,
                                        password: LibConfigProperties.Settings.ReportServerPassword,
                                        domain: "hobbycorp",
                                        timout: 10000,
                                        reportFormat: HobbyLobby.Reporting.ReportFormat.HTML4);

                    HLLogging.Info(LibConfigProperties.Settings.ReportServerUrl);
                    HLLogging.Info(LibConfigProperties.Settings.ReportServerUsername);

                    using (System.IO.FileStream fs = System.IO.File.Create(path))
                    {
                        fs.Write(result, 0, result.Length);
                    }
                }

            }
            catch (Exception ex)
            {
                HLLogging.Error(ex.Message);
//                throw ex;
            }
        }

        public ActionResult Get_Container(string id)
        {
            var containersVM = new ContainerViewModel();
            try
            {
                containersVM.GetFiltered(id);
                if (containersVM.ContainerCount == 0)
                {
                    HLLogging.Info("Container " + id + " was not found.");
                    containersVM.Message = "Container not found.";
                    containersVM.Message_Type = "danger";
                }
            }
            catch (Exception ex)
            {
                HLLogging.Error("Get Container Function Error: " + ex);
                containersVM.Message = "An error occurred. Please try again.";
                containersVM.Message_Type = "danger";
            }
            return View("Index", containersVM);
        }


        [HttpPost]
        public ActionResult Make_Change(ContainerInputModel input)
        {
            var containersVM = new ContainerViewModel();
            try
            {
                HLLogging.Info("A '" + input.do_action + "' change has started on container " + input.container);
                containersVM.Make_Change(input.container, input.do_action, input.status_code);
            }
            catch (Exception ex)
            {
                HLLogging.Error("Change on container " + input.container + " was not made. See Error below.");
                HLLogging.Error(ex);
                containersVM.Message = "An error occurred. Please try again.";
                containersVM.Message_Type = "danger";
            }
            finally
            {
                HLLogging.Info("Change for container " + input.container + " complete");
                //Create_Report(true);
            }
            return View("Index", containersVM);
        }

    }
}
