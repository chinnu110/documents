﻿using HobbyLobby.MvcUtil;
using System;
using System.Web.Mvc;

namespace HemispheresContainers.Web.ActionFilters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public class HemispheresContainersCaptureErrorAttribute : CaptureErrorAttribute
    {
        public override void LogException(System.Web.Mvc.ExceptionContext filterContext)
        {
            HobbyLobby.HLUtil.Logging.HLLogging.Error(filterContext.Exception);
        }
    }
}

