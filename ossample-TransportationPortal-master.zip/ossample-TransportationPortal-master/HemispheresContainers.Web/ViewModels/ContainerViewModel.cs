﻿using ContainerSystem.Models;
using ContainerSystem.Service;
using HemispheresContainers.Core.Repositories;
using HobbyLobby.HLUtil.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using TransportationPortal;

namespace HemispheresContainers.Web.ViewModels
{
    public class ContainerViewModel
    {
        public StatusRepository repo = new StatusRepository();
        public List<ContainerInfo> Containers { get; set; }
        public IEnumerable<ContainerActionResult> Results { get; set; }
        public int ContainerCount { get; set; }
        public string Message { get; set; }
        public string Message_Type { get; set; }
        

        public ContainerViewModel()
        {
        }

        public void GetFiltered(string filter)
        {
            var containerInfoList = repo.Get_Filtered(filter);
            Containers = containerInfoList;
            ContainerCount = containerInfoList.Count;
        }
            
        public void Make_Change(string Container_Number, string Action_Code, string Status_Code)
        {
            Results = repo.Make_Change(Container_Number, Action_Code);
            string action = String.Empty;
            switch (Action_Code)
            {
                case "05": action = "'Arrived'"; break;
                case "06": action = "'Empty'"; break;
            }
            this.GetFiltered(Container_Number);
            // Should always be one but just in case...
            foreach (ContainerInfo item in Containers)
            {
                if (item.ContainerNumber == Container_Number)
                {
                    if (item.StatusCode == Status_Code)
                    {
                        Message =  "Container " + Container_Number + " was not updated.";
                        HLLogging.Info(Message);
                        Message_Type = "danger";
                    }
                    else
                    {
                        Message = "Container " + Container_Number + " has been updated to " + action;
                        Message_Type = "success";
                    }
                    break;
                }
            }
           
        }
    }
}