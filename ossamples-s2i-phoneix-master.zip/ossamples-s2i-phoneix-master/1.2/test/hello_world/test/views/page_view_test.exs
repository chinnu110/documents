defmodule HelloWorld.PageViewTest do
  use HelloWorld.ConnCase, async: true
end
