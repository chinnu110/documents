defmodule HelloWorld.LayoutViewTest do
  use HelloWorld.ConnCase, async: true
end