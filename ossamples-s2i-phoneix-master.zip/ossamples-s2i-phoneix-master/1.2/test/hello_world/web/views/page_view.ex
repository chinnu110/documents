defmodule HelloWorld.PageView do
  use HelloWorld.Web, :view
end
