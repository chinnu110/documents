defmodule HelloWorld.LayoutView do
  use HelloWorld.Web, :view
end
