#!/bin/bash

for host in {master,infra}0{1..3} lb01 pod0{1..2};do ssh pocos${host}.HobbyLobby.corp echo 1;done

for host in {master,infra}0{1..3} lb01 pod0{1..2};do ssh pocos${host}.HobbyLobby.corp 'echo -e "10.100.37.79 openshift-cluster.HobbyLobby.corp openshift-cluster" >> /etc/hosts';done

cp -f hosts /etc/ansible/hosts

#for host in master0{1..3} pod0{1..2}
#do
#  ssh pocos${host} "bash -s" < imagePull.sh
#done

ansible-playbook -i /etc/ansible/hosts /usr/share/ansible/openshift-ansible/playbooks/prerequisites.yml

ansible-playbook -i /etc/ansible/hosts /usr/share/ansible/openshift-ansible/playbooks/deploy_cluster.yml
