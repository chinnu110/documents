#!/bin/bash

IMAGES="""openshift3/ose-ansible
openshift3/ose-cluster-capacity
openshift3/ose-deployer
openshift3/ose-docker-builder
openshift3/ose-docker-registry
openshift3/ose-egress-http-proxy
openshift3/ose-egress-router
openshift3/ose-f5-router
openshift3/ose-haproxy-router
openshift3/ose-keepalived-ipfailover
openshift3/ose-pod
openshift3/ose-sti-builder
openshift3/ose
openshift3/container-engine
openshift3/efs-provisioner
openshift3/node
openshift3/openvswitch
rhel7/etcd
openshift3/logging-auth-proxy
openshift3/logging-curator
openshift3/logging-deployer
openshift3/logging-elasticsearch
openshift3/logging-fluentd
openshift3/logging-kibana
openshift3/metrics-cassandra
openshift3/metrics-deployer
openshift3/metrics-hawkular-metrics
openshift3/metrics-hawkular-openshift-agent
openshift3/metrics-heapster
openshift3/ose-service-catalog
openshift3/ose-ansible-service-broker
openshift3/mediawiki-apb
openshift3/postgresql-apb
openshift3/ose-web-console
openshift3/ose-template-service-broker"""

INPUT_TAG=${1:-"v3.9.14"}
REGISTRY_HOST="hlsatellite01.HobbyLobby.corp:5000"
for IMAGE in $IMAGES
do
	for TAG in $INPUT_TAG latest
	do
		docker pull ${REGISTRY_HOST}/hl-redhat-${IMAGE/\//_}:${TAG}
		docker tag ${REGISTRY_HOST}/hl-redhat-${IMAGE/\//_}:${TAG} hl-redhat-${IMAGE/\//_}:${TAG}
		docker tag ${REGISTRY_HOST}/hl-redhat-${IMAGE/\//_}:${TAG} ${IMAGE}:${TAG}
	done
done
