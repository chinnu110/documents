# OpenShift
## Installation Process
Process for installing OpenShift

## Required Files
* inventory - Master configuration file
* Files referenced in inventory
  * adv-audit.yaml - Advanced auditing configuration (required for authentication logging)
  * OSconsole.pem - Public certificate for administration console
  * OSconsole.key - Private key for administration console
