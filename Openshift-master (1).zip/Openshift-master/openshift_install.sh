seq 2 | xargs -Iz echo "--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/"
echo "INSTALLATION STARTED"
seq 2 | xargs -Iz echo "--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/"
echo "Setting up SELINUX policy on all the nodes"
ssh root@sndosmaster01 'sed -i s/^SELINUX=.*$/SELINUX=enforcing/ /etc/selinux/config && for host in Sndosinfra01 Sndosinfra02 Sndosinfra03 Sndoslb01 Sndospod01 Sndospod02 sndosmaster03 sndosmaster02 sndosmaster01 ; do scp /etc/selinux/config ${host}:/etc/selinux/; done'
seq 2 | xargs -Iz echo "--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/"
echo "SELINUX is sucessfully set to Enforcing on all the nodes"
seq 2 | xargs -Iz echo "--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/"
#REBOOTING SEQUENCE START...................
sleep 1
ssh root@sndosmaster01 'for host in Sndosinfra01 Sndosinfra02 Sndosinfra03 Sndoslb01 Sndospod01 Sndospod02 sndosmaster03 sndosmaster02 sndosmaster01; do ssh root@${host} reboot && echo rebooted;done'
sleep 1
for i in Sndosinfra01 Sndosinfra02 Sndosinfra03 Sndoslb01 Sndospod01 Sndospod02 sndosmaster03 sndosmaster02 sndosmaster01 
do
sleep 1
printf "%s" "waiting for Server to come up ..."
while ! ping -c 1 -n -w 2 ${i} &> /dev/null
do
    printf "%c" "."
done
printf "\n%s\n"  "Server is back online"
done
sleep 1
ssh root@sndosmaster01 'for host in Sndosinfra01 Sndosinfra02 Sndosinfra03 Sndoslb01 Sndospod01 Sndospod02 sndosmaster03 sndosmaster02 sndosmaster01; do ssh root@${host} hostname -f;done'
seq 2 | xargs -Iz echo "--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/"
#REBOOTING SEQUENCE END...................
echo -e "Installing required packages LIST:\nwget \ngit \nnet-tools \nbind-utils \nyum-utils \niptables-services \nbridge-utils \nbash-completion \nkexec-tools \nsos \npsacct \nopenshift-ansible \ndocker-1.13.1 "
ssh root@sndosmaster01 'for host in Sndosinfra01 Sndosinfra02 Sndosinfra03 Sndoslb01 Sndospod01 Sndospod02 sndosmaster03 sndosmaster02 sndosmaster01; do ssh  root@${host} "yum install -y wget git net-tools bind-utils yum-utils iptables-services bridge-utils bash-completion kexec-tools sos psacct openshift-ansible docker-1.13.1 && wipefs -a /dev/sdb && echo -e 'DEVS=/dev/sdb' >/etc/sysconfig/docker-storage-setup && echo -e 'VG=docker-vg' >>/etc/sysconfig/docker-storage-setup  && docker-storage-setup && systemctl enable docker && systemctl start docker"; done'
seq 2 | xargs -Iz echo "--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/"
echo -e "Sucessfully completed Installing required packages LIST:\nwget \ngit \nnet-tools \nbind-utils \nyum-utils \niptables-services \nbridge-utils \nbash-completion \nkexec-tools \nsos \npsacct \nopenshift-ansible \ndocker-1.13.1 "
#REBOOTING SEQUENCE START...................
sleep 1
ssh root@sndosmaster01 'for host in Sndosinfra01 Sndosinfra02 Sndosinfra03 Sndoslb01 Sndospod01 Sndospod02 sndosmaster03 sndosmaster02 sndosmaster01; do ssh root@${host} "reboot && echo rebooted";done'
sleep 1
for i in Sndosinfra01 Sndosinfra02 Sndosinfra03 Sndoslb01 Sndospod01 Sndospod02 sndosmaster03 sndosmaster02 sndosmaster01 
do
sleep 1
printf "%s" "waiting for Server to come up ..."
while ! ping -c 1 -n -w 2 ${i} &> /dev/null
do
    printf "%c" "."
done
printf "\n%s\n"  "Server is back online"
done
sleep 1
ssh root@sndosmaster01 'for host in Sndosinfra01 Sndosinfra02 Sndosinfra03 Sndoslb01 Sndospod01 Sndospod02 sndosmaster03 sndosmaster02 sndosmaster01; do ssh root@${host} hostname -f;done'
#REBOOTING SEQUENCE END...................
ssh root@sndosmaster01 'ssh-keyscan hlgithub.hobbylobby.corp >> githubKey && ssh-keygen -lf githubKey && cat githubKey >> ~/.ssh/known_hosts && git clone git@hlgithub.hobbylobby.corp:SystemAdmins/Openshift.git /opt/openshift/'
ssh root@sndosmaster01 'for host in sndosmaster03 sndosmaster02 sndosmaster01 ;do ssh root@${host} mkdir -p /etc/origin/master && scp root@sndosmaster01:/opt/openshift/adv-audit.yaml ${host}:/etc/origin/master/adv-audit.yaml; done'
ssh root@sndosmaster01 'for host in Sndosinfra01 Sndosinfra02 Sndosinfra03 Sndoslb01 Sndospod01 Sndospod02 sndosmaster03 sndosmaster02 sndosmaster01; do ssh root@${host} cp /etc/containers/registries.conf /etc/containers/registries.conf.bkp`date +"%m%d%Y_%H%M"`;done'
seq 2 | xargs -Iz echo "--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/"
echo "Starting Openshift prerequisites"
ssh root@sndosmaster01 'ansible-playbook -i /opt/openshift/inventory /usr/share/ansible/openshift-ansible/playbooks/prerequisites.yml && echo "Completed Openshift prerequisites" && echo "Starting Openshift Deploy" && ansible-playbook -i /opt/openshift/inventory /usr/share/ansible/openshift-ansible/playbooks/deploy_cluster.yml'
seq 2 | xargs -Iz echo "--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/--/"
ssh root@sndosmaster01 'for host in sndosmaster03 sndosmaster02 sndosmaster01; do ssh root@${host} cp /etc/origin/master/master-config.yaml /etc/origin/master/master-config.yaml.bkp`date +"%m%d%Y_%H%M"`;done'
echo -e "Openshift Enterprise is sucessfully installed. \nOpenShift Console URL: https://sndoscluster.hobbylobby.corp \n"
