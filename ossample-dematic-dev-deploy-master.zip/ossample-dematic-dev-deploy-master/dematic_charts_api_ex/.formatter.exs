# Used by "mix format"
[
  inputs: ["mix.exs", "config/*.exs"],
  subdirectories: ["apps/*"]
]
