use Mix.Config


config :libcluster,
  topologies: [
    epmd: [
      # The selected clustering strategy. Required.
      strategy: Cluster.Strategy.Epmd,
      # Configuration for the provided strategy. Optional.
      config: [hosts: [:"dematiccharts_node@deverlapp01.hobbylobby.corp", :"dematiccharts_node@deverlapp02.hobbylobby.corp"]]
    ]
  ]



