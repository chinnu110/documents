defmodule DematicChartsCore.GetTotalQueueWorker do
    use GenServer

    @name GTQW


    #####################
    ##   Client APIs   ##
    #####################

    def start_link(opts \\ []) do

        case GenServer.start_link(__MODULE__, :ok, name: {:global, :GTQW}) do
            {:ok, pid} ->
                IO.puts "get total queue worker starting unlinked"
                {:ok, pid}

            {:error, {:already_started, pid}} ->
                IO.puts "get total queue worker starting linked"
                Process.link(pid)
                {:ok, pid}
        end

    end



    #get_total_queue_data
    def handle_info(:loop, _) do

        #call Repo to get updated data
        {:ok, get_total_queue_data} = DematicChartsCore.DematicRepo.get_total_queue()
        #call state server to send updated data
        DematicChartsCore.Stateserver.update(:get_total_queue, get_total_queue_data)

        #restart the loop after a 10 second wait
        Process.send_after(self, :loop, 30000)

        {:noreply, []}

    end


    ######################
    ## Server Callbacks ##
    ######################

    def init(:ok) do
        Process.send_after(self, :loop, 100)   #loop
        {:ok, %{}}
    end

end
