defmodule DematicChartsCore.GetConsumptionRateWorker do
    use GenServer

    @name GCRW


    #####################
    ##   Client APIs   ##
    #####################

    def start_link(opts \\ []) do

        case GenServer.start_link(__MODULE__, :ok, name: {:global, :GCRW}) do
            {:ok, pid} ->
                IO.puts "get consumption rate worker starting unlinked"
                {:ok, pid}

            {:error, {:already_started, pid}} ->
                IO.puts "get consumption rate worker starting linked"
                Process.link(pid)
                {:ok, pid}
        end

    end



    def handle_info(:loop, state) do

        #call Repo to get updated data
        {:ok, get_consumption_rate_data} = DematicChartsCore.DematicRepo.get_consumption_rate(-1)

        #call state server to send updated data
        DematicChartsCore.Stateserver.update(:get_consumption_rate, get_consumption_rate_data)

        Process.send_after(self, :loop, 30000)

        {:noreply, state}

    end


    ######################
    ## Server Callbacks ##
    ######################

    def init(:ok) do
        Process.send_after(self, :loop, 2500)   #loop
        {:ok, %{}}
    end

end
