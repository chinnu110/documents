defmodule DematicChartsCore.GetProcessHistoriesWorker do
    use GenServer

    @name GPHW


    #####################
    ##   Client APIs   ##
    #####################

    def start_link(opts \\ []) do

        case GenServer.start_link(__MODULE__, :ok, name: {:global, :GPHW}) do
            {:ok, pid} ->
                IO.puts "get process histories worker starting unlinked"
                {:ok, pid}

            {:error, {:already_started, pid}} ->
                IO.puts "get process histories worker starting linked"
                Process.link(pid)
                {:ok, pid}
        end

    end


    def handle_info(:loop, _) do


        {{year, month, day}, _} = :calendar.local_time()

        #call Repo to get updated data
        {:ok, get_process_histories_data} = DematicChartsCore.DematicRepo.get_process_histories(year, month, day)
        # call state server to send updated data
        DematicChartsCore.Stateserver.update(:get_process_histories, get_process_histories_data)

        #restart the loop after a 10 second wait
        Process.send_after(self, :loop, 30000)

        {:noreply, []}

    end


    ######################
    ## Server Callbacks ##
    ######################

    def init(:ok) do
        Process.send_after(self, :loop, 2200)   #loop
        {:ok, %{}}
    end

end
