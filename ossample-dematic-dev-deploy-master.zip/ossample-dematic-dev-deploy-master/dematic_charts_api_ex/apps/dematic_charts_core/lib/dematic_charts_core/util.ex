defmodule DematicChartsCore.Util do
  def gen_processor_multi(res, struct_name) do
    cols = Enum.map(res.columns, &String.to_atom(&1))

    data =
      Enum.map(res.rows, fn row ->
        struct(struct_name, Enum.zip(cols, row))
      end)

    {:ok, data}
  end
end
