defmodule DematicChartsCore.DematicRepo do
  def get_queue() do
    with query <- "select msg_type, count(*) as num_of_msgs,
               min(created_time) as oldest, max(created_time) as newest,
               datediff(ms, min(created_time), max(created_time)) as latency
               from hst.wmsmessagequeue (nolock)
               where transmitted = 'N' group by msg_type",
         {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []) do
      results
      |> DematicChartsCore.Util.gen_processor_multi(%DematicChartsCore.QueueByMessage{})
    end
  end

  def get_total_queue() do
    with query <- "select total_messages, oldest, newest, datediff(ms, oldest, newest) as latency
               from
               (
               select count(*) as total_messages, min(created_time) as oldest, max(created_time) as newest
               from DirectorIT_Sorting.hst.wmsmessagequeue (nolock)
               where transmitted = 'N'
               ) a",
         {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []) do
      results
      |> DematicChartsCore.Util.gen_processor_multi(%DematicChartsCore.TotalQueue{})
    end
  end

  def get_process_histories(year, month, day) do
    with  query <- "select coalesce(a.timeofday, b.timeofday) as timeofday, create_count, process_count
               from
               (
               select LEFT(CONVERT(VARCHAR, created_time, 8),5) as timeofday,
               count(*) as create_count
               from DirectorIT_Sorting.hst.wmsmessagequeueLog (nolock)
               where transmitted = 'Y'
               and created_time between
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 04, 00, 01, 0 ) and
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 23, 59, 59, 0 )
               group by LEFT(CONVERT(VARCHAR, created_time, 8),5)
               ) a
               
               left join
               (
               select LEFT(CONVERT(VARCHAR, updated_time, 8),5) as timeofday,
               count(*) as process_count
               from DirectorIT_Sorting.hst.wmsmessagequeueLog (nolock)
               where transmitted = 'Y'
               and created_time between
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 04, 00, 01, 0 ) and
               DATETIMEFROMPARTS (#{year}, #{month}, #{day}, 23, 59, 59, 0 )
               group by LEFT(CONVERT(VARCHAR, updated_time, 8),5)
               ) b on a.timeofday = b.timeofday
               order by timeofday",
          {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []),
          results <- DematicChartsCore.Util.gen_processor_multi(results, %DematicChartsCore.ProcessHistory{})
           do

            add_dates(results, year, month, day)
    end
  end

  defp add_dates({:ok, results}, year, month, day) do
    #assumed that year, month, and day are strings

    results = 
    Enum.map(results, fn result -> 
      current_tod = Map.get(result, :timeofday)
      new_tod = "#{month}-#{day}-#{year} " <> current_tod

      Map.put(result, :timeofday, new_tod)
    end)

    {:ok, results}
  end

  def get_consumption_rate(last_minutes) do
    with query <-
           "select a.create_count, b.consumed_count, b.consumed_count/(iif(a.create_count = 0,1,a.create_count) * 1.00) as consumption_rate
               from
               (
               select count(*) as create_count
               from DirectorIT_Sorting.hst.wmsMessageQueueLog (nolock)
               where created_time between dateadd(mi,#{last_minutes},getdate()) and getdate()
               ) a
                
               cross join
                
               (
               select count(*) as consumed_count
               from DirectorIT_Sorting.hst.wmsMessageQueueLog (nolock)
               where updated_time between dateadd(mi,#{last_minutes},getdate()) and getdate()
               ) b",
         {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []) do
      results
      |> DematicChartsCore.Util.gen_processor_multi(%DematicChartsCore.ConsumptionRate{})
    end
  end

  def get_active_skus() do
    with query <-
           "SELECT DISTINCT LocationID, BM.SKU, BM.PO, BM.Distribution, S.ManifestID, SKUType
               FROM DirectorIT_SORTING.WCS.SupplyLocation SL
               INNER JOIN DirectorIT_SORTING.WCS.Supply S ON SL.SupplyKey = S.SupplyKey
               INNER JOIN DirectorIT_SORTING.WCS.BatchMap BM ON S.BatchKey = BM.BatchKey
               WHERE StartSKU = 'Y'",
         {:ok, results} <- DematicChartsCore.Repo.exec_sql(query, []) do
      results
      |> DematicChartsCore.Util.gen_processor_multi(%DematicChartsCore.ActiveSkus{})
    end
  end
end
