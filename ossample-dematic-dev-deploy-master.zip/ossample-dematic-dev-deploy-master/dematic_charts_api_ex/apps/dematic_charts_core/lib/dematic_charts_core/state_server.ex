defmodule DematicChartsCore.Stateserver do
    use GenServer
    require Logger

    @name SS


    #####################
    ##   Client APIs   ##
    #####################

    def start_link(opts \\ []) do

        case GenServer.start_link(__MODULE__, :ok, name: {:global, :SS}) do
            {:ok, pid} ->
                IO.puts "state server starting unlinked"
                {:ok, pid}

            {:error, {:already_started, pid}} ->
                IO.puts "state server starting linked"
                Process.link(pid)
                {:ok, pid}
        end

    end

    def get_data do
       :global.whereis_name(:SS)
       |>  GenServer.call(:read)
    end

    def update(key, newvalue) do
        :global.whereis_name(:SS)
        |> GenServer.cast({:update, key, newvalue})
    end



    #####################
    ## Server Callbacks ##
    #####################


    #read current state
    def handle_call(:read, _from, state) do
        {:reply, state, state}
    end


    #update state with new data
    def handle_cast({:update, key, newvalue}, state) do

    state = update_state(state, key, newvalue)

    {:noreply, state}
    end


    def handle_info(:loop, state) do

            case DematicChartsWebWeb.Endpoint.broadcast("channel:data", "data_updated", state)
            do
                :ok -> :ok
                {:error, reason} -> reason |> Logger.error()
            end



        Process.send_after(self, :loop, 20000)
        {:noreply, state}

    end


    def init(:ok) do
    Process.send_after(self, :loop, 7000)   #loop
    {:ok, %{}}
    end



    #####################
    ## Helper Functions ##
    #####################


    defp update_state(state, key, newvalue) do
    newstate = case Map.has_key?(state, key) do
        true ->
            Map.replace!(state, key, newvalue)
        false ->
            Map.put_new(state, key, newvalue)
    end
    newstate
    end

end
