defmodule DematicChartsCore.BoxHistory do
  defstruct "bcwh#": "",
            whname: "",
            date: "",
            put_cases: "",
            residual_cases: "",
            full_cases: "",
            total_cases_received: "",
            closed_repacks: "",
            cases_shipped: "",
            cases_sent: ""
end
