defmodule DematicChartsCore.TotalQueue do
  defstruct total_messages: "",
            oldest: "",
            newest: "",
            latency: ""
end
