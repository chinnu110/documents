defmodule DematicChartsCore do
  @moduledoc """
  Documentation for DematicChartsCore.
  """

  @doc """
  Hello world.

  ## Examples

      iex> DematicChartsCore.hello()
      :world

  """
  def hello do
    :world
  end
end
