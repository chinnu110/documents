# DematicChartsCore

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed
by adding `dematic_charts_core` to your list of dependencies in `mix.exs`:

```elixir
def deps do
  [
    {:dematic_charts_core, "~> 0.1.0"}
  ]
end
```

Documentation can be generated with [ExDoc](https://github.com/elixir-lang/ex_doc)
and published on [HexDocs](https://hexdocs.pm). Once published, the docs can
be found at [https://hexdocs.pm/dematic_charts_core](https://hexdocs.pm/dematic_charts_core).

