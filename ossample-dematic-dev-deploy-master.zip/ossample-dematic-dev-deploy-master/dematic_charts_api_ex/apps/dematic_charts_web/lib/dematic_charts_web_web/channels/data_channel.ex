defmodule DematicChartsWebWeb.DataChannel do
    use Phoenix.Channel
    require Logger
  
    def join("channel:data", _payload, socket) do
      Logger.debug("Joined Channel")
      {:ok, DematicChartsCore.Stateserver.get_data(), socket}
    end
  end