defmodule DematicChartsWebWeb.BuildingSixController do
  use DematicChartsWebWeb, :controller

  def get_consumption_rate(conn, _params) do
    case DematicChartsCore.DematicRepo.get_consumption_rate(-1) do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_queue(conn, _params) do
    case DematicChartsCore.DematicRepo.get_queue() do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_total_queue(conn, _params) do
    case DematicChartsCore.DematicRepo.get_total_queue() do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_process_histories(conn, %{"year" => year, "month" => month, "day" => day} = params) do
    case DematicChartsCore.DematicRepo.get_process_histories(year, month, day) do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_active_skus(conn, _params) do
    case DematicChartsCore.DematicRepo.get_active_skus() do
      {:ok, results} -> conn |> json(results)
      {:error, reason} -> conn |> send_error_resp(reason)
      _ -> conn |> send_error_resp("Unexpected Error.")
    end
  end

  def get_box_history(conn, %{"warehouses" => warehouses} = params) do
    # get set current date and previous year
    {{year, month, day}, _} = :calendar.local_time()
    lastyear = year - 1
    yesterday_int = day - 1

    # make sure month and day are both always 2 digits
    day = String.pad_leading("#{day}", 2, "0")
    month = String.pad_leading("#{month}", 2, "0")
    yesterday = String.pad_leading("#{yesterday_int}", 2, "0")

    # Jan 1 of last year
    from_last_year = "#{lastyear}-01-01"

    # Today's date last year
    to_last_year = "#{lastyear}-#{month}-#{day}"

    # datestring is current date
    datestring = "#{year}-#{month}-#{day}"

    # yesterdaydatestring is yesterday's date
    yesterdaydatestring = "#{year}-#{month}-#{yesterday}"

    # current month & day but previous year
    lastyeardatestring = "#{lastyear}-#{month}-#{day}"


    #Define the Today date range
    todaydaterange = Date.range(Date.from_iso8601(datestring) |> elem(1), Date.from_iso8601(datestring) |> elem(1))

    #Define the Yesterday date range
    yesterdaydaterange = Date.range(Date.from_iso8601(yesterdaydatestring) |> elem(1), Date.from_iso8601(yesterdaydatestring) |> elem(1))

    #Define the last year date range from Jan 1 to today's month & day last year
    lastyeardaterange = Date.range(Date.from_iso8601(from_last_year) |> elem(1), Date.from_iso8601(to_last_year) |> elem(1))


    #set last week date range from last week's Monday to it's following Sunday
    lastweekdaterange = Date.range(Date.from_erl(DateHelpers.monday_in_the_week_of(Timex.shift(:calendar.local_time(), weeks: -1))) |> elem(1),
                                   Date.from_erl(DateHelpers.sunday_in_the_week_of(Timex.shift(:calendar.local_time(), weeks: -1))) |> elem(1))
    

    # results handling for box history
    with {:ok, results} <-
           DematicChartsCore.HarvestRepo.get_box_history(
             from_last_year,
             datestring,
             warehouses
           ) do

      # bldg 6 shipped & induced today
      {buildingsixshippedtoday, buildingsixinducedtoday} = filter_range(results, todaydaterange, 6)

      # bldg 2 shipped & induced today 
      {buildingtwoshippedtoday, buildingtwoinducedtoday} = filter_range(results, todaydaterange, 2)

      # bldg 6 shipped & induced yesterday
      {buildingsixshippedyesterday, buildingsixinducedyesterday} = filter_range(results, yesterdaydaterange, 6)

      # bldg 2 shipped & induced yesterday 
      {buildingtwoshippedyesterday, buildingtwoinducedyesterday} = filter_range(results, yesterdaydaterange, 2)

      # bldg 6 shipped & induced last year
      {buildingsixshippedlastyear, buildingsixinducedlastyear} = filter_range(results, lastyeardaterange, 6)

      # bldg 2 shipped & induced last year
      {buildingtwoshippedlastyear, buildingtwoinducedlastyear} = filter_range(results, lastyeardaterange, 2)

      # bldg 6 shipped & induced last week
      {buildingsixshippedlastweek, buildingsixinducedlastweek} = filter_range(results, lastweekdaterange, 6)

      # bldg 2 shipped & induced last week
      {buildingtwoshippedlastlastweek, buildingtwoinducedlastweek} = filter_range(results, lastweekdaterange, 2)


      #output the gathered data
      ret = %{
        buildingSixShippedToday: buildingsixshippedtoday,
        buildingSixInducedToday: buildingsixinducedtoday,
        buildingTwoShippedToday: buildingtwoshippedtoday,
        buildingTwoInducedToday: buildingtwoinducedtoday,
        buildingSixShippedLastYear: buildingsixshippedlastyear,
        buildingSixInducedLastYear: buildingsixinducedlastyear,
        buildingTwoShippedLastYear: buildingtwoshippedlastyear,
        buildingTwoInducedLastYear: buildingtwoinducedlastyear,
        buildingSixShippedLastWeek: buildingsixshippedlastweek,
        buildingSixInducedLastWeek: buildingsixinducedlastweek,
        buildingTwoShippedLastLastWeek: buildingtwoshippedlastlastweek,
        buildingTwoInducedLastWeek: buildingtwoinducedlastweek,
        buildingSixShippedYesterday: buildingsixshippedyesterday,
        buildingSixInducedYesterday: buildingsixinducedyesterday,
        buildingTwoShippedYesterday: buildingtwoshippedyesterday,
        buildingTwoInducedYesterday: buildingtwoinducedyesterday
      }

      conn |> json(ret)
    else
      {:error, reason} -> conn |> send_error_resp(reason)
    end
  end


  def send_error_resp(conn, error) do
    conn
    |> put_resp_content_type("application/json")
    |> send_resp(500, Poison.encode!(error))
    |> halt
  end

  #function that filters and sums/reduces the gathered data
  defp filter_range(results, daterange, warehouse) do
      results
      |> Enum.filter(fn x ->
        x."bcwh#" == warehouse &&
          Enum.member?(daterange, Date.from_iso8601(x.date) |> elem(1))
      end)
      |> Enum.reduce({0, 0}, fn x, {shipped, induced} ->
        {x.cases_shipped + shipped, x.total_cases_received + induced}
      end)
  end
end

defimpl Poison.Encoder, for: [Tuple] do
  # Assumption is anything in this tuple format is an Ecto.DateTime
  def encode({{_y, _m, _d}, {_h, _min, _s, _ms}} = dt, _opts) do
    {:ok, dt} = Ecto.DateTime.load(dt)
    <<?", Ecto.DateTime.to_iso8601(dt)::binary, ?">>
  end
end