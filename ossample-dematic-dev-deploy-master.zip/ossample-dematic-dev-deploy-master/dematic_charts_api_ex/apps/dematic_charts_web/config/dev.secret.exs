use Mix.Config

config :hobbylobby_harvest_ex, :inventory,
connection_string: 'DSN=HLINVT;UID=DEMDASHSRV;PWD=DemSrv2013',
db_type: :db2

config :dematic_charts_core, DematicChartsCore.Repo,
adapter: MssqlEcto,
database: "DirectorIT_Sorting",
username: "DematicChartsUser",
password: "jIFkCG&!X@eUcI1V",
hostname: "Hldmb6sql01",
instance_name: "MSSQLSERVER",
port: "1433",
pool_size: 2,
odbc_driver: "{ODBC Driver 17 for SQL Server}"
