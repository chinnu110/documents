import { get_active_skus } from "./activeskus";
import { get_consumption_rate } from "./consumptionrate";
import { get_process_histories } from "./processhistory";
import { get_queue } from "./queue";
import { get_total_queue } from "./totalqueue";
import { get_box_history } from "./boxhistory";

export class Data {
    get_active_skus: get_active_skus[] = [];
    get_box_history: get_box_history;
    get_consumption_rate: get_consumption_rate[] = [];
    get_process_histories: get_process_histories[] = [];
    get_queue: get_queue[] = [];
    get_total_queue: get_total_queue[] = [];
}