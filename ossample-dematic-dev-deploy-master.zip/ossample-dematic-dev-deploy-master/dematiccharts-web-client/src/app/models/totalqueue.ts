export class get_total_queue {
    latency: number;
    newest: string;
    oldest: string;
    total_messages: number;
}