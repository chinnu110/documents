export class get_box_history {
    buildingSixInducedLastWeek: number;
    buildingSixInducedLastYear: number;
    buildingSixInducedToday: number;
    buildingSixInducedYesterday: number;
    buildingSixShippedLastWeek: number;
    buildingSixShippedLastYear: number;
    buildingSixShippedToday: number;
    buildingSixShippedYesterday: number;
    buildingTwoInducedLastWeek: number;
    buildingTwoInducedLastYear: number;
    buildingTwoInducedToday: number;
    buildingTwoInducedYesterday: number;
    buildingTwoShippedLastLastWeek: number;
    buildingTwoShippedLastYear: number;
    buildingTwoShippedToday: number;
    buildingTwoShippedYesterday: number;
}