export class View {
    create_count: number;
    process_count: number;
    timeofday: string;
}