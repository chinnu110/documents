import { Injectable } from '@angular/core';
import { Socket, Channel } from 'phoenix';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SocketService {

  private socket: Socket = undefined;
  private channel: Channel;

  constructor() { }

  public initConnection() {
    this.socket = new Socket(environment.socketUrl, {});
    this.socket.connect();
  }

  public connected() {
    if (this.socket) {
      return this.channel.socket.isConnected();
    }
    else return false;
  }

  public join(func): Channel {
    this.initConnection();
    this.channel = this.socket.channel('channel:data');
    this.channel.join()
      .receive('ok', resp => {
        console.log('joined the room: channel', resp);
        func(resp);
      })
      .receive('error', reason => console.error('join failed', reason));
    return this.channel;
  }

  public getChannel(func): Channel {
    if (!this.channel) {
      return this.join(func);
    }
    this.channel.leave();
    return this.join(func);

  }

  public onUpdate(callback: (resp) => any) {
    this.channel.on('data_updated', (resp) => console.log(resp));
    this.channel.on('data_updated', callback);
  }
}
