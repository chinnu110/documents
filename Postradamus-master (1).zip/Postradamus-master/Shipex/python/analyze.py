import logging
import sys
import os.path
import os
import getopt
import pandas as pd
import json
import requests
import numpy as np
import pyodbc
from datetime import datetime, timedelta
from logging.handlers import TimedRotatingFileHandler
from keras.models import load_model


def unhandled_exception_handler(_type, value, _tb):
    logger.exception("Uncaught exception: {0}".format(str(value)))


log_dir = './logs/'
log_file = 'analyze-predictions-' + datetime.today().strftime("%Y-%m-%d") + '.log'
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

format = '%(asctime)s - %(levelname)s - %(message)s'
formatter = logging.Formatter(format)

logging.basicConfig(
    format=format,
    datefmt='%m/%d/%Y %I:%M:%S %p',
    level=logging.DEBUG
)

logger = logging.getLogger(__name__)
# logging.getLogger("urllib3").setLevel(logging.WARNING)
handler = TimedRotatingFileHandler(log_dir + log_file, when="d", interval=1, backupCount=5)
handler.setLevel(logging.DEBUG)
handler.setFormatter(formatter)
logger.addHandler(handler)
sys.excepthook = unhandled_exception_handler


def parse_date(date_string):
    try:
        new_date = datetime.strptime(date_string, '%m/%d/%Y')
    except ValueError:
        try:
            new_date = datetime.strptime(date_string, '%m-%d-%Y')
        except ValueError:
            new_date = None

    return new_date


def get_shipping_data(start_date, end_date):
    """Gets Shipping data from HLShipper"""

    logger.debug('get_shipping_data :: retrieving data')

    server = 'tcp:hlsqlapp12.hobbylobby.corp'
    database = 'HLShipper'
    connection_string = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER=_server_;' \
                        'DATABASE=_database_;' \
                        'Trusted_Connection=yes;'
    connection_string = connection_string.replace('_server_', server)
    connection_string = connection_string.replace('_database_', database)

    cnxn = pyodbc.connect(connection_string)
    sql = "SELECT s.Msn, s.Ship_Dttm, s.Total_Charges, s.Shipper_Reference, sp.TrackingNumber_1, " \
          "sp.TrackingNumber_2, " \
          "sp.Height as height, sp.Width as width, sp.Length as length, sp.Weight as weight, c.Carrier_Name, " \
          "se.Service_Id, se.Service_Symbol, " \
          "na.contact as recipient_contact, na.company as recipient_company, na.address1 as recipient_address, " \
          "na.city as recipient_city, na.state_province as recipient_state, " \
          "CASE " \
          "WHEN CHARINDEX('-',na.postal_code) > 0 THEN LEFT(na.postal_code,CHARINDEX('-',na.postal_code)-1) " \
          "WHEN LEN(na.postal_code) > 5 THEN LEFT(na.postal_code,5) " \
          "WHEN CHARINDEX('-',na.postal_code) = 0 THEN na.postal_code " \
          "END as recipient_postal, na.country_symbol as recipient_country, " \
          "shna.contact as origin_contact, shna.company as origin_company, shna.address1 as origin_address, " \
          "shna.city as origin_city, shna.state_province as origin_state, " \
          "CASE " \
          "WHEN CHARINDEX('-',shna.postal_code) > 0 THEN LEFT(shna.postal_code,CHARINDEX('-',shna.postal_code)-1) " \
          "WHEN LEN(shna.postal_code) > 5 THEN LEFT(shna.postal_code,5) " \
          "WHEN CHARINDEX('-',shna.postal_code) = 0 THEN shna.postal_code " \
          "END as origin_postal, shna.country_symbol as origin_country " \
          "FROM [ara].[Shipment] as s " \
          "LEFT JOIN [ara].[Shipment_Package] as sp on s.Msn = sp.Msn " \
          "LEFT JOIN [ara].[Name_Address] as na on s.Name_Address_Id = na.id " \
          "LEFT JOIN [dbo].[Service] as se on s.Service_Id = se.Service_Id " \
          "LEFT JOIN [dbo].[Carrier] as c on se.Carrier_Id = c.Carrier_Id " \
          "LEFT JOIN [dbo].[Shipper] as sh on s.Shipper_Id = sh.Shipper_Id " \
          "LEFT JOIN [ara].[Name_Address] as shna on sh.Name_Address_Id = shna.id " \
          "WHERE s.Is_Voided_Flag = 0 " \
          "AND s.Shipped_By_User_Id = 'panda' " \
          "AND se.Service_Symbol in ('CONNECTSHIP_ENDICIA.USPS.PRIORITY','FEX.SMART_POST','FEX.FEDEX_GROUND') " \
          "AND s.Ship_Dttm > 'start_date' " \
          "AND s.Ship_Dttm <= 'end_date' " \
          "ORDER BY s.Msn DESC;"

    sql = sql.replace('start_date', start_date)
    sql = sql.replace('end_date', end_date)

    df = pd.read_sql(sql, cnxn)

    logger.debug('get_shipping_data :: Records(' + str(len(df)) + ')')

    return df


def rate_shipex(shipment):
    url = "http://hlerlapp01/shipex/api/rate/test-rate"
    headers = {"Content-Type": "application/json"}

    d = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
    ship_date = d.strftime("%m-%d-%Y")
    origin_person = shipment["origin_contact"]
    origin_company = shipment["origin_company"]
    origin_address = shipment["origin_address"]
    origin_city = shipment["origin_city"]
    origin_state = shipment["origin_state"]
    origin_country = shipment["origin_country"]
    origin_zip = shipment["origin_postal"]
    recipient_person = shipment["recipient_contact"]
    recipient_company = shipment["recipient_company"]
    recipient_address = shipment["recipient_address"]
    recipient_city = shipment["recipient_city"]
    recipient_state = shipment["recipient_state"]
    recipient_country = shipment["recipient_country"]
    recipient_zip = shipment["recipient_postal"]
    width = shipment["width"]
    length = shipment["length"]
    height = shipment["height"]
    weight = str(shipment["weight"])

    data = {
              "services": [
                "USPS:PRIORITY",
                "FEX:SMART_POST",
                "FEX:FEDEX_GROUND"
              ],
              "ship_date": ship_date,
              "shipper": {
                "person_name": origin_person,
                "company": origin_company,
                "address": [
                  origin_address,
                  "",
                  ""
                ],
                "city": origin_city,
                "state_or_province_code": origin_state,
                "country_code": origin_country,
                "phone_number": "",
                "postal_code": origin_zip,
                "residential": ""
              },
              "extended_shipper_properties": {
                "shipper_symbol": "SHL",
                "third_party": False,
                "bill_to_account": "SHL"
              },
              "origin": {
                "person_name": origin_person,
                "company": "Hobby Lobby",
                "address": [
                  origin_address,
                  "",
                  ""
                ],
                "city": origin_city,
                "state_or_province_code": origin_state,
                "country_code": origin_country,
                "phone_number": "",
                "postal_code": origin_zip,
                "residential": ""
              },
              "recipient": {
                "person_name": recipient_person,
                "company": recipient_company,
                "address": [
                  recipient_address,
                  ""
                ],
                "city": recipient_city,
                "state_or_province_code": recipient_state,
                "country_code": recipient_country,
                "phone_number": None,
                "postal_code": recipient_zip,
                "residential": True
              },
              "package_type": "YOUR_PACKAGING",
              "packages": [
                {
                  "sequence": 1,
                  "insured_value": None,
                  "signature_option": None,
                  "dimensions": {
                    "length": length,
                    "height": height,
                    "width": width
                  },
                  "weight": weight,
                  "shipper_reference": "test",
                  "contents": {
                    "quantity": 1,
                    "description": "Craft Supplies",
                    "value": 0.0
                  }
                }
              ],
              "saturday_delivery": None,
              "return_shipment": None
            }
    resp = requests.post(url, headers=headers, data=json.dumps(data))
    return resp.json()


def read_zipcode_distances():
    logger.debug('read_zipcode_distances :: getting zipcode data')

    with open('zip_code_distances.json', 'r') as f:
        zip_code_dict = json.load(f)

    df = pd.DataFrame.from_dict(zip_code_dict, orient='columns')

    logger.debug('read_zipcode_distances :: Records(' + str(len(df)) + ')')

    return df


def get_service_str(service_id):
    if service_id == 0:
        return 'CONNECTSHIP_ENDICIA.USPS.PRIORITY'
    elif service_id == 1:
        return 'FEX.SMART_POST'
    elif service_id == 2:
        return 'FEX.FEDEX_GROUND'


def get_service_id(service_str):
    if service_str == 'CONNECTSHIP_ENDICIA.USPS.PRIORITY':
        return 0
    elif service_str == 'FEX.SMART_POST':
        return 1
    elif service_str == 'FEX.FEDEX_GROUND':
        return 2


def analyze(model, data_df, zip_code_df, package_count):
    wrong = 0
    right = 0
    bad_zip = 0
    total_wrong_amount = 0.0
    count = 0
    data_df = data_df.sample(n=package_count)
    logger.info("Analyzing " + str(len(data_df)) + " records")

    for index, row in data_df.iterrows():
        zipcode = zip_code_df[zip_code_df.zip_2 == row['recipient_postal']]
        if len(zipcode) > 0:
            df_x = pd.DataFrame({
                'height': row['height'],
                'width': row['width'],
                'length': row['length'],
                'weight': row['weight'],
                'distance': zipcode.iloc[0]['distance']
            }, index=[0])

            p = model.predict(df_x)[0]
            pm = np.argmax(p)
            val = get_service_id(row['Service_Symbol'])

            if pm != val:
                wrong += 1
                rs = rate_shipex(row)
                g = rs["data"]
                predicted_amount = 0.0
                shipped_amount = 0.0
                for d in g:
                    if d["service"] == "PRIORITY" and pm == 0:
                        predicted_amount = d["total_charges"]
                    if d["service"] == "PRIORITY" and val == 0:
                        shipped_amount = d["total_charges"]
                    if d["service"] == "SMART_POST" and pm == 1:
                        predicted_amount = d["total_charges"]
                    if d["service"] == "SMART_POST" and val == 1:
                        shipped_amount = d["total_charges"]
                    if d["service"] == "FEDEX_GROUND" and pm == 2:
                        predicted_amount = d["total_charges"]
                    if d["service"] == "FEDEX_GROUND" and val == 2:
                        shipped_amount = d["total_charges"]

                wrong_amount = predicted_amount - shipped_amount
                total_wrong_amount += wrong_amount

                count += 1
                if count % 10 == 0:
                    logger.debug("=============")
                    logger.debug("Count: " + str(count))
                    logger.debug("Wrong: " + str(total_wrong_amount))
                    logger.debug("=============")

            else:
                right += 1
        else:
            bad_zip += 1

    logger.debug("        Right = " + str(right))
    logger.debug("        Wrong = " + str(wrong))
    logger.debug(" Wrong Amount = " + str(total_wrong_amount))
    logger.debug("Bad Zip Codes = " + str(bad_zip))


def main(argv):
    usage = '\n\nusage: analyze.py \n' \
            '    -e : environment to use; ex. dev/test/prod, default: prod \n' \
            '    -s : start date; ex. ''6/25/2018'' \n' \
            '    -n : end date; ex. ''6/25/2018'' \n' \
            '    -c : package count; ex. ''-c 80'' \n'

    environment = 'prod'
    start = (datetime.today() - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    end = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
    package_count = 10

    try:
        opts, args = getopt.getopt(argv, 'e:s:n:c:h', ['env=', 'start=', 'end=', 'count=', 'help'])
    except getopt.GetoptError:
        logger.error(usage)
        sys.exit(2)

    for opt, arg in opts:
        if opt == '-h':
            logger.info(usage)
            sys.exit()
        elif opt in ('-e', '--env'):
            environment = arg.lower()
        elif opt in ('-s', '--start'):
            start = parse_date(arg)
            if start is None:
                logger.error('Start date not a date')
                logger.error(usage)
                sys.exit()
        elif opt in ('-n', '--end'):
            end = parse_date(arg)
            if end is None:
                logger.error('End date not a date')
                logger.error(usage)
                sys.exit()
        elif opt in ('-c', '--count'):
            try:
                package_count = int(arg)
            except ValueError:
                logger.error('Package Count is not a number.')
                logger.error(usage)
                sys.exit(-1)

    logger.info("main :: start")
    logger.info('main :: Environment = ' + environment)
    logger.info('main ::       Start = ' + start.strftime("%m-%d-%Y"))
    logger.info('main ::         End = ' + end.strftime("%m-%d-%Y"))

    shipment_df = get_shipping_data(
        start_date=start.strftime("%m-%d-%Y %H:%M:%S")
        , end_date=end.strftime("%m-%d-%Y %H:%M:%S")
    )
    zip_codes = read_zipcode_distances()

    model_file_h5 = 'rating_pred.h5'

    if os.path.isfile(model_file_h5):
        model = load_model(model_file_h5)
    else:
        logger.error("Model (" + model_file_h5 + ") does not exist.")
        sys.exit()

    analyze(model, shipment_df, zip_codes, package_count)


if __name__ == '__main__':
    main(sys.argv[1:])
