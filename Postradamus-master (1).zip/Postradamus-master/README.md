# Postradamus
**Projects for Machine Learning around Shipping**


### [Shipex Project](Shipex/)  
