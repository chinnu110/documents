# Hana_Cleaner RPM Build

## Description
Builds an RPM to deploy the hanacleaner script.
Includes:
* Wrapper script that sets host:port, username, and password in hdbuserstore
* Configuration file with flags for the script
* Cron file to run script weekly at 7am on Sundays
* The hanacleaner.py script itself

## Instructions
1. Ensure build host has the RPM build packages installed: rpm-build, rpmdevtools, rpmlint
1. Clone this repo to build host
1. cd into the repo directory
1. Run the command `rpmbuild -bb rpmbuild/SPECS/hanacleaner.spec`
