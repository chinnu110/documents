#!/bin/bash

# Wrapper script for HANA Cleaner
# Elliott - 6/17/2019
# 

. $HOME/.sapenv.sh

echo "Starting the Hana Cleaner..."
CLNR_USER="HANACLEANER1"
CLNR_PWD="H4n4Cl34n"
SYSTEM_PORT=30013
TENANT_PORT=30041
HOSTNAME=`hostname -s`


hdbuserstore -i set SYSTEMCLEAN ${HOSTNAME}:${SYSTEM_PORT} ${CLNR_USER} ${CLNR_PWD}
hdbuserstore -i set TENANTCLEAN ${HOSTNAME}:${TENANT_PORT} ${CLNR_USER} ${CLNR_PWD}
python hanacleaner.py -ff hanacleaner_configfile
