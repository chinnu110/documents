defmodule Order.Producer do
  use GenStage
  require Logger

  def start_link do
    GenStage.start_link(__MODULE__, :ok, name: __MODULE__)
  end

  ## Callbacks

  def init(:ok) do
    {:producer, []}
  end

  def handle_demand(demand, events) when demand > 0 do
    Logger.debug(demand)
    case events do
      [] ->
        {:noreply, [], events}
      _ ->
        request =  Enum.slice(events, 0, demand)
        events = Enum.slice(events,demand,length(events) - demand)
        IO.inspect request
        IO.inspect events
        {:noreply, request, events}

    end

  end

  def add(events), do: GenServer.cast(__MODULE__, {:add, events})

  def handle_cast({:add, events}, state) when is_list(events) do
    {:noreply, events, state}
  end
  def handle_cast({:add, events}, state), do: {:noreply, [events], state}



end
