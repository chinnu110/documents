defmodule Order.QueueReader do
  use GenServer
  import Common.Util
  import Common.Configuration
  require Logger
  def start_link() do
    GenServer.start_link(__MODULE__, %{on: true})
  end

  def init(state) do
    schedule_work()
    {:ok, state}
  end

  def handle_info(:work, state) do
    # Do the desired work here
    schedule_work() # Reschedule once more
    {:noreply, state}
  end

  defp schedule_work() do
    case ExAws.SQS.receive_message("#{get_account_number()}/#{get_order_request_queue()}",[attribute_names: :all])
         |>ExAws.request([access_key_id: get_access_key_id(),
                          secret_access_key: get_secret_key(),
                          region: get_region()])
                          |> IO.inspect() do
     {:ok, %{body: %{messages: []}}} ->
         Logger.debug("All Messages have been read for now")
         Process.send_after(self(), :work, 2 * 60 * 1000)
     {:ok, %{body: %{messages: messages}}}  ->
         Enum.map(messages,fn msg ->
         QueueBroadcaster.sync_notify(msg)
         end)
         Process.send_after(self(), :work, 5000)
      _ ->
        Logger.debug("Hmmmmm")

      end
    end
end
