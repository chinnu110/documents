defmodule Order.Export do
  import Common.Configuration
  require Logger

  def start_link(%{message_id: _message_id, receipt_handle: receipt_handle, body: body} = _message) do
    Task.start_link(fn ->
      process_receive(body)
      |> IO.inspect
      |> send_response
      delete_message(receipt_handle)
    end)
  end

  def process_receive(message) do
    deserialize_request(message)
    |> WebOrderProcessCore.save_order()
    |> serialize_response()
  end

  def deserialize_request(body) do
    Base.decode64!(body)
      |>Common.Util.decrypt(Common.Util.hash_password(get_key(),get_salt()), get_iv())
      |>Base.decode64!()
      |>:zlib.gunzip()
      |>Poison.decode!()
  end

  defp send_response(message) do
    ExAws.SQS.send_message("#{Common.Configuration.get_account_number()}/#{Common.Configuration.get_order_response_queue()}", message,[attribute_names: :all])
    |> ExAws.request([access_key_id: get_access_key_id(),
                    secret_access_key: get_secret_key(),
                    region: get_region()])
  end

  defp delete_message(receipt_handle) do
    ExAws.SQS.delete_message(get_order_request_queue(), receipt_handle)
    |> ExAws.request([access_key_id: get_access_key_id(),
    secret_access_key: get_secret_key(),
    region: get_region()])
  end

  defp serialize_response(data) do
    Poison.encode!(data)
    |>:zlib.gzip()
    |>Base.encode64()
    |>Common.Util.encrypt(Common.Util.hash_password(get_key(),get_salt()), get_iv())
    |>Base.encode64()
  end
end
