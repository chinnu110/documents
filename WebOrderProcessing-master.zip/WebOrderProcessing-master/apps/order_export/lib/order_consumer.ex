defmodule Order.Consumer do
  use ConsumerSupervisor

  def start_link() do
    ConsumerSupervisor.start_link(__MODULE__,[])
  end

  def init(_) do
    children = [
      worker(Order.Export, [], restart: :temporary, start: {Order.Export, :start_link, []},id: Order.Export)


    ]
    opts = [strategy: :one_for_one,  subscribe_to: [{QueueBroadcaster, max_demand: 9}]]
    ConsumerSupervisor.init(children, opts)
  end
end
