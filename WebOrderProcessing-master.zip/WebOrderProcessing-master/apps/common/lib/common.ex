defmodule Common do
  @moduledoc """
  Documentation for Common.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Common.hello
      :world

  """
  def hello do
    :world
  end
end
