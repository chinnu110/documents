defmodule Common.Order do
    defstruct(
      order_info: nil,
      shipping_info: nil,
      totals_info: nil,
      consignments: []
    )

    def parse(json) do
      %Common.Order{
        order_info: Common.OrderInfo.parse(json["orderInfo"]),
        shipping_info: Common.ShippingInfo.parse(json["shippingInfo"]),
        totals_info: Common.TotalsInfo.parse(json["totalsInfo"]),
        consignments: json["consignments"] |> Enum.map(fn consignment ->
          consignment
          |> Common.Order.Consignment.parse()

        end)
      }
    end
end
