defmodule Common.Util do
  @key_size 16

  def hash_password(password,salt) do
    Plug.Crypto.KeyGenerator.generate(password, salt, [iterations: 65536, length: @key_size, digest: :sha])
  end

  def encrypt(data,password, iv) do
    padded_data = data
    |> add_padding(@key_size)
    :crypto.block_encrypt :aes_cbc128, password, iv, padded_data
  end

  def decrypt(data, key, iv) do
    :crypto.block_decrypt(:aes_cbc128, key, iv, data)
    |> remove_padding()
  end

  def send_message(message, queue, secret, id) do

  end

  def order_export_recv_message() do
   ExAws.SQS.receive_message(order_export_queue())
   |> request(order_export_secrets())
  end

  defp request(operation,[access_key_id: access_key_id, secret_access_key: secret_access_key, region: region]) do
    operation
    |> ExAws.request(access_key_id: access_key_id,
    secret_access_key: secret_access_key ,
    region: region)
  end

  def order_export_delete_message(%{receipt_handle: receipt_handle}) do
    ExAws.SQS.delete_message(order_export_queue(), receipt_handle)
    |> request(order_export_secrets())
  end

  defp order_export_queue() do
    "696221319119/sqs_devhlhyb60_orderExport"
  end

  defp order_export_secrets() do
    [access_key_id: "AKIAJGZ2YVHA5ATE4RLQ",secret_access_key: "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", region: "us-east-1"]
  end

  defp add_padding(data,key_size) do
    pad_val = key_size - rem(byte_size(data),key_size)
    data <> :binary.copy(<<pad_val>>,pad_val)
  end

  defp remove_padding(data) do
    size_of_data = byte_size(data)
    :binary.part(data,0, size_of_data - :binary.last(data))
  end
end
