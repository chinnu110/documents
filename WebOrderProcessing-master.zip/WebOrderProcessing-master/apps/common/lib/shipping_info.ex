defmodule Common.ShippingInfo do
  defstruct(
    shipping_address: nil,
    shipping_method: 0,
    shipping_service: nil
  )

  def parse(json) do
    %Common.ShippingInfo{
      shipping_address: Common.Address.parse(json),
      shipping_method: json["shippingMethod"],
      shipping_service: json["shippingService"]
    }
  end


end
