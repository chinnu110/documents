defmodule Common.Address do
  defstruct(
     first_name: nil,
     last_name: nil,
     middle_initial: nil,
     company: nil,
     address1: nil,
     address2: nil,
     is_po_box: false,
     city: nil,
     state: nil,
     region: nil,
     country: nil,
     zipcode: nil,
     phone_number: nil
  )

  def parse(json) do
    %Common.Address{
      first_name: json["firstName"],
      last_name: json["lastName"],
      middle_initial: json["middleInitial"],
      company: json["company"],
      address1: json["address1"],
      address2: json["address2"],
      is_po_box: json["isPoBox"],
      city: json["city"],
      state: json["state"],
      region: json["region"],
      country: json["country"],
      zipcode: json["zipcode"],
      phone_number: json["phoneNumber"]
    }
    |>validate()
  end

  defp validate(address) do
    if !(address.first_name > "") do
      throw "first name is required"
    end
    if !(address.last_name > "") do
      throw "last name is required"
    end
    if !(address.address1 > "") do
      throw "address1 is required"
    end
    if !(address.city > "") do
      throw "city is required"
    end
    if !(address.state > "") do
      throw "state is required"
    end
    if !(address.zipcode > "") do
      throw "zipcode is required"
    end
    if !(address.country > "") do
      throw "country is required"
    end
    address
  end

end
