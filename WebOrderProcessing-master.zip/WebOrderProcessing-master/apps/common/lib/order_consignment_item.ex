defmodule Common.Order.Consignment.Item do
  import Common.Property.Validate

  defstruct(
     sku: nil,
     quantity: 0,
     item_price: 0.0,
     line_price: 0.0,
     line_number: 0.0,
     discount_amount: 0.0,
     discount_type: nil,
     is_ormd: false,
     shipping_surcharge: 0.0,
     item_pk: 0
  )
  def parse(json) do
      %Common.Order.Consignment.Item{
        sku: json["sku"],
        quantity: json["quantity"],
        item_price: json["itemPrice"],
        line_price: json["linePrice"],
        line_number: json["lineNumber"],
        discount_amount: json["discountAmount"],
        discount_type: json["discountType"],
        is_ormd: json["isOrmd"],
        shipping_surcharge: json["shippingSurcharge"],
        item_pk: json["itemPk"]
      }
      |> validate()
  end

  defp validate(%Common.Order.Consignment.Item{} = item) do
    require_property(item.sku, "sku",:sku)
    require_property(item.quantity, "quantity", :number)
    require_property(item.item_price, "item_price", :number)
    require_property(item.line_price, "line price", :number)
    require_property(item.discount_amount, "discount amount", :number)

    item
  end
end
