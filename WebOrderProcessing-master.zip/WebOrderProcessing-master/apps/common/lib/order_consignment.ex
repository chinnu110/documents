defmodule Common.Order.Consignment do
  import Common.Property.Validate
  defstruct(
     order_number: "",
     items: [],
     has_ormd_items: false,
     consignment_number: nil,
     consigment_type: nil
  )
  def parse(json) do
    %Common.Order.Consignment{order_number: json["orderNumber"],
    items: json["items"] |>Enum.map(fn item ->
      Common.Order.Consignment.Item.parse(item)
    end),
    has_ormd_items: json["hasOrmdItems"],
    consignment_number: json["consignmentNumber"],
    consigment_type: json["consignmentType"]
   }
   |> validate()
  end


  defp validate(%Common.Order.Consignment{} = consignment) do
    require_property(consignment.order_number, "order number", :order_number)
    consignment
  end

  def hold_order_shipment_type(shiptment_method) do
    case shiptment_method do
      "Employee" ->
        "D"
      "Expedited" ->
        "Q"
      _ ->
        ""
    end
  end
end
