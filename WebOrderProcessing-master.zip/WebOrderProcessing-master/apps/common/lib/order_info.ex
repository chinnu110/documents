defmodule Common.OrderInfo do
  import Common.Property.Validate

  defstruct(
    address_info: nil,
    order_number: nil,
    customer_number: 0,
    is_gift: false,
    to: nil,
    from: nil,
    notes: nil,
    gift_notes1: nil,
    gift_notes2: nil,
    reference_number: nil,
    email_address: nil
  )

  def parse(json) do
    %Common.OrderInfo{
      address_info: Common.Address.parse(json),
      order_number: json["orderNumber"],
      customer_number: json["customerNumber"],
      is_gift: json["isGift"],
      to: json["to"],
      from: json["from"],
      notes: json["notes"],
      gift_notes1: json["giftNotes1"],
      gift_notes2: json["giftNotes2"],
      reference_number: json["referenceNumber"],
      email_address: json["emailAddress"]
    }
    |> validate()
  end

  defp validate(%Common.OrderInfo{} = order_info) do
    require_property(order_info.order_number, "order_number", :order_number)
    require_property(order_info.customer_number, "customer number", :number)
    require_property(order_info.email_address, "email address", :email_address)

    order_info
  end
end
