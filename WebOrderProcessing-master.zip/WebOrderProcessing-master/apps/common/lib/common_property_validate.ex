defmodule Common.Property.Validate  do
  def require_property(term, property, :number) do
    if !(is_number(term)) do
      throw("#{property} is required")
    end
  end

  def require_property(term, _property, :order_number) do
    if !(Regex.match?(~r/(^\d{1,8}$)/, term)) do
      throw("Order number is invalid.")
    end
  end

  def require_property(term, property, _exepected_term_type) do
    if !(term > "") do
      throw("#{property} is required")
    end
  end
end
