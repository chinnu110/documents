defmodule Common.TotalsInfo do
  import Common.Property.Validate

  defstruct(
    base_subtotal: 0.0,
    discount: 0.0,
    subtotal: 0.0,
    shipping: 0.0,
    tax: 0.0,
    auth_id: nil,
    total: 0.0,
    order_date: nil,
    ship_comments: nil,
    giftcard_total: 0.0
  )

  def parse(json) do
    %Common.TotalsInfo{
      base_subtotal: json["baseSubtotal"],
      discount: json["discount"],
      subtotal: json["subtotal"],
      shipping: json["shipping"],
      tax: json["tax"],
      auth_id: json["authId"],
      total: json["total"],
      order_date: json["orderDate"],
      ship_comments: json["shipComments"],
      giftcard_total: json["giftCardTotal"]
    } |> validate()
  end

  defp validate(%Common.TotalsInfo{} = totals) do
    require_property(totals.base_subtotal,"base_subtotal", :number)
    require_property(totals.discount,"discount", :number)
    require_property(totals.subtotal,"subtotal" , :number)
    require_property(totals.shipping,"shipping" , :number)
    require_property(totals.tax,"tax", :number)
    require_property(totals.total,"total" , :number)
    require_property(totals.order_date,"order_date", :date)

    totals
  end



end
