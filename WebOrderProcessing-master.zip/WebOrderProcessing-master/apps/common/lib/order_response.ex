defmodule Common.OrderResponse do
  defstruct(
     order_number: 0,
     status: 0,
     message: 0
  )
end
