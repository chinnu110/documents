defmodule Common.Configuration do
  def get_active_chain() do
    Application.get_env(:common, :chain)
  end

  def get_key() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:crypto]["key"]
  end

  def get_salt() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:crypto]["salt"]
  end

  def get_iv() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:crypto]["iv"]
  end

  def get_capture_request_queue() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:aws_queues]["capture_request"]
  end

  def get_capture_response_queue() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:aws_queues]["capture_response"]
  end

  def get_order_request_queue() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:aws_queues]["order_request"]
  end

  def get_order_response_queue() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:aws_queues]["order_response"]
  end

  def get_account_number() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:aws_credentials]["account_number"]
  end

  def get_access_key_id() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:aws_credentials]["access_key_id"]
  end

  def get_secret_key() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:aws_credentials]["secret_access_key"]
  end

  def get_region() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:aws_credentials]["region"]
  end

  def get_db() do
    chain = get_active_chain()
    Application.get_env(:common, chain)[:db]["connection"]
  end

  def get_db_collection() do
    chain=get_active_chain()
    Application.get_env(:common, chain)[:db]["collection"]
  end
end
