defmodule Common.Payment.PaymentCaptureRequest do
  defstruct(
    OrderNumber: 0,
    SettlementAmount: 0.00
  )

  def parse(request) do
    %Common.Payment.PaymentCaptureRequest{
      OrderNumber: request["orderNumber"],
      SettlementAmount: parse_amount(request["settlementAmount"])
    }
  end

  defp parse_amount(amount) do
    Float.parse(amount)
  end
end
