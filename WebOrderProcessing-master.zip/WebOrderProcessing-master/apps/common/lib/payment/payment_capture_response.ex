defmodule Common.Payment.PaymentCaptureResponse do
  defstruct(
    order_number: 0,
    status: "",
    status_message: ""
  )

  def parse(request) do
    %Common.Payment.PaymentCaptureResponse{
      order_number: request["orderNumber"],
      status: parse_status(request["status"]),
      status_message: request["statusMessage"]
    }
  end

  defp parse_status(status) do
    (String.downcase(status) == "success") && "S" || "F"
  end
end
