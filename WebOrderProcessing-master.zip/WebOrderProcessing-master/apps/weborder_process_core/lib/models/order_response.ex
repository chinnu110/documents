defmodule Order.Response do
  defstruct(
      status_code: 0,
      status_message: ""
  )
end
