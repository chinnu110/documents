defmodule WebOrderProcessCore do
  @moduledoc """
  Documentation for WebOrderProcessCore.
  """

  def save_order(json) do
    order = Common.Order.parse(json)

    giftcard_totals = Enum.find(order.consignments,%Common.Order.Consignment{}, fn consignment ->
      consignment.consigment_type == "GiftCard"
    end)
    |> Map.get(:items)
    |> Enum.reduce({0 , 0}, fn item ,{gc_total, gc_surcharge} ->
      {gc_total + item.line_price,gc_surcharge + item.shipping_surcharge}
    end)

    status = order.consignments
    |> Enum.map(fn consignment ->
      with {:ok, _, _} <- save_consignment(order,consignment,giftcard_totals)
      do
        Enum.map(consignment.items, fn item ->
          save_item(consignment, item)
        end)
        %{"OrderStatus" => "OK"}
      else
        err ->
          %{"OrderStatus" => "ERROR"}
      end
    end)
    case Enum.any?(status, fn(s) ->
      s["OrderStatus"] != "OK"
    end) do
      true ->
        %{"OrderNumber" => order.order_info.order_number, "Status" => "ERROR", "Message" => "Cannot create or edit order"}
      _ ->
        %{"OrderNumber" => order.order_info.order_number, "Status" => "OK", "Message" => ""}
    end
  end

  defp save_consignment(order,%Common.Order.Consignment{consigment_type: "GiftCard" } = consignment, {gc_total, gc_surcharge} = _giftcard_totals) do
    Core.Gift.Order.Repository.insert_order(order,consignment,false, gc_total,gc_surcharge)
  end

  defp save_consignment(order, consignment, {gc_total, gc_surcharge} = _giftcard_totals) do
    Core.Merchandise.Order.Repository.insert_order(order,consignment,false,gc_total, gc_surcharge)
  end
  defp save_item(%Common.Order.Consignment{order_number: cart_number, consigment_type: "GiftCard"}, item) do
    Core.Gift.Order.Repository.insert_cart(cart_number, item)
  end

  defp save_item(%Common.Order.Consignment{order_number: cart_number}, item) do
    Core.Merchandise.Order.Repository.insert_cart(cart_number, item)
  end

  #defp save_imprint(%{Common.Order.Consignment{order_number: cart_number}, imprint) do
  #  Core.Merchandise.Order.Repository.insert_imprint(cart_number, imprint)
  #end

  def get_order_status(cart_number) do
    case [get_merch_status(cart_number), get_gift_status(cart_number)]
    |> IO.inspect
    |> Enum.filter(fn({status, message}) -> status != 0 end)
    |> Enum.any?() do
      true ->
        %{"OrderNumber" => cart_number, "Status" => "ERROR", "Message" => "Cannot edit order" }
      false ->
        %{"OrderNumber" => cart_number, "Status" => "OK", "Message" => ""}
    end
  end

  defp get_merch_status(cart_number) do
    {_, _, status} = Core.Merchandise.Order.Repository.get_status(cart_number)
    status |> Enum.at(0)
  end

  defp get_gift_status(cart_number) do
    {_, _, status} = Core.Gift.Order.Repository.get_status(cart_number)
    status |> Enum.at(0)
  end

  def cancel(cart_number) do
    case [cancel_merch(cart_number), cancel_gift(cart_number)]
    |> IO.inspect
    |> Enum.filter(fn({status, message}) -> status != 0 end)
    |> Enum.any?() do
      true ->
        %{"OrderNumber" => cart_number, "Status" => "ERROR", "Message" => "Cannot edit or cancel order" }
      false ->
        %{"OrderNumber" => cart_number, "Status" => "OK", "Message" => ""}
    end
  end

  defp cancel_merch(cart_number) do
    {_, _, status} = Core.Merchandise.Order.Repository.cancel(cart_number)
    status |> Enum.at(0)
  end

  defp cancel_gift(cart_number) do
    {_, _, status} = Core.Gift.Order.Repository.cancel(cart_number)
    status |> Enum.at(0)
  end
end
