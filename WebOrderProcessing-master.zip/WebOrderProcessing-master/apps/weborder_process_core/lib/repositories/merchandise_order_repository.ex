defmodule Core.Merchandise.Order.Repository do
  import HobbylobbyHarvestEx.Param
  import Common.Configuration

  def insert_order(%Common.Order{} = %Common.Order{order_info: order_info,  shipping_info: shipping_info, totals_info: totals_info}, consignment, has_ormd_items, gc_total \\ 0, gc_surcharge \\ 0 ) do
    params = [
      #CTCART
      add_parameter(:sql_numeric,8,0,:in,order_info.order_number),
      #CTORD
      add_parameter(:sql_numeric,5,0,:in,0),
      #CTCST
      add_parameter(:sql_numeric,6,0,:in,0),
      #CTAN8
      add_parameter(:sql_numeric,8,0,:in,9999),
      #CTSNAMF
      add_parameter(:sql_char,20,:in,order_info.address_info.first_name),
      #CTSNAMI
      add_parameter(:sql_char,1,:in,order_info.address_info.middle_initial |> default_when_nil()),
      #CTSNAML
      add_parameter(:sql_char,20,:in,order_info.address_info.last_name),
      #CTSNAM
      add_parameter(:sql_char,30,:in," "),
      #CTSCOMP
      add_parameter(:sql_char,40,:in,order_info.address_info.company |> default_when_nil()),
      #CTADD1
      add_parameter(:sql_char,40,:in,order_info.address_info.address1),
      #CTADD2
      add_parameter(:sql_char,40,:in,order_info.address_info.address2 |> default_when_nil()),
      #CTCITY
      add_parameter(:sql_char,25,:in,order_info.address_info.city),
      #CTSTAT
      add_parameter(:sql_char,2,:in,order_info.address_info.state),
      #CTZIP
      add_parameter(:sql_char,10,:in,order_info.address_info.zipcode),
      #CTCNTRY
      add_parameter(:sql_char,4,:in,order_info.address_info.country),
      #CTREGN
      add_parameter(:sql_char,25,:in,order_info.address_info.region),
      #CTSPNAMF
      add_parameter(:sql_char,20,:in,shipping_info.shipping_address.first_name),
      #CTSPNAMI
      add_parameter(:sql_char,1,:in,shipping_info.shipping_address.middle_initial |> default_when_nil()),
      #CTSPNAML
      add_parameter(:sql_char,20,:in,shipping_info.shipping_address.last_name),
      #CTSPNAM
      add_parameter(:sql_char,30,:in," "),
      #CTSPCOMP
      add_parameter(:sql_char,40,:in,shipping_info.shipping_address.company |> default_when_nil()),#CTMGD
      #CTSPADD1
      add_parameter(:sql_char,40,:in,shipping_info.shipping_address.address1),
      #CTSPADD2
      add_parameter(:sql_char,40,:in,shipping_info.shipping_address.address2),
      #CTSPCITY
      add_parameter(:sql_char,25,:in,shipping_info.shipping_address.city),
      #CTSPSTAT
      add_parameter(:sql_char,2,:in,shipping_info.shipping_address.state),
      #CTSPZIP
      add_parameter(:sql_char,10,:in,shipping_info.shipping_address.zipcode),
      #CTSPCNTRY
      add_parameter(:sql_char,4,:in,shipping_info.shipping_address.country),
      #CTSPREGN
      add_parameter(:sql_char,25,:in,shipping_info.shipping_address.region),
      #CTAUTH
      add_parameter(:sql_char,12,:in,totals_info.auth_id),
      #CTSHPMTHD
      add_parameter(:sql_char,10,:in,shipping_info.shipping_method),
      #CTPHONE
      add_parameter(:sql_char,20,:in,order_info.address_info.phone_number),
      #CTEMAIL
      add_parameter(:sql_char,50,:in,order_info.email_address),
      #CTGIFT
      add_parameter(:sql_char,1,:in,order_info.is_gift|> to_string() |> String.upcase() |> String.slice(0,1)),
      #CTGIFTFRM
      add_parameter(:sql_char,30,:in,order_info.from |> default_when_nil()),
      #CTGIFTTO
      add_parameter(:sql_char,30,:in,order_info.to |> default_when_nil()),
      #CTMIS1
      add_parameter(:sql_char,90,:in,order_info.gift_notes1 |> default_when_nil()),
      #CTMIS2
      add_parameter(:sql_char,30,:in,order_info.gift_notes2 |> default_when_nil()),
      #CTMIS3
      add_parameter(:sql_char,30,:in,order_info.notes |> default_when_nil()),
      #CTORDGRS
      add_parameter(:sql_numeric,8,2,:in,totals_info.total),
      #CTORDDSC
      add_parameter(:sql_numeric,8,2,:in,totals_info.discount),
      #CTORDDSCP
      add_parameter(:sql_numeric,5,2,:in,0),
      #CTORDNET
      add_parameter(:sql_numeric,8,2,:in,totals_info.base_subtotal),
      #CTORDSHP
      add_parameter(:sql_numeric,8,2,:in,totals_info.shipping),
      #CTORDTAX
      add_parameter(:sql_numeric,8,2,:in,totals_info.tax),
      #CTTAXRATE
      add_parameter(:sql_numeric,8,4,:in,0),
      #CTGFTAMT1
      add_parameter(:sql_numeric,6,2,:in,totals_info.giftcard_total),
      #CTORDINV
      add_parameter(:sql_numeric,8,2,:in,0),
      #CTRCVDAT
      add_parameter(:sql_char,10,:in,(Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(0,10))),
      #CTRCVTIM
      add_parameter(:sql_char,8,:in,(Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(11,8))),
      #CTSENTHL
      add_parameter(:sql_char,1,:in," "),
      #CTHLORD
      add_parameter(:sql_numeric,5,0,:in,0),
      #CTINVDAT
      add_parameter(:sql_char,10,:in,(Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(0,10))),
      #CTINVTIM
      add_parameter(:sql_char,8,:in,(Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(11,8))),
      #CTORDSTS
      add_parameter(:sql_char,1,:in," "),
      #CTCONSIGN
      add_parameter(:sql_char,15,:in,consignment.consignment_number),
      #CTSPPOBOX
      add_parameter(:sql_char,1,:in,shipping_info.shipping_address.is_po_box |> to_string() |> String.upcase() |> String.slice(0,1)),
      #CTSHPSVC
      add_parameter(:sql_char,50,:in,shipping_info.shipping_service),
      #CTHOLDSHP
      add_parameter(:sql_char,1,:in,(Common.Order.Consignment.hold_order_shipment_type(shipping_info.shipping_method))),
      #CTORMD
      add_parameter(:sql_char,1,:in,(if (has_ormd_items), do: "Y", else: "")),
      #CTORDGC$
      add_parameter(:sql_numeric,8,2,:in,gc_total),
      #CTORDFEE$
      add_parameter(:sql_numeric,8,2,:in,gc_surcharge),
      #CTREF#
      add_parameter(:sql_numeric,10,0,:in,(if (order_info.reference_number == "" || order_info.reference_number == nil), do: "0", else: order_info.reference_number)),
      add_parameter(:sql_integer ,:out,0),
      add_parameter(:sql_char,100 ,:out," ")
    ]
    |>IO.inspect()

    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "#{get_db_collection()}.USP_HYBRIS_UPSERT_MERCH_ORDER",
            params,
            Order.Response,
            get_db()
    )
    |> IO.inspect()
  end
  def insert_cart(cart_number, %Common.Order.Consignment.Item{} = item) do
    params = [
      add_parameter(:sql_numeric,8,0,:in, cart_number), #@COCART
      add_parameter(:sql_numeric,11,0,:in, item.sku), #@COITEM
      add_parameter(:sql_numeric,5,0,:in, 0), #@COORD
      add_parameter(:sql_numeric,3,0,:in,item.line_number), #@COLINE
      add_parameter(:sql_numeric,5,0,:in,item.quantity), #@COOQTY
      add_parameter(:sql_numeric,7,2,:in,item.line_price), #@COLIST
      add_parameter(:sql_numeric,7,2,:in,item.item_price), #@COSALE
      add_parameter(:sql_numeric,7,2,:in,item.discount_amount), #@COIMDISC
      add_parameter(:sql_char,1, :in,(if (item.discount_type == nil or item.discount_type == ""), do: " ", else: item.discount_type )), #COPROMO
      add_parameter(:sql_numeric,13,0 ,:in, item.item_pk), #ITEM_PK
      add_parameter(:sql_integer ,:out,0),
      add_parameter(:sql_char,100 ,:out," ")
    ]
    |> IO.inspect()

    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "#{get_db_collection()}.USP_HYBRIS_UPSERT_MERCH_CART",
            params,
            Order.Response,
            get_db()
    )
    |> IO.inspect()
  end

  def save_payment_response(payment_capture_response) do
    params = [
      add_parameter(:sql_numeric, 8, 9, :in, payment_capture_response.order_number),
      add_parameter(:sql_char, 1, :in, payment_capture_response.status)
    ]

    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "#{get_db_collection()}.USP_HYBRIS_UPDATE_CAPTURE_STATUS",
      params,
      get_db()
    )

  end

  def get_status(cart_number) do
    params = [
      add_parameter(:sql_numeric,8,0,:in, cart_number), #CART
      add_parameter(:sql_integer,:out, 0), #@STATUS_CODE
      add_parameter(:sql_char,100, :out, " "), #@STATUS_MESSAGE
    ]

    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "#{get_db_collection()}.USP_HYBRIS_MERCH_ORDER_STATUS",
            params,
            Order.Response,
            get_db()
    )
  end

  def cancel(cart_number) do
    params = [
      #CART_NUM
      add_parameter(:sql_numeric,8,0,:in, cart_number),
      #CLOSED_BY
      add_parameter(:sql_char, 10, :in, "hybris"),
      #CLOSED_DATE
      add_parameter(:sql_char,10,:in,(Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(0,10))),
      #CLOSED_TIME
      add_parameter(:sql_char,8,:in,(Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(11,8))),
      #STATUS_CODE
      add_parameter(:sql_integer,:out, 0),
      #STATUS_MESSAGE
      add_parameter(:sql_char,100, :out, " "),
    ]

    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "#{get_db_collection()}.USP_HYBRIS_CANCEL_MERCH",
            params,
            Order.Response,
            get_db()
    )
  end
end
