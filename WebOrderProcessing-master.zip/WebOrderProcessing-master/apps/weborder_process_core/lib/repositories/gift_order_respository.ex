defmodule Core.Gift.Order.Repository do
  import HobbylobbyHarvestEx.Param
  import Common.Configuration

  def insert_order(%Common.Order{} = %Common.Order{order_info: order_info,  shipping_info: shipping_info, totals_info: totals_info}, consignment, _has_ormd_items, gc_total \\ 0, gc_surcharge \\ 0 ) do
    params = [
      # @CART_NUM
      add_parameter(:sql_char, 10, :in, order_info.order_number),
      # @CUST_NUM
      add_parameter(:sql_integer, :in, 9999),
      # @B_FNAME
      add_parameter(:sql_char, 20, :in, order_info.address_info.first_name),
      # @B_LNAME
      add_parameter(:sql_char, 20, :in, order_info.address_info.last_name),
      # @B_COMPANY
      add_parameter(:sql_char, 40, :in, order_info.address_info.company |> default_when_nil()),
      # @B_ADDRESS1
      add_parameter(:sql_char, 30, :in, order_info.address_info.address1),
      # @B_ADDRESS2
      add_parameter(:sql_char, 30, :in, order_info.address_info.address2),
      # @B_CITY
      add_parameter(:sql_char, 25, :in, order_info.address_info.city),
      # @B_STATE
      add_parameter(:sql_char, 2, :in, order_info.address_info.state),
      # @B_ZIP
      add_parameter(:sql_char, 10, :in, order_info.address_info.zipcode),
      # @B_COUNTRY
      add_parameter(:sql_char, 20, :in, order_info.address_info.country),
      # @B_REGION
      add_parameter(:sql_char, 25, :in, order_info.address_info.region),
      # @B_PHONE
      add_parameter(:sql_char, 20, :in, order_info.address_info.phone_number),
      # @B_EMAIL
      add_parameter(:sql_char, 50, :in, order_info.email_address),
      # @S_FNAME
      add_parameter(:sql_char, 20, :in, shipping_info.shipping_address.first_name),
      # @S_LNAME
      add_parameter(:sql_char, 20, :in, shipping_info.shipping_address.last_name),
      # @S_COMPANY
      add_parameter(:sql_char, 40, :in, shipping_info.shipping_address.company |> default_when_nil()),
      # @S_ADDRESS1
      add_parameter(:sql_char, 30, :in, shipping_info.shipping_address.address1),
      # @S_ADDRESS2
      add_parameter(:sql_char, 30, :in, shipping_info.shipping_address.address2),
      # @S_CITY
      add_parameter(:sql_char, 25, :in, shipping_info.shipping_address.city),
      # @S_STATE
      add_parameter(:sql_char, 2, :in, shipping_info.shipping_address.state),
      # @S_ZIP
      add_parameter(:sql_char, 10, :in, shipping_info.shipping_address.zipcode),
      # @S_COUNTRY
      add_parameter(:sql_char, 20, :in, shipping_info.shipping_address.country),
      # @S_REGION
      add_parameter(:sql_char, 25, :in, shipping_info.shipping_address.region),
      # @S_PHONE
      add_parameter(:sql_char, 20, :in, shipping_info.shipping_address.phone_number),
      # @AUTH_ID
      add_parameter(:sql_char, 12, :in, totals_info.auth_id),
      # @SHP_METHOD
      add_parameter(:sql_char, 20, :in, shipping_info.shipping_method),
      # @GIFT_FLAG
      add_parameter(:sql_char, 1, :in, order_info.is_gift |> to_string() |> String.upcase() |> String.at(0)),
      # @GIFT_FROM
      add_parameter(:sql_char, 30, :in, order_info.from |> default_when_nil()),
      # @GIFT_TO
      add_parameter(:sql_char, 30, :in, order_info.to |> default_when_nil()),
      # @GIFT_MSG_1
      add_parameter(:sql_char, 255, :in, order_info.notes |> default_when_nil()),
      # @GIFT_MSG_2
      add_parameter(:sql_char, 255, :in,order_info.gift_notes1 |> default_when_nil() ),
      # @GIFT_MSG_3
      add_parameter(:sql_char, 30, :in, order_info.gift_notes2 |> default_when_nil()),
      # @TOTAL
      add_parameter(:sql_numeric, 8, 2,:in, gc_total + gc_surcharge),
      # @DISCOUNT
      add_parameter(:sql_numeric, 8, 2, :in, 0),
      # @SUBTOTAL
      add_parameter(:sql_numeric,  8, 2, :in,  gc_total),
      # @TOTAL_SHIP
      add_parameter(:sql_numeric,  8, 2, :in, gc_surcharge),
      # @TOTAL_TAX
      add_parameter(:sql_numeric, 8, 2, :in, 0),
      # @TAX_RATE
      add_parameter(:sql_numeric, 8, 4, :in,  0),
      # @OPENED_BY
      add_parameter(:sql_char, 30, :in, "hybris"),
      # @RECV_DATE
      add_parameter(:sql_char, 10, :in, (Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(0,10))),
      # @RECV_TIME
      add_parameter(:sql_char, 8, :in, (Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(11,8))),
      # @CTCONSIGN
      add_parameter(:sql_char, 15, :in, consignment.consignment_number),
      # @CTREF#
      add_parameter(:sql_char, 10, :in, order_info.reference_number),
      # @STATUS_CODE
      add_parameter(:sql_integer, :out, 0),
      # @STATUS_MESSAGE
      add_parameter(:sql_char, 100, :out, "")
    ]
    |> IO.inspect()

    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "#{get_db_collection()}.USP_HYBRIS_UPSERT_GC_ORDER",
            params,
            Order.Response,
            get_db()
    )
    |> IO.inspect()
  end

  def insert_cart(cart_number, %Common.Order.Consignment.Item{} = item) do
    params = [
      add_parameter(:sql_char,10,:in, cart_number), #@CART_NUM
      add_parameter(:sql_char, 11,:in, item.sku), #@ITEM_NUM
      add_parameter(:sql_integer,:in,item.quantity), #@QUANTITY
      add_parameter(:sql_numeric, 7,2, :in, item.item_price), #@AMOUNT
      add_parameter(:sql_numeric, 7,2,:in, item.line_price), #@TOTAL
      add_parameter(:sql_numeric,13,0 ,:in, item.item_pk), #ITEM_PK
      add_parameter(:sql_integer,:out, 0), #@STATUS_CODE
      add_parameter(:sql_char,100, :out, " "), #@STATUS_MESSAGE
    ]
    |> IO.inspect()

    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "#{get_db_collection()}.USP_HYBRIS_UPSERT_GC_CART",
            params,
            Order.Response,
            get_db()
    )
    |> IO.inspect()
  end

  def get_status(cart_number) do
    params = [
      add_parameter(:sql_char,10,:in, cart_number), #@CART_NUM
      add_parameter(:sql_integer,:out, 0), #@STATUS_CODE
      add_parameter(:sql_char,100, :out, " "), #@STATUS_MESSAGE
    ]

    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "#{get_db_collection()}.USP_HYBRIS_GC_ORDER_STATUS",
            params,
            Order.Response,
            get_db()
    )
  end

  def cancel(cart_number) do
    params = [
      #CART_NUM
      add_parameter(:sql_numeric,8,0,:in, cart_number),
      #CLOSED_BY
      add_parameter(:sql_char, 10, :in, "hybris"),
      #CLOSED_DATE
      add_parameter(:sql_char,10,:in,(Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(0,10))),
      #CLOSED_TIME
      add_parameter(:sql_char,8,:in,(Timex.now("America/Chicago") |> DateTime.to_string |> String.slice(0,19) |> String.slice(11,8))),
      #STATUS_CODE
      add_parameter(:sql_integer,:out, 0),
      #STATUS_MESSAGE
      add_parameter(:sql_char,100, :out, " "),
    ]

    HobbylobbyHarvestEx.QueryProxy.exec_procedure(
      "#{get_db_collection()}.USP_HYBRIS_CANCEL_GC",
            params,
            Order.Response,
            get_db()
    )
  end
end
