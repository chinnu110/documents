defmodule WebOrderProcessCore.Application do
  import Common.Configuration
  # See https://hexdocs.pm/elixir/Application.html
  # for more information on OTP Applications
  @moduledoc false

  use Application


  def start(_type, _args) do
    import Supervisor.Spec
    # List all child processes to be supervised
    connection = get_db()
    connection_pool_config = [
      {:name, {:local, connection}},
      {:worker_module, HobbylobbyHarvestEx.ConnectionPoolWorker},
      {:size, 2},
      {:max_overflow, 1}
    ]
    children = [
      :poolboy.child_spec(connection, connection_pool_config, connection)
    ]

    # See https://hexdocs.pm/elixir/Supervisor.html
    # for other strategies and supported options
    opts = [strategy: :one_for_one, name: WebOrderProcessCore.Supervisor]
    Supervisor.start_link(children, opts)
  end
end
