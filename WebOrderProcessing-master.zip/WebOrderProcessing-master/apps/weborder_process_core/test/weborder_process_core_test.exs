defmodule WebOrderProcessCoreTest do
  use ExUnit.Case
  doctest WebOrderProcessCore

  test "greets the world" do
    assert WebOrderProcessCore.hello() == :world
  end
end
