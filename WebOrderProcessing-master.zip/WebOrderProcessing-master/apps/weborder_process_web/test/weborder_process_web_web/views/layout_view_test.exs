defmodule WebOrderProcessWebWeb.LayoutViewTest do
  use WebOrderProcessWebWeb.ConnCase, async: true
end
