defmodule WebOrderProcessWebWeb.PageViewTest do
  use WebOrderProcessWebWeb.ConnCase, async: true
end
