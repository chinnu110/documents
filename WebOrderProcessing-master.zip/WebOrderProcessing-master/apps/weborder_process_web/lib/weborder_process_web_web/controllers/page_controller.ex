defmodule WebOrderProcessWebWeb.PageController do
  use WebOrderProcessWebWeb, :controller

  def index(conn, _params) do
    render conn, "index.html"
  end
end
