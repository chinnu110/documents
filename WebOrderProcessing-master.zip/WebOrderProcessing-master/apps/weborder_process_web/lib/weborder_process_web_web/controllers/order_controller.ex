defmodule WebOrderProcessWebWeb.OrderController do
  use WebOrderProcessWebWeb, :controller

  def insert(conn, %{"_json" => orders} = _params) do
    json(conn, process_orders(orders, []) |> ProperCase.to_camel_case)
  end

  defp process_orders([] = _orders, responses)  do
    responses
  end

  defp process_orders(orders, responses) do
    order = orders |> Enum.at(0) |> ProperCase.to_camel_case

    #TODO - use GenStage?
    response = WebOrderProcessCore.save_order(order)
    responses = responses ++ [response]
    [_ | remaining_orders] = orders
    process_orders(remaining_orders, responses)
  end

  def cancel(conn, %{"order_number" => cart_number} = _params) do
    cancel_status = WebOrderProcessCore.cancel(cart_number)
    json(conn, cancel_status)
  end

  def status(conn, %{"order_number" => cart_number} = _params) do
    status = WebOrderProcessCore.get_order_status(cart_number)
    json(conn, status)
  end
end
