defmodule WebOrderProcessWebWeb.PaymentCaptureController do
  use WebOrderProcessWebWeb, :controller

  def capture(conn, %{"order_number" => order_number, "settlement_amount" => settlement_amount} =  _params) do
    %Common.Payment.PaymentCaptureRequest{OrderNumber: order_number, SettlementAmount: settlement_amount}
    |> PaymentCapture.build_message
    |> PaymentCapture.send_request
    |> IO.inspect

    json(conn, "Show me the money!")
  end
end
