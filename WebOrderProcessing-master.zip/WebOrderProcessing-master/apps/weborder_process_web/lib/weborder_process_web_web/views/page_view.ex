defmodule WebOrderProcessWebWeb.PageView do
  use WebOrderProcessWebWeb, :view
end
