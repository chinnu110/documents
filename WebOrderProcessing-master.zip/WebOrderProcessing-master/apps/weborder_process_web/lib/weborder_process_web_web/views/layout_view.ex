defmodule WebOrderProcessWebWeb.LayoutView do
  use WebOrderProcessWebWeb, :view
end
