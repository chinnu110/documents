defmodule WebOrderProcessWebWeb.Router do
  use WebOrderProcessWebWeb, :router

  pipeline :browser do
    plug :accepts, ["html"]
    plug :fetch_session
    plug :fetch_flash
    plug :protect_from_forgery
    plug :put_secure_browser_headers
  end

  pipeline :api do
    plug :accepts, ["json"]
    plug ProperCase.Plug.SnakeCaseParams
  end

  scope "/", WebOrderProcessWebWeb do
    pipe_through :browser # Use the default browser stack

    get "/", PageController, :index
  end

  # Other scopes may use custom stacks.
  scope "/api", WebOrderProcessWebWeb do
     pipe_through :api
     post "/payment/capture", PaymentCaptureController, :capture
     post "/orders/insert", OrderController, :insert
     post "/orders/cancel", OrderController, :cancel
     post "/orders/status", OrderController, :status
  end
end
