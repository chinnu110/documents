defmodule PaymentCaptureConsumer do
  use ConsumerSupervisor

  def start_link() do
    ConsumerSupervisor.start_link(__MODULE__,[])
  end

  def init(_) do
    children = [
      worker(PaymentCaptureWorker, [], restart: :temporary,
      start: {PaymentCaptureWorker, :start_link, []},id: PaymentCaptureWorker)
    ]
    opts = [strategy: :one_for_one,  subscribe_to: [{PaymentCaptureBroadcaster, max_demand: 9}]]
    ConsumerSupervisor.init(children, opts)
  end
end
