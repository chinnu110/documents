defmodule PaymentCapture do
  import Common.Configuration

  def build_message(payment_request) do
    Poison.encode!(payment_request)
    #|> Macro.camelize
    |>:zlib.gzip()
    |>Base.encode64()
    |>Common.Util.encrypt(Common.Util.hash_password(get_key(),get_salt()),get_iv())
    |>Base.encode64()
  end

  def send_request(message) do
    ExAws.SQS.send_message("#{Common.Configuration.get_account_number()}/#{Common.Configuration.get_capture_request_queue()}", message,[attribute_names: :all])
    |> IO.inspect
         |>ExAws.request([access_key_id: get_access_key_id(),
                          secret_access_key: get_secret_key(),
                          region: get_region()])
  end

  def start_stage() do
    PaymentCaptureBroadcaster.start_link
    PaymentCaptureConsumer.start_link
    PaymentCaptureQueueReader.start_link
  end

  def start_order_stage() do
    QueueBroadcaster.start_link()
    Order.Consumer.start_link()
    Order.QueueReader.start_link()
  end
end
