defmodule PaymentCaptureWorker do
  import Common.Configuration
  require Logger

  def start_link(%{message_id: _message_id, receipt_handle: receipt_handle, body: body} = _message) do
    Task.start_link(fn ->
      Logger.info("Starting Payment Capture Worker process...")
      case process_receive(body) |> IO.inspect do
        {:ok, _} ->
          delete_message(receipt_handle)
        _ ->
          Logger.error("Something went awry!!")
      end
    end)
  end

  defp delete_message(receipt_handle) do
    ExAws.SQS.delete_message(get_capture_response_queue(), receipt_handle)
    |> ExAws.request([access_key_id: get_access_key_id(),
    secret_access_key: get_secret_key(),
    region: get_region()])
  end

  #m99XJvcYQgGRc/FDqN7ZdT8VOcyadgAI29uHDD0y0g7cg8BVAbFnnzcYVu2xUlU+ZiINWggNXYkodV1O8EPQgfZqa8nJc10qyD2sIem010Jk7V+f3rf2EUPpEcGSAsZuK8k5zctWPnbcvd3rStyTMEiX7+lHd+LLpexLjYIi+871Aw29ZMdSIDz02Po01cW8mWEUNBkirKXS3aHmqt0xqA==
  def process_receive(message) do
    deserialize_request(message)
    |> save_response()
    #|> serialize_response()
  end

  defp save_response(json) do
    Common.Payment.PaymentCaptureResponse.parse(json)
    |> Core.Merchandise.Order.Repository.save_payment_response
  end

  defp deserialize_request(body) do
    Base.decode64!(body)
      |>Common.Util.decrypt(Common.Util.hash_password(get_key(),get_salt()),get_iv())
      |>Base.decode64!()
      |>:zlib.gunzip()
      |>Poison.decode!()
  end

  defp serialize_response(data) do
    Poison.encode!(data)
    |>:zlib.gzip()
    |>Base.encode64()
    |>Common.Util.encrypt(Common.Util.hash_password(get_key(),get_salt()),get_iv())
    |>Base.encode64()
  end
end
