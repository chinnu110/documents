defmodule PaymentCaptureTest do
  use ExUnit.Case
  doctest PaymentCapture

  test "greets the world" do
    assert PaymentCapture.hello() == :world
  end
end
